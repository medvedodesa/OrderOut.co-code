#!/bin/sh
#
# thibault@orderout.co
#
# 03/31/2019
#

# ng serve
dev_appserver.py app.yaml --host=0.0.0.0 --log_level=debug --enable_host_checking=false
