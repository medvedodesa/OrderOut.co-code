WITH Docker
Please install the Docker desktop for the Mac.
After you may run the following commands in order to run Admin as it is dockerized.

make build
make run

WITHOUT Docker
We require a node.
       Can you please tell me which version you have for the node if you have installed already?
       Please type node -v command in terminal to get installed node version.
  2. If the node does not install, then
          please run the following commands (We are installing nvm - node version manager)
         a)  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.35.3/install.sh | bash
         b)  Close the terminal and open terminal again
         c)  Let's verify that nvm installed or not by this command nvm --version  NOTE: It should give output 0.35.3
         d) nvm install 10.21.0 Please run this command to install node
3) Please check the node and npm version
    node -v = 10.21.0
    npm -v = 6.14.4



# Local Environement setup
- git checkout develop
- npm install
- ./0_start_development_server.sh

# Visual Code Extensions
- tslint https://marketplace.visualstudio.com/items?itemName=ms-vscode.vscode-typescript-tslint-plugin

# Websites / BLogs / Tutorial used as inspiration

- Angular Material: https://material.angular.io/guide/getting-started
- Auth0: https://auth0.com/docs/quickstart/spa/angular2#create-an-authentication-service
- Good Practice: https://medium.freecodecamp.org/best-practices-for-a-clean-and-performant-angular-application-288e7b39eb6f
- Observales: https://blog.angularindepth.com/the-best-way-to-unsubscribe-rxjs-observable-in-the-angular-applications-d8f9aa42f6a0

- https://auth0.com/blog/creating-beautiful-apps-with-angular-material/

# TODO:
- Auth0 - During loging, console error with endpoints /user/ssodata
