export interface ConfirmationDialogOptions {
    message?: {
        name: string;
        type: string;
    };
    customMessage?: string;
    text?: string;
    type?: string;
    title?: string;
    note?: string;
}