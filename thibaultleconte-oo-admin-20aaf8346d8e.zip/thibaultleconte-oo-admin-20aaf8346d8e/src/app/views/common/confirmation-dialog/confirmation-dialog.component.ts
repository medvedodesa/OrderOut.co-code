import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { FormControl, FormGroup, Validators, ValidatorFn, AbstractControl } from '@angular/forms';

@Component({
  selector: 'app-confirmation-dialog',
  templateUrl: './confirmation-dialog.component.html',
  styleUrls: ['./confirmation-dialog.component.scss']
})
export class ConfirmationDialogComponent implements OnInit {

  public delConfirm: FormGroup;
  public esiConfirm: FormGroup;

  public confirmMessage: string = 'Are you sure want to delete?';
  public customMessage: string; // DO NOT SET VALUE. It will break the title of confirmation dialog
  public confirmText: string = 'DELETE';
  public title: string = 'Are you sure?';
  public note: string = 'set message here!';

  public dialogType: string = 'del-confirm';

  constructor(public dialogRef: MatDialogRef<ConfirmationDialogComponent>) { }

  ngOnInit() {
    this.delConfirm = new FormGroup({
      confirmText: new FormControl('', [Validators.required, this.isValidConfirmText()]),
    });

    this.esiConfirm = new FormGroup({
      recipientEmail: new FormControl('', [Validators.required, Validators.email]),
    });
  }

  setConfirmMessage(name: string, type: string) {
    this.confirmMessage = 'Are you sure want to delete <b>' + name + '</b> ' + type + '?';
  }

  setCustomMessage(message: string) {
    this.customMessage = message;
  }

  setConfirmText(text: string) {
    this.confirmText = text;
  }

  setDialogType(type: string) {
    this.dialogType = type;
  }

  setDialogTitle(title: string) {
    this.title = title;
  }

  setDialogNote(note: string) {
    this.note = note;
  }

  isValidConfirmText(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: boolean } | null => {
      if (control.value !== undefined && control.value === this.confirmText) {
        return null;
      }
      return { 'confirmText': true };
    };
  }

}
