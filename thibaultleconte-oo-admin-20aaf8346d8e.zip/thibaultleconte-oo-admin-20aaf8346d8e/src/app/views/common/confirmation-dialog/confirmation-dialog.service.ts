import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MatDialog, MatDialogRef } from '@angular/material';

import { ConfirmationDialogOptions } from './confirmation-dialog';
import { ConfirmationDialogComponent } from './confirmation-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class ConfirmationDialogService {

  public dialogRef: MatDialogRef<ConfirmationDialogComponent>;

  constructor(public dialog: MatDialog) { }

  confirm(options: ConfirmationDialogOptions): Observable<any> {
    this.dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      disableClose: false,
      width: options.type === 'email-setup-instructions-confirm' ? '300px' : 'auto',
      maxWidth: '600px'
    });

    if (options.message) {
      this.dialogRef.componentInstance.setConfirmMessage(options.message.name, options.message.type);
    }

    if (options.customMessage) {
      this.dialogRef.componentInstance.setCustomMessage(options.customMessage);
    }

    if (options.text) {
      this.dialogRef.componentInstance.setConfirmText(options.text);
    }

    if (options.type) {
      this.dialogRef.componentInstance.setDialogType(options.type);
    }

    if (options.title) {
      this.dialogRef.componentInstance.setDialogTitle(options.title);
    }

    if (options.note) {
      this.dialogRef.componentInstance.setDialogNote(options.note);
    }

    return this.dialogRef.afterClosed();
  }
}
