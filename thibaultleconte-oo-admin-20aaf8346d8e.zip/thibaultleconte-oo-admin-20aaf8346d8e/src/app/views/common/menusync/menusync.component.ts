import { Component, OnInit } from '@angular/core';
import { Observable, forkJoin, of } from 'rxjs';
import { PointOfSale } from '../../pointofsale/pointofsale';
import { DeliveryService } from '../../deliveryservice/deliveryservice';
import { FetchTask } from '../../menu/menuSync';
import { MenuService } from '../../menu/menu.service';
import { InjectorService } from '../../../service/injector.service';

@Component({
  selector: 'app-menusync',
  templateUrl: './menusync.component.html',
  styleUrls: ['./menusync.component.scss']
})
export class MenusyncComponent implements OnInit {

  menuSyncMapDataSource: (DeliveryService | PointOfSale)[] = [];
  menuSyncTaskDisplayedColumns: string[] = ['id', 'category', 'api_created_at', 'executed_at'];
  menuSyncTaskDataSource: FetchTask[] = [];

  public data: (DeliveryService | PointOfSale);
  public getMenuSync: string;
  public menusyncService;
  public menuService: MenuService;

  constructor() {
    const injector = InjectorService.getInjector();
    this.menuService = injector.get(MenuService);
  }

  ngOnInit() {
    this.menuSyncMapDataSource.push(this.data);
    this.fetchMenuSyncTasks().subscribe(fetchTasks => {
      this.menuSyncTaskDataSource = fetchTasks;
    });
  }

  fetchMenu() {
    this.menusyncService.fetchMenu(this.data.id).subscribe(() => {
      console.log(`Fetching menu for ${this.data.type}`);
    });
  }

  refreshData(btn) {
    btn.disabled = true;
    btn.textContent = 'Refreshing...';
    this.getData()
      .subscribe(res => {
        this.data = res[0];
        this.menuSyncMapDataSource = [res[0]];
        this.menuSyncTaskDataSource = res[1];
        btn.disabled = false;
        btn.textContent = 'Refresh Data';
      }, err => {
        console.log(err);
      });
  }

  fetchMenuSyncTasks(): Observable<[FetchTask]> {
    return this.data.menuSync && this.data.menuSync.id ? this.menuService.fetchMenuSyncTasks(this.data.menuSync.id) : of();
  }

  getMenuSyncData(): Observable<any> {
    return this.menusyncService[this.getMenuSync](this.data.id);
  }

  getData(): Observable<any> {
    const menuSyncData = this.getMenuSyncData();
    const fetchTasks = this.fetchMenuSyncTasks();
    return forkJoin([menuSyncData, fetchTasks]);
  }

}
