import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenusyncComponent } from './menusync.component';

describe('MenusyncComponent', () => {
  let component: MenusyncComponent;
  let fixture: ComponentFixture<MenusyncComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenusyncComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenusyncComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
