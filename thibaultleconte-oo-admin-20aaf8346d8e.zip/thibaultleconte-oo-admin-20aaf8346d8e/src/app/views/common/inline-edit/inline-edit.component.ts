import { Component,
  Input,
  Output,
  ElementRef,
  ViewChild,
  Renderer,
  forwardRef,
  OnInit,
  EventEmitter } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

const INLINE_EDIT_CONTROL_VALUE_ACCESSOR = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => InlineEditComponent),
  multi: true
};

@Component({
  selector: 'app-inline-edit',
  templateUrl: './inline-edit.component.html',
  providers: [INLINE_EDIT_CONTROL_VALUE_ACCESSOR],
  styleUrls: ['./inline-edit.component.scss']
})
export class InlineEditComponent implements ControlValueAccessor, OnInit {

  // input DOM element
  @ViewChild('inlineEditControl') inlineEditControl: ElementRef;

  @Input('label') label?: string = '';
  @Input('type') type?: string = 'text';
  @Input('required') required?: boolean = true;
  @Input('disabled') disabled?: boolean = false;
  @Input('currency') currency?: boolean = false;
  @Input('nav') nav?: boolean = false;
  @Input('navRoute') navRoute?: string;
  @Input() value: string;
  @Output() valueChange = new EventEmitter();
  private _value: string = '';
  public preValue: string = '';
  public editMode: boolean = false;
  public onChange: any = Function.prototype;
  public onTouched: any = Function.prototype;

  public minNum:number = 0;
  public maxNum:number = 999;

  // get value(): any {
  //   return this._value;
  // }

  // set value(v: any) {
  //   if (v !== this._value) {
  //     this._value = v;
  //     this.onChange(v);
  //   }
  // }

  constructor(private _renderer: Renderer) {}

  ngOnInit() {}

  writeValue(value: any) {
    this._value = value;
  }

  public registerOnChange(fn: (_: any) => {}): void {
    this.onChange = fn;
  }

  public registerOnTouched(fn: () => {}): void {
    this.onTouched = fn;
  }

  onBlur(event: Event) {
    console.log(this.inlineEditControl.nativeElement);
    if (this.inlineEditControl.nativeElement.validity.valid) {
      console.log(event);
      this.editMode = false;
      this.valueChange.emit(this.value);
    }
  }

  edit(value) {
    if (this.disabled) {
      return;
    }

    this.preValue = value;
    this.editMode = true;

    // Focus on the input element just as the editing begins
    setTimeout(_ => this._renderer.invokeElementMethod(this.inlineEditControl.nativeElement,
      'focus', []));
  }

  isCompTypeText() {
    return this.type === 'text';
  }

}
