export interface breadcrumb {
    path?: (string | number)[];
    name: string;
}