import { Injectable } from '@angular/core';

import { Account } from '../../account/account';
import { Restaurant } from '../../restaurant/restaurant';
import { Menu, MenuSection, MenuCategory, MenuItem } from '../../menu/menu';
import { breadcrumb } from './breadcrumb';
import { DeliveryService } from '../../deliveryservice/deliveryservice';
import { PointOfSale } from '../../pointofsale/pointofsale';
import { Printer } from '../../printer/printer';
import { Order } from '../../order/order';

@Injectable({
  providedIn: 'root'
})
export class BreadcrumbService {

  public breadcrumbList: breadcrumb[] = [];

  constructor() { }

  resetBreadcrumbList() {
    this.breadcrumbList = [];
  }

  getAccount(account: Account) {
    this.breadcrumbList.push({
      name: account.name,
      path: ['account', account.id]
    });
    return this.breadcrumbList;
  }

  getRestaurant(account: Account, restaurant: Restaurant) {
    this.getAccount(account);
    this.breadcrumbList.push({
      name: restaurant.name
    });
    return this.breadcrumbList;
  }

  addRestaurantPath(account: Account, restaurant: Restaurant) {
    this.getRestaurant(account, restaurant);
    this.breadcrumbList.pop();
    this.breadcrumbList.push({
      name: restaurant.name,
      path: ['restaurant', restaurant.id]
    });
  }

  getDeliveryService(account: Account, restaurant: Restaurant, ds: DeliveryService) {
    this.addRestaurantPath(account, restaurant);
    this.breadcrumbList.push({
      name: ds ? ds.type : 'Delivery Service'
    });
    return this.breadcrumbList;
  }

  getDSMenu(account: Account, restaurant: Restaurant, ds: DeliveryService, pos: PointOfSale) {
    this.getDeliveryService(account, restaurant, ds);
    this.breadcrumbList.pop();
    this.breadcrumbList.push({
      name: ds.type,
      path: ['restaurant', restaurant.id, 'ds', ds.id]
    });
    this.breadcrumbList.push({
      name: pos.type
    });
    return this.breadcrumbList;
  }

  getPointOfSale(account: Account, restaurant: Restaurant, pos: PointOfSale) {
    this.addRestaurantPath(account, restaurant);
    this.breadcrumbList.push({
      name: pos ? pos.type : 'Point Of Sale'
    });
    return this.breadcrumbList;
  }

  getPrinter(account: Account, restaurant: Restaurant, printer: Printer) {
    this.addRestaurantPath(account, restaurant);
    this.breadcrumbList.push({
      name: printer ? printer.manufacturerName + ' Printer' : 'Printer'
    });
    return this.breadcrumbList;
  }

  getPrinterAllJobs(account: Account, restaurant: Restaurant, printer: Printer) {
    this.addRestaurantPath(account, restaurant);
    this.breadcrumbList.push({
      name: 'Printer',
      path: ['restaurant', restaurant.id, 'printer', printer.id]
    });
    this.breadcrumbList.push({
      name: 'Print Jobs'
    });
    return this.breadcrumbList;
  }

  getPrinterJob(account: Account, restaurant: Restaurant, printerId: number) {
    this.addRestaurantPath(account, restaurant);
    this.breadcrumbList.push({
      name: 'Printer',
      path: ['restaurant', restaurant.id, 'printer', printerId]
    });
    this.breadcrumbList.push({
      name: 'Print Job'
    });
    return this.breadcrumbList;
  }

  getMenu(account: Account, restaurant: Restaurant, menu: Menu) {
    this.addRestaurantPath(account, restaurant);
    this.breadcrumbList.push({
      name: (menu.service && menu.service.type) || menu.name || 'NO DS'
    });
    return this.breadcrumbList;
  }

  getCategory(account: Account, restaurant: Restaurant, menu: Menu, section: MenuSection, category: MenuCategory) {
    this.getMenu(account, restaurant, menu);
    this.breadcrumbList.pop();
    this.breadcrumbList.push({
      name: (menu.service && menu.service.type) || menu.name || 'NO DS',
      path: ['restaurant', restaurant.id, 'menu', menu.id]
    });
    this.breadcrumbList.push({
      name: section.name
    });
    this.breadcrumbList.push({
      name: category.name
    });
    return this.breadcrumbList;
  }

  getModifier(account: Account, restaurant: Restaurant, menu: Menu, section: MenuSection, category: MenuCategory, item: MenuItem) {
    this.getCategory(account, restaurant, menu, section, category);
    this.breadcrumbList.pop();
    this.breadcrumbList.push({
      name: category.name,
      path: ['restaurant', restaurant.id, 'menu', menu.id, 'category', category.id]
    });
    this.breadcrumbList.push({
      name: item.name
    });
    return this.breadcrumbList;
  }

  getOrderDetail(account: Account, restaurant: Restaurant, order: Order) {
    this.addRestaurantPath(account, restaurant);
    this.breadcrumbList.push({
      name: order.delivery_service.type + ' Order ' + (order.delivery_service_short_uuid ? order.delivery_service_short_uuid : '')
    });
    return this.breadcrumbList;
  }

}
