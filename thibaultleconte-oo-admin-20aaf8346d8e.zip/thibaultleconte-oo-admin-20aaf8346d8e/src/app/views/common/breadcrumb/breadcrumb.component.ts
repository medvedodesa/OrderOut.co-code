import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { breadcrumb } from './breadcrumb';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class BreadcrumbComponent implements OnInit {

  @Input('breadcrumbList') breadcrumbList: breadcrumb[];

  constructor(private router: Router) { }

  ngOnInit() {
  }

  navigate(item) {
    this.router.navigate(item.path);
  }

}
