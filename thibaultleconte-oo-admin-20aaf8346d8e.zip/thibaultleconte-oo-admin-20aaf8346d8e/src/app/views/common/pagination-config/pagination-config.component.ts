import { Component, Input, Output, EventEmitter, ViewChild} from '@angular/core';
import { MatPaginator, PageEvent } from '@angular/material';

@Component({
  selector: 'app-pagination-config',
  templateUrl: './pagination-config.component.html',
  styleUrls: ['./pagination-config.component.scss']
})
export class PaginationConfigComponent {

  // MatPaginator Inputs
  @Input('length') length?: number = 100;
  @Input('pageSize') pageSize?: number = 25;
  @Input('pageSizeOptions') pageSizeOptions?: number[] = [10, 25, 50, 100];
  @Input('hidden') isHidden?: boolean;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  
  @Output('page') page: EventEmitter<PageEvent> = new EventEmitter();

  setPage(event){
    this.page.emit(event);
  }

}
