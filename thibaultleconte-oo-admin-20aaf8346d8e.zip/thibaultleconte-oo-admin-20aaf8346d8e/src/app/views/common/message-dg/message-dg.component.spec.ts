import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MessageDgComponent } from './message-dg.component';

describe('MessageDgComponent', () => {
  let component: MessageDgComponent;
  let fixture: ComponentFixture<MessageDgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MessageDgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MessageDgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
