import { Component, EventEmitter, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-message-dg',
  templateUrl: './message-dg.component.html',
  styleUrls: ['./message-dg.component.scss']
})
export class MessageDgComponent implements OnInit {

  public message: string;
  public options = {
    positive: false,
    negative: false
  }
  constructor(
    public dialogRef: MatDialogRef<MessageDgComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {
    this.message = data.message;
    this.options = Object.assign(this.options, data.options);
  }

  ngOnInit() {
  }

}
