export const menu_messages = {
    AUTO_MAP: "Menu auto mapping started. It may take a while." +
              "<br/> <br/> You may visit this page after a few minutes."
}

export const events_messages = {
    ADMIN_URL: "There is no admin URL attached to this core event."
}

export const onboarding_messages = {
    RESET_UE_CRED_POS: "Your UberEats Credential has been reset successfully." +
              "<br/> <br/> Please click on the UberEats Connect button to connect Your UberEats store!",
    RESET_UE_CRED_NEG: "Your UberEats Credential has not been reset successfully.",
}