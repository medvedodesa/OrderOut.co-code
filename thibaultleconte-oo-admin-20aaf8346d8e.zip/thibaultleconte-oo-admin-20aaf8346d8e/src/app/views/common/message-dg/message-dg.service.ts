import { Injectable } from '@angular/core';
import { MatDialog } from "@angular/material";

import { MessageDgComponent } from './message-dg.component';

@Injectable({
  providedIn: 'root'
})
export class MessageDgService {

  constructor(private dialog: MatDialog) { }

  openMsgDialog(msg: string, options?) {
    this.dialog.open(MessageDgComponent, {
      data: {
        message: msg,
        options: options
      }
    });
  }
}
