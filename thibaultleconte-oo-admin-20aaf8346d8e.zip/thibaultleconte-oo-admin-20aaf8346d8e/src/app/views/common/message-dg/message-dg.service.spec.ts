import { TestBed } from '@angular/core/testing';

import { MessageDgService } from './message-dg.service';

describe('MessageDgService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MessageDgService = TestBed.get(MessageDgService);
    expect(service).toBeTruthy();
  });
});
