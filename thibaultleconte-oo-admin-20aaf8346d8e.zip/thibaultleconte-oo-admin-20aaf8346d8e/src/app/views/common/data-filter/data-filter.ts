export interface filters {
    page: number;
    item_per_page: number;
    sort_order: String;
    sortOrder: String;
    pageSize: number;
    next_cursor: String;
    prev_cursor: String;
}