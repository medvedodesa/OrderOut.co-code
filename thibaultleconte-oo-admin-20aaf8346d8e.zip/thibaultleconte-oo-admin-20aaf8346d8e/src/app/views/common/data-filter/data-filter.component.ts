import { Component, OnInit } from '@angular/core';
import { filters } from './data-filter';

import { PaginationConfigComponent } from '../../common/pagination-config/pagination-config.component';
import { OrdersList, OrderOptions } from '../../order/order';
import { AccountsList, AccountOptions } from '../../account/account';

@Component({
  selector: 'app-data-filter',
  templateUrl: './data-filter.component.html',
  styleUrls: ['./data-filter.component.scss'],
  providers: [ PaginationConfigComponent ],
})
export class DataFilterComponent implements OnInit {

  public options: filters;

  public paginationLength: number;

  constructor(private paginationConfig: PaginationConfigComponent) {
    this.options = {
      sortOrder: 'desc',
      sort_order: 'desc',
      item_per_page: this.paginationConfig.pageSize,
      pageSize: this.paginationConfig.pageSize,
      page: 1,
      next_cursor: null,
      prev_cursor: null
    }

    this.paginationLength = this.paginationConfig.length;
  }

  ngOnInit() {
    
  }

  resetCursors(options: (OrderOptions | AccountOptions)) {
    options.next_cursor = null;
    options.prev_cursor = null;
  }

  setCursors(options: (OrderOptions | AccountOptions), list: (OrdersList | AccountsList), data) {
    if (options.pageSize === data.pageSize) {
      if (data.pageIndex > data.previousPageIndex) {
        options.next_cursor = list.next_cursor;
      } else {
        options.prev_cursor = list.prev_cursor;
      }
    } else {
      this.resetPagination(data);
    }

    options.pageSize = data.pageSize;
  }

  updateCursors(options: (OrderOptions | AccountOptions), list: (OrdersList | AccountsList), data) {
    this.resetCursors(options);
    this.setCursors(options,list, data);
  }

  resetPagination(data) {
    data.pageIndex = 0; // Doesn't work. I need to find another way to reset page to 0 index.
    console.log(data);
  }

}
