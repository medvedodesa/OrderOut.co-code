import { CollectionViewer, DataSource } from '@angular/cdk/collections';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';

import { InjectorService } from '../../service/injector.service';
import { MenuItem } from './menu';
import { MenuService } from './menu.service';
import { SortByPipe } from '../../pipes/sort-by.pipe';

export class MenuItemsDataSource implements DataSource<MenuItem> {

    private allMenuItemsSubject = new BehaviorSubject<MenuItem[]>([]);

    private loadingSubject = new BehaviorSubject<boolean>(false);
    public loading$ = this.loadingSubject.asObservable();

    public menuService: MenuService;
    public sortByPipe: SortByPipe;

    constructor() {
        const injector = InjectorService.getInjector();
        this.menuService = injector.get(MenuService);
        this.sortByPipe = injector.get(SortByPipe);
    }

    connect(collectionViewer: CollectionViewer): Observable<MenuItem[]> {
        return this.allMenuItemsSubject.asObservable();
    }

    disconnect(collectionViewer: CollectionViewer): void {
        this.allMenuItemsSubject.complete();
        this.loadingSubject.complete();
    }

    loadByDeliveryService(deliveryServiceId: number) {

        this.loadingSubject.next(true);

        this.menuService.getByDeliveryService(deliveryServiceId).pipe(
            catchError(() => of([])),
            finalize(() => this.loadingSubject.next(false))
        )
            .subscribe(menuItems => {
                menuItems = this.sortByPipe.transform(menuItems, 'name');
                this.allMenuItemsSubject.next(menuItems);
            });
    }
}
