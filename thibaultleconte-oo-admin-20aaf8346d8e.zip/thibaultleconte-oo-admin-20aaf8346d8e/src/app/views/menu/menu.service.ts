import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import * as _ from 'lodash';

import { environment } from '../../../environments/environment';
import { ApiService } from './../../core/api.service';
import { Menu, MenuItem, MenuItemModifier, MenuList, MenuSection, MenuCategory, ModifierGroup } from './menu';
import { FetchTask } from './menuSync';

import menu from './menu.json';

@Injectable({
  providedIn: 'root'
})
export class MenuService {

  private menuRestaurantUrl = environment.backend_url + 'restaurant';
  private menuUrl = environment.backend_url + 'menu';
  private menusyncUrl = environment.backend_url + 'menusync';

  constructor(private api: ApiService) {}

  getByPointOfSale(pointOfSaleId: number): Observable<[MenuItem]> {
    const url = `${this.menuUrl}/pos/${pointOfSaleId}`;
    return this.api.get(url);
  }

  getByDeliveryService(deliveryServiceId: number): Observable<[MenuItem]> {
    const url = `${this.menuUrl}/ds/${deliveryServiceId}`;
    return this.api.get(url);
  }

  getModifiersForMenuItem(menuItemId: number): Observable<[MenuItemModifier]> {
    const url = `${this.menuUrl}/item/${menuItemId}/modifiers`;
    return this.api.get(url);
  }

  autoMapDeliveryServiceMenuItemsToPointOfSaleMenuItems(deliveryServiceId: number, pointOfSaleId: number) {
    const url = `${this.menuUrl}/automap/ds/${deliveryServiceId}/pos/${pointOfSaleId}`;
    return this.api.get(url);
  }

  magicMapAll(deliveryServiceId: number, pointOfSaleId: number) {
    const url = `${this.menuUrl}/magicmapping/ds/${deliveryServiceId}/pos/${pointOfSaleId}`;
    return this.api.put(url);
  }

  magicMapItem(itemId: number, pointOfSaleId: number) {
    const url = `${this.menuUrl}/magicmapping/mi/${itemId}/pos/${pointOfSaleId}`;
    return this.api.put(url);
  }

  magicMapModifier(itemId: number, modifierId: number, pointOfSaleId: number) {
    const url = `${this.menuUrl}/magicmapping/mi/${itemId}/mod/${modifierId}/pos/${pointOfSaleId}`;
    return this.api.put(url);
  }

  mapDSMenuItemToPOSMenuItem(deliveryServiceMenuItemId: number, pointOfSaleMenuItemId: number) {
    const url = `${this.menuUrl}/map/item/ds/${deliveryServiceMenuItemId}/pos/${pointOfSaleMenuItemId}`;
    return this.api.put(url, {});
  }

  mapDSModifierToPOSModifier(dsModifierId: number, posModifierId: number) {
    const url = `${this.menuUrl}/map/modifier/ds/${dsModifierId}/pos/${posModifierId}`;
    return this.api.put(url, {});
  }

  resetMappingForDeliveryServiceMenuItem(deliveryServiceMenuItemId: number) {
    const url = `${this.menuUrl}/item/${deliveryServiceMenuItemId}/reset`;
    return this.api.put(url);
  }

  resetMappingForDSModifiers(dsModifierId: number) {
    const url = `${this.menuUrl}/modifier/${dsModifierId}/reset`;
    return this.api.put(url);
  }

  fetchMenuSyncTasks(menuSyncId: number): Observable<[FetchTask]> {
    const url = `${this.menusyncUrl}/${menuSyncId}/tasks`;
    return this.api.get(url);
  }

  // Get menu list by restaurant id
  getByRestaurant(restaurantId: number): Observable<MenuList> {
    const url = `${this.menuRestaurantUrl}/${restaurantId}/menusync`;
    return this.api.get(url);
  }

  // Get Menu by menu sync id
  getByMenuSyncId(menuSyncId: number): Observable<Menu> {
    const url = `${this.menuUrl}/ms/${menuSyncId}`;
    return this.api.get(url);
  }

  // Get sections by menu sync id
  getSectionsByMenuSyncId(menuSyncId: number): Observable<MenuSection[]> {
    const url = `${this.menuUrl}/ms/${menuSyncId}/sections`;
    return this.api.get(url);
  }

  // Get section by section id
  getSectionBySectionId(menuSectionId: number): Observable<MenuSection> {
    const url = `${this.menuUrl}/section/${menuSectionId}?expanded=True`;
    return this.api.get(url);
  }

  // Get tasks by menu sync id
  getTasksByMenuSyncId(menuSyncId: number): Observable<any> {
    const url = `${this.menusyncUrl}/${menuSyncId}/tasks`;
    return this.api.get(url);
  }

  addMenu(menuOri: Menu): Observable<Menu> {
    return of(_.cloneDeep(menu));
    // const url = `${this.menuUrl}`;
    // return this.api.post(url, menu).pipe(
    //   catchError(this.handleError('addMenu', null))
    // );
  }

  deleteMenu(menuId: number) {
    const url = `${this.menuUrl}/ms/${menuId}`;
    return this.api.delete(url);
  }

  addSection(data: Object): Observable<MenuSection> {
    const url = `${this.menuUrl}/section/`;
    return this.api.post(url, data);
  }

  updateSection(section: MenuSection): Observable<MenuSection> {
    const url = `${this.menuUrl}/section/${section.id}`;
    let payload = {
      "name": section.name,
      "position": section.position,
      "description": section.description || '',
      "enabled": section.enabled,
      "availability": section.availability
    };
    return this.api.put(url, payload);
  }

  deleteSection(sectionId: number) {
    const url = `${this.menuUrl}/section/${sectionId}`;
    return this.api.delete(url);
  }

  addCategory(data: Object): Observable<MenuSection> {
    const url = `${this.menuUrl}/category/`;
    return this.api.post(url, data);
  }

  updateCategory(category: MenuCategory): Observable<MenuCategory> {
    const url = `${this.menuUrl}/category/${category.id}`;
    let payload = {
      "name": category.name,
      "position": category.position,
      "enabled": category.enabled
    };
    return this.api.put(url, payload);
  }

  deleteCategory(categoryId: number) {
    const url = `${this.menuUrl}/category/${categoryId}`;
    return this.api.delete(url);
  }

  addMenuItem(data: Object): Observable<MenuItem> {
    const url = `${this.menuUrl}/item/`;
    return this.api.post(url, data);
  }

  updateMenuItem(menuItem: MenuItem): Observable<MenuItem> {
    const url = `${this.menuUrl}/item/${menuItem.id}`;
    let payload = {
      "name": menuItem.name,
      "is_available": menuItem.is_available,
      "price":  Number.parseFloat((menuItem.price).toString())
    };
    return this.api.put(url, payload);
  }

  deleteMenuItem(menuItemId: number) {
    const url = `${this.menuUrl}/item/${menuItemId}`;
    return this.api.delete(url);
  }

  addModifierGroup(data: Object): Observable<ModifierGroup> {
    const url = `${this.menuUrl}/modifiergroup/`;
    return this.api.post(url, data);
  }

  updateModifierGroup(modifierGroup: ModifierGroup): Observable<ModifierGroup> {
    const url = `${this.menuUrl}/modifiergroup/${modifierGroup.id}`;
    let payload = {
      "name": modifierGroup.name,
      "is_available": modifierGroup.is_available,
      "min_permitted": Number.parseFloat((modifierGroup.min_permitted).toString()),
      "max_permitted": Number.parseFloat((modifierGroup.max_permitted).toString())
    };
    return this.api.put(url, payload);
  }

  deleteModifierGroup(modifierGroupId: number) {
    const url = `${this.menuUrl}/modifiergroup/${modifierGroupId}`;
    return this.api.delete(url);
  }

  addModifier(data: Object): Observable<MenuItemModifier> {
    const url = `${this.menuUrl}/modifier/`;
    return this.api.post(url, data);
  }

  updateModifier(modifier: MenuItemModifier): Observable<MenuItemModifier> {
    const url = `${this.menuUrl}/modifier/${modifier.id}`;
    let payload = {
      "name": modifier.name,
      "is_available": modifier.is_available,
      "price":  Number.parseFloat((modifier.price).toString())
    };
    return this.api.put(url, payload);
  }

  deleteModifier(modifierId: number) {
    const url = `${this.menuUrl}/modifier/${modifierId}`;
    return this.api.delete(url);
  }

}
