import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuCategoryPageDetailsComponent } from './menu-category-page-details.component';

describe('MenuCategoryPageDetailsComponent', () => {
  let component: MenuCategoryPageDetailsComponent;
  let fixture: ComponentFixture<MenuCategoryPageDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuCategoryPageDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuCategoryPageDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
