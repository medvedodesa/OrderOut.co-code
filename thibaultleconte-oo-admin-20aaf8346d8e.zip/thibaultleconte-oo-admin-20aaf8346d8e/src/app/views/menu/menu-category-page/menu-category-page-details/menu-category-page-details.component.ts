import { Component, Input, OnInit } from '@angular/core';

import { Account } from 'src/app/views/account/account';
import { Restaurant } from 'src/app/views/restaurant/restaurant';
import { Menu, MenuCategory, MenuSection } from '../../menu';
import { breadcrumb } from '../../../common/breadcrumb/breadcrumb';

import { AccountService } from '../../../account/account.service';
import { BreadcrumbService } from '../../../common/breadcrumb/breadcrumb.service';
import { MenuHelperService } from '../../menu-helper.service';

@Component({
  selector: 'app-menu-category-page-details',
  templateUrl: './menu-category-page-details.component.html',
  styleUrls: ['./menu-category-page-details.component.scss']
})
export class MenuCategoryPageDetailsComponent implements OnInit {

  @Input() account: Account;
  @Input() restaurant: Restaurant;
  @Input() menu: Menu;
  @Input() category: MenuCategory;
  @Input() editMode: boolean;

  public section: MenuSection;
  public breadcrumbList: breadcrumb[] = [];

  constructor(
    private accountService: AccountService,
    private breadcrumbService: BreadcrumbService,
    private menuHelperService: MenuHelperService
  ) { }

  ngOnInit() {
    this.section = this.menuHelperService.getMenuSection(this.category.id);

    this.breadcrumbService.resetBreadcrumbList();
    this.breadcrumbList = this.breadcrumbService.getCategory(
      this.account,
      this.restaurant,
      this.menu,
      this.section,
      this.category
    );
   
  }

}
