import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';

import { Account } from '../../account/account';
import { AccountRestaurant, Restaurant } from '../../restaurant/restaurant';
import { Menu, MenuCategory } from '../menu';
import { MenuHelperService } from '../menu-helper.service';

@Component({
  selector: 'app-menu-category-page',
  templateUrl: './menu-category-page.component.html',
  styleUrls: ['./menu-category-page.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MenuCategoryPageComponent implements OnInit {

  public accountRestaurant: AccountRestaurant;
  public account: Account;
  public restaurant: Restaurant;
  public menu: Menu;
  public category: MenuCategory;
  public editMode: boolean;

  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();

  constructor(
    private route: ActivatedRoute,
    private menuHelperService: MenuHelperService
  ) { }

  ngOnInit() {
    this.accountRestaurant = this.route.snapshot.data.accountRestaurant;
    this.account = this.accountRestaurant.account;
    this.restaurant = this.accountRestaurant.restaurant;
    this.menu = this.route.snapshot.data.menu;
    this.editMode = this.route.snapshot.data.edit === true ? true : false;

    this.loadingSubject.next(true);
    this.menuHelperService.getFullMenu(this.menu.id).pipe(
      catchError(() => of([] as any)),
      finalize(() => {
          this.loadingSubject.next(false);
        })
      ).
      subscribe(function(menu_sections) {
        this.menu.menu_sections = menu_sections[0]; // Get all menu sections with array wrapper so accessed with 0th index
        this.menuHelperService.menu = this.menu;
        this.category = this.menuHelperService.getMenuCategory(this.route.snapshot.data.categoryId);
        this.menuHelperService.setAlertConfig();
      }.bind(this));
    
  }

}
