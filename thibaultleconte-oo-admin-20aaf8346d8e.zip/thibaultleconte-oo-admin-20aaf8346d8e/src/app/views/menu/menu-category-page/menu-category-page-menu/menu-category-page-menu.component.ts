import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { CdkDrag, CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';

import { Restaurant } from 'src/app/views/restaurant/restaurant';
import { Menu, MenuCategory, MenuItem, ModifierGroup } from '../../menu';

import { MenuService } from '../../../menu/menu.service';
import { ConfirmationDialogService } from '../../../common/confirmation-dialog/confirmation-dialog.service';
import { MenuDialogComponent } from '../../menu-dialog/menu-dialog.component';

@Component({
  selector: 'app-menu-category-page-menu',
  templateUrl: './menu-category-page-menu.component.html',
  styleUrls: ['./menu-category-page-menu.component.scss']
})
export class MenuCategoryPageMenuComponent implements OnInit {

  @Input() restaurant: Restaurant;
  @Input() menu: Menu;
  @Input() category: MenuCategory;
  @Input() editMode: boolean;

  public menuItems: MenuItem[];

  constructor(
    private router: Router,
    private dialog: MatDialog,
    private menuService: MenuService,
    public cdService: ConfirmationDialogService
  ) { }

  ngOnInit() {
    this.menuItems = this.category.menuitems;
  }

  toggleEnabled(event, menuItem: MenuItem) {
    menuItem.is_available = event.checked;
    this.updateMenuItem(menuItem);
  }

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.menuItems, event.previousIndex, event.currentIndex);
    this.setPosition();
  }

  dragStarted(event: {source: CdkDrag}) {
    setTimeout(() => {
      const dropContainer = event.source._dragRef['_dropContainer'];

      if (dropContainer) {
        dropContainer['_cacheOwnPosition']();
        dropContainer['_cacheItemPositions']();
      }
    }, 200);
  }

  dragEnded(event: CdkDragDrop<string[]>) {
  }

  setPosition() {
    this.menuItems.forEach((menuItem, index) => {
      menuItem.position = index;
    });
  }

  itemSelected(menuItem: MenuItem) {
    this.router.navigate(['restaurant', this.restaurant.id, 'menu', this.menu.id, 'category', this.category.id, 'item', menuItem.id]);
  }

  modifierGroupSelected(menuItem: MenuItem, modifierGroup: ModifierGroup) {
    this.router.navigate(['restaurant', this.restaurant.id, 'menu', this.menu.id, 'category', this.category.id, 'item', menuItem.id], { fragment: 'id' + modifierGroup.id });
  }

  addMenuItem() {
    const dialogRef = this.dialog.open(MenuDialogComponent, {
      width: '600px',
      data: 'Add Menu Item'
    });
    dialogRef.componentInstance.event.subscribe((result) => {
      if(result.data && result.data.name) {
        this.menuService.addMenuItem({
          'menu_sync_id' : this.menu.id,
          'category_id': this.category.id,
          'name': result.data.name
        }).subscribe(menuItem => {
          if (menuItem) {
            this.menuItems ? this.menuItems.push(menuItem) : this.menuItems = [menuItem];
          }
        });
      }
    });
  }

  deleteMenuItem(menuItem: MenuItem) {
    this.cdService.confirm({
      message: {
        name: menuItem.name,
        type: 'menu item'
      }
    }).subscribe(result => {
      if (result) {
        this.menuService.deleteMenuItem(menuItem.id).subscribe((result) => {
          this.menuItems = this.menuItems.filter(mMenuItem => mMenuItem.id !== menuItem.id);
        })
      }
    });
  }

  onValueChange(value: string, key: string,  menuItem: MenuItem) {
    value = value && typeof(value) === 'string' ? value.trim() : value;
    if (menuItem[key] !== value ) {
      menuItem[key] = value;
      this.updateMenuItem(menuItem);
    }
  }

  updateMenuItem(menuItem: MenuItem) {
    this.menuService.updateMenuItem(menuItem).subscribe((result) => {
      console.log(result);
    });
  }

}
