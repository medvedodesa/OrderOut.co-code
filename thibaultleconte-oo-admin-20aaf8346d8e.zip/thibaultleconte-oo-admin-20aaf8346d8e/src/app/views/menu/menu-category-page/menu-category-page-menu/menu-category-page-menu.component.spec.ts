import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuCategoryPageMenuComponent } from './menu-category-page-menu.component';

describe('MenuCategoryPageMenuComponent', () => {
  let component: MenuCategoryPageMenuComponent;
  let fixture: ComponentFixture<MenuCategoryPageMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuCategoryPageMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuCategoryPageMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
