import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { MenuCategory } from '../menu';
import { MenuHelperService } from '../menu-helper.service';

@Injectable()
export class MenuCategoryResolve implements Resolve<number> {

    constructor(private menuHelperService: MenuHelperService) { }

    resolve(route: ActivatedRouteSnapshot) {
        return route.params.categoryId;
    }
}