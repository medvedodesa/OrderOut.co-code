import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, forkJoin , of } from 'rxjs';
import { catchError, finalize, mergeMap, map } from 'rxjs/operators';

import { MenuService } from './menu.service'; 
import { Menu, MenuSection, MenuCategory } from './menu';

import { ConfirmationDialogService } from '../common/confirmation-dialog/confirmation-dialog.service';

@Injectable({
  providedIn: 'root'
})
export class MenuHelperService {

  private _menu: Menu;
  private _isAlertConfig: boolean = false;

  constructor(
    private menuService: MenuService,
    private cdService: ConfirmationDialogService
  ) { }

  get menu(): Menu {
    return this._menu;
  }

  set menu(menu: Menu) {
    this._menu = menu;
  }

  getFullMenu(menuId) {

    if (this._menu && this._menu.id === menuId && this._menu.menu_sections && this._menu.menu_sections.length > 0) {
      return of([this._menu.menu_sections]);
    } 

    let menu_sections = [];

    return this.menuService.getSectionsByMenuSyncId(menuId)
        .pipe(
            mergeMap(menuSections => {

                const sectionObservables = [];
                menuSections.forEach((menuSection) => {
                    sectionObservables.push(this.menuService.getSectionBySectionId(menuSection.id));
                });
                return forkJoin(sectionObservables).pipe(
                    map(menuSection => {
                        menu_sections.push(menuSection as any);
                        return menu_sections;
                    })
                );
                
            })
        );

  }

  getMenuSection(categoryId: number): MenuSection {
    /**
     *  Note: We may replace this logic with API call
    **/
    let obj;
    this._menu.menu_sections.forEach(section => {
      section.categories.forEach(category => {
        if (category.id == categoryId) {
          obj = section;
        }
      });
    });
    return obj;
  }

  getMenuCategory(categoryId: number): MenuCategory {

    /**
     *  Note: We may replace this logic with API call
    **/
    let obj;
    this._menu.menu_sections.forEach(section => {
      section.categories.forEach(category => {
        if (category.id == categoryId) {
          obj = category;
          return;
        }
      });
    });
    return obj;
  }

  getMenuItem(menuItems, itemId: number) {

    /**
     *  Note: We may replace this logic with API call
    **/
    let obj;
    menuItems.forEach(menuItem => {
      if (menuItem.id == itemId) {
        obj = menuItem;
        return;
      }
    });
    return obj;
  }

  setAlertConfig() {

    if(this._isAlertConfig === false) {
      this._menu.menu_sections.forEach((section) => {

        if(section && section.categories && section.categories.length > 0) {
          this._isAlertConfig = true;
          section.categories.forEach((category) => {

            if(category && category.menuitems && category.menuitems.length > 0) {
              
              category.menuitems.forEach((menuitem) => {
                
                if(menuitem && menuitem.modifier_groups && menuitem.modifier_groups.length > 0) {

                  menuitem.modifier_groups.forEach((modifier_group) => {
                    if (modifier_group.modifiers) {
                      let count = 0;
                      modifier_group.modifiers.forEach((modifier, i) => {
                        modifier.is_available === true ? count++ : '';
                      });
                    
                      if (modifier_group.max_permitted > count || modifier_group.min_permitted > count) {
                        modifier_group['alert_setting'] = {
                          alert: true
                        }
                        category["is_alert"] = true;
                        menuitem["is_alert"] = true;
                      }
                    }
                  });

                }

              });
            }

          });
        }

      });

    }

  }

  showConfirmDialog() {
    return this.cdService.confirm({
      type: 'general-confirm',
      note: "WARNING: If you dont know how dangerous this button is, ask Thibault!"
    })
  }
}
