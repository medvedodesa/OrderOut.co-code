import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ISubscription } from 'rxjs/Subscription';
import { MatDialog, MatTableDataSource, MatSort } from '@angular/material';
import { Observable, forkJoin, of, BehaviorSubject } from 'rxjs';

import { Account } from '../../account/account';
import { AccountService } from '../../account/account.service';

import { AccountRestaurant, Restaurant } from '../../restaurant/restaurant';

import { PointOfSale } from '../../pointofsale/pointofsale';
import { PointofsaleService } from '../../pointofsale/pointofsale.service';

import { DeliveryService } from '../../deliveryservice/deliveryservice';
import { DeliveryserviceService } from '../../deliveryservice/deliveryservice.service';

import { MenuItem, MenuItemModifier } from '../menu';
import { MenuService } from '../menu.service';
import { MenuHelperService } from '../menu-helper.service';
import { MenuItemsDataSource } from '../menuItems.datasource';

import { MenuSyncModifierComponent } from '../menu-sync-modifier/menu-sync-modifier.component';
import { MenuMapDialogComponent } from '../menu-map-dialog/menu-map-dialog.component';

import { breadcrumb } from '../../common/breadcrumb/breadcrumb';
import { BreadcrumbService } from '../../common/breadcrumb/breadcrumb.service';

import { MessageDgService } from '../../common/message-dg/message-dg.service';
import { menu_messages } from '../../common/message-dg/message-dg';

import { LoaderService } from '../../../service/loader.service';


@Component({
  selector: 'app-menu-sync',
  templateUrl: './menu-sync.component.html',
  providers: [PointofsaleService, MenuService],
  styleUrls: ['./menu-sync.component.scss']
})
export class MenuSyncComponent implements OnInit, OnDestroy {

  private subscription: ISubscription;

  public columnsToDisplay = ['name', 'mappedTo']; // 'mappedToMenuItem'
  public dataSource: MatTableDataSource<MenuItem>;
  @ViewChild(MatSort) sort: MatSort;

  public accountRestaurant: AccountRestaurant;
  public account: Account;
  public restaurant: Restaurant;
  public deliveryService: DeliveryService;
  public pointOfSale: PointOfSale;
  public options: MenuItem[];
  public posModifiersList: MenuItemModifier[] = [];

  public menuStats;
  public menuStatsColumns = ['title', 'mapped', 'unmapped', 'total', 'progress'];

  public breadcrumbList: breadcrumb[] = [];

  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();

  public showMBAll: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private pointofsaleService: PointofsaleService,
    private menuService: MenuService,
    private menuHelperService: MenuHelperService,
    public dialog: MatDialog,
    private accountService: AccountService,
    private dsService: DeliveryserviceService,
    private breadcrumbService: BreadcrumbService,
    private loaderService: LoaderService,
    public msgDgService: MessageDgService
  ) { }

  ngOnInit() {
    this.accountRestaurant = this.route.snapshot.data.accountRestaurant;
    this.account = this.accountRestaurant.account;
    this.restaurant = this.accountRestaurant.restaurant;
    this.deliveryService = this.route.snapshot.data.deliveryService;

    this.showMBAll = this.route.snapshot.queryParams.show_magic_button_for_all === '1';

    if (!this.restaurant.pointOfSaleId) {
      this.pointOfSale = {
        id: null,
        type: "POS",
        service_merchant_id: null,
        service_employee_id: null,
        menuSync: null,
        settings: null,
        api_created_at: null,
      }
      this.getBreadcrumb(this.pointOfSale);
    }

    this.loadingSubject.next(true);
    this.getDataSubscribe();

    this.buildMenuStats();
  }

  ngOnDestroy() {
    if (!this.subscription) { return; }
    this.subscription.unsubscribe();
  }

  getByDeliveryService(): Observable<[MenuItem]> {
    return this.menuService.getByDeliveryService(this.deliveryService.id);
  }

  getPointOfSale(): Observable<PointOfSale> {
    return this.restaurant.pointOfSaleId ? this.pointofsaleService.getPointOfSale(this.restaurant.pointOfSaleId) : of(this.pointOfSale);
  }

  getByPointOfSale(): Observable<[MenuItem]> {
    return this.restaurant.pointOfSaleId ? this.menuService.getByPointOfSale(this.restaurant.pointOfSaleId) : of([] as any);
  }

  getDeliveryService(): Observable<DeliveryService> {
    return this.dsService.getDeliveryService(this.route.snapshot.params.deliveryServiceId);
  }

  getDataSubscribe(isRefresh?: boolean) {
    this.subscription = this.getData(isRefresh)
      .subscribe(res => {

        // DS Menu Items
        let menuItems = this.addModifiersStats(res[0]);
        this.dataSource = new MatTableDataSource(menuItems);
        this.dataSource.sort = this.sort;

        // Point of Sale
        if (this.restaurant.pointOfSaleId) {
          this.pointOfSale = res[1];
          this.getBreadcrumb(this.pointOfSale);
        }

        // POS Menu Items
        this.options = res[2];
        this.getPOSModifiersList(res[2]);

        // Delivery Service
        if (res && res[3]) {
          this.deliveryService = res[3];
          this.buildMenuStats();
        }
        
      }, err => {
        console.log(err);
      }).add(() => {
        // Hide the loader
        this.loadingSubject.next(false);
        this.loaderService.hide();
      });
  }

  getData(isRefresh?: boolean): Observable<any> {
    const joinReq = [this.getByDeliveryService(), this.getPointOfSale(), this.getByPointOfSale()];
    isRefresh === true ? joinReq.push(this.getDeliveryService() as any) : '';
    return forkJoin(joinReq);
  }

  // Data Fetch Helper

  getPointOfSaleMappedMenuItem(pointOfSaleMenuItemId: number): MenuItem {
    const posMenuItem = this.options && this.options.find(entity => entity.id === pointOfSaleMenuItemId);
    return posMenuItem && posMenuItem.name ? posMenuItem : {} as any;
  }

  // Actions

  openMapMenuItemDialog(dsMenuItem: MenuItem) {
    const dialogRef = this.dialog.open(MenuMapDialogComponent, {
      width: '800px',
      data: { dsMenuItem, posMenuItem: this.options, deliveryService: this.deliveryService, pointOfSale: this.pointOfSale },
    });
    dialogRef.componentInstance.event.subscribe((result) => {
      console.log(result);
    });
  }

  mapModifiersForMenuItem(dsMenuItem: MenuItem) {
    console.log(`mapModifiersForMenuItem for ${dsMenuItem.name} -> ${dsMenuItem.modifier_groups.length} modifiers`);
    const dialogRef = this.dialog.open(MenuSyncModifierComponent, {
      width: '800px',
      data: { 
        dsMenuItem: dsMenuItem,
        posModifiers: this.posModifiersList,
        posId: this.restaurant.pointOfSaleId
      }
    });
    dialogRef.afterClosed().subscribe(res => {

      if (dialogRef.componentInstance.isUpdated) {
        this.addModifiersStats([dsMenuItem]);

        // It will reset modifier states for the same modifier groups.
        if(dsMenuItem && dsMenuItem.modifier_groups && dsMenuItem.modifier_groups.length > 0) {
          dsMenuItem.modifier_groups.forEach(mg => {
            this.dataSource.data.forEach(menuItem => {
              let flag = 0;
              if (menuItem && menuItem.modifier_groups && menuItem.modifier_groups.length > 0) {
                menuItem.modifier_groups.forEach(menuItem_mg => {
                  if(menuItem_mg.id === mg.id) {
                    menuItem_mg = Object.assign(menuItem_mg, mg);
                    flag = 1;
                  }
                });
              }
              if(flag === 1) {
                this.addModifiersStats([menuItem]);
              }
            })
          })
        }
      }
      
    })
  }

  autoMapMenuItems(btn) {
    btn.textContent = 'Auto-Mapping...';
    btn.disabled = true;
    this.loaderService.show();
    this.subscription = this.menuService.autoMapDeliveryServiceMenuItemsToPointOfSaleMenuItems(this.deliveryService.id, this.restaurant.pointOfSaleId)
      .subscribe((result) => {
        if (result && result.length > 0) {
          result = this.addModifiersStats(result);
          this.dataSource = new MatTableDataSource(result);
          this.sort.direction = 'asc';
          this.sort._stateChanges.next();
          this.dataSource.sort = this.sort;
          btn.textContent = 'Auto-Mapped';
        } else {
          btn.textContent = 'Auto-Map';
        }
        btn.disabled = false;
        btn.classList.add("hide");
        this.loaderService.hide();
        this.msgDgService.openMsgDialog(menu_messages.AUTO_MAP);
      });
  }

  resetMappingForDeliveryServiceMenuItem(btn, deliveryServiceMenuItem: MenuItem) {
    btn.textContent = 'Resetting';
    btn.disabled = true;
    this.subscription = this.menuService.resetMappingForDeliveryServiceMenuItem(deliveryServiceMenuItem.id).subscribe((menuItem) => {
      let catName = deliveryServiceMenuItem.category_name;
      deliveryServiceMenuItem = Object.assign(deliveryServiceMenuItem, menuItem);
      deliveryServiceMenuItem.category_name = catName;
      btn.textContent = 'Reset';
      btn.disabled = false;
    });
  }

  addModifiersStats(menuItems) {
    menuItems.forEach(item => {
      if (item.modifier_groups && item.modifier_groups.length !== 0) {
        let flag = 0;
        let total_modifiers = 0;
        let unmapped_modifiers = 0;
        item.modifier_groups.forEach(group => {
          total_modifiers += group.modifiers.length;
          if (group.modifiers && group.modifiers.length != 0) {
            group.modifiers.forEach(modifier => {
              modifier.mappedToMenuItemModifier ? '' : unmapped_modifiers = unmapped_modifiers + 1;
            });
            item.unmapped_modifiers = unmapped_modifiers;
            flag = 1;
          }
        });
        item.total_modifiers = total_modifiers;
        if (flag == 0) {
          item.total_modifiers = 0;
        }
      } else {
        item.total_modifiers = 0;
      }
    });
    return menuItems;
  }

  getBreadcrumb(pos: PointOfSale) {
    this.accountService.getAccount(this.restaurant.accountId).subscribe(account => {
      this.breadcrumbService.resetBreadcrumbList();
      this.breadcrumbList = this.breadcrumbService.getDSMenu(
        account,
        this.restaurant,
        this.deliveryService,
        this.pointOfSale
      );
    });
  }

  buildMenuStats() {

    let menuSync = this.deliveryService.menuSync;
    if (menuSync) {
      let totleMappedEle = menuSync.map_mapped_menu_items + menuSync.map_mapped_menu_modifiers;
      let totalUnmappeEle = menuSync.map_unmapped_menu_items + menuSync.map_unmapped_menu_modifiers;
      let totalEle = menuSync.map_total_menu_items + menuSync.map_total_menu_modifiers;
      let totalMappedElePer = totalEle != 0 ? Math.round((totleMappedEle * 100) / totalEle) : 0;
      let MappedMenuItemsPer = menuSync.map_total_menu_items != 0 ? Math.round((menuSync.map_mapped_menu_items * 100) / menuSync.map_total_menu_items) : 0;
      let MappedMenuModifiersPer = menuSync.map_total_menu_modifiers != 0 ? Math.round((menuSync.map_mapped_menu_modifiers * 100) / menuSync.map_total_menu_modifiers) : 0;

      let rowMenuItems = {
        displayText: 'Menu Items',
        mapped: menuSync.map_mapped_menu_items,
        unmapped: menuSync.map_unmapped_menu_items,
        total: menuSync.map_total_menu_items,
        progress: MappedMenuItemsPer
      }

      let rowMenuModifiers = {
        displayText: 'Menu Modifiers',
        mapped: menuSync.map_mapped_menu_modifiers,
        unmapped: menuSync.map_unmapped_menu_modifiers,
        total: menuSync.map_total_menu_modifiers,
        progress: MappedMenuModifiersPer
      }

      let rowMenuTotal = {
        displayText: 'Total',
        mapped: totleMappedEle,
        unmapped: totalUnmappeEle,
        total: totalEle,
        progress: totalMappedElePer
      }

      this.menuStats = [rowMenuItems, rowMenuModifiers, rowMenuTotal];
    }
    
  }

  getPOSModifiersList(posMenuItemsList: [MenuItem]) {
    if (posMenuItemsList && posMenuItemsList.length > 0) {
      posMenuItemsList.forEach(posMenuItem => {
        if(posMenuItem.modifier_groups && posMenuItem.modifier_groups.length > 0) {
          posMenuItem.modifier_groups.forEach(modifier_group => {
            if (modifier_group && modifier_group.modifiers && modifier_group.modifiers.length > 0) {
              modifier_group.modifiers.forEach(modifer => {
                modifer.itemId = posMenuItem.id;
                this.posModifiersList.push(modifer);
              });
            }
          });
        }
      });
    }
  }

  refreshMenuMapping() {
    this.loaderService.show();
    this.getDataSubscribe(true);
  }

  magicMapAll(btn) {
   
    this.menuHelperService.showConfirmDialog().subscribe(result => {
      if (result) {
        btn.disabled = true;
        this.loaderService.show();
        this.subscription = this.menuService.magicMapAll(this.deliveryService.id, this.restaurant.pointOfSaleId)
          .subscribe((result) => {
            if (result && result.success) {

              // Update DS items
              this.dataSource.data.forEach(dsItem => {
                result.ds_items.forEach(ds_item => {
                  if(dsItem.id === ds_item.id) {
                    let catName = dsItem.category_name;
                    dsItem = Object.assign(dsItem, ds_item);
                    dsItem.category_name = catName;
                  }
                });
              })

              // Update POS items
              if (result.pos_items && result.pos_items.length > 0) {
                this.options.push(...result.pos_items);
              }
            }
          }).add(() => {
            btn.disabled = false;
            this.loaderService.hide();
          });
      }
    });
    
  }

}
