import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { MatDialog, MatTableDataSource, MatSort } from '@angular/material';
import { Router } from '@angular/router';

import { Restaurant } from '../../restaurant/restaurant';

import { Menu } from '../menu';
import { MenuService } from '../menu.service';

import { MenuDialogComponent } from '../menu-dialog/menu-dialog.component';

@Component({
  selector: 'app-menu-summary',
  templateUrl: './menu-summary.component.html',
  styleUrls: ['./menu-summary.component.scss']
})
export class MenuSummaryComponent implements OnInit, OnDestroy {

  @Input() restaurant: Restaurant;
  columnsToDisplay = ['id', 'name', 'api_created_at'];
  public menuDataSource: MatTableDataSource<Menu>;

  constructor(
    public router: Router,
    private menuService: MenuService,
    public dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.menuService.getByRestaurant(this.restaurant.id).subscribe(menuList => {
      this.menuDataSource = new MatTableDataSource(menuList.data);
    });
  }

  ngOnDestroy() {
  }

  addMenu() {
    const dialogRef = this.dialog.open(MenuDialogComponent, {
      width: '600px',
      data: 'Add Menu'
    });
    dialogRef.componentInstance.event.subscribe((result) => {
      this.createMenu(result.data.name);
    });
  }

  createMenu(name: string) {
    name = name.trim();
    if (!name) { return; }
    const newMenu: Menu = { name } as Menu;
    this.menuService.addMenu(newMenu).subscribe(menu => {
      this.router.navigate(['restaurant', this.restaurant.id, 'menu', menu.id]);
    });
  }

  rowSelected(menu: Menu) {
    this.router.navigate(['restaurant', this.restaurant.id, 'menu', menu.id]);
  }

}
