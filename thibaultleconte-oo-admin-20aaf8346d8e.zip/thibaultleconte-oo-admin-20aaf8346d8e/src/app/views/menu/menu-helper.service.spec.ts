import { TestBed } from '@angular/core/testing';

import { MenuHelperService } from './menu-helper.service';

describe('MenuHelperService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MenuHelperService = TestBed.get(MenuHelperService);
    expect(service).toBeTruthy();
  });
});
