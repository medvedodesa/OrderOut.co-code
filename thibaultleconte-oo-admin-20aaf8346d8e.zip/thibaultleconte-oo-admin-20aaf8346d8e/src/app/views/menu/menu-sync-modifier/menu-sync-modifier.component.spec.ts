import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuSyncModifierComponent } from './menu-sync-modifier.component';

describe('MenuSyncModifierComponent', () => {
  let component: MenuSyncModifierComponent;
  let fixture: ComponentFixture<MenuSyncModifierComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuSyncModifierComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuSyncModifierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
