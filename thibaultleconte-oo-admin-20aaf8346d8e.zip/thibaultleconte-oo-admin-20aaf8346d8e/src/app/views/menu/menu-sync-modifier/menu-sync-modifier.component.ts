import { Component, EventEmitter, Inject, OnInit, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatTableDataSource, MatSort } from '@angular/material';

import { FormControl } from '@angular/forms';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, startWith, switchMap } from 'rxjs/operators';

import { MenuItemModifier, GroupBy } from '../menu';
import { MenuService } from '../menu.service';
import { MenuHelperService } from '../menu-helper.service';

import { SortByPipe } from '../../../pipes/sort-by.pipe';

@Component({
  selector: 'app-menu-sync-modifier',
  templateUrl: './menu-sync-modifier.component.html',
  styleUrls: ['./menu-sync-modifier.component.scss']
})
export class MenuSyncModifierComponent implements OnInit {

  columnsToDisplay = ['name', 'mappedToModifiers'];
  dataSource: MatTableDataSource<(MenuItemModifier | GroupBy)>;
  @ViewChild(MatSort) sort: MatSort;

  myControl = new FormControl('');
  posModifiers: MenuItemModifier[] = [];
  posMenuItemModifiers: MenuItemModifier[] = [];
  filteredPOSMenuItemModifiers: Observable<MenuItemModifier[]>;
  public filteredOptions;

  public event: EventEmitter<any> = new EventEmitter();
  public isUpdated: boolean = false;

  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();

  constructor(
    public dialogRef: MatDialogRef<MenuSyncModifierComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private menuService: MenuService,
    private menuHelperService: MenuHelperService,
    private sortByPipe: SortByPipe,
  ) { }

  ngOnInit() {

    this.dataSource = new MatTableDataSource(this.getDataSourceSortby());
    this.posModifiers = this.data.posModifiers;

    this.switchPOSModifiers(true);

    this.filteredPOSMenuItemModifiers = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => typeof value === 'string' ? this._filter(value, this.myControl) : [])
    );
  }

  ngAfterViewInit() {
    this.dataSource.sortData = (data, sort) => {
      return this.getDataSourceSortby(sort.direction)
    };

    setTimeout(() => {
      this.dataSource.sort = this.sort;
    });
  }

  getDataSourceSortby(order: string = 'asc') {
    let dsMenuItem = Object.assign({}, this.data.dsMenuItem);

    let modifierGroupsData: (MenuItemModifier | GroupBy)[] = [];
    dsMenuItem.modifier_groups.forEach(group => {
      let groupBy = {
        "groupName": group.name,
        "isGroupBy": true,
      };
      modifierGroupsData.push(groupBy);
      group.modifiers = this.sortByPipe.transform(group.modifiers, 'name', order);
      group.modifiers.forEach(modifier => {
        modifierGroupsData.push(modifier);
      });
    });
    return modifierGroupsData;
  }

  // Data Fetch Helper

  getPOSModifier(posModifierId: number) {
    const posMenuItemModifier = this.posModifiers && this.posModifiers.find(entity => entity.id === posModifierId);
    return posMenuItemModifier && posMenuItemModifier.name ? posMenuItemModifier : '';
  }

  // Autocomplete Helpers

  displayFn(menuItemModifier?: MenuItemModifier): string | undefined {
    return menuItemModifier ? menuItemModifier.name : undefined;
  }

  private _filter(value: string, control): MenuItemModifier[] {
    const filterValue = value.toLowerCase();
    this.filteredOptions = this.posMenuItemModifiers.filter(posMenuItemModifier => posMenuItemModifier.name.toLowerCase().includes(filterValue));
    return this.filteredOptions;
  }

  showMagicBtn(modifier) {
    if (this.filteredOptions && this.filteredOptions.length === 0) {
      modifier.showMagicBtn = true;
    }
  }

  // Actions

  onSelectionChanged(deliveryServiceMenuItem: MenuItemModifier, pointOfSaleMenuItem: MenuItemModifier, event) {
    this.mapDSModifierToPOSModifier(deliveryServiceMenuItem, pointOfSaleMenuItem, event);
  }

  mapDSModifierToPOSModifier(dsModifier: MenuItemModifier, posMenuItem: MenuItemModifier, event) {
    let formFieldWrapper = event._elementRef.nativeElement.closest(".form-field-wrapper");
    formFieldWrapper.nextSibling.classList.remove("hide");
    formFieldWrapper.classList.add("hide");
    this.menuService.mapDSModifierToPOSModifier(dsModifier.id, posMenuItem.id).subscribe((modifierItem) => {
      dsModifier = Object.assign(dsModifier, modifierItem);
      this.isUpdated = true;
    }).add(() => {
      formFieldWrapper.nextSibling.classList.add("hide");
      formFieldWrapper.classList.remove("hide");
      this.myControl.setValue(''); // reset the auto-complete value
    });
  }

  resetMappingForDSModifiers(btn, dsModifier: MenuItemModifier) {
    btn.textContent = 'Resetting';
    btn.disabled = true;
    this.menuService.resetMappingForDSModifiers(dsModifier.id).subscribe((menuItemModifier) => {
      dsModifier = Object.assign(dsModifier, menuItemModifier);
      this.isUpdated = true;
    }).add(() => {
      this.myControl.setValue(''); // reset the auto-complete value
    });;
  }

  isGroup(index, item): boolean {
    return item.isGroupBy;
  }

  magicMapModifier(btn, dsModifier) {
    this.menuHelperService.showConfirmDialog().subscribe(result => {
      if (result) {
        let formFieldWrapper = btn.closest(".form-field-wrapper");
        formFieldWrapper.nextSibling.classList.remove("hide");
        formFieldWrapper.classList.add("hide");
        this.menuService.magicMapModifier(this.data.dsMenuItem.id, dsModifier.id, this.data.posId)
          .subscribe((result) => {
            if (result && result.success) {
              dsModifier = Object.assign(dsModifier, result.ds_items[0]);

              // Update DS modifiers
              result.ds_items.forEach(ds_item => {
                if (ds_item.id === dsModifier.id) {
                  dsModifier = Object.assign(dsModifier, ds_item);
                }
              });

              // Update POS modifiers
              this.posMenuItemModifiers = this.posMenuItemModifiers.concat(result.pos_items)
              this.isUpdated = true;
            }
          }).add(() => {
            formFieldWrapper.nextSibling.classList.add("hide");
            formFieldWrapper.classList.remove("hide");
          });
      }
    });
  }

  switchPOSModifiers(showAll: boolean) {
    if (showAll) {
      let modifiersList = JSON.stringify(this.posModifiers);
      this.posMenuItemModifiers = JSON.parse(modifiersList);
    } else {
      this.posMenuItemModifiers = this.posMenuItemModifiers.filter(modifier => {
        return modifier.itemId === this.data.dsMenuItem.mappedToMenuItem;
      });
    }
    this.myControl.setValue('');
  }
}
