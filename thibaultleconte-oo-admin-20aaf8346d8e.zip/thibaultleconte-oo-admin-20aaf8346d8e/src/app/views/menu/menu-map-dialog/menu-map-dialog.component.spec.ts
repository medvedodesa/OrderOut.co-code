import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuMapDialogComponent } from './menu-map-dialog.component';

describe('MenuMapDialogComponent', () => {
  let component: MenuMapDialogComponent;
  let fixture: ComponentFixture<MenuMapDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuMapDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuMapDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
