import { Component, EventEmitter, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

import { MenuItem } from '../menu';
import { MenuService } from '../menu.service';
import { MenuHelperService } from '../menu-helper.service';
import { PointOfSale } from '../../pointofsale/pointofsale';
import { DeliveryService } from '../../deliveryservice/deliveryservice';

@Component({
  selector: 'app-menu-map-dialog',
  templateUrl: './menu-map-dialog.component.html',
  styleUrls: ['./menu-map-dialog.component.scss']
})
export class MenuMapDialogComponent implements OnInit {

  dsMenuItem: MenuItem;
  deliveryService: DeliveryService;
  pointOfSale: PointOfSale;

  myControl = new FormControl('');
  options: MenuItem[] = [];
  filteredOptions: Observable<MenuItem[]>;

  public event: EventEmitter<any> = new EventEmitter();

  isHidden: boolean = false;
  title: string;
  showMagicBtn: boolean = false;

  constructor(
    public dialogRef: MatDialogRef<MenuMapDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private menuService: MenuService,
    private menuHelperService: MenuHelperService
  ) { }

  ngOnInit() {
    this.dsMenuItem = this.data.dsMenuItem;
    this.deliveryService = this.data.deliveryService;
    this.pointOfSale = this.data.pointOfSale;
    this.options = this.data.posMenuItem;

    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => typeof value === 'string' ? this._filter(value) : [])
    );
    this.title = `Map "${this.dsMenuItem.name}" to`;
  }

  displayFn(menuItem?: MenuItem): string | undefined {
    return menuItem ? menuItem.name : undefined;
  }

  private _filter(value: string): MenuItem[] {
    const filterValue = value.toLowerCase();
    let res = this.options.filter(option => option.name.toLowerCase().includes(filterValue));
    if (res && res.length === 0) {
      this.showMagicBtn = true;
    }
    return res;
  }

  onSelectionChanged(deliveryServiceMenuItem: MenuItem, pointOfSaleMenuItem: MenuItem) {
    this.mapDSMenuItemToPOSMenuItem(deliveryServiceMenuItem, pointOfSaleMenuItem);
  }

  mapDSMenuItemToPOSMenuItem(deliveryServiceMenuItem: MenuItem, pointOfSaleMenuItem: MenuItem) {
    this.isHidden = true;
    this.title = `Map "${deliveryServiceMenuItem.name}" to "${pointOfSaleMenuItem.name}"`;
    this.menuService.mapDSMenuItemToPOSMenuItem(deliveryServiceMenuItem.id, pointOfSaleMenuItem.id)
      .subscribe((menuItem) => {
        let catName = deliveryServiceMenuItem.category_name;
        deliveryServiceMenuItem = Object.assign(deliveryServiceMenuItem, menuItem);
        deliveryServiceMenuItem.category_name = catName;
        this.dialogRef.close();
      });
  }

  magicMapItem(btn, dsMenuItem) {
    this.menuHelperService.showConfirmDialog().subscribe(result => {
      if (result) {
        btn.disabled = true;
        this.isHidden = true;
        this.menuService.magicMapItem(dsMenuItem.id, this.pointOfSale.id)
          .subscribe((result) => {
            if (result && result.success === true) {

              // Update DS items
              result.ds_items.forEach(ds_item => {
                if(ds_item.id === dsMenuItem.id) {
                  let catName = dsMenuItem.category_name;
                  dsMenuItem = Object.assign(dsMenuItem, ds_item);
                  dsMenuItem.category_name = catName;
                }
              });

              // Update POS items
              if (result.pos_items && result.pos_items.length > 0) {
                this.options.push(...result.pos_items);
              }
            }
          }).add(() => {
            btn.disabled = false;
            this.isHidden = false;
            this.dialogRef.close();
          });
      }
    });
  }

}
