export interface Menu {
    id: number;
    name: string;
    description: string;
    enabled: boolean;
    is_available: boolean;
    api_created_at: string;
    menu_sections?: MenuSection[];
    service: {
        type: string;
    }
}

export interface MenuList {
    more: boolean;
    previousCursor: string;
    nextCursor: string;
    data: Menu[];
}

export interface MenuSection {
    id: number;
    name: string;
    position: number;
    description: string;
    enabled: boolean;
    is_available: boolean;
    availability: availability[];
    api_created_at: string;
    categories?: MenuCategory[];
}

export interface availability {
    time_periods: time[];
    day_of_week: string;
    enabled: boolean;
}

export interface time {
    start_time: string;
    end_time: string;
}

export interface MenuCategory {
    id: number;
    name: string;
    position: number;
    enabled: boolean;
    menuitems?: MenuItem[];
}

export interface MenuItemsList {
    more: boolean;
    previousCursor: string;
    nextCursor: string;
    data: MenuItem[];
}

export interface MenuItem {
    id: number;
    uuid: string;
    name: string;
    price: number;
    is_available: boolean;
    is_alert?: boolean;
    mappedToMenuItem: number;
    modifier_groups?: ModifierGroup[];
    api_created_at: Date;
    total_modifiers?: number;
    unmapped_modifiers?: number;
    position: number;
    category_name: string;
}

export interface ModifierGroup {
    id: number;
    itemId?: number;
    uuid: string;
    name: string;
    modifiers?: MenuItemModifier[];
    api_created_at: Date;
    position?: number;
    min_permitted: number;
    max_permitted: number;
    is_available: boolean;
}

export interface MenuItemModifier {
    id: number;
    itemId?: number;
    uuid: string;
    name: string;
    price: number;
    is_available: boolean;
    mappedToMenuItemModifier: number;
    api_created_at: Date;
    position: number;
}

export interface GroupBy {
    groupName: string;
    isGroupBy: boolean;
}