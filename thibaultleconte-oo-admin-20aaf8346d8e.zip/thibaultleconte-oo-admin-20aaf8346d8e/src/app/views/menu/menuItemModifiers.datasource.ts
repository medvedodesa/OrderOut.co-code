import { CollectionViewer, DataSource } from '@angular/cdk/collections';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';

import { MenuItemModifier } from './menu';
import { MenuService } from './menu.service';

export class MenuItemModifiersDataSource implements DataSource<MenuItemModifier> {

    private allMenuItemModifiersSubject = new BehaviorSubject<MenuItemModifier[]>([]);

    private loadingSubject = new BehaviorSubject<boolean>(false);

    public loading$ = this.loadingSubject.asObservable();

    constructor(private menuService: MenuService) {}

    connect(collectionViewer: CollectionViewer): Observable<MenuItemModifier[]> {
        return this.allMenuItemModifiersSubject.asObservable();
    }

    disconnect(collectionViewer: CollectionViewer): void {
        this.allMenuItemModifiersSubject.complete();
        this.loadingSubject.complete();
    }

    loadByMenuItem(menuItemId: number) {

        this.loadingSubject.next(true);

        this.menuService.getModifiersForMenuItem(menuItemId).pipe(
            catchError(() => of([])),
            finalize(() => this.loadingSubject.next(false))
        )
        .subscribe(menuItemModifiers => {
            this.loadingSubject.next(false);
            this.allMenuItemModifiersSubject.next(menuItemModifiers);
        });
    }
}
