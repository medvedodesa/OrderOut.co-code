import { Component, Input, OnDestroy } from '@angular/core';
import { ISubscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';

import { Restaurant } from '../../../restaurant/restaurant';
import { Menu } from '../../menu';
import { MenuService } from '../../menu.service';

import { ConfirmationDialogService } from '../../../common/confirmation-dialog/confirmation-dialog.service';

@Component({
  selector: 'app-menu-admin',
  templateUrl: './menu-admin.component.html',
  providers: [ MenuService ],
  styleUrls: ['./menu-admin.component.scss']
})
export class MenuAdminComponent implements OnDestroy {

  private subscription: ISubscription;

  @Input() restaurant: Restaurant;
  @Input() menu: Menu;

  constructor(
    private router: Router,
    private menuService: MenuService,
    public cdService: ConfirmationDialogService,
    ) { }

  ngOnDestroy() {
    if (!this.subscription) { return; }
    this.subscription.unsubscribe();
  }

  deleteMenu() {

    this.cdService.confirm({
      message: {
        name: (this.menu.service && this.menu.service.type) || this.menu.name || 'NO DS',
        type: 'menu'
      }
    }).subscribe(result => {
      if (result) {
        this.subscription = this.menuService.deleteMenu(this.menu.id).subscribe(() => {
          this.router.navigate(['restaurant', this.restaurant.id]);
        });
      }
    });
    
  }

}
