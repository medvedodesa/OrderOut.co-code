import { Component, OnInit, Input } from '@angular/core';
import { MatDialog, MatTableDataSource, MatSort } from '@angular/material';
import { CdkDrag, CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';

import { Restaurant } from '../../../restaurant/restaurant';
import { Menu, MenuSection, availability } from '../../menu';

import { MenuService } from '../../../menu/menu.service';
import { ConfirmationDialogService } from '../../../common/confirmation-dialog/confirmation-dialog.service';

import { MenuSectionAvailabilityDialogComponent } from './menu-section-availability-dialog/menu-section-availability-dialog.component';
import { MenuDialogComponent } from '../../menu-dialog/menu-dialog.component';

@Component({
  selector: 'app-menu-section',
  templateUrl: './menu-section.component.html',
  styleUrls: ['./menu-section.component.scss']
})
export class MenuSectionComponent implements OnInit {

  @Input() restaurant: Restaurant;
  @Input() menu: Menu;
  @Input() editMode: boolean;

  public name: string = 'Name';
  public description: string = 'Description';

  constructor(
    private dialog: MatDialog,
    private menuService: MenuService,
    private cdService: ConfirmationDialogService
  ) { }

  ngOnInit() {}

  toggleEnabled(event, section: MenuSection) {
    section.enabled = event.checked;
    this.updateSection(section);
  }

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.menu.menu_sections, event.previousIndex, event.currentIndex);
    this.setPosition();
  }

  setPosition() {
    this.menu.menu_sections.forEach((section, index) => {
      section.position = index;
    });
  }

  dragStarted(event: {source: CdkDrag}) {
    setTimeout(() => {
      const dropContainer = event.source._dragRef['_dropContainer'];

      if (dropContainer) {
        dropContainer['_cacheOwnPosition']();
        dropContainer['_cacheItemPositions']();
      }
    }, 200);
  }

  dragEnded(event: CdkDragDrop<string[]>) {
  }

  openAvailabilityDialog(section: MenuSection) {
    const dialogRef = this.dialog.open(MenuSectionAvailabilityDialogComponent, {
      width: '600px',
      data: section.availability
    });
    dialogRef.componentInstance.event.subscribe((result) => {
      let data = typeof(result.data) === 'string' ? JSON.parse(result.data) : result.data;
      section.availability = data;
      if (result.update && result.update === true) {
        this.updateSection(section);
      }
    });
  }

  addSection() {
    const dialogRef = this.dialog.open(MenuDialogComponent, {
      width: '600px',
      data: 'Add Section'
    });
    dialogRef.componentInstance.event.subscribe((result) => {
      if(result.data && result.data.name) {
        this.menuService.addSection({
          'menu_sync_id' : this.menu.id,
          'name': result.data.name
        }).subscribe(section => {
          if (section) {
            this.menu.menu_sections ? this.menu.menu_sections.push(section) : this.menu.menu_sections = [section];
          }
        });
      }
    });
  }

  deleteSection(section: MenuSection) {
    this.cdService.confirm({
      message: {
        name: section.name,
        type: 'section'
      }
    }).subscribe(result => {
      if (result) {
        this.menuService.deleteSection(section.id).subscribe((result) => {
          this.menu.menu_sections = this.menu.menu_sections.filter(mSection => mSection.id !== section.id);
        })
      }
    });
  }

  onValueChange(value: string, key: string,  section: MenuSection) {
    value = value && typeof(value) === 'string' ? value.trim() : value;
    if (section[key] !== value ) {
      section[key] = value;
      this.updateSection(section);
    }
  }

  updateSection(section) {
    this.menuService.updateSection(section).subscribe((result) => {
      section.availability = result.availability;
    })
  }

  addPeriod(aTimePeriod, period) {
    let sPeriod = JSON.stringify(period);
    aTimePeriod.push(JSON.parse(sPeriod));
  }

  removePeriod(aTimePeriod, index) {
    aTimePeriod.splice(index, 1);
  }

  addDay(availability, day, index) {
    let sDay = JSON.stringify(day);
    availability.splice((index + 1), 0, JSON.parse(sDay));
  }

  removeDay(availability, day, index) {
    let filterDays = availability.filter(aDay => {
      return aDay.day_of_week === day.day_of_week;
    });
    if(filterDays.length > 1) {
      availability.splice(index, 1);
    }
  }

}
