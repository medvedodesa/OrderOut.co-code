import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuSectionAvailabilityDialogComponent } from './menu-section-availability-dialog.component';

describe('MenuSectionAvailabilityDialogComponent', () => {
  let component: MenuSectionAvailabilityDialogComponent;
  let fixture: ComponentFixture<MenuSectionAvailabilityDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuSectionAvailabilityDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuSectionAvailabilityDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
