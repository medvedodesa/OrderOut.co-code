import { Component, EventEmitter, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-menu-section-availability-dialog',
  templateUrl: './menu-section-availability-dialog.component.html',
  styleUrls: ['./menu-section-availability-dialog.component.scss']
})
export class MenuSectionAvailabilityDialogComponent {

  public event: EventEmitter<any> = new EventEmitter();

  public title: string= 'Edit weekly hours';
  public hours: any = [];
  public minutes: any = [];
  public periods: any = [];

  public clonedData: string;

  constructor(
    public dialogRef: MatDialogRef<MenuSectionAvailabilityDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {
    this.hours.length === 0 && this.init();
    this.clonedData = JSON.stringify(data);
  }

  init() {

    // set Hours 
    for(let i=1; i<=12; i++) {
      let label = i<10 ? "0"+i : i;
      let obj = {
        label: label.toString(),
        value: i
      }
      this.hours.push(obj);
    }

    // set Minutes
    for(let i=0; i<60; i++) {
      let label = i<10 ? "0"+i : i;
      let obj = {
        label: label.toString(),
        value: i
      }
      this.minutes.push(obj);
    }

    // set periods
    let aPeriods = ["AM","PM"];
    for(let i=0; i<aPeriods.length; i++) {
      let obj = {
        label: aPeriods[i],
        value: aPeriods[i]
      }
      this.periods.push(obj);
    }

    // Set Time periods if empty
    let defaultTimePeriod;
    for(let i=0; i< this.data.length; i++) {
      if(this.data[i].time_periods && this.data[i].time_periods.length !== 0) {
        defaultTimePeriod = this.data[i].time_periods;
      }
    }
    defaultTimePeriod = JSON.stringify(defaultTimePeriod);
    for(let i=0; i< this.data.length; i++) {
      if(this.data[i].time_periods && this.data[i].time_periods.length === 0) {
        this.data[i].time_periods = JSON.parse(defaultTimePeriod);
      }
    }
  }

  onNoClick(): void {
    // Reset data when the user clicks on cancel
    this.event.emit({data: this.clonedData});
    this.dialogRef.close();
  }

  onSubmit(): void {
    this.event.emit({data: this.data, update: true});
    this.dialogRef.close();
  }

  toggleEnabled(event, day) {
    day.enabled = event.checked;
  }

  updateStartHours(event, timePeriod): string {
    let sTime = this.updateHours(event.value, timePeriod.start_time);
    this.setNextDay(event, sTime, timePeriod.end_time);
    return sTime;
  }

  updateStartMinutes(event, timePeriod): string {
    let sTime = this.updateMinutes(event.value, timePeriod.start_time);
    this.setNextDay(event, sTime, timePeriod.end_time);
    return sTime;
  }

  updateStartPeriod(event, timePeriod): string {
    let sTime = this.updatePeriod(event.value, timePeriod.start_time);
    this.setNextDay(event, sTime, timePeriod.end_time);
    return sTime;
  }

  updateEndHours(event, timePeriod): string {
    let eTime = this.updateHours(event.value, timePeriod.end_time);
    this.setNextDay(event, timePeriod.start_time, eTime);
    return eTime;
  }

  updateEndMinutes(event, timePeriod): string {
    let eTime = this.updateMinutes(event.value, timePeriod.end_time);
    this.setNextDay(event, timePeriod.start_time, eTime);
    return eTime;
  }

  updateEndPeriod(event, timePeriod): string {
    let eTime = this.updatePeriod(event.value, timePeriod.end_time);
    this.setNextDay(event, timePeriod.start_time, eTime);
    return eTime;
  }

  updateHours(value, time): string {
    let hours = parseInt(time.split(':')[0]);
    if (hours > 12) {
      value = value + 12;
    }
    value = (value > 9 ? '' : '0') + value + ':';
    return time.replace(/.*:/gm, value);
  }

  updateMinutes(value, time): string {
    value = ':' + (value > 9 ? '' : '0') + value;
    return time.replace(/:.*/gm, value);
  }

  updatePeriod(value, time): string {
    let hours = parseInt(time.split(':')[0]);
    if (value === "AM" && hours > 11) {
      hours = hours - 12;
      hours = (hours > 9 ? '' : '0') + hours as any;
      time = hours + ':' + time.split(':')[1];
    } else if (value === "PM" && hours < 13) {
      time = (hours + 12) + ':' + time.split(':')[1];
    }
    return time; 
  }

  setNextDay(event, startTime, endTime) {
    let nextDay = event.source._elementRef.nativeElement.closest('.weekday').querySelector('.next-day').classList;
    let isNextDay = new Date("1990-01-01T" + startTime + "Z") > new Date("1990-01-01T" + endTime + "Z");
    isNextDay ? nextDay.add("show") : nextDay.remove('show');
  }

  copyDays(event) {

    let daysWrapper = event.target.closest('.mat-dialog-actions').previousSibling;

    if (daysWrapper.hasChildNodes()) {

      /**
        * Assumption: First index object would be Monday.
      **/
      let mondayTimePerios = JSON.stringify(this.data[0].time_periods);
      this.data.forEach(day => {
        day.time_periods = JSON.parse(mondayTimePerios);
      });

      /**
       * Reset Next Day status for all the days.
      **/
      // let openTime = this.data[0].time_periods[0].start_time;
      // let closedTime = this.data[0].time_periods[0].end_time;
      // let isNextDay = new Date("1990-01-01T" + openTime + "Z") > new Date("1990-01-01T" + closedTime + "Z");
      // daysWrapper.querySelectorAll('.next-day').forEach(function(nextday) {
      //   nextday.classList.toggle('show', isNextDay);
      // });

    }

  }

}
