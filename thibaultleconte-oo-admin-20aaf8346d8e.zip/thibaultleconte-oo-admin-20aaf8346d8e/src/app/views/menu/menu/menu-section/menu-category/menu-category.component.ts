import { Component, OnInit, Input } from '@angular/core';
import { MatDialog } from '@angular/material';
import { Router } from '@angular/router';

import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { Restaurant } from '../../../../restaurant/restaurant';
import { Menu, MenuCategory, MenuSection } from '../../../menu';

import { MenuService } from '../../../../menu/menu.service';
import { ConfirmationDialogService } from '../../../../common/confirmation-dialog/confirmation-dialog.service';
import { MenuDialogComponent } from '../../../menu-dialog/menu-dialog.component';

@Component({
  selector: 'app-menu-category',
  templateUrl: './menu-category.component.html',
  styleUrls: ['./menu-category.component.scss']
})
export class MenuCategoryComponent implements OnInit {

  @Input() restaurant: Restaurant;
  @Input() menu: Menu;
  @Input() section: MenuSection;
  @Input() menuCategories: MenuCategory[];
  @Input() editMode: boolean;

  public name: string = 'Name';

  constructor(
    private router: Router,
    private dialog: MatDialog,
    private menuService: MenuService,
    public cdService: ConfirmationDialogService
  ) { }

  ngOnInit() {}

  toggleEnabled(event, category: MenuCategory) {
    category.enabled = event.checked;
    this.updateCategory(category);
  }

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.menuCategories, event.previousIndex, event.currentIndex);
    this.setPosition();
  }

  setPosition() {
    this.menuCategories.forEach((category, index) => {
      category.position = index;
    });
  }

  categorySelected(category: MenuCategory) {
    this.router.navigate(['restaurant', this.restaurant.id, 'menu', this.menu.id, 'category', category.id]);
  }

  addCategory() {
    const dialogRef = this.dialog.open(MenuDialogComponent, {
      width: '600px',
      data: 'Add Category'
    });
    dialogRef.componentInstance.event.subscribe((result) => {
      if(result.data && result.data.name) {
        this.menuService.addCategory({
          'menu_sync_id' : this.menu.id,
          'section_id': this.section.id,
          'name': result.data.name
        }).subscribe(category => {
          if (category) {
            this.section.categories ? this.section.categories.push(category) : this.section.categories = [category];
          }
        });
      }
    });
  }

  deleteCategory(category: MenuCategory) {
    this.cdService.confirm({
      message: {
        name: category.name,
        type: 'category'
      }
    }).subscribe(result => {
      if (result) {
        this.menuService.deleteCategory(category.id).subscribe((result) => {
          this.section.categories = this.section.categories.filter(mCategory => mCategory.id !== category.id);
        })
      }
    });
  }

  onNameChange(value: string, category: MenuCategory) {
    value = value && value.trim();
    if (category.name !== value ) {
      category.name = value;
      this.updateCategory(category);
    }
  }

  updateCategory(category: MenuCategory) {
    this.menuService.updateCategory(category).subscribe((result) => {
      console.log(result);
    });
  }

}
