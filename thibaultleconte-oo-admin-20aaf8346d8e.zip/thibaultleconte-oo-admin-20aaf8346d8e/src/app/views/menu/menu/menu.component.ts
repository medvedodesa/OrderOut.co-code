import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';
import { ISubscription } from 'rxjs/Subscription';

import { Account } from '../../account/account';
import { AccountRestaurant, Restaurant } from '../../restaurant/restaurant';
import { Menu, MenuSection } from '../menu';
import { MenuHelperService } from '../menu-helper.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MenuComponent implements OnInit {

  private subscription: ISubscription;

  public accountRestaurant: AccountRestaurant;
  public account: Account;
  public restaurant: Restaurant;
  public menu: Menu;
  public sections: MenuSection[];
  public editMode: boolean;

  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();

  constructor(
    private route: ActivatedRoute,
    private menuHelperService: MenuHelperService
  ) {}

  ngOnInit() {
    this.accountRestaurant = this.route.snapshot.data.accountRestaurant;
    this.account = this.accountRestaurant.account;
    this.restaurant = this.accountRestaurant.restaurant;
    this.menu = this.route.snapshot.data.menu;
    this.editMode = this.route.snapshot.data.edit === true ? true : false;

    this.loadingSubject.next(true);
    this.menuHelperService.getFullMenu(this.menu.id).pipe(
      catchError(() => of([] as any)),
      finalize(() => {
          this.loadingSubject.next(false);
        })
      ).
      subscribe(function(menu_sections) {
        this.sections = menu_sections[0];
        this.menu.menu_sections = menu_sections[0]; // Get all menu sections with array wrapper so accessed with 0th index
        this.menuHelperService.menu = this.menu;
        this.menuHelperService.setAlertConfig();
      }.bind(this));

  }

  ngOnDestroy() {
    if (!this.subscription) { return; }
    this.subscription.unsubscribe();
  }
}
