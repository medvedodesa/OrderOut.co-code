import { Component, OnInit, Input } from '@angular/core';

import { Account } from '../../../account/account';
import { Restaurant } from '../../../restaurant/restaurant';
import { Menu } from '../../menu';
import { breadcrumb } from '../../../common/breadcrumb/breadcrumb';

import { BreadcrumbService } from '../../../common/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-menu-details',
  templateUrl: './menu-details.component.html',
  styleUrls: ['./menu-details.component.scss']
})
export class MenuDetailsComponent implements OnInit {

  @Input() account: Account;
  @Input() restaurant: Restaurant;
  @Input() menu: Menu;
  @Input() editMode: boolean;

  public breadcrumbList: breadcrumb[] = [];

  constructor(
    private breadcrumbService: BreadcrumbService
  ) { }

  ngOnInit() {
    this.breadcrumbService.resetBreadcrumbList();
    this.breadcrumbList = this.breadcrumbService.getMenu(
      this.account,
      this.restaurant,
      this.menu,
    );
  }

}
