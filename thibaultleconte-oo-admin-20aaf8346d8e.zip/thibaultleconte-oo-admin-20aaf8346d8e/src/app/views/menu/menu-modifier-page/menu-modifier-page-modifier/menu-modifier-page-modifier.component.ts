import { Component, Input, OnInit } from '@angular/core';
import { CdkDrag, CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { MatDialog } from '@angular/material';

import { Menu, ModifierGroup, MenuItemModifier } from '../../menu';

import { MenuService } from '../../../menu/menu.service';
import { ConfirmationDialogService } from '../../../common/confirmation-dialog/confirmation-dialog.service';
import { MenuDialogComponent } from '../../menu-dialog/menu-dialog.component';

@Component({
  selector: 'app-menu-modifier-page-modifier',
  templateUrl: './menu-modifier-page-modifier.component.html',
  styleUrls: ['./menu-modifier-page-modifier.component.scss']
})
export class MenuModifierPageModifierComponent implements OnInit {

  @Input() menu: Menu;
  @Input() modifier_group: ModifierGroup;
  @Input() editMode: boolean;

  modifiers: MenuItemModifier[];

  constructor(
    private dialog: MatDialog,
    private menuService: MenuService,
    public cdService: ConfirmationDialogService
  ) { }

  ngOnInit() {
    this.modifiers = this.modifier_group.modifiers;
  }

  toggleEnabled(event, modifier: MenuItemModifier) {
    modifier.is_available = event.checked;
    this.updateModifier(modifier);
  }

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.modifiers, event.previousIndex, event.currentIndex);
    this.setPosition();
  }

  setPosition() {
    this.modifiers.forEach((modifier, index) => {
      modifier.position = index;
    });
  }

  dragStarted(event: {source: CdkDrag}) {
    setTimeout(() => {
      const dropContainer = event.source._dragRef['_dropContainer'];

      if (dropContainer) {
        dropContainer['_cacheOwnPosition']();
        dropContainer['_cacheItemPositions']();
      }
    }, 200);
  }

  dragEnded(event: CdkDragDrop<string[]>) {
  }

  addModifier() {
    const dialogRef = this.dialog.open(MenuDialogComponent, {
      width: '600px',
      data: 'Add Modifier'
    });
    dialogRef.componentInstance.event.subscribe((result) => {
      if(result.data && result.data.name) {
        this.menuService.addModifier({
          'menu_sync_id' : this.menu.id,
          'modifier_group_id': this.modifier_group.id,
          'name': result.data.name
        }).subscribe(modifier => {
          if (modifier) {
            this.modifiers ? this.modifiers.push(modifier) : this.modifiers = [modifier];
          }
        });
      }
    });
  }

  deleteModifier(modifier: MenuItemModifier) {
    this.cdService.confirm({
      message: {
        name: modifier.name,
        type: 'modifier'
      }
    }).subscribe(result => {
      if (result) {
        this.menuService.deleteModifier(modifier.id).subscribe((result) => {
          this.modifiers = this.modifiers.filter(mModifier => mModifier.id !== modifier.id);
        });
      }
    });
  }

  onValueChange(value: string, key: string,  modifier: MenuItemModifier) {
    value = value && typeof(value) === 'string' ? value.trim() : value;
    if (modifier[key] !== value ) {
      modifier[key] = value;
      this.updateModifier(modifier);
    }
  }

  updateModifier(modifier: MenuItemModifier) {
    this.menuService.updateModifier(modifier).subscribe((result) => {
      console.log(result);
    });
  }

}
