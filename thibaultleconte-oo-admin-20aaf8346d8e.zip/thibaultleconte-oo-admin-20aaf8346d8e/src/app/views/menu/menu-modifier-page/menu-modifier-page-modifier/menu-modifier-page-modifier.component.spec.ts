import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuModifierPageModifierComponent } from './menu-modifier-page-modifier.component';

describe('MenuModifierPageModifierComponent', () => {
  let component: MenuModifierPageModifierComponent;
  let fixture: ComponentFixture<MenuModifierPageModifierComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuModifierPageModifierComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuModifierPageModifierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
