import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuModifierPageComponent } from './menu-modifier-page.component';

describe('MenuModifierPageComponent', () => {
  let component: MenuModifierPageComponent;
  let fixture: ComponentFixture<MenuModifierPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuModifierPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuModifierPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
