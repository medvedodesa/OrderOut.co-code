import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { MenuItem } from '../menu';
import { MenuService } from '../menu.service';

@Injectable()
export class MenuModifierResolve implements Resolve<number> {

    constructor(private menuService: MenuService) { }

    resolve(route: ActivatedRouteSnapshot) {
        return route.params.itemId;
    }
}