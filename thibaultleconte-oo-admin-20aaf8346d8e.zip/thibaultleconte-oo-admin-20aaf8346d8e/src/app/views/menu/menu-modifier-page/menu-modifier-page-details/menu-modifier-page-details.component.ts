import { Component, Input, OnInit } from '@angular/core';

import { Account } from 'src/app/views/account/account';
import { Restaurant } from 'src/app/views/restaurant/restaurant';
import { Menu, MenuSection, MenuCategory, MenuItem } from '../../menu';
import { breadcrumb } from '../../../common/breadcrumb/breadcrumb';

import { AccountService } from '../../../account/account.service';
import { BreadcrumbService } from '../../../common/breadcrumb/breadcrumb.service';
import { MenuHelperService } from '../../menu-helper.service';

@Component({
  selector: 'app-menu-modifier-page-details',
  templateUrl: './menu-modifier-page-details.component.html',
  styleUrls: ['./menu-modifier-page-details.component.scss']
})
export class MenuModifierPageDetailsComponent implements OnInit {

  @Input() account: Account;
  @Input() restaurant: Restaurant;
  @Input() menu: Menu;
  @Input() category: MenuCategory;
  @Input() item: MenuItem;
  @Input() editMode: boolean;

  public section: MenuSection;
  public breadcrumbList: breadcrumb[] = [];

  constructor(
    private accountService: AccountService,
    private breadcrumbService: BreadcrumbService,
    private menuHelperService: MenuHelperService
  ) { }

  ngOnInit() {
    this.section = this.menuHelperService.getMenuSection(this.category.id);

    this.breadcrumbService.resetBreadcrumbList();
    this.breadcrumbList = this.breadcrumbService.getModifier(
      this.account,
      this.restaurant,
      this.menu,
      this.section,
      this.category,
      this.item
    );

  }

}
