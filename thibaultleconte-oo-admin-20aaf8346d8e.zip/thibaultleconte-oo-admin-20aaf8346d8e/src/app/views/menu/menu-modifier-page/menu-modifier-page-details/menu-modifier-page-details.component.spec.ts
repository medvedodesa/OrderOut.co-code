import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuModifierPageDetailsComponent } from './menu-modifier-page-details.component';

describe('MenuModifierPageDetailsComponent', () => {
  let component: MenuModifierPageDetailsComponent;
  let fixture: ComponentFixture<MenuModifierPageDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuModifierPageDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuModifierPageDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
