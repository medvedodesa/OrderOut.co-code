import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CdkDrag, CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';
import { MatDialog } from '@angular/material';

import { Restaurant } from 'src/app/views/restaurant/restaurant';
import { Menu, MenuCategory, MenuItem, ModifierGroup } from '../../menu';

import { MenuService } from '../../../menu/menu.service';
import { ConfirmationDialogService } from '../../../common/confirmation-dialog/confirmation-dialog.service';
import { MenuDialogComponent } from '../../menu-dialog/menu-dialog.component';

@Component({
  selector: 'app-menu-modifier-page-modifier-group',
  templateUrl: './menu-modifier-page-modifier-group.component.html',
  styleUrls: ['./menu-modifier-page-modifier-group.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MenuModifierPageModifierGroupComponent implements OnInit {

  @Input() restaurant: Restaurant;
  @Input() menu: Menu;
  @Input() category: MenuCategory;
  @Input() item: MenuItem;
  @Input() editMode: boolean;

  modifier_groups: ModifierGroup[];

  constructor(
    private route: ActivatedRoute,
    private dialog: MatDialog,
    private menuService: MenuService,
    public cdService: ConfirmationDialogService
  ) { }

  ngOnInit() {
    this.modifier_groups = this.item.modifier_groups;
  }

  ngAfterViewInit() {
    this.route.fragment.subscribe((fragment: string) => { 
      if (fragment && document.getElementById(fragment) != null) {
        document.getElementById(fragment).scrollIntoView({ behavior: "smooth" });
      }
    });
  }

  toggleEnabled(event, modifier_group: ModifierGroup) {
    modifier_group.is_available = event.checked;
    this.updateModifierGroup(modifier_group);
  }

  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.modifier_groups, event.previousIndex, event.currentIndex);
    this.setPosition();
  }

  setPosition() {
    this.modifier_groups.forEach((modifier_group, index) => {
      modifier_group.position = index;
    });
  }

  dragStarted(event: {source: CdkDrag}) {
    setTimeout(() => {
      const dropContainer = event.source._dragRef['_dropContainer'];

      if (dropContainer) {
        dropContainer['_cacheOwnPosition']();
        dropContainer['_cacheItemPositions']();
      }
    }, 200);
  }

  dragEnded(event: CdkDragDrop<string[]>) {
  }

  addModifierGroup() {
    const dialogRef = this.dialog.open(MenuDialogComponent, {
      width: '600px',
      data: 'Add Modifier Group'
    });
    dialogRef.componentInstance.event.subscribe((result) => {
      if(result.data && result.data.name) {
        this.menuService.addModifierGroup({
          'menu_sync_id' : this.menu.id,
          'item_id': this.item.id,
          'name': result.data.name
        }).subscribe(modifierGroup => {
          if (modifierGroup) {
            this.modifier_groups ? this.modifier_groups.push(modifierGroup) : this.modifier_groups = [modifierGroup];
          }
        });
      }
    });
  }

  deleteModifierGroup(modifier_group: ModifierGroup) {
    this.cdService.confirm({
      message: {
        name: modifier_group.name,
        type: 'modifier group'
      }
    }).subscribe(result => {
      if (result) {
        this.menuService.deleteModifierGroup(modifier_group.id).subscribe((result) => {
          this.modifier_groups = this.modifier_groups.filter(mModifierGroup => mModifierGroup.id !== modifier_group.id);
        });
      }
    });
  }

  onValueChange(value: string, key: string,  modifier_group: ModifierGroup) {
    value = value && typeof(value) === 'string' ? value.trim() : value;
    if (modifier_group[key] !== value ) {
      modifier_group[key] = value;
      this.updateModifierGroup(modifier_group);

      if(key === 'max_permitted') {
        this.resetAlertConfig(this.category, this.item);
      }
    }
  }

  updateModifierGroup(modifier_group: ModifierGroup) {
    this.menuService.updateModifierGroup(modifier_group).subscribe((result) => {
      console.log(result);
    });
  }

  resetAlertConfig(category: MenuCategory, menuitem: MenuItem) {
    if(menuitem && menuitem.modifier_groups && menuitem.modifier_groups.length > 0) {

      let show_alert: boolean = false;
      menuitem.modifier_groups.forEach((modifier_group) => {
        if (modifier_group.modifiers) {
          let count = 0;
          modifier_group.modifiers.forEach((modifier, i) => {
            modifier.is_available === true ? count++ : '';
          });
        
          if (modifier_group.max_permitted > count || modifier_group.min_permitted > count) {
            modifier_group['alert_setting'] = {
              alert: true
            }
            show_alert = true;
          } else {
            modifier_group['alert_setting'] = {
              alert: false
            }
          }
        }
      });
      if (show_alert === false) {
        category["is_alert"] = false;
        menuitem["is_alert"] = false;
      } else {
        category["is_alert"] = true;
        menuitem["is_alert"] = true;
      }
    }
  }

}
