import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuModifierPageModifierGroupComponent } from './menu-modifier-page-modifier-group.component';

describe('MenuModifierPageModifierGroupComponent', () => {
  let component: MenuModifierPageModifierGroupComponent;
  let fixture: ComponentFixture<MenuModifierPageModifierGroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuModifierPageModifierGroupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuModifierPageModifierGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
