export interface MenuSync {
    id: number;
    restaurant: number;
    service: number;
    fetch_menu_status: string;
    process_menu_status: string;
    map_total_menu_items: number;
    map_mapped_menu_items: number;
    map_unmapped_menu_items: number;
    map_total_menu_modifiers: number;
    map_mapped_menu_modifiers: number;
    map_unmapped_menu_modifiers: number;
    api_updated_at?: string;
}

export interface FetchTask {
    id: number;
    category: string;
    name: string;
    scheduled_at: Date;
    executed_at: Date;
    api_created_at: Date;
}