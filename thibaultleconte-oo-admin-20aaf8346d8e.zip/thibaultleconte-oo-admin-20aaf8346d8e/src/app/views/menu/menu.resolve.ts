import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Menu } from './menu';
import { MenuService } from './menu.service';

@Injectable()
export class MenuResolve implements Resolve<Menu> {

    constructor(private menuService: MenuService) { }

    resolve(route: ActivatedRouteSnapshot) {
        return this.menuService.getByMenuSyncId(route.params.menuId);
    }
}