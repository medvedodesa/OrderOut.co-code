import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { environment } from '../../../environments/environment';
import { ApiService } from '../../core/api.service';

@Injectable({
  providedIn: 'root'
})
export class RequestsService {

  public showLoader: boolean = true;
  public noRecord: boolean;
  public length: number = 100;

  constructor(private api: ApiService) {}

  getRequestsBySearch(params): Observable<any> {
    const url = `${environment.core_backend_url}core/urlfetch/search`;
    return this.api.get(url, params);
  }

}
