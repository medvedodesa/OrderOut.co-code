import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

import { RequestsService } from '../requests.service';

@Component({
  selector: 'app-requests',
  templateUrl: './requests.component.html',
  styleUrls: ['./requests.component.scss']
})
export class RequestsComponent implements OnInit {

  @Input('name') name: string;
  @Input('id') id: string;


  constructor(
    private router: Router,
    public requestsService: RequestsService
  ) {
    this.requestsService.noRecord = undefined;
  }

  ngOnInit() { }

  getAllRequests() {
    this.router.navigate(['requests', this.name, this.id]);
  }

}
