import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { RequestsService } from '../requests.service';
import { AppService } from '../../../service/app.service';
import { MessageService } from '../../../service/messages/message.service';

@Component({
  selector: 'app-requests-page',
  templateUrl: './requests-page.component.html',
  styleUrls: ['./requests-page.component.scss']
})
export class RequestsPageComponent implements OnInit {

  public entity_name: string;
  public entity_id: string;

  public item_per_page = 25;
  public page = 1;

  @ViewChild('requestsTable') requestsTable;
  @ViewChild('paginationConfig') paginationConfig;

  constructor(
    private route: ActivatedRoute,
    public requestsService: RequestsService,
    public appService: AppService,
    public messageService: MessageService
  ) { }

  ngOnInit() {
    this.entity_name = this.route.snapshot.params.name;
    this.entity_id = this.route.snapshot.params.id;
  }

  onPaginationChange(data) {
    if (this.item_per_page === data.pageSize) {
      this.page = data.pageIndex + 1;
    } else {
      this.paginationConfig.paginator.firstPage();
      this.page = 1;
      this.item_per_page = data.pageSize;
    }

    this.requestsService.showLoader = true;
    this.requestsTable.getRequestsBySearch({
      item_per_page: this.item_per_page,
      page: this.page
    });
  }

}
