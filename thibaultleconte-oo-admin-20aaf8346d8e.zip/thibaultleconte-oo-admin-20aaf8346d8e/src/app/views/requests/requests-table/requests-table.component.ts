import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatTableDataSource } from "@angular/material";

import { RequestsService } from '../requests.service';
import { AppService } from '../../../service/app.service';
import { MessageDgService } from '../../common/message-dg/message-dg.service';
import { events_messages } from '../../common/message-dg/message-dg';
import { environment } from '../../../../environments/environment';

import { serviceTypes } from '../requests';

@Component({
  selector: 'app-requests-table',
  templateUrl: './requests-table.component.html',
  styleUrls: ['./requests-table.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class RequestsTableComponent implements OnInit {

  @Input('name') name: string;
  @Input('id') id: string;
  @Input('item_per_page') item_per_page?: number;

  public columnsToDisplay = ['id', 'service', 'method', 'statuscode', 'success', 'api_created_at', 'admin_url'];
  public expandedElement;
  public dataSource: MatTableDataSource<any>;
  public noRecord: boolean;
  public requestsOptions = {
    entity_name: '',
    entity_id: '',
    item_per_page: 25,
    page: 1
  }
  @ViewChild('paginationConfig') paginationConfig;

  constructor(
    private requestsService: RequestsService,
    public appService: AppService,
    public msgDgService: MessageDgService
  ) { }

  ngOnInit() {
    this.requestsOptions.entity_name = this.name;
    this.requestsOptions.entity_id = this.id;
    this.requestsOptions.item_per_page = this.item_per_page ? this.item_per_page : 25;

    this.getRequestsBySearch();
  }

  getRequestsBySearch(options = {}) {
    this.requestsOptions = Object.assign({}, this.requestsOptions, options);
    
    this.requestsService.getRequestsBySearch(this.requestsOptions).subscribe(requests => {
      this.noRecord = requests.data.length === 0 ? true : false;

      this.requestsService.noRecord = this.noRecord;
      this.requestsService.length = requests.count;

      this.dataSource = new MatTableDataSource(requests.data);
    }).add(() => {
      this.requestsService.showLoader = false;
    });
  }

  rowSelected(request) {
    if (request && request.id) {
      this.appService.openExternalURL( environment.core_backend_url + 'infrastructure/admin/urlfetch/' + request.id)
    } else {
      this.msgDgService.openMsgDialog(events_messages.ADMIN_URL);
    }
  }

  getServiceType(id: number): any {
    return serviceTypes[id];
  }

}
