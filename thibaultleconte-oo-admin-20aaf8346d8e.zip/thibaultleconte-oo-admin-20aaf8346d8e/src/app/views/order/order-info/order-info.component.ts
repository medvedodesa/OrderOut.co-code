import { Component, OnInit, Input } from '@angular/core';

import { Order } from '../order';
import { OrderService } from '../order.service';
import { LoaderService } from '../../../service/loader.service';

@Component({
  selector: 'app-order-info',
  templateUrl: './order-info.component.html',
  styleUrls: ['./order-info.component.scss']
})
export class OrderInfoComponent implements OnInit {

  @Input() order: Order;

  constructor(
    private orderService: OrderService,
    private loaderService: LoaderService,
  ) { }

  ngOnInit() {
  }

  saveOrderToPointOfSale() {
    this.orderService.saveOrderToPointOfSale(this.order.id).subscribe(() => {
      console.log(`Saving Order to Point Of Sale`);
    });
  }

  printOrder() {
    this.orderService.printOrder(this.order.id).subscribe(() => {
      console.log(`Printing Order`);
    });
  }

  cancelOrder() {
    this.orderService.cancelOrder(this.order.id).subscribe(() => {
      console.log(`Canceling Order`);
    });
  }

  refreshOrder() {
    this.loaderService.show();
    this.orderService.getOrder(this.order.id).subscribe(order => {
      this.order = order;
      this.loaderService.hide();
    });
  }

}
