import { CollectionViewer, DataSource } from '@angular/cdk/collections';
import { Subject, BehaviorSubject, Observable, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';

import { Order, OrdersList } from './order';
import { OrderService } from './order.service';

export class OrdersDataSource implements DataSource<Order> {

    private allOrdersSubject = new BehaviorSubject<Order[]>([]);

    private loadingSubject = new BehaviorSubject<boolean>(false);
    public loading$ = this.loadingSubject.asObservable();

    private _ordersList: Subject<OrdersList> = new Subject<OrdersList>();
    public ordersListObs = this._ordersList.asObservable();

    private ordersList: OrdersList;

    constructor(private orderService: OrderService) { }

    connect(collectionViewer: CollectionViewer): Observable<Order[]> {
        return this.allOrdersSubject.asObservable();
    }

    disconnect(collectionViewer: CollectionViewer): void {
        this.allOrdersSubject.complete();
        this.loadingSubject.complete();
    }

    loadOrders(options) {
        this.loadingSubject.next(true);

        this.orderService.getOrders(options).pipe(
            catchError(() => of([])),
            finalize(() => {
                this.loadingSubject.next(false);
            })
        )
            .subscribe(orders => {
                this.ordersList = orders as OrdersList;
                this.allOrdersSubject.next(this.ordersList.data);
                this._ordersList.next(this.ordersList);
            });
    }
}
