import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import * as _ from 'lodash';

import { environment } from '../../../environments/environment';
import { ApiService } from './../../core/api.service';
import { Order, OrdersList } from './order';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  ordersUrl = environment.backend_url + 'order/list';
  orderUrl = environment.backend_url + 'order';

  constructor(private api: ApiService) {}

  getOrders(options): Observable<OrdersList> {

    options = _.pickBy(options);

    return this.api.get(this.ordersUrl, options);
  }

  getOrder(orderId: number): Observable<Order> {
    const url = `${this.orderUrl}/${orderId}`;
    return this.api.get(url);
  }

  saveOrderToPointOfSale(orderId: number) {
    const url = `${this.orderUrl}/${orderId}/save_to_pos`;
    return this.api.put(url);
  }

  printOrder(orderId: number) {
    const url = `${this.orderUrl}/${orderId}/print`;
    return this.api.put(url);
  }

  cancelOrder(orderId: number) {
    const url = `${this.orderUrl}/${orderId}/cancel`;
    return this.api.put(url);
  }

}
