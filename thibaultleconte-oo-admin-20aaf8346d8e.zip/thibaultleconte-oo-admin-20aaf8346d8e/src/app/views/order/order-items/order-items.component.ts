import { Component, OnInit, Input } from '@angular/core';
import { Order, OrderItem } from '../order';

@Component({
  selector: 'app-order-items',
  templateUrl: './order-items.component.html',
  styleUrls: ['./order-items.component.scss']
})
export class OrderItemsComponent implements OnInit {

  @Input() order: Order;

  public columnsToDisplay = ['item_name', 'qty', 'unit_price', 'price', 'modifiers', 'store_instructions'];

  constructor() { }

  ngOnInit() {}

}
