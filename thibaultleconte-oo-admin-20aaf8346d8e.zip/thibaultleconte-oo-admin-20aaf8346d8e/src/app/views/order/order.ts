import { DeliveryService } from '../deliveryservice/deliveryservice';
import { Account } from '../account/account'
import { MenuItem, MenuItemModifier } from '../menu/menu';
import { Restaurant } from '../restaurant/restaurant';
import { PointOfSale } from '../pointofsale/pointofsale';
import { filters } from '../common/data-filter/data-filter';

export interface Order {
    id: number;
    account: Account;
    restaurant: Restaurant;
    status: string;
    type: string;
    order_items: OrderItem[];
    customer_name: string;
    customer_phone: string;
    point_of_sale: PointOfSale;
    point_of_sale_uuid: string;
    delivery_service: DeliveryService;
    delivery_service_uuid: string;
    delivery_service_short_uuid: string;
    charge_customer_delivery_fee: number;
    charge_tax: number;
    charge_subtotal: number;
    charge_fee: number;
    charge_total: number;
    charge_mode: string;
    store_instructions: string;
    delivery_instructions: string;
    delivery_address: string;
    delivery_city: string;
    delivery_state: string;
    delivery_zip: number;
    charge_tip: number;
    ready_by: string;
    api_created_at: Date;
    api_updated_at: Date;
}

export interface OrdersList {
    count: number;
    item_per_page: number;
    next: boolean;
    prev: boolean;
    page: number;
    data: Order[];
    delivery_services_available: any;
    next_cursor: String;
    prev_cursor: String;
}

export interface OrderItem {
    id: number;
    menu_item: MenuItem;
    modifiers: [OrderItemModifier];
    quantity: number;
    price: number;
    store_instructions: string;
    api_created_at: Date;
}

export interface OrderItemModifier {
    id: number;
    modifier: MenuItemModifier;
    price: number;
    api_created_at: Date;
}

export interface OrderOptions extends filters{
    account_id: number;
    restaurant_id: String;
    from_timestamp: number;
    to_timestamp: number;
    page: number;
    item_per_page: number;
    sort_order: String;
    delivery_service_type: String;
}