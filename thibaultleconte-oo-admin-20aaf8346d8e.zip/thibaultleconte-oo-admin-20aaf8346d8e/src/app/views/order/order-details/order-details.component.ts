import { Component, OnInit, Input } from '@angular/core';

import { Order } from '../order';
import { OrderService } from '../order.service';

import { breadcrumb } from '../../common/breadcrumb/breadcrumb';
import { BreadcrumbService } from '../../common/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.scss']
})
export class OrderDetailsComponent implements OnInit {

  @Input() order: Order;

  public breadcrumbList: breadcrumb[] = [];

  constructor(private breadcrumbService: BreadcrumbService) { }

  ngOnInit() {
    this.initBreadcrumbList();
  }

  private initBreadcrumbList() {
    this.breadcrumbService.resetBreadcrumbList();
    this.breadcrumbList = this.breadcrumbService.getOrderDetail(
      this.order.account,
      this.order.restaurant,
      this.order
    );
  }

}
