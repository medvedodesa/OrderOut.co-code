import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { Router } from '@angular/router';
import { MatPaginator } from '@angular/material';
import * as _ from 'lodash';

import { Order, OrdersList, OrderOptions } from '../order';
import { OrderService } from '../order.service';
import { OrdersDataSource } from '../order.datasource';

import { CurrentAccountService } from '../../../core/current-account.service';
import { RestaurantService } from '../../restaurant/restaurant.service';
import { Restaurant } from '../../restaurant/restaurant';

import { DataFilterComponent } from '../../common/data-filter/data-filter.component';

@Component({
  selector: 'app-order-list',
  templateUrl: './order-list.component.html',
  styleUrls: ['./order-list.component.scss'],
  providers: [ OrderService, DataFilterComponent ],
})
export class OrderListComponent implements OnInit {

  public columnsToDisplay = ['restaurant', 'delivery_service_type', 'order_short_uuid', 'order_status', 'api_created_at'];
  public dataSource: OrdersDataSource;
  private ordersList: OrdersList;
  public noRecord: boolean;

  public restaurants = new FormControl(''); // Pass the value blank to select all option by default
  public restaurantsList: Restaurant[];
  public filteredRestaurants: Restaurant[];
  public availableDS = new FormControl();
  public availableDSList: any;

  public today = new Date();
  public date = new FormControl();
  public minStartDate: Date;
  public maxStartDate: Date;
  public minEndDate: Date;
  public maxEndDate: Date;

  @ViewChild('paginationConfig') paginationConfig;
  // MatPaginator length
  public length: number;

  @ViewChild('refreshBtn') refreshBtn;
  private isRefreshBtn: boolean = false;

  public orderOptions: OrderOptions;
  public defaultOrderOptions = {
    'account_id': null,
    'restaurant_id': null,
    'from_timestamp': null,
    'to_timestamp': null,
    'page': null,
    'item_per_page': null,
    'sort_order': null,
    'delivery_service_type': null,
  }

  constructor(
    private router: Router,
    private orderService: OrderService,
    private restaurantService: RestaurantService,
    private _caService: CurrentAccountService,
    private dataFilter: DataFilterComponent
  ) { }

  ngOnInit() {

    // Set MatPaginator length
    this.length = this.dataFilter.paginationLength;

    // Set Order options
    this.orderOptions = Object.assign(this.defaultOrderOptions, this.dataFilter.options);

    let accountId = _.get(this._caService.getCurrentAccount(), 'id');
    if (accountId) {
      this.orderOptions.account_id = accountId;
      this.restaurantService.getRestaurants(accountId).subscribe(restaurants => {
        this.restaurantsList = restaurants.data;
      });
    } else {
      this.columnsToDisplay.unshift('account');
    }

    this.dataSource = new OrdersDataSource(this.orderService);
    this.loadOrders();

    this.dataSource.ordersListObs.subscribe((orders) => {
      this.ordersList = orders;
      this.availableDSList = this.ordersList.delivery_services_available;
      this.noRecord = this.ordersList.data.length === 0 ? true : false;
      this.length = this.ordersList.count;
      this.orderOptions.page = this.ordersList.page;
      this.orderOptions.item_per_page = this.ordersList.item_per_page;

      if (this.isRefreshBtn) {
        this.isRefreshBtn = false;
        let refreshBtn = this.refreshBtn._elementRef.nativeElement;
        refreshBtn.disabled = false;
        refreshBtn.textContent = 'Refresh Data';
      }
    });

    // Set dates to date range picker inputs
    const backDate = (numOfDays) => {
      const today = new Date();
      return new Date(today.setDate(today.getDate() - numOfDays));
    }

    this.minStartDate = backDate(365);
    this.maxStartDate = new Date(this.today);
    this.minEndDate = backDate(365);
    this.maxEndDate = new Date(this.today);
  }

  onPaginationChange(data){
    if (this.orderOptions.item_per_page === data.pageSize) {
      this.orderOptions.page = data.pageIndex + 1;
    } else {
      this.paginationConfig.paginator.firstPage();
      this.orderOptions.page = 0;
      this.orderOptions.item_per_page = data.pageSize;
    }
    
    this.loadOrdersPage(data);
  }

  // Selection
  rowSelected(order: Order) {
    this.router.navigate(['order', order.id]);
  }

  loadOrders() {
    this.dataSource.loadOrders(this.orderOptions);
  }

  loadOrdersPage(data) {
    //this.dataFilter.updateCursors(this.orderOptions, this.ordersList, data);
    this.loadOrders();
  }

  filterRestaurants(data) {
    this.orderOptions.restaurant_id = data;
    this.loadOrders();
  }

  filterDeliveryServices(data) {
    this.orderOptions.delivery_service_type = data && data.length > 0 ? data.join(',') : '';
    this.loadOrders();
  }

  startDateChange(event: MatDatepickerInputEvent<Date>) {
    this.minEndDate = new Date(event.value);
    let from_timestamp = this.getTimestampWithoutTimeZone(event.value);
    this.orderOptions.from_timestamp = from_timestamp;
    if (this.orderOptions.from_timestamp && this.orderOptions.to_timestamp) {
      this.loadOrders();
    }
  }

  endDateChange(event: MatDatepickerInputEvent<Date>) {
    this.maxStartDate = new Date(event.value);
    let to_timestamp = this.getTimestampWithoutTimeZone(event.value);
    to_timestamp = to_timestamp + 86399; // Set hours 23:59:59 by adding 86399 seconds
    this.orderOptions.to_timestamp = to_timestamp;
    if (this.orderOptions.from_timestamp && this.orderOptions.to_timestamp) {
      this.loadOrders();
    }
  }

  getTimestampWithoutTimeZone(localDate) {
    let oDate = new Date(localDate);
    let date = oDate.getDate().toString().length == 1 ? '0' + oDate.getDate() : oDate.getDate();
    let month = (oDate.getMonth() + 1).toString();
    month = month.length === 1 ? '0' + month : month;
    let fullYear = oDate.getFullYear();
    return (new Date(month + '/' + date + '/' + fullYear).getTime() / 1000);
  }

  refreshData() {
    this.isRefreshBtn = true;
    let refreshBtn = this.refreshBtn._elementRef.nativeElement;
    refreshBtn.disabled = true;
    refreshBtn.textContent = 'Refreshing...';
    //this.dataFilter.resetCursors(this.orderOptions);
    //this.resetPagination();  // Fixed this when resetPagination method start works in data filter compoent
    this.loadOrders();
  }

}
