import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Order } from './order';
import { OrderService } from './order.service';

@Injectable()
export class OrderResolve implements Resolve<Order> {

  constructor(private orderServiceService: OrderService) {}

  resolve(route: ActivatedRouteSnapshot) {
    return this.orderServiceService.getOrder(route.params.orderId);
  }
}