import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnboardMenuListDgComponent } from './onboard-menu-list-dg.component';

describe('OnboardMenuListDgComponent', () => {
  let component: OnboardMenuListDgComponent;
  let fixture: ComponentFixture<OnboardMenuListDgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnboardMenuListDgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnboardMenuListDgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
