import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { finalize } from 'rxjs/operators';

import { OnboardService } from '../onboard.service';
import { DeliveryserviceService } from '../../deliveryservice/deliveryservice.service';

@Component({
  selector: 'app-onboard-menu-list-dg',
  templateUrl: './onboard-menu-list-dg.component.html',
  styleUrls: ['./onboard-menu-list-dg.component.scss']
})
export class OnboardMenuListDgComponent implements OnInit {

  public columnsToDisplay = ['type', 'item_name','modifier_name'];
  public unmapped_list;
  public showLoader: boolean = true;

  constructor(
    private onboardService: OnboardService,
    private dsService: DeliveryserviceService,
    public dialogRef: MatDialogRef<OnboardMenuListDgComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) { }

  ngOnInit() {
    this.onboardService.getUnmappedMenuList(this.data.ds.id)
      .pipe(
        finalize(() => {
          this.showLoader = false;
        })
      )
      .subscribe(menuItems => {
        let itemsList = this.dsService.getNewMenuItems(menuItems, this.data.ds);
        this.unmapped_list = this.dsService.getUnMappedMenuList(itemsList);
      });
  }

}
