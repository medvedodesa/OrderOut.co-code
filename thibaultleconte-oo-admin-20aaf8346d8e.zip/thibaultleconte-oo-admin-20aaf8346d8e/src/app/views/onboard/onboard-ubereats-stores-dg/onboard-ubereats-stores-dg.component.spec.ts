import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnboardUbereatsStoresDgComponent } from './onboard-ubereats-stores-dg.component';

describe('OnboardUbereatsStoresDgComponent', () => {
  let component: OnboardUbereatsStoresDgComponent;
  let fixture: ComponentFixture<OnboardUbereatsStoresDgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnboardUbereatsStoresDgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnboardUbereatsStoresDgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
