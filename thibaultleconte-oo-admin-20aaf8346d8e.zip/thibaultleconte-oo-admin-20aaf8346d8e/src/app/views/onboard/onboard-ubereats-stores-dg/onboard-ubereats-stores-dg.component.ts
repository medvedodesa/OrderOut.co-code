import { Component, OnInit, EventEmitter, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

import { OnboardService } from '../onboard.service';
import { ConfirmationDialogService } from '../../common/confirmation-dialog/confirmation-dialog.service';
import { Restaurant } from '../../restaurant/restaurant';

import { MessageDgService } from '../../common/message-dg/message-dg.service';
import { onboarding_messages } from '../../common/message-dg/message-dg';

@Component({
  selector: 'app-onboard-ubereats-stores-dg',
  templateUrl: './onboard-ubereats-stores-dg.component.html',
  styleUrls: ['./onboard-ubereats-stores-dg.component.scss']
})
export class OnboardUbereatsStoresDgComponent implements OnInit {

  public event: EventEmitter<any> = new EventEmitter();
  public restaurant: Restaurant;
  public stores;
  public showLoader: boolean = false;

  constructor(
    private onboardService: OnboardService,
    public cdService: ConfirmationDialogService,
    public msgDgService: MessageDgService,
    public dialogRef: MatDialogRef<OnboardUbereatsStoresDgComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {
    this.stores = data.stores;
    this.restaurant = data.restaurant;
  }

  ngOnInit() {
  }

  selectStore(store) {
    this.event.emit(store);
    this.dialogRef.close();
  }

  reset() {
    this.cdService.confirm({
      type: 'general-confirm',
      note: 'It will reset UberEats connection.'
    }).subscribe(result => {
      if (result && result === true) {
        this.showLoader = true;
        this.onboardService.delUberEatsStores(this.restaurant.id).subscribe({
          next: res => {
            if (res && res.success === true) {
              this.dialogRef.close('reset'); // Reset Stores
              this.msgDgService.openMsgDialog(onboarding_messages.RESET_UE_CRED_POS, {positive: true});
            } else {
              this.msgDgService.openMsgDialog(onboarding_messages.RESET_UE_CRED_NEG, {negative: true});
            }
          },
          complete: () => {
            this.showLoader = false;
          },
        });
      }
    });
  }

}
