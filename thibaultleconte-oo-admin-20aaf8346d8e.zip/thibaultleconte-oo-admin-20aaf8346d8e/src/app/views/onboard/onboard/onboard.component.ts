import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material';
import { Intercom } from 'ng-intercom';
import { environment } from '../../../../environments/environment';

import { Account } from '../../account/account';
import { Restaurant } from '../../restaurant/restaurant';
import { DeliveryService, const_ds } from '../../deliveryservice/deliveryservice';
import { PointOfSale } from '../../pointofsale/pointofsale';
import { Printer } from '../../printer/printer';

import { OnboardService } from '../onboard.service';
import { LoaderService } from '../../../service/loader.service';

import { OnboardDsDialogComponent } from '../onboard-ds-dialog/onboard-ds-dialog.component';
import { OnboardMenuListDgComponent } from '../onboard-menu-list-dg/onboard-menu-list-dg.component';
import { OnboardDsSuccessDgComponent } from '../onboard-ds-success-dg/onboard-ds-success-dg.component';
import { OnboardUbereatsStoresDgComponent } from '../onboard-ubereats-stores-dg/onboard-ubereats-stores-dg.component';
import { AppService } from '../../../service/app.service';

@Component({
  selector: 'app-onboard',
  templateUrl: './onboard.component.html',
  styleUrls: ['./onboard.component.scss']
})
export class OnboardComponent implements OnInit, OnDestroy {

  public account: Account;
  public restaurant: Restaurant;

  public menuSyncMapDisplayedColumns: string[] = ['total_items', 'mapped_items','total_modifiers', 'mapped_modifiers', 'unmapped_btn'];
  public isExpansionDetailRow = (i: number, row: Object) => row.hasOwnProperty('detailRow');
  public expandedElement: any;

  public deliveryServices: DeliveryService[];
  public pointOfSale: PointOfSale;
  public printers: Printer[];
  public onboardDS;
  public dsList;
  public ubereatsStores = [];

  private restaurantId: number;
  public showConnectedDS: boolean = false;
  public showMissingItems: boolean = false;
  public supportUrl = 'http://support.orderout.co/en/';

  constructor(
    public intercom: Intercom,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private loaderService: LoaderService,
    private onboardService: OnboardService,
    public appService: AppService
  ) { }

  ngOnInit() {
    this.restaurantId = this.route.snapshot.params['restaurantId'];
    this.showMissingItems = this.route.snapshot.queryParams.show_missing_items === '1';

    this.launchIntercom();
    this.getRestaurantStatus();
  }

  ngOnDestroy() {
    this.removeIntercom();
  }

  private getRestaurantStatus() {
    this.loaderService.show();
    this.onboardService.getRestaurantStatus(this.restaurantId).subscribe({
      next: res => {
        let restaurant_status = res.restaurant_status;
        this.account = restaurant_status.account;
        this.restaurant = restaurant_status.restaurant;
        this.pointOfSale = restaurant_status.pos_connected;
        this.deliveryServices = restaurant_status.ds_connected || [];
        this.printers = restaurant_status.printer_connected;
        this.filterAddDeliveryServices(res.global_settings.ds_available);
        this.getUberEatsStores(restaurant_status.ds_connected);
      },
      complete: () => {
        //this.loaderService.hide();
      }
    });
  }

  filterAddDeliveryServices(availableDS) {
    this.onboardDS = availableDS;
    this.onboardDS.forEach(ds => {
      ds.type = ds.name;
      ds.enable = const_ds[ds.name.toLowerCase()].enable;
    });
    if (this.deliveryServices && this.deliveryServices.length > 0) {
      this.onboardDS = availableDS.filter(function(obj) {
        return !this.has(obj.name) && obj.enable; // Filtered enable delivery services too
      }, new Set(this.deliveryServices.map(obj => obj.type)));
      this.dsList = this.deliveryServices.concat(this.onboardDS);
    } else {
      this.dsList = availableDS.filter(function(obj) {
        return obj.enable; // Filtered enable delivery services too
      });
    }
  }

  openDSDialog(ds) {
    if (ds && ds.type && ds.type.toLowerCase() === 'ubereats') {
      if (this.ubereatsStores && this.ubereatsStores.length === 0) {
        this.loaderService.show();
        this.onboardService.getUbereatsAuthUrl(this.restaurant.id).subscribe({
          next: res => {
            window.open(res.authorization_url, '_blank');
          },
          complete: () => {
            this.loaderService.hide();
          }
        });
      } else {
        this.showUberEatsStoresDialog();
      }
    } else {
      const dialogRef = this.dialog.open(OnboardDsDialogComponent, {
        width: "600px",
        data: {
          'ds': ds
        }
      });
      dialogRef.componentInstance.event.subscribe(delivery_service => {
        this.loaderService.show();
  
        this.onboardService.updateRestaurantDS(this.restaurant.id, delivery_service).subscribe({
          next: res => {
  
            // Show success dialog if DS was connected successfully
            let isDSConnected = res.ds_connected.filter(connectedDs => {
              return connectedDs.type === delivery_service.name;
            })
            if (isDSConnected && isDSConnected.length > 0) {
              this.dialog.open(OnboardDsSuccessDgComponent, {
                width: "620px",
                data: {
                  'ds': delivery_service
                }
              });
            }
  
            this.deliveryServices = res.ds_connected;
            this.filterAddDeliveryServices(this.onboardDS);
          },
          complete: () => {
            this.loaderService.hide();
          },
        });
  
      });
    }
  }

  toggleConnectedDS($event) {
    this.showConnectedDS = $event.checked;
    this.dsList = this.showConnectedDS === true ? this.deliveryServices : this.deliveryServices.concat(this.onboardDS);
  }

  launchIntercom() {
    this.intercom.boot({
      app_id: environment.INTERCOM_APP_ID,
      // Supports all optional configuration.
      widget: {
        "activator": "#intercom" 
      }
    });
  }

  removeIntercom() {
    //this.intercom.shutdown();
  }

  getUnmappedList(ds) {
    this.dialog.open(OnboardMenuListDgComponent, {
      width: "600px",
      data: {
        'ds': ds
      }
    });
  }

  getUberEatsStores(connectedDS) {
    let isUberEatsConnected = connectedDS && connectedDS.filter(ds => ds.type.toLowerCase() === 'ubereats') || [];
    if (isUberEatsConnected && isUberEatsConnected.length === 0) {
      this.loaderService.show();
      this.onboardService.getUberEatsStores(this.restaurant.id).subscribe({
        next: res => {
          this.ubereatsStores = res;
          if (res && res.length > 0) {
            this.showUberEatsStoresDialog();
          }
        },
        complete: () => {
          this.loaderService.hide();
        },
      });
    } else {
      this.loaderService.hide();
    }
  }

  showUberEatsStoresDialog() {
    const dialogRef = this.dialog.open(OnboardUbereatsStoresDgComponent, {
      width: "600px",
      data: {
        'stores': this.ubereatsStores,
        'restaurant': this.restaurant
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result && result === 'reset') {
        this.ubereatsStores = []; // Reset stores
      }
    });
    dialogRef.componentInstance.event.subscribe(store => {
      this.loaderService.show();
      this.onboardService.connectUberEats(this.restaurant.id, store.store_id).subscribe({
        next: res => {
          this.dialog.open(OnboardDsSuccessDgComponent, {
            width: "620px",
            data: {
              'ds': res
            }
          });

          this.deliveryServices.push(res);
          this.filterAddDeliveryServices(this.onboardDS);
        },
        complete: () => {
          this.loaderService.hide();
        },
      });
    });
  }

}
