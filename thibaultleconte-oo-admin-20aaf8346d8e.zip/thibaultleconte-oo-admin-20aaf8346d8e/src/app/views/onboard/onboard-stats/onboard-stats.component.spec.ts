import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnboardStatsComponent } from './onboard-stats.component';

describe('OnboardStatsComponent', () => {
  let component: OnboardStatsComponent;
  let fixture: ComponentFixture<OnboardStatsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnboardStatsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnboardStatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
