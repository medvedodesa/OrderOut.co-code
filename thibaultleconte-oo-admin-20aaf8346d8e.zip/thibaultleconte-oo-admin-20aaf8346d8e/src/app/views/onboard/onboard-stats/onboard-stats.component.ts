import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, forkJoin, BehaviorSubject } from 'rxjs';
import { MatTableDataSource, MatSort, Sort } from "@angular/material";

import { Restaurant } from '../../restaurant/restaurant';
import { OnboardService } from '../onboard.service';

@Component({
  selector: 'app-onboard-stats',
  templateUrl: './onboard-stats.component.html',
  styleUrls: ['./onboard-stats.component.scss']
})
export class OnboardStatsComponent implements OnInit {

  public onboardStatsColumns = ['columnText', 'no-ds', 'pending-ds', 'no-live-ds', 'live-ds', 'no-pos'];
  public onboardRestaurantsColumns = ['accountName', 'restaurantName', 'api_created_at'];
  public onboardStats;
  public aOnboardStats = [];
  public onboardRestaurants;
  public nodsDataSource: MatTableDataSource<any>;
  public pendingdsDataSource: MatTableDataSource<any>;
  public nolivedsDataSource: MatTableDataSource<any>;
  public livedsDataSource: MatTableDataSource<any>;
  public noposDataSource: MatTableDataSource<any>;

  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();

  @ViewChild(MatSort) sort: MatSort;

  constructor(
    private router: Router,
    private onboardService: OnboardService
  ) { }

  ngOnInit() {
    this.loadingSubject.next(true);
    this.getData()
      .subscribe(res => {

        this.onboardStats = res[0];
        // Add Column Label
        this.onboardStats._last_7d.columnText = 'Last 7 Days';
        this.onboardStats._7_to_14d.columnText = '7 to 14 Days';
        this.onboardStats._14_to_21d.columnText = '14 to 21 Days';
        this.onboardStats._21_to_28d.columnText = '21 to 28 Days';
        this.onboardStats._28_to_45d.columnText = '28 to 45 Days';
        this.onboardStats._more_than_45d.columnText = 'More than 45 Days';

        this.aOnboardStats.push(this.onboardStats._last_7d);
        this.aOnboardStats.push(this.onboardStats._7_to_14d);
        this.aOnboardStats.push(this.onboardStats._14_to_21d);
        this.aOnboardStats.push(this.onboardStats._21_to_28d);
        this.aOnboardStats.push(this.onboardStats._28_to_45d);
        this.aOnboardStats.push(this.onboardStats._more_than_45d);
        
        this.onboardRestaurants = res[1];
        this.nodsDataSource = new MatTableDataSource(this.onboardRestaurants.no_ds);
        this.pendingdsDataSource = new MatTableDataSource(this.onboardRestaurants.pending_ds);
        this.nolivedsDataSource = new MatTableDataSource(this.onboardRestaurants.no_live_ds);
        this.livedsDataSource = new MatTableDataSource(this.onboardRestaurants['live_1+_ds']);
        this.noposDataSource = new MatTableDataSource(this.onboardRestaurants.no_ds);

        this.nodsDataSource.sort = this.pendingdsDataSource.sort = this.nolivedsDataSource.sort = this.livedsDataSource.sort = this.noposDataSource.sort = this.sort;
        // const sortState: Sort = {active: 'api_created_at', direction: 'desc'};
        // this.sort.active = sortState.active;
        // this.sort.direction = sortState.direction;
        // this.sort.sortChange.emit(sortState);

      }, err => {
        console.log(err);
      }, () => {
        this.loadingSubject.next(false);
      });

  }

  getOnboardingStats(): Observable<any> {
    return this.onboardService.getOnboardingStats();
  }

  getOnboardingRestaurantsPending(): Observable<any> {
    return this.onboardService.getOnboardingRestaurantsPending();
  }

  getData(): Observable<any> {
    return forkJoin([this.getOnboardingStats(), this.getOnboardingRestaurantsPending()]);
  }

  public navAccount(restaurant: Restaurant) {
    this.router.navigate(["account", restaurant.account.id]);
  }

  public navRestaurant(restaurant: Restaurant) {
    this.router.navigate(['restaurant', restaurant.id]);
  }

}
