import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnboardDsDialogComponent } from './onboard-ds-dialog.component';

describe('OnboardDsDialogComponent', () => {
  let component: OnboardDsDialogComponent;
  let fixture: ComponentFixture<OnboardDsDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnboardDsDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnboardDsDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
