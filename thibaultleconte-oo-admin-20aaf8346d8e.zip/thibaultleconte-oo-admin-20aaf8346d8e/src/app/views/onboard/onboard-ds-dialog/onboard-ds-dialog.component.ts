import { Component, OnInit, EventEmitter, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ds } from '../onboard';
import { const_ds } from '../../deliveryservice/deliveryservice';

@Component({
  selector: 'app-onboard-ds-dialog',
  templateUrl: './onboard-ds-dialog.component.html',
  styleUrls: ['./onboard-ds-dialog.component.scss']
})
export class OnboardDsDialogComponent implements OnInit {

  public onboardDSFormGroup: FormGroup;
  public ds: ds;
  public restaurantUrl: string = '';
  public selectedDS;
  public event: EventEmitter<any> = new EventEmitter();
  public hide: boolean = true;
  public const_ds = const_ds;
  
  constructor(
    public dialogRef: MatDialogRef<OnboardDsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {
    this.ds = data.ds;
    const result = const_ds.DS_INFO_LIST.filter(dsInfo => {
      return dsInfo.name == this.ds.name;
    });
    this.selectedDS = result[0];
  }

  ngOnInit() {
    const nonWhitespaceRegExp: RegExp = new RegExp("\\S");
    const pincodeRegExp: RegExp = new RegExp("^[0-9]{4,8}$");
    this.onboardDSFormGroup = new FormGroup({
      restaurantUrl: new FormControl(this.restaurantUrl, Validators.pattern(new RegExp(this.selectedDS.regex, 'i'))),
      username: new FormControl('', [Validators.pattern(nonWhitespaceRegExp)]),
      password: new FormControl('', [Validators.pattern(nonWhitespaceRegExp)]),
      pincode: new FormControl('', [Validators.pattern(nonWhitespaceRegExp), Validators.pattern(pincodeRegExp)])
    });
  }

  get usernameInput() { 
    return this.onboardDSFormGroup.get('username'); 
  }

  get passwordInput() { 
    return this.onboardDSFormGroup.get('password'); 
  }

  get pincodeInput() {
    return this.onboardDSFormGroup.get('pincode');
  }

  onSubmit(value): void {
    let resUrl = value.restaurantUrl && value.restaurantUrl.split(/[?#]/)[0];
    this.event.emit({
      "name": this.ds.name,
      "id": this.ds.id,
      "value": resUrl,
      "username": value.username,
      "password": value.password,
      "pincode": value.pincode,
      "type": this.ds.name
    });
    this.dialogRef.close();
  }

}
