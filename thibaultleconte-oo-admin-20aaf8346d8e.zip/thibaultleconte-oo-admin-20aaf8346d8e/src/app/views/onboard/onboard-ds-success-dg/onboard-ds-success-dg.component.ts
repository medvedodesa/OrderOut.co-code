import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ds } from '../onboard';

@Component({
  selector: 'app-onboard-ds-success-dg',
  templateUrl: './onboard-ds-success-dg.component.html',
  styleUrls: ['./onboard-ds-success-dg.component.scss']
})
export class OnboardDsSuccessDgComponent implements OnInit {

  public ds;

  constructor(
    public dialogRef: MatDialogRef<OnboardDsSuccessDgComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {
    this.ds = data.ds;
  }

  ngOnInit() {
  }

}
