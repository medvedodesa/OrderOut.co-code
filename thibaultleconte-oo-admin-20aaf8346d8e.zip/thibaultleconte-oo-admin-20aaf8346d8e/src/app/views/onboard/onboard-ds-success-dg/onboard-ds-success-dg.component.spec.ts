import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnboardDsSuccessDgComponent } from './onboard-ds-success-dg.component';

describe('OnboardDsSuccessDgComponent', () => {
  let component: OnboardDsSuccessDgComponent;
  let fixture: ComponentFixture<OnboardDsSuccessDgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnboardDsSuccessDgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnboardDsSuccessDgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
