import { Account } from '../account/account';
import { Restaurant } from '../restaurant/restaurant';
import { DeliveryService } from '../deliveryservice/deliveryservice';
import { PointOfSale } from '../pointofsale/pointofsale';
import { Printer } from '../printer/printer';

export interface OnboardRestaurant {
    restaurant_status: RestaurantStatus;
    global_settings: GlobalSettings;
}

export interface RestaurantStatus {
    account: Account;
    restaurant: Restaurant;
    ds_connected: DeliveryService[];
    pos_connected: PointOfSale;
    printer_connected: Printer[];
}

export interface GlobalSettings {
    ds_available: ds[];
}

export interface ds {
    name: string;
    id: number;
}