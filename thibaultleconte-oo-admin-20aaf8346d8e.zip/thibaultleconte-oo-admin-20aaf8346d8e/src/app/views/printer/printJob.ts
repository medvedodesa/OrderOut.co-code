import { Printer } from './printer';

export interface PrintJob {
    id: number;
    printerId: number;
    printer: Printer;
    mediaType: string;
    body: string;
    failsafe: boolean;
    test: boolean;
    printed: boolean;
    api_created_at: Date;
}

export interface PrintJobsList {
    data: PrintJob[];
    count: number;
    item_per_page: number;
    next: boolean;
    prev: boolean;
    page: number;
}