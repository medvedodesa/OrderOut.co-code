import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Account } from '../../account/account';
import { AccountRestaurant, Restaurant } from '../../restaurant/restaurant';
import { PrintJob } from '../printJob';
import { breadcrumb } from '../../common/breadcrumb/breadcrumb';

import { BreadcrumbService } from '../../common/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-printer-jobs-details',
  templateUrl: './printer-jobs-details.component.html',
  styleUrls: ['./printer-jobs-details.component.scss', '../../../app.component.scss']
})
export class PrinterJobsDetailsComponent implements OnInit {

  public accountRestaurant: AccountRestaurant;
  public account: Account
  public restaurant: Restaurant;
  public printJob: PrintJob;

  public breadcrumbList: breadcrumb[] = [];

  constructor(
    private breadcrumbService: BreadcrumbService,
    private route: ActivatedRoute,
  ) { }

  ngOnInit() {
    this.accountRestaurant = this.route.snapshot.data.accountRestaurant;
    this.account = this.accountRestaurant && this.accountRestaurant.account;
    this.restaurant = this.accountRestaurant && this.accountRestaurant.restaurant;
    this.printJob = this.route.snapshot.data.printJob;

    this.breadcrumbService.resetBreadcrumbList();
    this.breadcrumbList = this.breadcrumbService.getPrinterJob(
      this.account,
      this.restaurant,
      this.printJob.printer.id
    );
  }

}
