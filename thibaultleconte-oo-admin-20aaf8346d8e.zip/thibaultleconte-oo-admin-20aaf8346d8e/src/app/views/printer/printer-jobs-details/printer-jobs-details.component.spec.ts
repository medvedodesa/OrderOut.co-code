import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrinterJobsDetailsComponent } from './printer-jobs-details.component';

describe('PrinterJobsDetailsComponent', () => {
  let component: PrinterJobsDetailsComponent;
  let fixture: ComponentFixture<PrinterJobsDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrinterJobsDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrinterJobsDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
