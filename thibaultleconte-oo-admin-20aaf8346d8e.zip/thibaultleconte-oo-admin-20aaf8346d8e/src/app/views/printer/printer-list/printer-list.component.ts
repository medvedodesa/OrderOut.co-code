import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { MatSlideToggleChange } from '@angular/material';

import { Restaurant } from '../../restaurant/restaurant';
import { Printer } from '../printer';

import { RestaurantService } from '../../restaurant/restaurant.service';
import { PrinterService } from '../printer.service';
import { RestaurantHelper } from '../../restaurant/restaurant.helper';

@Component({
  selector: 'app-printer-list',
  templateUrl: './printer-list.component.html',
  styleUrls: ['./printer-list.component.scss', '../../../app.component.scss']
})
export class PrinterListComponent implements OnInit {

  @Input() restaurant: Restaurant;

  columnsToDisplay = ['mac', 'pairingSuccess', 'api_created_at'];

  printers: Printer[] = [];

  constructor(
    private router: Router,
    private restaurantService: RestaurantService,
    private printerService: PrinterService,
    public restaurantHelper: RestaurantHelper
  ) { }

  ngOnInit() {
    this.getPrinters();
  }

  private getPrinters() {
    this.printerService.getPrinters(this.restaurant.id).subscribe(printersList => {
      this.printers = printersList.data;
      this.restaurantHelper.setPrinters(this.printers);
    });
  }

  addPrinter() {
    this.router.navigate(['restaurant', this.restaurant.id, 'printer']);
  }

  rowSelected(printer: Printer) {
    this.router.navigate(['restaurant', this.restaurant.id, 'printer', printer.id]);
  }

  printTestOrder() {
    this.printerService.testPrintForRestaurant(this.restaurant).subscribe(() => {
      console.log('Print Test Order for Restaurant');
    });
  }

  printDoubleOrderChange(ob: MatSlideToggleChange) {
    this.restaurant.printDoubleOrder = ob.checked;
    this.restaurantService.updateRestaurant(this.restaurant).subscribe();
  }

}
