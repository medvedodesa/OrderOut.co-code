import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BehaviorSubject} from 'rxjs';

import { Account } from '../../account/account';
import { AccountRestaurant, Restaurant } from '../../restaurant/restaurant';
import { Printer } from '../printer';
import { PrintJob } from '../printJob';
import { breadcrumb } from '../../common/breadcrumb/breadcrumb';

import { PrinterService } from '../printer.service';
import { BreadcrumbService } from '../../common/breadcrumb/breadcrumb.service';


@Component({
  selector: 'app-printer-jobs-all',
  templateUrl: './printer-jobs-all.component.html',
  styleUrls: ['./printer-jobs-all.component.scss', '../../../app.component.scss']
})
export class PrinterJobsAllComponent implements OnInit {

  public accountRestaurant: AccountRestaurant;
  public account: Account;
  public restaurant: Restaurant;
  public printer: Printer;

  columnsToDisplay = ['id', 'printed', 'api_created_at'];

  public printjobs: PrintJob[] = [];
  public breadcrumbList: breadcrumb[] = [];

  public noRecord: boolean;
  public length: number = 100;
  public jobOptions = {
    item_per_page: 25,
    page: 1
  }
  @ViewChild('paginationConfig') paginationConfig;

  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private printerService: PrinterService,
    private breadcrumbService: BreadcrumbService,
  ) { }

  ngOnInit() {
    this.accountRestaurant = this.route.snapshot.data.accountRestaurant;
    this.account = this.accountRestaurant.account;
    this.restaurant = this.accountRestaurant.restaurant;
    this.printer = this.route.snapshot.data.printer;

    this.breadcrumbService.resetBreadcrumbList();
    this.breadcrumbList = this.breadcrumbService.getPrinterAllJobs(
      this.account,
      this.restaurant,
      this.printer
    );

    this.getPrintJobs();
  }

  private getPrintJobs() {
    this.loadingSubject.next(true);
    this.printerService.getPrintJobs(this.printer.id, this.jobOptions).subscribe(printJobsList => {
      this.loadingSubject.next(false);
      this.printjobs = printJobsList.data;
      this.noRecord = this.printjobs.length === 0 ? true : false;
      this.length = printJobsList.count;
      this.jobOptions.page = printJobsList.page;
      this.jobOptions.item_per_page = printJobsList.item_per_page;
    });
  }

  rowSelected(printjob: PrintJob) {
    this.router.navigate(['restaurant', this.restaurant.id, 'printjob', printjob.id]);
  }

  onPaginationChange(data){
    if (this.jobOptions.item_per_page === data.pageSize) {
      this.jobOptions.page = data.pageIndex + 1;
    } else {
      this.paginationConfig.paginator.firstPage();
      this.jobOptions.page = 1;
      this.jobOptions.item_per_page = data.pageSize;
    }
    this.getPrintJobs();
  }

}
