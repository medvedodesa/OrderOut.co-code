import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrinterJobsAllComponent } from './printer-jobs-all.component';

describe('PrinterJobsAllComponent', () => {
  let component: PrinterJobsAllComponent;
  let fixture: ComponentFixture<PrinterJobsAllComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrinterJobsAllComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrinterJobsAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
