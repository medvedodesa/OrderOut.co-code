import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrinterJobsRecentComponent } from './printer-jobs-recent.component';

describe('PrinterJobsRecentComponent', () => {
  let component: PrinterJobsRecentComponent;
  let fixture: ComponentFixture<PrinterJobsRecentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrinterJobsRecentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrinterJobsRecentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
