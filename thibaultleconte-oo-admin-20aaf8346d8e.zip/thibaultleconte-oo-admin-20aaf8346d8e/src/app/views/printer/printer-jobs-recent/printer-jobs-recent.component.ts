import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

import { Restaurant } from '../../restaurant/restaurant';
import { Printer } from '../printer';
import { PrintJob } from '../printJob';

import { PrinterService } from '../printer.service';

@Component({
  selector: 'app-printer-jobs-recent',
  templateUrl: './printer-jobs-recent.component.html',
  styleUrls: ['./printer-jobs-recent.component.scss', '../../../app.component.scss']
})
export class PrinterJobsRecentComponent implements OnInit {

  @Input() restaurant: Restaurant;
  @Input() printer: Printer;

  columnsToDisplay = ['id', 'printed', 'api_created_at'];

  printjobs: PrintJob[] = [];

  constructor(
    private router: Router,
    private printerService: PrinterService,
    ) { }

  ngOnInit() {
    this.getPrintJobs();
  }

  private getPrintJobs() {
    this.printerService.getPrintJobs(this.printer.id, { item_per_page: 3 }).subscribe(printJobsList => {
      this.printjobs = printJobsList.data;
    });
  }

  rowSelected(printjob: PrintJob) {
    this.router.navigate(['restaurant', this.restaurant.id, 'printjob', printjob.id]);
  }

  showAllPrintJobs() {
      this.router.navigate(['restaurant', this.restaurant.id, 'printer', this.printer.id, 'jobs']);
  }

}
