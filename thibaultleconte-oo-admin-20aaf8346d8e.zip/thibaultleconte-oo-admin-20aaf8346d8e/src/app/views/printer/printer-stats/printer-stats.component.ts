import { Component, OnInit, ViewChild } from '@angular/core';
import { Observable, forkJoin, BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';

import { PrintJob } from '../printJob';
import { PrinterService } from '../printer.service';

@Component({
  selector: 'app-printer-stats',
  templateUrl: './printer-stats.component.html',
  styleUrls: ['./printer-stats.component.scss']
})
export class PrinterStatsComponent implements OnInit {

  public printJobSummary;
  public aPrintJobSummary = [];
  public PrintStatsColumns = ['columnText', 'not-printed', 'printed', 'total'];
  public printJobsColumns = ['id', 'printed', 'api_created_at'];

  public printjobs: PrintJob[] = [];
  public noRecord: boolean;
  public length: number = 100;
  public jobOptions = {
    show_only_not_printed: 0,
    item_per_page: 25,
    page: 1
  }
  @ViewChild('paginationConfig') paginationConfig;

  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();

  private jobsSubject = new BehaviorSubject<boolean>(false);
  public jobloading$ = this.jobsSubject.asObservable();

  constructor(
    private router: Router,
    private printerService: PrinterService
  ) { }

  ngOnInit() {

    this.loadingSubject.next(true);
    this.getData()
      .subscribe(res => {

        this.printJobSummary = res[0];

        // Add Column Label
        this.printJobSummary._1h.columnText = '1 Hour';
        this.printJobSummary._6h.columnText = '6 Hours';
        this.printJobSummary._12h.columnText = '12 Hours';
        this.printJobSummary._1d.columnText = '1 Day';
        this.printJobSummary._2d.columnText = '2 Days';
        this.printJobSummary._7d.columnText = '7 Days';
        this.printJobSummary._14d.columnText = '14 Days';
        this.printJobSummary._30d.columnText = '30 Days';

        this.aPrintJobSummary.push(this.printJobSummary._1h);
        this.aPrintJobSummary.push(this.printJobSummary._6h);
        this.aPrintJobSummary.push(this.printJobSummary._12h);
        this.aPrintJobSummary.push(this.printJobSummary._1d);
        this.aPrintJobSummary.push(this.printJobSummary._2d);
        this.aPrintJobSummary.push(this.printJobSummary._7d);
        this.aPrintJobSummary.push(this.printJobSummary._14d);
        this.aPrintJobSummary.push(this.printJobSummary._30d);
        
        this.getAllPrintJobsCallback(res[1]);

      }, err => {
        console.log(err);
      }, () => {
        this.loadingSubject.next(false);
      });
  }

  getPrintJobSummary(): Observable<any> {
    return this.printerService.getPrintJobSummary();
  }

  getAllPrintJobsInit(): Observable<any> {
    return this.printerService.getAllPrintJobs(this.jobOptions);
  }

  getData(): Observable<any> {
    return forkJoin([this.getPrintJobSummary(), this.getAllPrintJobsInit()]);
  }

  getAllPrintJobsCallback(printJobsList) {
    this.printjobs = printJobsList.data;
    this.noRecord = this.printjobs.length === 0 ? true : false;
    this.length = printJobsList.count;
    this.jobOptions.page = printJobsList.page;
    this.jobOptions.item_per_page = printJobsList.item_per_page;
  }

  getAllPrintJobs() {
    this.jobsSubject.next(true);
    this.printerService.getAllPrintJobs(this.jobOptions).subscribe(this.getAllPrintJobsCallback.bind(this)).add(() => {
      this.jobsSubject.next(false);
    });
  }

  getNotPrintedJobs(show_only_not_printed: boolean) {
    this.jobOptions.show_only_not_printed = show_only_not_printed === true ? 1 : 0;
    this.getAllPrintJobs();
  }

  rowSelected(printjob: PrintJob) {
    this.router.navigate(['restaurant', printjob.printer.restaurant, 'printjob', printjob.id]);
  }

  onPaginationChange(data){
    if (this.jobOptions.item_per_page === data.pageSize) {
      this.jobOptions.page = data.pageIndex + 1;
    } else {
      this.paginationConfig.paginator.firstPage();
      this.jobOptions.page = 1;
      this.jobOptions.item_per_page = data.pageSize;
    }
    this.getAllPrintJobs();
  }

}
