import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material';

import { Account } from '../../account/account';
import { AccountRestaurant, Restaurant } from '../../restaurant/restaurant';

import { PrinterService } from '../printer.service';
import { PointofsaleService } from '../../pointofsale/pointofsale.service';
import { LoaderService } from '../../../service/loader.service';
import { const_pos } from '../../pointofsale/pointofsale';

@Component({
  selector: 'app-printer-create',
  templateUrl: './printer-create.component.html',
  styleUrls: ['./printer-create.component.scss', '../../../app.component.scss']
})
export class PrinterCreateComponent implements OnInit {

  public accountRestaurant: AccountRestaurant;
  public account: Account
  public restaurant: Restaurant;
  public pairingCode: string;
  public isCloverPOS: boolean = false;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private printerService: PrinterService,
    private pointofsaleService: PointofsaleService,
    private loaderService: LoaderService,
  ) { }

  ngOnInit() {
    this.accountRestaurant = this.route.snapshot.data.accountRestaurant;
    this.account = this.accountRestaurant.account;
    this.restaurant = this.accountRestaurant.restaurant;
    
    this.getPointOfSales();
  }

  onSubmit(): void {
    if (!this.pairingCode) { return; }
    this.pairingCode = this.pairingCode.trim();
    this.loaderService.show();
    this.printerService.pairPrinter(this.restaurant, this.pairingCode).subscribe(printer => {
      this.loaderService.hide();
      this.router.navigate(['restaurant', this.restaurant.id, 'printer', printer.id]);
    });
  }

  connectCloverPrinter() {
    if (!this.isCloverPOS) { return; }
    this.printerService.connectCloverPrinter(this.restaurant).subscribe(printer => {
      this.router.navigate(['restaurant', this.restaurant.id, 'printer', printer.id]);
    });
  }

  getPointOfSales() {
    this.pointofsaleService.getPointOfSales(this.restaurant.id).subscribe(pointOfSales => {
      if(pointOfSales && pointOfSales.length > 0) {
        pointOfSales.forEach(pointOfSale => {
          if (pointOfSale.type === const_pos.CLOVER.toUpperCase()) {
            this.isCloverPOS = true;
          }
        })
      }
    });
  }

}
