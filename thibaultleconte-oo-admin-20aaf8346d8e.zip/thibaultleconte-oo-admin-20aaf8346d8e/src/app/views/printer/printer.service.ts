import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { ApiService } from 'src/app/core/api.service';
import { Restaurant } from '../restaurant/restaurant';
import { Printer, PrintersList } from './printer';
import { PrintJobsList, PrintJob } from './printJob';

@Injectable({
  providedIn: 'root'
})
export class PrinterService {

  printerRestaurantUrl = environment.backend_url + 'restaurant';
  printerUrl = environment.backend_url + 'printer';
  printJobUrl = environment.backend_url + 'printer/job';

  constructor(private api: ApiService) {}

  // Printer

  getPrinters(restaurantId: number): Observable<PrintersList> {
    const url = `${this.printerRestaurantUrl}/${restaurantId}/printers`;
    return this.api.get(url);
  }

  getPrinter(printerId: number): Observable<Printer> {
    const url = `${this.printerUrl}/${printerId}`;
    return this.api.get(url);
  }

  deletePrinter(printerId: number) {
    const url = `${this.printerUrl}/${printerId}`;
    return this.api.delete(url);
  }

  // Pairing

  pairPrinter(restaurant: Restaurant, pairingCode: string): Observable<Printer> {
    const url = `${this.printerUrl}/pairing`;
    const params = {
      pairingCode,
      restaurantId: restaurant.id
    };
    return this.api.post(url, params);
  }

  connectCloverPrinter(restaurant: Restaurant): Observable<Printer> {
    const url = `${this.printerUrl}/clover/connect`;
    const params = {
      restaurant_id: restaurant.id
    };
    return this.api.post(url, params);
  }

  // Testing

  testPrintForRestaurant(restaurant: Restaurant) {
    const url = `${this.printerRestaurantUrl}/${restaurant.id}/printers/test`;
    return this.api.get(url);
  }

  // Print Job

  getPrintJobs(printerId: number, options): Observable<PrintJobsList> {
    const url = `${this.printerUrl}/${printerId}/jobs`;
    return this.api.get(url, options);
  }

  getPrintJob(printJobId: number): Observable<PrintJob> {
    const url = `${this.printJobUrl}/${printJobId}`;
    return this.api.get(url);
  }

  getPrintJobSummary(): Observable<any> {
    const url = `${environment.backend_url}monitoring/printjob/summary`;
    return this.api.get(url);
  }

  getAllPrintJobs(params : {}): Observable<any> {
    const url = `${environment.backend_url}printjobs`;
    return this.api.get(url, params);
  }

}
