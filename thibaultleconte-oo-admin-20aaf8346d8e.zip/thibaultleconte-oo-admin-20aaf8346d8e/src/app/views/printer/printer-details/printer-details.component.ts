import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';

import { Account } from '../../account/account';
import { Restaurant } from '../../restaurant/restaurant';
import { Printer } from '../printer';
import { breadcrumb } from '../../common/breadcrumb/breadcrumb';

import { BreadcrumbService } from '../../common/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-printer-details',
  templateUrl: './printer-details.component.html',
  styleUrls: ['./printer-details.component.scss', '../../../app.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PrinterDetailsComponent implements OnInit {

  @Input() account: Account;
  @Input() restaurant: Restaurant;
  @Input() printer?: Printer;

  public breadcrumbList: breadcrumb[] = [];

  constructor(
    private breadcrumbService: BreadcrumbService,
  ) { }

  ngOnInit() {
    this.breadcrumbService.resetBreadcrumbList();
    this.breadcrumbList = this.breadcrumbService.getPrinter(
      this.account,
      this.restaurant,
      this.printer
    );
  }

}
