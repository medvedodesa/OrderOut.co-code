import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { PrinterService } from './printer.service';
import { Printer } from './printer';

@Injectable()
export class PrinterResolve implements Resolve<Printer> {

  constructor(private printerService: PrinterService) {}

  resolve(route: ActivatedRouteSnapshot) {
    return this.printerService.getPrinter(route.params.printerId);
  }
}