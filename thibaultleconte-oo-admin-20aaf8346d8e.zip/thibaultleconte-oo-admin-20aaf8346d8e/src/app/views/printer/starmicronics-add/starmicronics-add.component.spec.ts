import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StarmicronicsAddComponent } from './starmicronics-add.component';

describe('StarmicronicsAddComponent', () => {
  let component: StarmicronicsAddComponent;
  let fixture: ComponentFixture<StarmicronicsAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StarmicronicsAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StarmicronicsAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
