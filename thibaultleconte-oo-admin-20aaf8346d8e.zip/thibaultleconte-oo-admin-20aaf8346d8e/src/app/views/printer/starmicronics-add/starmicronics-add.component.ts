import { Component, EventEmitter, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-starmicronics-add',
  templateUrl: './starmicronics-add.component.html',
  styleUrls: ['./starmicronics-add.component.scss', '../../../app.component.scss']
})
export class StarmicronicsAddComponent {

  printer = {
    mac: '',
    manufacturerName: 'Star Micronics'
  };

  public event: EventEmitter<any> = new EventEmitter();

  constructor(
    public dialogRef: MatDialogRef<StarmicronicsAddComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

  onSubmit(): void {
    this.event.emit({data: this.printer});
    this.dialogRef.close();
  }

}