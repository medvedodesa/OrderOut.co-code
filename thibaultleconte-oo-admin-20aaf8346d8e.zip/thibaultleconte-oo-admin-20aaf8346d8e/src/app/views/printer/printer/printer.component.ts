import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Account } from '../../account/account';
import { AccountRestaurant, Restaurant } from '../../restaurant/restaurant';
import { Printer } from '../printer';

@Component({
  selector: 'app-printer',
  templateUrl: './printer.component.html',
  styleUrls: ['./printer.component.scss', '../../../app.component.scss']
})
export class PrinterComponent implements OnInit {

  public accountRestaurant: AccountRestaurant;
  public account: Account;
  public restaurant: Restaurant;
  public printer: Printer;

  constructor(
    private route: ActivatedRoute,
  ) { }

  ngOnInit() {
    this.accountRestaurant = this.route.snapshot.data.accountRestaurant;
    this.account = this.accountRestaurant.account;
    this.restaurant = this.accountRestaurant.restaurant;
    this.printer = this.route.snapshot.data.printer;
  }

}
