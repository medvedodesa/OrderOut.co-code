import { Component, Input, OnDestroy } from '@angular/core';
import { Printer } from '../printer';
import { Router } from '@angular/router';
import { PrinterService } from '../printer.service';
import { Restaurant } from '../../restaurant/restaurant';
import { ISubscription } from 'rxjs/Subscription';
import { ConfirmationDialogService } from '../../common/confirmation-dialog/confirmation-dialog.service';

@Component({
  selector: 'app-printer-admin',
  templateUrl: './printer-admin.component.html',
  styleUrls: ['./printer-admin.component.scss', '../../../app.component.scss']
})
export class PrinterAdminComponent implements OnDestroy {

  @Input() restaurant: Restaurant;
  @Input() printer: Printer;

  private subscription: ISubscription;

  constructor(
    private router: Router,
    private printerService: PrinterService,
    public cdService: ConfirmationDialogService,
  ) { }

  ngOnDestroy() {
    if (!this.subscription) { return; }
    this.subscription.unsubscribe();
  }

  deletePrinter() {

    this.cdService.confirm({
      message: {
        name: this.printer.mac,
        type: 'Printer'
      }
    }).subscribe(result => {
      if (result) {
        this.subscription = this.printerService.deletePrinter(this.printer.id).subscribe(() => {
          this.router.navigate(['restaurant', this.restaurant.id]);
        });
      }
    });

  }
}