import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrinterAdminComponent } from './printer-admin.component';

describe('PrinterAdminComponent', () => {
  let component: PrinterAdminComponent;
  let fixture: ComponentFixture<PrinterAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrinterAdminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrinterAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
