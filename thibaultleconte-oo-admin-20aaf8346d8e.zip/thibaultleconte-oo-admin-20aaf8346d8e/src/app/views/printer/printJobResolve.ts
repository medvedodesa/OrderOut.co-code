import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { PrinterService } from './printer.service';
import { PrintJob } from './printJob';

@Injectable()
export class PrintJobResolve implements Resolve<PrintJob> {

  constructor(private printerService: PrinterService) {}

  resolve(route: ActivatedRouteSnapshot) {
    return this.printerService.getPrintJob(route.params.printJobId);
  }
}
