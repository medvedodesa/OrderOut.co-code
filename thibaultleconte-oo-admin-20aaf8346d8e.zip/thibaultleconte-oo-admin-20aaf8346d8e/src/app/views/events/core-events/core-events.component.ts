import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

import { CoreEventsService } from '../core-events.service';


@Component({
  selector: 'app-core-events',
  templateUrl: './core-events.component.html',
  styleUrls: ['./core-events.component.scss']
})
export class CoreEventsComponent implements OnInit {

  @Input('name') name: string;
  @Input('id') id: string;


  constructor(
    private router: Router,
    public coreEventsService: CoreEventsService
  ) {
    this.coreEventsService.noRecord = undefined;
  }

  ngOnInit() { }

  getAllCoreEvents() {
    this.router.navigate(['events', this.name, this.id]);
  }

}
