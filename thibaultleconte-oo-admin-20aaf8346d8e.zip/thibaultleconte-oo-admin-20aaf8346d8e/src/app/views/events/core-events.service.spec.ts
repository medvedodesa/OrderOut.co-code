import { TestBed } from '@angular/core/testing';

import { CoreEventsService } from './core-events.service';

describe('CoreEventsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CoreEventsService = TestBed.get(CoreEventsService);
    expect(service).toBeTruthy();
  });
});
