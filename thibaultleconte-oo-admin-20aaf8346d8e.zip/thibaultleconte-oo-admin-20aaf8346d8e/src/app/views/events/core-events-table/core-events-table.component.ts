import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { MatTableDataSource } from "@angular/material";

import { CoreEventsService } from '../core-events.service';
import { AppService } from '../../../service/app.service';
import { MessageDgService } from '../../common/message-dg/message-dg.service';
import { events_messages } from '../../common/message-dg/message-dg';

@Component({
  selector: 'app-core-events-table',
  templateUrl: './core-events-table.component.html',
  styleUrls: ['./core-events-table.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class CoreEventsTableComponent implements OnInit {

  @Input('name') name: string;
  @Input('id') id: string;
  @Input('item_per_page') item_per_page?: number;

  public columnsToDisplay = ['id', 'category', 'name', 'api_created_at', 'admin_url'];
  public expandedElement;
  public dataSource: MatTableDataSource<any>;
  public noRecord: boolean;
  public eventsOptions = {
    entity_name: '',
    entity_id: '',
    item_per_page: 25,
    page: 1
  }
  @ViewChild('paginationConfig') paginationConfig;

  constructor(
    private coreEventsService: CoreEventsService,
    public appService: AppService,
    public msgDgService: MessageDgService
  ) { }

  ngOnInit() {
    this.eventsOptions.entity_name = this.name;
    this.eventsOptions.entity_id = this.id;
    this.eventsOptions.item_per_page = this.item_per_page ? this.item_per_page : 25;

    this.getEventsBySearch();
  }

  getEventsBySearch(options = {}) {
    this.eventsOptions = Object.assign({}, this.eventsOptions, options);
    
    this.coreEventsService.getEventsBySearch(this.eventsOptions).subscribe(events => {
      this.noRecord = events.data.length === 0 ? true : false;

      this.coreEventsService.noRecord = this.noRecord;
      this.coreEventsService.length = events.count;

      this.dataSource = new MatTableDataSource(events.data);
    }).add(() => {
      this.coreEventsService.showLoader = false;
    });
  }

  rowSelected(event) {
    if (event && event.admin_url) {
      this.appService.openExternalURL(event.admin_url)
    } else {
      this.msgDgService.openMsgDialog(events_messages.ADMIN_URL);
    }
  }

}
