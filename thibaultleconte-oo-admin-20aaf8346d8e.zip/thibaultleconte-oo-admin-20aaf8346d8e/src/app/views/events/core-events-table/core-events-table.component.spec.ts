import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CoreEventsTableComponent } from './core-events-table.component';

describe('CoreEventsTableComponent', () => {
  let component: CoreEventsTableComponent;
  let fixture: ComponentFixture<CoreEventsTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CoreEventsTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoreEventsTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
