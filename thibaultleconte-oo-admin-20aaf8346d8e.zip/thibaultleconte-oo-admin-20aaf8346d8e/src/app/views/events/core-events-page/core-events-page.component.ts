import { Component, OnInit, ViewChild } from '@angular/core';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { ActivatedRoute } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { MatTableDataSource } from "@angular/material";

import { CoreEventsService } from '../core-events.service';
import { AppService } from '../../../service/app.service';
import { MessageService } from '../../../service/messages/message.service';

@Component({
  selector: 'app-core-events-page',
  templateUrl: './core-events-page.component.html',
  styleUrls: ['./core-events-page.component.scss']
})
export class CoreEventsPageComponent implements OnInit {

  public entity_name: string;
  public entity_id: string;

  public item_per_page = 25;
  public page = 1;

  @ViewChild('eventsTable') eventsTable;
  @ViewChild('paginationConfig') paginationConfig;

  constructor(
    private route: ActivatedRoute,
    public coreEventsService: CoreEventsService,
    public appService: AppService,
    public messageService: MessageService
  ) { }

  ngOnInit() {
    this.entity_name = this.route.snapshot.params.name;
    this.entity_id = this.route.snapshot.params.id;
  }

  onPaginationChange(data) {
    if (this.item_per_page === data.pageSize) {
      this.page = data.pageIndex + 1;
    } else {
      this.paginationConfig.paginator.firstPage();
      this.page = 1;
      this.item_per_page = data.pageSize;
    }

    this.coreEventsService.showLoader = true;
    this.eventsTable.getEventsBySearch({
      item_per_page: this.item_per_page,
      page: this.page
    });
  }

}
