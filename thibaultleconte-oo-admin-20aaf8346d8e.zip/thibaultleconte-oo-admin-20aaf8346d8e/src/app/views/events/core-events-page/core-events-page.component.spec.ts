import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CoreEventsPageComponent } from './core-events-page.component';

describe('CoreEventsPageComponent', () => {
  let component: CoreEventsPageComponent;
  let fixture: ComponentFixture<CoreEventsPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CoreEventsPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoreEventsPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
