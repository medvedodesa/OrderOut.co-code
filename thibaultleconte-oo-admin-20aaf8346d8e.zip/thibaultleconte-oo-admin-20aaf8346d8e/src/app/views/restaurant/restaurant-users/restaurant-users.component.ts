import { Component, OnInit, Input } from '@angular/core';
import { MatDialog, MatSlideToggleChange, MatTableDataSource } from '@angular/material';

import { Account } from '../../account/account';

import { Restaurant, User } from '../restaurant';
import { RestaurantService } from '../../restaurant/restaurant.service';
import { RestaurantUsersDgComponent } from '../restaurant-users-dg/restaurant-users-dg.component';

import { LoaderService } from '../../../service/loader.service';
import { MessageService } from '../../../service/messages/message.service';
import { ConfirmationDialogService } from '../../common/confirmation-dialog/confirmation-dialog.service';

@Component({
  selector: 'app-restaurant-users',
  templateUrl: './restaurant-users.component.html',
  styleUrls: ['./restaurant-users.component.scss']
})
export class RestaurantUsersComponent implements OnInit {

  @Input() account: Account;
  @Input() restaurant: Restaurant;

  columnsToDisplay = ['fname', 'lname', 'email',
    'phone', 'role', 'notification', 'update', 'delete'];
  public userList: MatTableDataSource<User>;
  public noRecord: boolean;

  constructor(
    private restaurantService: RestaurantService,
    private loaderService: LoaderService,
    private messageService: MessageService,
    public cdService: ConfirmationDialogService,
    public dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.getuserList();
  }

  getuserList() {
    this.restaurantService.getUserList(this.restaurant.id).subscribe((userList) => {
      this.userList = new MatTableDataSource(userList);
      const isOwner = userList && userList.length === 1 && userList[0].role && userList[0].role.toLowerCase() === 'owner';
      if (isOwner) {
        userList[0].isOwner = true;
        this.columnsToDisplay = ['fname', 'lname', 'email', 'phone', 'role', 'notification'];
      }
      this.updateNoRecord();
    });
  }

  UserDialog(user?) {
    let options = {
      width: '600px'
    } as any;
    if (user) {
      options.data = user;
    }
    const dialogRef = this.dialog.open(RestaurantUsersDgComponent, options);
    dialogRef.componentInstance.event.subscribe((result) => {
      user ? this.updateUser(user, result) : this.addUser(result);
    });
  }

  updateUser(user, result, ob?: MatSlideToggleChange) {
    if (user.email) {
      this.loaderService.show();
      let isError = true;
      this.restaurantService.updateUser(this.restaurant.id, user.id, result).subscribe({
        next: resData => {
          if (resData && resData.id) {
            isError = false;
            const index = this.userList.data.findIndex(dataUser => dataUser.id === resData.id);
            if (index !== -1) {
              this.userList.data[index] = resData;
              this.userList.data = this.userList.data.slice(0);
            }
            this.messageService.openSnackBar("Your restaurant user updated successfully!");
          }
        }
      }).add(() => {
        if (isError) {
          user.receives_notification = !ob.checked;
        }
        this.loaderService.hide();
      });
    }
  }

  addUser(user) {
    if (user.email) {
      this.loaderService.show();
      this.restaurantService.addUser(this.restaurant.id, user).subscribe({
        next: res => {
          if (res && res.id) {
            this.messageService.openSnackBar("Your restaurant user created successfully!");
            this.userList.data.push(res);
            this.userList.data = this.userList.data; // To Refresh UI
            this.updateNoRecord();
          }
        },
        complete: () => {
          this.loaderService.hide();
        },
      });
    }
  }

  deleteUser(user) {
    if (user && user.role && user.role.toLowerCase() !== 'owner') {
      this.cdService.confirm({
        type: 'general-confirm',
        note: 'Want to delete <b>' + user.email + '</b> user?'
      }).subscribe(result => {
        if (result && result === true) {
          this.loaderService.show();
          this.restaurantService.deleteUser(this.restaurant.id, user.id).subscribe({
            next: res => {
              if (JSON.stringify(res) === '{}') {
                this.messageService.openSnackBar("Your restaurant user deleted successfully!");
                this.userList.data = this.userList.data.filter(luser => {
                  return luser.id !== user.id;
                });
                this.updateNoRecord();
              }
            },
            complete: () => {
              this.loaderService.hide();
            },
          });
        }
      });
    }
  }

  updateReceiveNotification(ob: MatSlideToggleChange, user: User) {
    const state = ob.checked === true ? 'Enable' : 'Disable';
    this.cdService.confirm({
      type: 'general-confirm',
      note: 'Want to <b>' + state + '</b> receive notification for <b>' + user.email + '</b>?'
    }).subscribe(result => {
      if (result && result === true) {
        const params = {
          firstname: user.firstname,
          lastname: user.lastname,
          email: user.email,
          role: user.role,
          phone: user.phone,
          receives_notification: ob.checked
        }
        this.updateUser(user, params, ob);
      } else {
        user.receives_notification = !ob.checked;
      }
    });

  }

  updateNoRecord() {
    this.noRecord = this.userList.data.length === 0 ? true : false;
  }

}
