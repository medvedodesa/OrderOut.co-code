import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaurantUsersComponent } from './restaurant-users.component';

describe('RestaurantUsersComponent', () => {
  let component: RestaurantUsersComponent;
  let fixture: ComponentFixture<RestaurantUsersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestaurantUsersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurantUsersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
