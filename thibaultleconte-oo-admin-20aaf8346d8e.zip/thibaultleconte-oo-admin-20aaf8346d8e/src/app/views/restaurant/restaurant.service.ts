import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import * as _ from 'lodash';

import { environment } from '../../../environments/environment';
import { ApiService } from './../../core/api.service';
import { Restaurant, RestaurantsList } from './restaurant';

@Injectable()
export class RestaurantService {

  accountUrl = environment.backend_url + 'account';
  restaurantUrl = environment.backend_url + 'restaurant';
  pointOfSaleUrl = environment.backend_url + 'pos';

  constructor(private api: ApiService) { }

  getRestaurants(accountId: number): Observable<RestaurantsList> {
    const url = `${this.accountUrl}/${accountId}/restaurants`;
    return this.api.get(url);
  }

  getRestaurant(restaurantId: number): Observable<Restaurant> {
    const url = `${this.restaurantUrl}/${restaurantId}`;
    return this.api.get(url);
  }

  getContactList(restaurantId: number): Observable<any> {
    const url = `${this.restaurantUrl}/${restaurantId}/contact`;
    return this.api.get(url);
  }

  getUserList(restaurantId: number): Observable<any> {
    const url = `${this.restaurantUrl}/${restaurantId}/user`;
    return this.api.get(url);
  }

  addContact(restaurantId: number, payload): Observable<any> {
    const url = `${this.restaurantUrl}/${restaurantId}/contact`;
    const params = {
      name: payload.name,
      email: payload.email,
      phone_number: payload.phone_number
    };
    return this.api.post(url, params);
  }

  addUser(restaurantId: number, payload): Observable<any> {
    payload = _.omitBy(payload, _.isNil)
    const url = `${this.restaurantUrl}/${restaurantId}/user`;
    return this.api.post(url, payload);
  }

  updateUser(restaurantId: number, userId: number, payload): Observable<any> {
    payload = _.omitBy(payload, _.isNil)
    const url = `${this.restaurantUrl}/${restaurantId}/user/${userId}`;
    return this.api.put(url, payload);
  }

  addRestaurant(accountId: number, restaurant: Restaurant): Observable<Restaurant> {
    const params = {
      parent_id: accountId,
      entity: restaurant
    };
    return this.api.post(this.restaurantUrl, params);
  }

  updateRestaurant(restaurant: Restaurant): Observable<Restaurant> {
    const url = `${this.restaurantUrl}/${restaurant.id}`;
    const params = {
      name: restaurant.name,
      printDoubleOrder: restaurant.printDoubleOrder,
      pointOfSaleIntegrationEnabled: restaurant.pointOfSaleIntegrationEnabled,
      "preparation_time": restaurant.preparation_time
    };
    return this.api.put(url, params);
  }

  deleteContact(restaurantId: number, contactId: number) {
    const url = `${this.restaurantUrl}/${restaurantId}/contact/${contactId}`;
    return this.api.delete(url);
  }

  deleteUser(restaurantId: number, userId: number) {
    const url = `${this.restaurantUrl}/${restaurantId}/user/${userId}`;
    return this.api.delete(url);
  }

  deleteRestaurant(restaurantId: number) {
    const url = `${this.restaurantUrl}/${restaurantId}`;
    return this.api.delete(url);
  }

}
