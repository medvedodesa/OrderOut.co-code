import { Component, OnInit, EventEmitter, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormBuilder, FormControl, FormGroup, Validators, ValidationErrors } from '@angular/forms';

@Component({
  selector: 'app-restaurant-contact-dg',
  templateUrl: './restaurant-contact-dg.component.html',
  styleUrls: ['./restaurant-contact-dg.component.scss']
})
export class RestaurantContactDgComponent implements OnInit {

  public addContactFormGroup: FormGroup;
  public title: string = 'Add New Contact';
  public okBtn: string = 'Add';
  public clBtn: string = 'Cancel';
  public event: EventEmitter<any> = new EventEmitter();

  constructor(
    public dialogRef: MatDialogRef<RestaurantContactDgComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public fb: FormBuilder
  ) {
    if (data) {
      this.title = data.title || this.title;
      this.okBtn = data.okBtn || this.okBtn;
    }
  }

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    const nonWhitespaceRegExp: RegExp = new RegExp("\\S");
    let name = new FormControl(this.data && this.data.name, {
      validators: Validators.compose([
        Validators.required,
        Validators.pattern(nonWhitespaceRegExp)
      ])
    });

    let email = new FormControl(this.data && this.data.email, {
      validators: Validators.compose([
        //Validators.required,
        Validators.email
      ])
    });

    let phone_number = new FormControl(this.data && this.data.phone_number, {
      validators: Validators.compose([
        //Validators.required,
        Validators.pattern(/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im)
      ])
    });

    this.addContactFormGroup = this.fb.group({
      'name': name,
      'email': email,
      'phone_number': phone_number
    },
      { validator: this.atLeastOne('email', 'phone_number') },
    );
  }

  hasError(field, validator) {
    return field && validator ? this.addContactFormGroup.get(field).hasError(validator) : false;
  }

  onSubmit(value): void {
    console.log(value);
    this.event.emit(value);
    this.dialogRef.close();
  }

  atLeastOne(...fields: string[]) {
    return (fg: FormGroup): ValidationErrors | null => {
      return fields.some(fieldName => {
        const field = fg.get(fieldName).value;
        if (typeof field === 'number') return field && field >= 0 ? true : false;
        if (typeof field === 'string') return field && field.length > 0 ? true : false;
      })
        ? null
        : ({ atLeastOne: 'At least one field has to be provided.' } as ValidationErrors);
    };
  }

}
