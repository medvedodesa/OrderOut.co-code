import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaurantContactDgComponent } from './restaurant-contact-dg.component';

describe('RestaurantContactDgComponent', () => {
  let component: RestaurantContactDgComponent;
  let fixture: ComponentFixture<RestaurantContactDgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestaurantContactDgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurantContactDgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
