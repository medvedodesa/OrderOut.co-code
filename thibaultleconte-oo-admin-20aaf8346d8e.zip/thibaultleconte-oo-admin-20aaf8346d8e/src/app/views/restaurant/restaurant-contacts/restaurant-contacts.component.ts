import { Component, OnInit, Input } from '@angular/core';
import { MatDialog, MatTableDataSource } from '@angular/material';

import { Account } from '../../account/account';

import { Restaurant } from '../restaurant';
import { RestaurantService } from '../../restaurant/restaurant.service';
import { RestaurantContactDgComponent } from '../restaurant-contact-dg/restaurant-contact-dg.component';

import { LoaderService } from '../../../service/loader.service';
import { MessageService } from '../../../service/messages/message.service';
import { ConfirmationDialogService } from '../../common/confirmation-dialog/confirmation-dialog.service';

@Component({
  selector: 'app-restaurant-contacts',
  templateUrl: './restaurant-contacts.component.html',
  styleUrls: ['./restaurant-contacts.component.scss']
})
export class RestaurantContactsComponent implements OnInit {

  @Input() account: Account;
  @Input() restaurant: Restaurant;

  columnsToDisplay = ['name', 'email', 'phone', 'delete'];
  public contactList: MatTableDataSource<any>;
  public noRecord: boolean;

  constructor(
    private restaurantService: RestaurantService,
    private loaderService: LoaderService,
    private messageService: MessageService,
    public cdService: ConfirmationDialogService,
    public dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.getContactList();
  }

  getContactList() {
    this.restaurantService.getContactList(this.restaurant.id).subscribe((contactList) => {
      this.contactList = new MatTableDataSource(contactList && contactList.data);
      this.updateNoRecord();
    });
  }

  addContactDialog() {
    const dialogRef = this.dialog.open(RestaurantContactDgComponent, {
      width: '600px'
    });
    dialogRef.componentInstance.event.subscribe((result) => {
      this.addContact(result);
    });
  }

  addContact(contact) {
    if (contact.name && (contact.email || contact.phone_number)) {
      this.loaderService.show();
      this.restaurantService.addContact(this.restaurant.id, contact).subscribe({
        next: res => {
          if (res && res.id) {
            this.messageService.openSnackBar("Your restaurant contact created successfully!");
            this.contactList.data.push(res);
            this.contactList.data = this.contactList.data; // To Refresh UI
            this.updateNoRecord();
          }
        },
        complete: () => {
          this.loaderService.hide();
        },
      });
    }
  }

  deleteContact(contact) {
    this.cdService.confirm({
      type: 'general-confirm',
      note: 'Want to delete <b>' + contact.name + '</b> contact?'
    }).subscribe(result => {
      if (result && result === true) {
        this.loaderService.show();
        this.restaurantService.deleteContact(this.restaurant.id, contact.id).subscribe({
          next: res => {
            if (JSON.stringify(res) === '{}') {
              this.messageService.openSnackBar("Your restaurant contact deleted successfully!");
              this.contactList.data = this.contactList.data.filter(lcontact => {
                return lcontact.id !== contact.id;
              });
              this.updateNoRecord();
            }
          },
          complete: () => {
            this.loaderService.hide();
          },
        });
      }
    });
  }

  updateNoRecord() {
    this.noRecord = this.contactList.data.length === 0 ? true : false;
  }

}
