import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaurantContactsComponent } from './restaurant-contacts.component';

describe('RestaurantContactsComponent', () => {
  let component: RestaurantContactsComponent;
  let fixture: ComponentFixture<RestaurantContactsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestaurantContactsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurantContactsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
