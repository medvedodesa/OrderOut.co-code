import { Component, OnInit, OnDestroy, Input } from '@angular/core';
import { ISubscription } from 'rxjs/Subscription';
import { MatDialog } from '@angular/material';

import { Account } from '../../account/account';

import { Restaurant } from '../restaurant';
import { RestaurantService } from '../../restaurant/restaurant.service';
import { RestaurantDialogComponent } from '../../restaurant/restaurant-dialog/restaurant-dialog.component';

import { breadcrumb } from '../../common/breadcrumb/breadcrumb';
import { BreadcrumbService } from '../../common/breadcrumb/breadcrumb.service';
import { LoaderService } from '../../../service/loader.service';

@Component({
  selector: 'app-restaurant-details',
  templateUrl: './restaurant-details.component.html',
  styleUrls: ['./restaurant-details.component.scss']
})
export class RestaurantDetailsComponent implements OnInit, OnDestroy {

  private subscription: ISubscription;
  public preparationTime: number = 15;

  @Input() account: Account;
  @Input() restaurant: Restaurant;

  public breadcrumbList: breadcrumb[] = [];

  constructor(
    public dialog: MatDialog,
    private restaurantService: RestaurantService,
    private breadcrumbService: BreadcrumbService,
    private loaderService: LoaderService
  ) { }

  ngOnInit() {
    this.initBreadcrumbList();
    this.preparationTime = Math.round(this.restaurant.preparation_time / 60);
  }

  ngOnDestroy() {
    if (!this.subscription) { return; }
    this.subscription.unsubscribe();
  }

  openEditRestaurantDialog() {
    const dialogRef = this.dialog.open(RestaurantDialogComponent, {
      width: '600px',
      data: {
        'title': 'Update Restaurant',
        'restaurant': this.restaurant
      }
    });
    dialogRef.componentInstance.event.subscribe((result) => {
      this.updateRestaurant(result);
    });
  }

  updateRestaurant(res) {
    this.restaurant.name = res.restaurantName;
    this.preparationTime = res.preparationTime / 60;
    this.restaurant.preparation_time = res.preparationTime;
    this.initBreadcrumbList();
    this.loaderService.show();
    this.restaurantService.updateRestaurant(this.restaurant).subscribe(res => {
    }).add(() => {
      this.loaderService.hide();
    });
  }

  initBreadcrumbList() {
    this.breadcrumbService.resetBreadcrumbList();
    this.breadcrumbList = this.breadcrumbService.getRestaurant(
      this.account,
      this.restaurant
    );
  }

}
