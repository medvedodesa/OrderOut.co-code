import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { mergeMap, map } from 'rxjs/operators';
import { RestaurantService } from './restaurant.service';
import { AccountService } from '../account/account.service';

@Injectable()
export class RestaurantResolve implements Resolve<any> {

  constructor(
    private restaurantService: RestaurantService,
    private accountService: AccountService
  ) {}

  resolve(route: ActivatedRouteSnapshot) {

    return this.restaurantService.getRestaurant(route.params.restaurantId);

    // let oAccountRestaurant = {};

    // return this.restaurantService.getRestaurant(route.params.restaurantId).pipe(
    //   mergeMap(restaurant => {
    //     oAccountRestaurant['restaurant'] = restaurant;
    //     return this.accountService.getAccount(restaurant.accountId).pipe(
    //       map(account => {
    //         oAccountRestaurant['account'] = account;
    //         return oAccountRestaurant;
    //       })
    //     );
    //   })
    // );
    
  }
}