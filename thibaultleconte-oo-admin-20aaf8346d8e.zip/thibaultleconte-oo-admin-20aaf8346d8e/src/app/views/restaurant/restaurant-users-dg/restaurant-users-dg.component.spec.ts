import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaurantUsersDgComponent } from './restaurant-users-dg.component';

describe('RestaurantUsersDgComponent', () => {
  let component: RestaurantUsersDgComponent;
  let fixture: ComponentFixture<RestaurantUsersDgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestaurantUsersDgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurantUsersDgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
