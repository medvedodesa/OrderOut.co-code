import { Component, OnInit, EventEmitter, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormBuilder, FormControl, FormGroup, Validators, ValidationErrors } from '@angular/forms';

@Component({
  selector: 'app-restaurant-users-dg',
  templateUrl: './restaurant-users-dg.component.html',
  styleUrls: ['./restaurant-users-dg.component.scss']
})
export class RestaurantUsersDgComponent implements OnInit {

  public userFormGroup: FormGroup;
  public title: string = 'Add New User';
  public okBtn: string = 'Add';
  public clBtn: string = 'Cancel';
  public event: EventEmitter<any> = new EventEmitter();
  public showRoleField: boolean = true;
  public roles = [{
    displayValue: 'MANAGER',
    value: 'manager'
  },
  {
    displayValue: 'USER',
    value: 'user'
  }];

  constructor(
    public dialogRef: MatDialogRef<RestaurantUsersDgComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public fb: FormBuilder
  ) {
    if (data) {
      this.title = 'Update User';
      this.okBtn = "Update";
    }
  }

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    const nonWhitespaceRegExp: RegExp = new RegExp("\\S");
    const firstname = {
      validators: Validators.compose([
        Validators.required,
        Validators.pattern(nonWhitespaceRegExp)
      ])
    };

    const lastname = {
      validators: Validators.compose([
        Validators.pattern(nonWhitespaceRegExp)
      ])
    };

    let email = new FormControl(this.data && this.data.email, {
      validators: Validators.compose([
        Validators.required,
        Validators.email
      ])
    });

    let phone_number = new FormControl(this.data && this.data.phone, {
      validators: Validators.compose([
        //Validators.required,
        Validators.pattern(/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im)
      ])
    });

    let formFields = {
      'firstname': new FormControl(this.data && this.data.firstname, firstname),
      'lastname': new FormControl(this.data && this.data.lastname, lastname),
      'email': email,
      'role': new FormControl(this.data && this.data.role && this.data.role.toLowerCase()),
      'phone': phone_number,
      'receives_notification': new FormControl(this.data && this.data.receives_notification),
    };
    const aEmail = this.data && this.data.email && this.data.email.split('@');
    if (aEmail && aEmail[1] && aEmail[1] === 'orderout.co') {
      this.showRoleField = false;
      delete formFields.role;
    }
    this.userFormGroup = this.fb.group(formFields);
  }

  hasError(field, validator) {
    return field && validator ? this.userFormGroup.get(field).hasError(validator) : false;
  }

  onSubmit(value): void {
    this.event.emit(value);
    this.dialogRef.close();
  }

  atLeastOne(...fields: string[]) {
    return (fg: FormGroup): ValidationErrors | null => {
      return fields.some(fieldName => {
        const field = fg.get(fieldName).value;
        if (typeof field === 'number') return field && field >= 0 ? true : false;
        if (typeof field === 'string') return field && field.length > 0 ? true : false;
      })
        ? null
        : ({ atLeastOne: 'At least one field has to be provided.' } as ValidationErrors);
    };
  }

}
