import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaurantProcessDgComponent } from './restaurant-process-dg.component';

describe('RestaurantProcessDgComponent', () => {
  let component: RestaurantProcessDgComponent;
  let fixture: ComponentFixture<RestaurantProcessDgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestaurantProcessDgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurantProcessDgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
