import { Component, OnInit, Inject, ViewChild, TemplateRef, ViewEncapsulation } from '@angular/core';
import { Router } from "@angular/router";
import { STEPPER_GLOBAL_OPTIONS } from "@angular/cdk/stepper";
import { MatStepper } from '@angular/material/stepper';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

import { Restaurant } from '../restaurant';
import { DeliveryService } from '../../deliveryservice/deliveryservice';
import { PointOfSale } from '../../pointofsale/pointofsale';
import { Printer } from '../../printer/printer';

import { RestaurantHelper } from '../restaurant.helper';
import { DeliveryserviceService } from '../../deliveryservice/deliveryservice.service';
import { PointofsaleService } from '../../pointofsale/pointofsale.service';
import { PrinterService } from '../../printer/printer.service';
import { RestaurantService } from '../restaurant.service';
import { delay } from 'rxjs/operators';

@Component({
  selector: 'app-restaurant-process-dg',
  templateUrl: './restaurant-process-dg.component.html',
  styleUrls: ['./restaurant-process-dg.component.scss'],
  providers: [
    {
      provide: STEPPER_GLOBAL_OPTIONS,
      useValue: { displayDefaultIndicatorType: false }
    }
  ],
  encapsulation: ViewEncapsulation.None
})
export class RestaurantProcessDgComponent implements OnInit {

  @ViewChild('dsStepper') dsStepper: MatStepper;
  @ViewChild('posStepper') posStepper: MatStepper;
  @ViewChild('printerStepper') printerStepper: MatStepper;
  @ViewChild('resStepper') resStepper: MatStepper;

  @ViewChild('Restaurant') Restaurant: TemplateRef<any>;
  @ViewChild('DS') DS: TemplateRef<any>;
  @ViewChild('POS') POS: TemplateRef<any>;
  @ViewChild('Printers') Printers: TemplateRef<any>;

  public resEntities = [];
  public selected = 0;
  public restaurant: Restaurant;
  public deliveryServices: DeliveryService[];
  public pos: PointOfSale;
  public printers: Printer[];

  public actionList = [];
  public dsSteps;
  public posStep;
  public printerSteps;
  public resStep;

  constructor(
    public dialogRef: MatDialogRef<RestaurantProcessDgComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private router: Router,
    public restaurantHelper: RestaurantHelper,
    public dsService: DeliveryserviceService,
    public posService: PointofsaleService,
    public printerService: PrinterService,
    public resService: RestaurantService
  ) {
    this.restaurant = data.restaurant;
    this.restaurantHelper.deliveryServices$.subscribe(deliveryServices => this.deliveryServices = deliveryServices);
    this.restaurantHelper.pos$.subscribe(pos => this.pos = pos);
    this.restaurantHelper.printers$.subscribe(printers => this.printers = printers);
  }

  ngOnInit() {
    this.buildTabs();
    this.startActions();
  }

  nextTab() {
    this.selected = this.selected + 1;
  }

  nextStep(stepper) {
    stepper.next();
  }

  completeStep(stepper) {
    stepper.selected.completed = true;
    stepper.selected.state = "done";
  }

  buildTabs() {
    this.buildDSTab();

    this.buildPOSTab();

    this.buildPrintersTab();

    this.buildResTab();
  }

  buildDSTab() {
    if (this.deliveryServices && this.deliveryServices.length > 0) {
      this.resEntities.push({
        'text': 'Delivery Services',
        'name': 'DS'
      });

      this.dsSteps = [];
      this.deliveryServices.forEach(ds => {
        if (ds.integration_enabled) {
          if (ds.type === 'UBEREATS') {
            const uberEatsStep = this.getUberEatsStep(ds);
            this.dsSteps.push(uberEatsStep);
          }
          const disableDSStep = this.getDisableDSStep(ds);
          this.dsSteps.push(disableDSStep);
        }
        const deleteDSStep = this.getdeleteDSStep(ds);
        this.dsSteps.push(deleteDSStep);
      });

      let lastDSStep = this.dsSteps[this.dsSteps.length - 1];
      lastDSStep.lastStep = true;

      this.actionList = this.actionList.concat(this.dsSteps);
    }
  }

  buildPOSTab() {
    if (this.pos && this.pos.id) {
      this.resEntities.push({
        'text': 'Point Of Sale',
        'name': 'POS'
      });

      this.posStep = this.getDisconnectStep(this.pos.type);
      this.posStep.service = this.posService;
      this.posStep.method = 'disconnect';
      this.posStep.param = [this.pos.id];
      this.posStep.stepper = 'posStepper';
      this.posStep.lastStep = true;

      this.actionList = this.actionList.concat(this.posStep);
    }
  }

  buildPrintersTab() {
    if (this.printers && this.printers.length > 0) {
      this.resEntities.push({
        'text': 'Printers',
        'name': 'Printers'
      });

      this.printerSteps = [];
      this.printers.forEach(printer => {
        const name = printer.mac + ' (' + printer.manufacturerName + ') Printer';
        let disconnectStep: any = this.getDisconnectStep(name);
        disconnectStep.service = this.printerService;
        disconnectStep.method = 'deletePrinter';
        disconnectStep.param = [printer.id];
        disconnectStep.stepper = 'printerStepper';
        this.printerSteps.push(disconnectStep);
      });

      let lastPrinterStep = this.printerSteps[this.printerSteps.length - 1];
      lastPrinterStep.lastStep = true;

      this.actionList = this.actionList.concat(this.printerSteps);
    }
  }

  buildResTab() {
    if (this.restaurant && this.restaurant.id) {
      this.resEntities.push({
        'text': 'Restaurant',
        'name': 'Restaurant'
      });

      const name = this.restaurant.name + ' Restaurant';
      this.resStep = this.getDeleteStep(name);
      this.resStep.service = this.resService;
      this.resStep.method = 'deleteRestaurant';
      this.resStep.param = [this.restaurant.id];
      this.resStep.stepper = 'resStepper';
      this.resStep.lastStep = true;

      this.actionList = this.actionList.concat(this.resStep);
    }
  }

  getUberEatsStep(ds: DeliveryService) {
    const name = ds.type + ' POS data';
    let uberStep: any = this.getDisableStep(name);
    uberStep.isDisableStep = false; // Keep false for UberEats
    uberStep.entity = ds;
    uberStep.service = this.dsService;
    uberStep.method = 'updatePosStatus';
    const params = [ds.id, false]; // false - Disable Delivery Service POS status. true - Enable Delivery Service POS status.
    uberStep.param = params;
    uberStep.stepper = 'dsStepper';
    return uberStep;
  }

  getDisableDSStep(ds: DeliveryService) {
    let disableStep: any = this.getDisableStep(ds.type);
    disableStep.entity = ds;
    disableStep.service = this.dsService;
    disableStep.method = 'updateDeliveryService';
    const params = [{
      "id": ds.id,
      "integration_enabled": !ds.integration_enabled,
      "service_menu_url": ds.service_menu_url,
      "serviceLocationId": ds.serviceLocationId
    }];
    disableStep.param = params;
    disableStep.stepper = 'dsStepper';
    return disableStep;
  }

  getdeleteDSStep(ds: DeliveryService) {
    let deleteStep: any = this.getDeleteStep(ds.type);
    deleteStep.service = this.dsService;
    deleteStep.method = 'disconnect';
    deleteStep.param = [ds.id];
    deleteStep.stepper = 'dsStepper';
    return deleteStep;
  }

  getDisableStep(entity) {
    return {
      editable: false,
      status: '',
      lastStep: false,
      label: 'Disable ' + entity,
      activeLabel: 'Disabling ' + entity,
      activeText: 'Disable ' + entity + ' integration has been started.',
      errorLabel: 'Error in Disabling ' + entity,
      errorText: entity + ' integration has not been disabled.',
      successLabel: 'Disabled ' + entity,
      successText: 'Disabled ' + entity + ' Successfully.',
      isDisableStep: true,
    }
  }

  getDisconnectStep(entity) {
    return {
      editable: false,
      status: '',
      lastStep: false,
      label: 'Disconnect ' + entity,
      activeLabel: 'Disconnecting ' + entity,
      activeText: 'Disconnect ' + entity + ' has been started.',
      errorLabel: 'Error in Disconnecting ' + entity,
      errorText: entity + ' has not been Disconnected.',
      successLabel: 'Disconnected ' + entity,
      successText: 'Disconnected ' + entity + ' Successfully.',
    }
  }

  getDeleteStep(entity) {
    return {
      editable: false,
      status: '',
      lastStep: false,
      label: 'Delete ' + entity,
      activeLabel: 'Deleting ' + entity,
      activeText: 'Delete ' + entity + ' has been started.',
      errorLabel: 'Error in Delete ' + entity,
      errorText: entity + ' has not been Deleted.',
      successLabel: 'Deleted ' + entity,
      successText: 'Deleted ' + entity + ' Successfully.',
    }
  }

  startActions() {
    let loop = (list, action) => {
      action.status = 'A';
      action.label = action.activeLabel;
      action.service[action.method].apply(action.service, action.param).pipe(delay(3000)).subscribe(res => {
        console.log(action.successLabel);
        console.log(res);
        action.status = 'C';
        action.label = action.successLabel;
        action.isDisableStep ? action.entity.integration_enabled = false : '';
        if (action.lastStep) {
          action.activeText = action.successText;
          this.completeStep(this[action.stepper]);
          this.nextTab();
        } else {
          this.nextStep(this[action.stepper]);
        }
      }).add(() => {
        if (list.length && action.status === 'C') {
          loop(list, list.shift());
        } else if (action.status !== 'C') {
          action.status = 'E';
          action.label = action.errorLabel;
          action.activeText = action.errorText;
        } else {
          this.router.navigate(["account", this.restaurant.accountId]);
        }
      });
    }

    if (this.actionList && this.actionList.length > 0) {
      loop(this.actionList, this.actionList.shift());
    }
  }

}
