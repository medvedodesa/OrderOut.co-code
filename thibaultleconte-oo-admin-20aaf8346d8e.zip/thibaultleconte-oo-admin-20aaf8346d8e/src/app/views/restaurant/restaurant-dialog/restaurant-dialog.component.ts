import { Component, EventEmitter, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-restaurant-dialog',
  templateUrl: './restaurant-dialog.component.html',
  styleUrls: ['./restaurant-dialog.component.scss']
})
export class RestaurantDialogComponent {

  public restaurantFormGroup: FormGroup;
  public title: string = '';
  public restaurantName: string = '';
  public preparationTime: number = 15;
  public event: EventEmitter<any> = new EventEmitter();

  constructor(
    public dialogRef: MatDialogRef<RestaurantDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) { 
    this.restaurantName = data.restaurant && data.restaurant.name;
    this.preparationTime = data.restaurant && Math.round(data.restaurant.preparation_time / 60);
    this.title = data.title;
  }

  ngOnInit() {
    const nonWhitespaceRegExp: RegExp = new RegExp("\\S");
    const digitsRegExp: RegExp = new RegExp("^[0-9]*$");
    this.restaurantFormGroup = new FormGroup({
      restaurantName: new FormControl(this.restaurantName, [Validators.required, Validators.pattern(nonWhitespaceRegExp)]),
      preparationTime: new FormControl(this.preparationTime, [Validators.required, Validators.pattern(nonWhitespaceRegExp), Validators.pattern(digitsRegExp)])
    });
  }

  onSubmit(value): void {
    let name = value && value.restaurantName && value.restaurantName.trim();
    let preparationTime = value.preparationTime * 60;
    if(name && name.length > 0) {
      this.restaurantName = name;
      this.event.emit({
        "restaurantName": this.restaurantName,
        "preparationTime": preparationTime 
      });
      this.dialogRef.close();
    }
  }

}
