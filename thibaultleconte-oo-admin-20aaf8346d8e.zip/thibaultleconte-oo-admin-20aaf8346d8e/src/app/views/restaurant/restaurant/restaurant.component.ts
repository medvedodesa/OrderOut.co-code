import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Account } from '../../account/account';
import { AccountRestaurant, Restaurant } from '../restaurant';
import { DeliveryService } from '../../deliveryservice/deliveryservice';
import { cloverLead } from '../../pointofsale/pointofsale';

@Component({
  selector: 'app-restaurant',
  templateUrl: './restaurant.component.html',
  styleUrls: ['./restaurant.component.scss']
})
export class RestaurantComponent implements OnInit, OnDestroy {

  public accountRestaurant: AccountRestaurant;
  public account: Account;
  public restaurant: Restaurant;
  public deliveryServices: DeliveryService[];
  public cloverLead: cloverLead;

  constructor(
    private route: ActivatedRoute,
  ) { }

  ngOnInit() {
    this.accountRestaurant = this.route.snapshot.data.accountRestaurant;
    this.account = this.accountRestaurant.account;
    this.restaurant = this.accountRestaurant.restaurant;
  }

  emitDeliveryServicesList(list: DeliveryService[]) {
    this.deliveryServices = list;
  }

  emitCloverLead(cloverLead: cloverLead) {
    this.cloverLead = cloverLead;
  }

  ngOnDestroy() { }

}
