import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { MatDialog, MatTableDataSource, MatSort } from '@angular/material';
import { Router } from '@angular/router';

import { Restaurant } from '../../restaurant/restaurant';
import { RestaurantService } from '../../restaurant/restaurant.service';
import { RestaurantHelper } from '../restaurant.helper';
import { RestaurantDialogComponent } from '../../restaurant/restaurant-dialog/restaurant-dialog.component';

import { Account} from '../../account/account';

@Component({
  selector: 'app-restaurant-list',
  templateUrl: './restaurant-list.component.html',
  styleUrls: ['./restaurant-list.component.scss']
})
export class RestaurantListComponent implements OnInit {

  @Input() account: Account;

  columnsToDisplay = ['name', 'api_created_at'];  // 'operational',
  restaurants: Restaurant[];
  dataSource: MatTableDataSource<Restaurant>;

  public editEnable: boolean = false;

  @ViewChild(MatSort) sort: MatSort;

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private restaurantService: RestaurantService,
    public restaurantHelper: RestaurantHelper,
  ) { }

    ngOnInit() {
      this.restaurantService.getRestaurants(this.account.id).subscribe(restaurantsList => {
        this.restaurantHelper.setRestaurants(restaurantsList.data);
        this.restaurants = restaurantsList.data;
        this.dataSource = new MatTableDataSource(this.restaurants);
        this.dataSource.sort = this.sort;
      });
    }

    openCreateRestaurantDialog() {
      const dialogRef = this.dialog.open(RestaurantDialogComponent, {
        width: '600px',
        data: {
          'title': 'Add Restaurant'
        }
      });
      dialogRef.componentInstance.event.subscribe((result) => {
        this.createRestaurant(result.restaurantName);
      });
    }

    createRestaurant(name: string) {
      const newRestaurant: Restaurant = { name } as Restaurant;
      this.restaurantService.addRestaurant(this.account.id, newRestaurant).subscribe(restaurant => {
        this.router.navigate(['restaurant', restaurant.id]);
      });
    }

    rowSelected(restaurant: Restaurant) {
      this.router.navigate(['restaurant', restaurant.id]);
    }

    openEditRestaurantDialog(event, restaurant: Restaurant) {
      event.stopPropagation();
      const dialogRef = this.dialog.open(RestaurantDialogComponent, {
        width: '600px',
        data: {
          'title': 'Update Restaurant',
          'name': restaurant.name
        }
      });
      dialogRef.componentInstance.event.subscribe((result) => {
        this.updateRestaurant(result.restaurantName, restaurant);
      });
    }

    updateRestaurant(name: string, restaurant: Restaurant) {
      restaurant.name = name;
      this.restaurantService.updateRestaurant(restaurant).subscribe();
    }

}
