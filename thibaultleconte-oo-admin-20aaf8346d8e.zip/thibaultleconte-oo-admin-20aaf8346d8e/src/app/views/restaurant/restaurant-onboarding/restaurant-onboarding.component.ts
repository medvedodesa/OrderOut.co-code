import { Component, OnInit, Input } from '@angular/core';

import { Restaurant } from '../restaurant';
import { DeliveryService } from '../../deliveryservice/deliveryservice';

import { AppService } from '../../../service/app.service';
import { LoaderService } from '../../../service/loader.service';
import { DeliveryserviceService } from '../../deliveryservice/deliveryservice.service';

import { DsConnectDgService } from '../../deliveryservice/deliveryservice-connect-dialog/ds-connect-dg.service';
import { ConfirmationDialogService } from '../../common/confirmation-dialog/confirmation-dialog.service';

@Component({
  selector: 'app-restaurant-onboarding',
  templateUrl: './restaurant-onboarding.component.html',
  styleUrls: ['./restaurant-onboarding.component.scss']
})
export class RestaurantOnboardingComponent implements OnInit {

  @Input() restaurant: Restaurant;
  @Input() deliveryServices: DeliveryService[];

  public columnsToDisplay = ['type', 'menu_url', 'api_created_at', 'connect', 'delete'];
  public onboardURL: string;

  constructor(
    private appService: AppService,
    private loaderService: LoaderService,
    public cdService: ConfirmationDialogService,
    private deliveryserviceService: DeliveryserviceService,
    private dsConnectDgService: DsConnectDgService
  ) { }

  ngOnInit() {
    this.onboardURL = window.location.href + '/onboarding';
  }

  onNavigate(){
    window.open(this.onboardURL, "_blank");
  }

  copyURL() {
    this.appService.copyText(this.onboardURL);
  }

  connectDeliveryService(ds: DeliveryService) {
    this.dsConnectDgService.openConnectDSDialog(ds, this.restaurant.id);
  }

  deleteDeliveryService(ds: DeliveryService) {
    this.cdService.confirm({
      message: {
        name: ds.type,
        type: 'Delivery Service'
      }
    }).subscribe(result => {
      if (result) {
        this.loaderService.show();
        this.deliveryserviceService.disconnect(ds.id).subscribe(() => {
          this.loaderService.hide();
          this.deliveryServices = this.deliveryServices.filter(deliveryService => {
            return deliveryService.id !== ds.id;
          });
        });
      }
    });
  }

}
