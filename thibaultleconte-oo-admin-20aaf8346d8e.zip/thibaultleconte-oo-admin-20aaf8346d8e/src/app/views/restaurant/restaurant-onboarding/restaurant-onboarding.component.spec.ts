import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaurantOnboardingComponent } from './restaurant-onboarding.component';

describe('RestaurantOnboardingComponent', () => {
  let component: RestaurantOnboardingComponent;
  let fixture: ComponentFixture<RestaurantOnboardingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestaurantOnboardingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurantOnboardingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
