import { Component, OnInit, Input } from '@angular/core';
import { cloverLead } from '../../pointofsale/pointofsale';

@Component({
  selector: 'app-restaurant-merchant',
  templateUrl: './restaurant-merchant.component.html',
  styleUrls: ['./restaurant-merchant.component.scss']
})
export class RestaurantMerchantComponent implements OnInit {

  @Input() cloverLead: cloverLead;
  
  constructor() { }

  ngOnInit() {
  }

}
