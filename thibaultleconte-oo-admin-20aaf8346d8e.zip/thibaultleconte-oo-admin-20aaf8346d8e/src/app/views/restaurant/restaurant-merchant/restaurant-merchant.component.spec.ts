import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaurantMerchantComponent } from './restaurant-merchant.component';

describe('RestaurantMerchantComponent', () => {
  let component: RestaurantMerchantComponent;
  let fixture: ComponentFixture<RestaurantMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RestaurantMerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurantMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
