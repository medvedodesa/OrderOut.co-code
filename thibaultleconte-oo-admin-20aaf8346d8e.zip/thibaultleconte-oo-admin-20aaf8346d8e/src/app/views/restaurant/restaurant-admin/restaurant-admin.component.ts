import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';

import { Restaurant } from '../restaurant';
import { RestaurantProcessDgComponent } from '../restaurant-process-dg/restaurant-process-dg.component';
import { ConfirmationDialogService } from '../../common/confirmation-dialog/confirmation-dialog.service';


@Component({
  selector: 'app-restaurant-admin',
  templateUrl: './restaurant-admin.component.html',
  styleUrls: ['./restaurant-admin.component.scss']
})
export class RestaurantAdminComponent implements OnInit {

  @Input() restaurant: Restaurant;

  constructor(
    public cdService: ConfirmationDialogService,
    public dialog: MatDialog,
  ) { }

  ngOnInit() { }

  deleteRestaurant() {
    this.cdService.confirm({
      message: {
        name: this.restaurant.name,
        type: 'restaurant'
      }
    }).subscribe(result => {
      if (result) {
        const dgRef = this.dialog.open(RestaurantProcessDgComponent, {
          data: {
            restaurant: this.restaurant,
          },
          disableClose: true
        });
      }
    });
  }

}
