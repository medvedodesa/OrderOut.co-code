import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { distinctUntilChanged } from 'rxjs/operators';
import { Restaurant } from './restaurant';
import { DeliveryService } from '../deliveryservice/deliveryservice';
import { PointOfSale } from '../pointofsale/pointofsale';
import { Printer } from '../printer/printer';

@Injectable()
export class RestaurantHelper {

    private _restaurants$ = new BehaviorSubject<Restaurant[]>([] as any);
    private _pos$ = new BehaviorSubject<PointOfSale>({} as any);
    private _deliveryServices$ = new BehaviorSubject<DeliveryService[]>([] as any);
    private _printers$ = new BehaviorSubject<Printer[]>([] as any);

    get restaurants$(): Observable<Restaurant[]> {
        return this._restaurants$.pipe(distinctUntilChanged());
    }

    get restaurants(): Restaurant[] {
        return this._restaurants$.value;
    }

    get pos$(): Observable<PointOfSale> {
        return this._pos$.pipe(distinctUntilChanged());
    }

    get deliveryServices$(): Observable<DeliveryService[]> {
        return this._deliveryServices$.pipe(distinctUntilChanged());
    }

    get printers$(): Observable<Printer[]> {
        return this._printers$.pipe(distinctUntilChanged());
    }

    setRestaurants(restaurants: Restaurant[]) {
        this._restaurants$.next(restaurants);
    }

    setPos(pos: PointOfSale[]) {
        const pointOfSale = pos && pos[0]; // Get First object of POS List.
        this._pos$.next(pointOfSale);
    }

    setDeliveryServices(DeliveryServices: DeliveryService[]) {
        this._deliveryServices$.next(DeliveryServices);
    }

    setPrinters(printers: Printer[]) {
        this._printers$.next(printers);
    }

}