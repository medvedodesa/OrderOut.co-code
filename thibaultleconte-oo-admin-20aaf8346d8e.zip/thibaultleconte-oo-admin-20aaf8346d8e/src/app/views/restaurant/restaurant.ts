import { Account } from '../account/account';

export interface AccountRestaurant {
  account: Account;
  restaurant: Restaurant;
}

export interface Restaurant {
  id: number;
  name: string;
  account?: Account;
  accountId?: number;
  pointOfSaleId: number;
  printDoubleOrder: boolean;
  pointOfSaleIntegrationEnabled: boolean;
  preparation_time: number;
}

export interface RestaurantsList {
  more: boolean;
  previousCursor: string;
  nextCursor: string;
  data: Restaurant[];
}

export interface User {
  id: number;
  firstname: string;
  lastname: string;
  email: string;
  phone: string;
  receives_notification: boolean;
  role: string;
  api_created_at: string;
  isOwner?: boolean;
}