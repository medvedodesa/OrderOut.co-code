import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';

import { Account } from '../account';
import { AccountService } from "../account.service";
import { AccountDialogComponent } from "../account-dialog/account-dialog.component";

import { breadcrumb } from '../../common/breadcrumb/breadcrumb';
import { BreadcrumbService } from '../../common/breadcrumb/breadcrumb.service';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.scss']
})
export class AccountDetailsComponent implements OnInit {

  @Input() account: Account;

  public breadcrumbList: breadcrumb[] = [];

  constructor(
    public dialog: MatDialog,
    private accountService: AccountService,
    private breadcrumbService: BreadcrumbService
  ) { }

  ngOnInit() {
    this.initBreadcrumbList();
  }

  openEditAccountDialog() {
    const dialogRef = this.dialog.open(AccountDialogComponent, {
      width: "600px",
      data: {
        'title': 'Update Account',
        'name': this.account.name
      }
    });
    dialogRef.componentInstance.event.subscribe(result => {
      this.updateAccount(result.accountName);
    });
  }

  updateAccount(name: string) {
    this.account.name = name;
    this.initBreadcrumbList();
    this.accountService.updateAccount(this.account).subscribe();
  }

  initBreadcrumbList() {
    this.breadcrumbService.resetBreadcrumbList();
    this.breadcrumbList = this.breadcrumbService.getAccount(this.account);
  }

}
