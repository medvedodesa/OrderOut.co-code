import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Account } from './account';
import { AccountService } from './account.service';

@Injectable()
export class AccountResolve implements Resolve<Account> {

  constructor(private accountService: AccountService) {}

  resolve(route: ActivatedRouteSnapshot) {
    return this.accountService.getAccount(route.params.accountId);
  }
}