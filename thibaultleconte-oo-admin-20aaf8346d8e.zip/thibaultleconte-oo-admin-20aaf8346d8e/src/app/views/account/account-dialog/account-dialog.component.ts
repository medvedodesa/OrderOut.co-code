import { Component, EventEmitter, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-account-dialog',
  templateUrl: './account-dialog.component.html',
  styleUrls: ['./account-dialog.component.scss']
})
export class AccountDialogComponent {

  public accountFormGroup: FormGroup;
  public title: string = '';
  public accountName: string = '';
  public event: EventEmitter<any> = new EventEmitter();

  constructor(
    public dialogRef: MatDialogRef<AccountDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) { 
    this.accountName = data.name;
    this.title = data.title;
  }

  ngOnInit() {
    const nonWhitespaceRegExp: RegExp = new RegExp("\\S");
    this.accountFormGroup = new FormGroup({
      accountName: new FormControl(this.accountName, [Validators.required, Validators.pattern(nonWhitespaceRegExp)]),
    });
  }

  onSubmit(value): void {
    let name = value && value.accountName && value.accountName.trim();
    if(name && name.length > 0) {
      this.accountName = name;
      this.event.emit({"accountName": this.accountName});
      this.dialogRef.close();
    }
  }

}
