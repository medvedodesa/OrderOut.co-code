import { Injectable } from '@angular/core';

import { AccountRestaurant } from '../restaurant/restaurant';
const LOCAL_STORAGE_KEY_VISITED_ACCOUNT_LIST = 'visited_account_list';
const VISITED_ACCOUNT_LIST_LIMIT = 10;

@Injectable({
  providedIn: 'root'
})
export class VisitedAccountService {

  public accountList: AccountRestaurant[];

  constructor() { }

  addLSAccount(oAccountRestaurant) {
    if (oAccountRestaurant && oAccountRestaurant.account && oAccountRestaurant.restaurant) {
      this.accountList = this.getLSVisitedAccountList();
      this.accountList = this.accountList.filter(oAR => {
        return oAR.restaurant.id !== oAccountRestaurant.restaurant.id
      });
      this.accountList.splice(0, 0, oAccountRestaurant);
      this.accountList = this.accountList.slice(0, VISITED_ACCOUNT_LIST_LIMIT);
      localStorage.setItem(LOCAL_STORAGE_KEY_VISITED_ACCOUNT_LIST, JSON.stringify(this.accountList));
    }
  }

  getLSVisitedAccountList() {
    this.accountList = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY_VISITED_ACCOUNT_LIST)) || [];
    return this.accountList;
  }
}
