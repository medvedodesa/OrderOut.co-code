import { Component, Input, OnDestroy, TemplateRef, ViewChild } from '@angular/core';
import { ISubscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';
import { MatDialog } from "@angular/material";

import { Account } from '../../account/account';
import { AccountService } from '../../account/account.service';
import { RestaurantHelper } from '../../restaurant/restaurant.helper';

import { ConfirmationDialogService } from '../../common/confirmation-dialog/confirmation-dialog.service';

@Component({
  selector: 'app-account-admin',
  templateUrl: './account-admin.component.html',
  styleUrls: ['./account-admin.component.scss']
})
export class AccountAdminComponent implements OnDestroy {

  private subscription: ISubscription;
  @Input() account: Account;

  @ViewChild('accountAlert') accountAlert: TemplateRef<any>;
  public dialogRef;
  public message;

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private accountService: AccountService,
    public restaurantHelper: RestaurantHelper,
    public cdService: ConfirmationDialogService,
  ) { }

  ngOnDestroy() {
    if (!this.subscription) { return; }
    this.subscription.unsubscribe();
  }

  deleteAccount() {
    const restaurants = this.restaurantHelper.restaurants;
    if (restaurants && restaurants.length) {
      const text = restaurants.length > 1 ? 'restaurants' : 'restaurant';
      this.message = 'Sorry, you cannot delete the account. You have ' + restaurants.length + ' ' + text + ' active.';
      this.dialogRef = this.dialog.open(this.accountAlert, {
        width: "600px"
      });
    } else {
      this.cdService.confirm({
        message: {
          name: this.account.name,
          type: 'account'
        }
      }).subscribe(result => {
        if (result) {
          this.subscription = this.accountService.deleteAccount(this.account.id).subscribe(() => {
            this.router.navigate(['accounts']);
          });
        }
      });
    }
  }

  close() {
    this.dialogRef.close();
  }

}
