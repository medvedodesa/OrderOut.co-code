import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { CurrentAccountService } from '../../../core/current-account.service';
import { Account } from '../account';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.scss']
})
export class AccountComponent implements OnInit {

  account: Account;

  constructor(
    private route: ActivatedRoute,
    private _caService: CurrentAccountService
    ) { }

  ngOnInit() {
    this.account = this.route.snapshot.data.account;
    this._caService.setCurrentAccount(this.account);
  }

}
