import { TestBed } from '@angular/core/testing';

import { VisitedAccountService } from './visited-account.service';

describe('VisitedAccountService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: VisitedAccountService = TestBed.get(VisitedAccountService);
    expect(service).toBeTruthy();
  });
});
