import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import * as _ from 'lodash';

import { environment } from '../../../environments/environment';
import { ApiService } from './../../core/api.service';
import { Account, AccountsList } from './account';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  private accountsUrl = environment.backend_url + 'account/list';
  private accountUrl = environment.backend_url + 'account';

  constructor(private api: ApiService) {}

  getAccounts(options): Observable<AccountsList> {
    options = _.pickBy(options);
    return this.api.get(this.accountsUrl, options);
  }

  getAccount(accountId: number): Observable<Account> {
    const url = `${this.accountUrl}/${accountId}`;
    return this.api.get(url);
  }

  addAccount(account: Account): Observable<Account> {
    const url = `${this.accountUrl}/`;
    return this.api.post(url, account);
  }

  updateAccount(account: Account): Observable<Account> {
    const url = `${this.accountUrl}/${account.id}`;
    const params = {
      name: account.name,
    };
    return this.api.put(url, params);
  }

  deleteAccount(accountId: number) {
    const url = `${this.accountUrl}/${accountId}`;
    return this.api.delete(url);
  }

}
