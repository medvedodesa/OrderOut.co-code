import { filters } from '../common/data-filter/data-filter';

export class Account {
  api_created_at: string;
  id: number;
  name: string;
  ownerId: number;
}

export class AccountsList {
  more = false;
  prev_cursor: string = null;
  next_cursor: string = null;
  data: Account[] = [];
  count: number;
  item_per_page: number;
  next: boolean;
  prev: boolean;
  page: number;
}

export interface AccountOptions extends filters {
  name: string;
}