import { Component, OnInit, ViewChild, ViewEncapsulation } from "@angular/core";
import { Router } from "@angular/router";
import { Subject, BehaviorSubject, Observable, of } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { MatDialog, MatTableDataSource, MatSort } from "@angular/material";
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { SelectionModel } from '@angular/cdk/collections';

import { Account, AccountOptions, AccountsList } from "../../account/account";
import { AccountService } from "../../account/account.service";
import { AccountDialogComponent } from "../../account/account-dialog/account-dialog.component";

import { DataFilterComponent } from '../../common/data-filter/data-filter.component';

const NAME_SEARCH_TEXT_LENGTH_MIN = 2;

@Component({
  selector: "app-account-list",
  templateUrl: "./account-list.component.html",
  styleUrls: ["./account-list.component.scss"],
  providers: [ DataFilterComponent ],
  encapsulation: ViewEncapsulation.None
})
export class AccountListComponent implements OnInit {

  public filterFormGroup: FormGroup;
  columnsToDisplay = ["name", "api_created_at"];
  accounts: Account[];
  dataSource: MatTableDataSource<Account>;
  selection: SelectionModel<Account> = new SelectionModel<Account>(false, []);
  public accountsList: AccountsList;
  public noRecord: boolean;
  
  // MatPaginator length
  public length: number;

  @ViewChild('paginationConfig') paginationConfig;
  @ViewChild(MatSort) sort: MatSort;

  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();

  public accountOptions: AccountOptions;

  public editEnable: boolean = false;
  public searchAccountName;
  public minAccountNameLen: number = NAME_SEARCH_TEXT_LENGTH_MIN;

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private accountService: AccountService,
    private dataFilter: DataFilterComponent
  ) { }

  ngOnInit() {

    // Set MatPaginator length
    this.length = this.dataFilter.paginationLength;

    // Set Order options
    this.accountOptions = Object.assign({},{
      'name': ''
    }, this.dataFilter.options);
    
    // Filter FormGroup
    const nonWhitespaceRegExp: RegExp = new RegExp("\\S");
    this.filterFormGroup = new FormGroup({
      accountName: new FormControl(this.searchAccountName, [Validators.pattern(nonWhitespaceRegExp)]),
    });

    this.getAccounts();
  }

  onPaginationChange(data){
    if (this.accountOptions.item_per_page === data.pageSize) {
      this.accountOptions.page = data.pageIndex + 1;
    } else {
      this.paginationConfig.paginator.firstPage();
      this.accountOptions.page = 0;
      this.accountOptions.item_per_page = data.pageSize;
    }
    this.refetchAccounts(data);
  }

  getAccounts() {
    this.loadingSubject.next(true);
    this.accountService
      .getAccounts(this.accountOptions)
      .pipe(
        finalize(() => {
          this.loadingSubject.next(false);
        })
      )
      .subscribe(accountsList => {
        this.accountsList = accountsList as AccountsList;
        this.length = this.accountsList.count;

        this.accounts = this.accountsList.data;
        this.noRecord = this.accounts.length === 0 ? true : false;
        this.accountOptions.page = this.accountsList.page;
        this.accountOptions.item_per_page = this.accountsList.item_per_page;
        
        this.dataSource = new MatTableDataSource(this.accounts);
        this.dataSource.sort = this.sort;
      });
  }

  refetchAccounts(data) {
    this.dataFilter.updateCursors(this.accountOptions, this.accountsList, data);
    this.getAccounts();
  }

  openCreateAccountDialog() {
    const dialogRef = this.dialog.open(AccountDialogComponent, {
      width: "600px",
      data: {
        'title': 'Add Account'
      }
    });
    dialogRef.componentInstance.event.subscribe(result => {
      this.createAccount(result.accountName);
    });
  }

  createAccount(name: string) {
    const newAccount: Account = { name } as Account;
    this.accountService.addAccount(newAccount).subscribe(account => {
      this.router.navigate(["account", account.id]);
    });
  }

  rowSelected(account: Account) {
    this.router.navigate(["account", account.id]);
  }

  openEditAccountDialog(event, account: Account) {
    event.stopPropagation();
    const dialogRef = this.dialog.open(AccountDialogComponent, {
      width: "600px",
      data: {
        'title': 'Update Account',
        'name': account.name
      }
    });
    dialogRef.componentInstance.event.subscribe(result => {
      this.updateAccount(result.accountName, account);
    });
  }

  updateAccount(name: string, account: Account) {
    account.name = name;
    this.accountService.updateAccount(account).subscribe();
  }

  ApplyFilter($event) {
    let value = $event.target.value && $event.target.value.trim();
    if((this.searchAccountName && value === '') || (value && value.length > NAME_SEARCH_TEXT_LENGTH_MIN && this.searchAccountName !== value)) {
      this.paginationConfig.paginator.pageIndex = 0;
      this.accountOptions.name = value;
      this.getAccounts();
    }
    this.searchAccountName = value;
  }

  refreshAccounts() {
    this.searchAccountName = '';
    this.accountOptions.name = '';
    this.filterFormGroup.reset();

    this.accountOptions.page = 1;
    this.accountOptions.item_per_page = 25;
    this.paginationConfig.paginator.pageIndex = 0;
    
    this.getAccounts();
  }
}
