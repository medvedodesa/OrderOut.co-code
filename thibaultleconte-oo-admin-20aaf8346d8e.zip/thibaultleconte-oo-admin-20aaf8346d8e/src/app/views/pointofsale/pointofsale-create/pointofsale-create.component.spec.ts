import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PointofsaleCreateComponent } from './pointofsale-create.component';

describe('PointofsaleCreateComponent', () => {
  let component: PointofsaleCreateComponent;
  let fixture: ComponentFixture<PointofsaleCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PointofsaleCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PointofsaleCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
