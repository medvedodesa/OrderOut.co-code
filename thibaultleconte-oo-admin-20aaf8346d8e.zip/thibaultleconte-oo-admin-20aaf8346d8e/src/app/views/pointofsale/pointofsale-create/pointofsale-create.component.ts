import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Account } from '../../account/account';
import { AccountRestaurant, Restaurant } from '../../restaurant/restaurant';

import { PosConnectDgService } from '../pos-connect-dg/pos-connect-dg.service';

import { const_pos } from '../pointofsale';


@Component({
  selector: 'app-pointofsale-create',
  templateUrl: './pointofsale-create.component.html',
  styleUrls: ['./pointofsale-create.component.scss']
})
export class PointofsaleCreateComponent implements OnInit {

  public accountRestaurant: AccountRestaurant;
  public account: Account;
  public restaurant: Restaurant;

  public const_pos = const_pos;

  constructor(
    private route: ActivatedRoute,
    private PosConnectDgService: PosConnectDgService
  ) { }

  ngOnInit() {
    this.accountRestaurant = this.route.snapshot.data.accountRestaurant;
    this.account = this.accountRestaurant.account;
    this.restaurant = this.accountRestaurant.restaurant;
  }

  connectToSquare() {
    alert('Coming Soon');
  }

  connectToPOS(type: string) {
    this.PosConnectDgService.connectToPOS(type, this.restaurant);
  }

}
