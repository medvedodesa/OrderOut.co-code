import { Component, OnDestroy, Input } from '@angular/core';
import { PointOfSale } from '../pointofsale';
import { Router } from '@angular/router';
import { PointofsaleService } from '../pointofsale.service';
import { Restaurant } from '../../restaurant/restaurant';
import { ISubscription } from 'rxjs/Subscription';
import { ConfirmationDialogService } from '../../common/confirmation-dialog/confirmation-dialog.service';

@Component({
  selector: 'app-pointofsale-admin',
  templateUrl: './pointofsale-admin.component.html',
  styleUrls: ['./pointofsale-admin.component.scss']
})
export class PointofsaleAdminComponent implements OnDestroy {

  @Input() restaurant: Restaurant;
  @Input() pointofsale: PointOfSale;

  private subscription: ISubscription;

  constructor(
    private router: Router,
    private pointofsaleService: PointofsaleService,
    public cdService: ConfirmationDialogService,
  ) { }

  ngOnDestroy() {
    if (!this.subscription) { return; }
    this.subscription.unsubscribe();
  }

  deletePointofsale() {

    this.cdService.confirm({
      message: {
        name: this.pointofsale.type,
        type: 'Point Of Sale'
      }
    }).subscribe(result => {
      if (result) {
        this.subscription = this.pointofsaleService.disconnect(this.pointofsale.id).subscribe(() => {
          this.router.navigate(['restaurant', this.restaurant.id]);
        });
      }
    });

  }

}
