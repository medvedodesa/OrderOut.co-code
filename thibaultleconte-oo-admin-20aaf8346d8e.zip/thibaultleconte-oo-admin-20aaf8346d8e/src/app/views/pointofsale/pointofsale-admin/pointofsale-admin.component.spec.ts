import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PointofsaleAdminComponent } from './pointofsale-admin.component';

describe('PointofsaleAdminComponent', () => {
  let component: PointofsaleAdminComponent;
  let fixture: ComponentFixture<PointofsaleAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PointofsaleAdminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PointofsaleAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
