import { Component, OnInit, Input, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';

import { Account } from '../../account/account';
import { Restaurant } from '../../restaurant/restaurant';
import { PointOfSale, const_pos } from '../pointofsale';
import { breadcrumb } from '../../common/breadcrumb/breadcrumb';

import { PointofsaleService } from '../pointofsale.service';
import { BreadcrumbService } from '../../common/breadcrumb/breadcrumb.service';
import { LoaderService } from '../../../service/loader.service';
import { posHelper } from '../pointofsale.helper';
import { MessageDgService } from '../../common/message-dg/message-dg.service';
import { MessageService } from '../../../service/messages/message.service';

import { CloverLinkingDialogComponent } from '../clover/clover-linking-dialog/clover-linking-dialog.component';

@Component({
  selector: 'app-pointofsale-details',
  templateUrl: './pointofsale-details.component.html',
  styleUrls: ['./pointofsale-details.component.scss']
})
export class PointofsaleDetailsComponent extends posHelper implements OnInit {

  @Input() account: Account;
  @Input() restaurant: Restaurant;
  @Input() pointofsale?: PointOfSale;

  public breadcrumbList: breadcrumb[] = [];
  public isCloverPOS = false;
  public loading = false;
  public enableCSU: string; // Clover Support User

  constructor(
    @Inject(PointofsaleService) posService: PointofsaleService,
    @Inject(MessageDgService) msgDgService: MessageDgService,
    private router: Router,
    public dialog: MatDialog,
    private loaderService: LoaderService,
    protected pointofsaleService: PointofsaleService,
    private breadcrumbService: BreadcrumbService,
    private messageService: MessageService
  ) {
    super(posService, msgDgService);
  }

  ngOnInit() {
    this.breadcrumbService.resetBreadcrumbList();
    this.breadcrumbList = this.breadcrumbService.getPointOfSale(
      this.account,
      this.restaurant,
      this.pointofsale
    );
    this.isCloverPOS = this.pointofsale && this.pointofsale.type.toLowerCase() === const_pos.CLOVER.toLowerCase();
    if (this.isCloverPOS) {
      super.testConnection(this.pointofsale.id);
    }
    this.enableCSU = this.pointofsale && this.pointofsale.support_employee_id ? 'enable' : 'disable';
  }

  updateCloverLead() {
    const dialogRef = this.dialog.open(CloverLinkingDialogComponent, {
      width: '600px',
      data: {
        title: 'Update Clover Lead',
        btnText: 'Update'
      }
    });
    dialogRef.componentInstance.event.subscribe((cloverLeadResult) => {
      this.loaderService.show();
      const cloverLeadId = cloverLeadResult.cloverLeadId;
      this.pointofsaleService.updateCloverLead(this.pointofsale.id, cloverLeadId).subscribe((pointofsale) => {
        this.loaderService.hide();
        this.router.navigate(['restaurant', this.restaurant.id, 'pos', pointofsale.id]);
      });
    });
  }

  testConnection() {
    if (this.isCloverPOS) {
      super.testConnection(this.pointofsale.id);
    }
  }

  updateCSUser(value) {
    this.loaderService.show();
    this.pointofsaleService.updateCSUser(this.pointofsale.id, value === 'enable').subscribe((res) => {
      this.loaderService.hide();
      if (res && res.success === true) {
        this.messageService.openSnackBar("Clover Support Access has been " + value + "d!");
      } else {
        this.messageService.showError("Clover Support Access has not been " + value + "d.");
      }
    });
  }

}
