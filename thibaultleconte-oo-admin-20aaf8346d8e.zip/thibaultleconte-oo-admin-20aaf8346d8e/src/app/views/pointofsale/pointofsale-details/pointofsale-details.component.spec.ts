import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PointofsaleDetailsComponent } from './pointofsale-details.component';

describe('PointofsaleDetailsComponent', () => {
  let component: PointofsaleDetailsComponent;
  let fixture: ComponentFixture<PointofsaleDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PointofsaleDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PointofsaleDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
