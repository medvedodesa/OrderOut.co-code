import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { PointOfSale } from './pointofsale';
import { PointofsaleService } from './pointofsale.service';

@Injectable()
export class PointOfSaleResolve implements Resolve<PointOfSale> {

  constructor(private pointofsaleService: PointofsaleService) {}

  resolve(route: ActivatedRouteSnapshot) {
    return this.pointofsaleService.getPointOfSale(route.params.pointofsaleId);
  }
}