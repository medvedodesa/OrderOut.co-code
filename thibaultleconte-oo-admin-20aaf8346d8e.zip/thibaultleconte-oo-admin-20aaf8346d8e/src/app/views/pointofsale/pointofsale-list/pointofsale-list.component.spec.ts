import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PointofsaleListComponent } from './pointofsale-list.component';

describe('PointofsaleListComponent', () => {
  let component: PointofsaleListComponent;
  let fixture: ComponentFixture<PointofsaleListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PointofsaleListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PointofsaleListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
