import { Component, OnInit, Input, Output, EventEmitter, Inject } from '@angular/core';
import { Restaurant } from '../../restaurant/restaurant';
import { PointOfSale, const_pos } from '../pointofsale';
import { PointofsaleService } from '../pointofsale.service';
import { Router } from '@angular/router';
import { RestaurantHelper } from '../../restaurant/restaurant.helper';
import { posHelper } from '../pointofsale.helper';
import { MessageDgService } from '../../common/message-dg/message-dg.service';


@Component({
  selector: 'app-pointofsale-list',
  templateUrl: './pointofsale-list.component.html',
  styleUrls: ['./pointofsale-list.component.scss']
})
export class PointofsaleListComponent extends posHelper implements OnInit {

  @Input() restaurant: Restaurant;

  @Output() emitCloverLead = new EventEmitter<any>();

  columnsToDisplay = ['type', 'items', 'modifiers', 'elements', 'api_created_at', 'connectivity'];

  pointOfSales: PointOfSale[];
  public isCloverPOS = false;

  constructor(
    @Inject(PointofsaleService) posService: PointofsaleService,
    @Inject(MessageDgService) msgDgService: MessageDgService,
    private router: Router,
    private pointofsaleService: PointofsaleService,
    public restaurantHelper: RestaurantHelper
  ) {
    super(posService, msgDgService);
  }

  ngOnInit() {
    this.getPointOfSales();
  }

  private getPointOfSales() {
    this.pointofsaleService.getPointOfSales(this.restaurant.id).subscribe(pointOfSales => {
      this.pointOfSales = pointOfSales;
      this.restaurantHelper.setPos(this.pointOfSales);
      if (this.pointOfSales && this.pointOfSales.length > 0) {
        this.isCloverPOS = this.pointOfSales[0].type.toLowerCase() === const_pos.CLOVER.toLowerCase();
        if (this.isCloverPOS) {
          super.testConnection(this.pointOfSales[0].id);
        }
        if (this.pointOfSales[0] && this.pointOfSales[0].service_merchant_id && this.pointOfSales[0].service_employee_id) {
          this.pointofsaleService.getCloverLeadByMarchant(this.pointOfSales[0].service_merchant_id, this.pointOfSales[0].service_employee_id).subscribe(cloverLead => {
            if (cloverLead) {
              this.emitCloverLead.emit(cloverLead);
            }
          });
        }
      }
    });
  }

  addPointOfSale() {
    this.router.navigate(['restaurant', this.restaurant.id, 'pos']);
  }

  rowSelected(pointofsale: PointOfSale) {
    this.router.navigate(['restaurant', this.restaurant.id, 'pos', pointofsale.id]);
  }

}
