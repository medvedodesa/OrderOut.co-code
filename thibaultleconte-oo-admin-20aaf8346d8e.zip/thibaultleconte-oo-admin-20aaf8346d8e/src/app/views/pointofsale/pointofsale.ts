import { MenuSync } from '../menu/menuSync';


export interface PointOfSale {
  id: number;
  type: string;
  service_merchant_id: string;
  service_employee_id: string;
  support_employee_id?: string;
  menuSync: MenuSync;
  settings: POSSettings;
  api_created_at: Date;
}

export interface POSSettings {
  send_taxes: boolean;
  send_tips: boolean;
  send_fees: boolean;
  send_items_as_revenue: boolean;
}

export interface selectedDS {
  id: number;
  name: string;
  selected?: boolean;
}

export interface cloverLead {
  id: number,
  account_name: string,
  client_id: string,
  merchant_id: string,
  employee_id: string,
  owner_name: string,
  owner_email: string,
  street_address_1: string,
  street_address_2: string,
  street_address_3: string,
  city: string,
  state: string,
  country: string,
  phone_number: string,
  delivery_services: selectedDS[],
  is_new: boolean,
  api_created_at: string,
  zipcode: string
}

export interface cloverLeadList {
  data: cloverLead[];
  count: number;
  item_per_page: number;
  next: boolean;
  prev: boolean;
  page: number;
}

export const const_pos = {
  CLOVER: 'Clover',
  NEWTEK: 'NewTek',
  TABIT: 'Tabit'
}