import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { environment } from '../../../environments/environment';
import { ApiService } from './../../core/api.service';
import { PointOfSale, cloverLeadList, cloverLead } from '../pointofsale/pointofsale';
import { Restaurant } from '../restaurant/restaurant';

import { const_pos } from './pointofsale';


@Injectable({
  providedIn: 'root'
})
export class PointofsaleService {

  restaurantUrl = environment.backend_url + 'restaurant';
  pointOfSaleUrl = environment.backend_url + 'pos';
  pointOfSaleCloverUrl = environment.backend_url + 'pointofsale/clover';

  constructor(private api: ApiService) { }

  getPointOfSales(restaurantId: number): Observable<[PointOfSale]> {
    const url = `${this.restaurantUrl}/${restaurantId}/pos`;
    return this.api.get(url);
  }

  getPointOfSale(pointofsaleId: number): Observable<PointOfSale> {
    const url = `${this.pointOfSaleUrl}/${pointofsaleId}`;
    return this.api.get(url);
  }

  processCloverCallback(cloverMerchantId: string,
    cloverEmployeeId: string,
    cloverClientId: string,
    cloverCode: string) {
    const url = `${this.pointOfSaleUrl}/clover/callback`;
    const params = {
      merchant_id: cloverMerchantId,
      employee_id: cloverEmployeeId,
      client_id: cloverClientId,
      code: cloverCode
    };
    return this.api.post(url, params);
  }

  getCloverLead(cloverLeadId: number): Observable<cloverLead> {
    const url = `${this.pointOfSaleUrl}/lead/clover/${cloverLeadId}`;
    return this.api.get(url);
  }

  getCloverLeadByMarchant(marchantId: string, employeeId: string): Observable<cloverLead> {
    const url = `${this.pointOfSaleUrl}/lead/clover/mid/${marchantId}/eid/${employeeId}`;
    return this.api.get(url);
  }

  saveCloverLead(cloverLeadId: number, params: {}) {
    const url = `${this.pointOfSaleUrl}/clover/lead/${cloverLeadId}`;
    return this.api.post(url, params);
  }

  updateCloverLead(pointOfSaleId: number, cloverLeadId: number) {
    const url = `${this.pointOfSaleUrl}/${pointOfSaleId}/clover/lead/${cloverLeadId}/update`;
    return this.api.put(url);
  }

  getCloverLeads(params): Observable<cloverLeadList> {
    const url = `${this.pointOfSaleUrl}/lead/clover/`;
    return this.api.get(url, params);
  }

  getCloverStats(): Observable<any> {
    const url = `${environment.backend_url}monitoring/clover/lead/stats`;
    return this.api.get(url);
  }

  connectToPOS(type: string, posId: number, restaurant: Restaurant): Observable<PointOfSale> {
    let params = {} as any;
    let url;

    params.account_id = restaurant.accountId;
    params.restaurant_id = restaurant.id;

    switch (type) {
      case const_pos.CLOVER:
        params.clover_lead_id = posId;
        url = `${this.pointOfSaleUrl}/clover/link`;
        break;
      case const_pos.NEWTEK:
        params.newtek_store_uuid = posId;
        url = `${this.pointOfSaleUrl}/newtek/connect`;
        break;
      case const_pos.TABIT:
        params.tabit_store_uuid = posId;
        url = `${this.pointOfSaleUrl}/tabit/connect`;
        break;
    }
    return this.api.post(url, params);
  }

  linkRestaurantToCloverLead(accountId: number,
    restaurantId: number,
    cloverLeadId: string): Observable<PointOfSale> {
    const url = `${this.pointOfSaleUrl}/clover/link`;
    const params = {
      account_id: accountId,
      restaurant_id: restaurantId,
      clover_lead_id: cloverLeadId
    };
    return this.api.post(url, params);
  }

  fetchMenu(pointOfSaleId: number) {
    const url = `${this.pointOfSaleUrl}/${pointOfSaleId}/menu/fetch`;
    return this.api.get(url);
  }

  disconnect(pointOfSaleId: number) {
    const url = `${this.pointOfSaleUrl}/${pointOfSaleId}/disconnect`;
    return this.api.delete(url);
  }

  testConnection(pointOfSaleId: number) {
    const url = `${this.pointOfSaleUrl}/${pointOfSaleId}/test/connection`;
    return this.api.get(url);
  }

  updateCSUser(pointOfSaleId: number, enable: boolean) {
    const url = `${this.pointOfSaleUrl}/${pointOfSaleId}/clover/employee`;
    return enable ? this.api.post(url, {}) : this.api.delete(url);
  }

  updatePosConfig(pointofsaleId: number, config: any) {
    const params = {
      "send_taxes": config.send_taxes,
      "send_tips": config.send_tips,
      "send_fees": config.send_fees,
      "send_items_as_revenue": config.send_items_as_revenue,
    }
    const url = `${this.pointOfSaleUrl}/${pointofsaleId}/update_settings`;
    return this.api.post(url, params);
  }

}
