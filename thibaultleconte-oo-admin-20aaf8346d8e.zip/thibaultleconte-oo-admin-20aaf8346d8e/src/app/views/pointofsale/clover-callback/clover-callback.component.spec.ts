import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CloverCallbackComponent } from './clover-callback.component';

describe('CloverCallbackComponent', () => {
  let component: CloverCallbackComponent;
  let fixture: ComponentFixture<CloverCallbackComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CloverCallbackComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CloverCallbackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
