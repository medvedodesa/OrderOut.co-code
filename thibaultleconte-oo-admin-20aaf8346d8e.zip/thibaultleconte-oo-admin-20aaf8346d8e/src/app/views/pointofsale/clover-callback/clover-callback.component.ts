import { Component, OnInit, ElementRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { AbstractControl, FormBuilder, FormGroup, Validators, FormControl, FormArray } from '@angular/forms';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';

import { PointofsaleService } from '../pointofsale.service';

@Component({
  selector: 'app-clover-callback',
  templateUrl: './clover-callback.component.html',
  providers: [
    PointofsaleService,
    {
      provide: STEPPER_GLOBAL_OPTIONS, useValue: { showError: true }
    }
  ],
  styleUrls: ['./clover-callback.component.scss']
})
export class CloverCallbackComponent implements OnInit {

  userInfo: any;
  csFormGroup: FormGroup;

  showSpinner: boolean = true;
  showError: boolean = false;
  isLeadCreated: boolean = false;

  // Delivery selection input value
  public ds_val: boolean = false;

  /** Returns a FormArray with the name 'formArray'. */
  get formArray(): AbstractControl | null { return this.csFormGroup.get('formArray'); }

  constructor(
    private _elementRef : ElementRef,
    private router: Router,
    private route: ActivatedRoute,
    private pointOfSaleService: PointofsaleService,
    private fb: FormBuilder,
  ) { }

  ngOnInit() {

    const cloverAuthCallbackMerchantId = this.route.snapshot.queryParamMap.get('merchant_id');
    const cloverAuthCallbackEmployeeId = this.route.snapshot.queryParamMap.get('employee_id');
    const cloverAuthCallbackClientId = this.route.snapshot.queryParamMap.get('client_id');
    const cloverAuthCallbackCode = this.route.snapshot.queryParamMap.get('code');

    this.pointOfSaleService.processCloverCallback(
      cloverAuthCallbackMerchantId,
      cloverAuthCallbackEmployeeId,
      cloverAuthCallbackClientId,
      cloverAuthCallbackCode
    ).subscribe((result) => {
      this.showSpinner = false;
      if (result.is_new) {
        this.userInfo = result;
        this.createForm();
      } else {
        this.isLeadCreated = true;
      }

    });
  }

  createForm() {

    let zipcode = new FormControl(this.userInfo.zipcode, {
      validators: Validators.compose([
        Validators.required,
        Validators.pattern(/^\d{5}(?:[-\s]\d{4})?|[A-Z]\d[A-Z]\d[A-Z]\d$/ig)
      ])
    });

    let owner_email = new FormControl(this.userInfo.owner_email, {
      validators: Validators.compose([
        Validators.required,
        Validators.email
      ])
    });

    let phone_number = new FormControl(this.userInfo.phone_number, {
      validators: Validators.compose([
        Validators.required,
        Validators.pattern(/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im)
      ])
    });

    // To initialize FormGroup  
    this.csFormGroup = this.fb.group({
      formArray: this.fb.array([
        this.fb.group({
          'account_name': [this.userInfo.account_name, Validators.required],
        }),
        this.fb.group({
          'street_address_1': [this.userInfo.street_address_1, Validators.required],
          'street_address_2': [this.userInfo.street_address_2],
          'street_address_3': [this.userInfo.street_address_3],
          'city': [this.userInfo.city, Validators.required],
          'state': [this.userInfo.state, Validators.required],
          'zipcode': zipcode,
        }),
        this.fb.group({
          'owner_email': owner_email,
          'phone_number': phone_number,
        }),
        this.fb.group({
          'ds_validate': [false, Validators.requiredTrue],
        }),
      ])
    });

  }

  hasError(controlName: string, scopeFormArray: FormArray, errorName: string) {
    return scopeFormArray.controls[controlName].hasError(errorName);
  }

  onSubmit(value) {
    this.showSpinner = true;
    value = value.formArray;
    let updateValue = Object.assign({},value[0],value[1],value[2]);
    Object.assign(this.userInfo, updateValue);
    this.pointOfSaleService.saveCloverLead(this.userInfo.id, this.userInfo).subscribe((result) => {
      this.showSpinner = false;
      this.isLeadCreated = true;
    });
  }

  updateServices(id) {
    this.userInfo.delivery_services.forEach(service => {
      if (service.id === id) {
        service.selected = !service.selected;
      }
    });

    let dsValidate = this._elementRef.nativeElement.querySelector('#ds_validate');
    let selectedServices = this.getSelectedServices();
    if (selectedServices.length !== 0) {
      this.showError = false;
      if (dsValidate.checked === false) {
        dsValidate.click();
      }
    } else {
      this.showError = true;
      if (dsValidate.checked === true) {
        dsValidate.click();
      }
    }
  }

  getSelectedServices() {
    return this.userInfo.delivery_services.filter(function (service) {
      return service.selected === true;
    });
  }

}
