import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PointofsaleSettingsComponent } from './pointofsale-settings.component';

describe('PointofsaleSettingsComponent', () => {
  let component: PointofsaleSettingsComponent;
  let fixture: ComponentFixture<PointofsaleSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PointofsaleSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PointofsaleSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
