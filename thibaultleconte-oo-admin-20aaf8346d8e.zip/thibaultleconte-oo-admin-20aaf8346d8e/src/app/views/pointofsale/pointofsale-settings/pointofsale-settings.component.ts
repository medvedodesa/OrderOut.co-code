import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

import { PointOfSale } from '../pointofsale';

import { PointofsaleService } from '../pointofsale.service';
import { LoaderService } from '../../../service/loader.service';

@Component({
  selector: 'app-pointofsale-settings',
  templateUrl: './pointofsale-settings.component.html',
  styleUrls: ['./pointofsale-settings.component.scss']
})
export class PointofsaleSettingsComponent implements OnInit {

  @Input() pointofsale: PointOfSale;
  public config: FormGroup;
  constructor(
    private posService: PointofsaleService,
    private loaderService: LoaderService,
    public fb: FormBuilder
  ) { }

  ngOnInit() {
    if (this.pointofsale && !this.pointofsale.settings) {
      this.pointofsale.settings = {
        send_taxes: false,
        send_tips: false,
        send_fees: false,
        send_items_as_revenue: true
      }
    }
    this.buildForm();
  }

  buildForm() {
    this.config = this.fb.group({
      send_taxes: this.pointofsale.settings.send_taxes,
      send_tips: this.pointofsale.settings.send_tips,
      send_fees: this.pointofsale.settings.send_fees,
      send_items_as_revenue: this.pointofsale.settings.send_items_as_revenue
    });

    this.config.valueChanges.subscribe((value) => {
      this.setPosConfig();
    });
  }

  private setPosConfig() {
    this.loaderService.show();
    this.posService.updatePosConfig(this.pointofsale.id, this.config.value).subscribe(settings => {
      this.pointofsale.settings = settings;
      console.log(settings);
    }).add(() => {
      this.loaderService.hide();
    });
  }

}
