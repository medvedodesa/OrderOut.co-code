import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, forkJoin, BehaviorSubject } from 'rxjs';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { PointofsaleService } from '../../pointofsale.service';
import { cloverLead } from '../../pointofsale';

@Component({
  selector: 'app-leads',
  templateUrl: './leads.component.html',
  styleUrls: ['./leads.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LeadsComponent implements OnInit {

  public filterFormGroup: FormGroup;

  public cloverStatsColumns = ['columnText', 'total'];
  public cloverLeadsColumns = ['clientId','merchantId','name','address','api_created_at']
  public cloverLeadList;
  public cloverStats;
  public aCloverStats = [];
  public searchMerchantId;

  public noRecord: boolean;
  public length: number = 100;
  public leadsOptions = {
    merchant_uuid: '', // QAJFKP61BM71W
    item_per_page: 25,
    page: 1
  }
  @ViewChild('paginationConfig') paginationConfig;

  public showLoader: boolean = false;
  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();

  constructor(
    private router: Router,
    private posService: PointofsaleService
  ) { }

  ngOnInit() {

    this.loadingSubject.next(true);
    this.getData()
      .subscribe(res => {

        this.cloverStats = res[0];

        // Add Column Label
        this.cloverStats._1h.columnText = '1 Hour';
        this.cloverStats._6h.columnText = '6 Hours';
        this.cloverStats._12h.columnText = '12 Hours';
        this.cloverStats._1d.columnText = '1 Day';
        this.cloverStats._2d.columnText = '2 Days';
        this.cloverStats._7d.columnText = '7 Days';
        this.cloverStats._14d.columnText = '14 Days';
        this.cloverStats._30d.columnText = '30 Days';

        this.aCloverStats.push(this.cloverStats._1h);
        this.aCloverStats.push(this.cloverStats._6h);
        this.aCloverStats.push(this.cloverStats._12h);
        this.aCloverStats.push(this.cloverStats._1d);
        this.aCloverStats.push(this.cloverStats._2d);
        this.aCloverStats.push(this.cloverStats._7d);
        this.aCloverStats.push(this.cloverStats._14d);
        this.aCloverStats.push(this.cloverStats._30d);
        
        this.getCloverLeadsInitCallback(res[1]);

      }, err => {
        console.log(err);
      }, () => {
        this.loadingSubject.next(false);
      });

    const nonWhitespaceRegExp: RegExp = new RegExp("\\S");
    this.filterFormGroup = new FormGroup({
      merchantId: new FormControl(this.searchMerchantId, [Validators.pattern(nonWhitespaceRegExp),Validators.minLength(13),Validators.maxLength(13)]),
    });
  }

  getCloverStats(): Observable<any> {
    return this.posService.getCloverStats();
  }

  getCloverLeadsInit(): Observable<any> {
    return this.posService.getCloverLeads(this.leadsOptions);
  }

  getData(): Observable<any> {
    return forkJoin([this.getCloverStats(), this.getCloverLeadsInit()]);
  }

  getCloverLeadsInitCallback(cloverLeadList) {
    this.cloverLeadList = cloverLeadList.data;
    this.noRecord = this.cloverLeadList.length === 0 ? true : false;
    this.length = cloverLeadList.count;
    this.leadsOptions.page = cloverLeadList.page;
    this.leadsOptions.item_per_page = cloverLeadList.item_per_page;
  }

  getCloverLeads() {
    this.showLoader = true;
    this.posService.getCloverLeads(this.leadsOptions).subscribe(this.getCloverLeadsInitCallback.bind(this)).add(() => {
      this.showLoader = false;
      this.loadingSubject.next(false);
    });
  }

  rowSelected(cloverLead: cloverLead) {
    this.router.navigate(['lead', cloverLead.id], { state: {cloverlead : cloverLead } });
  }

  onPaginationChange(data){
    if (this.leadsOptions.item_per_page === data.pageSize) {
      this.leadsOptions.page = data.pageIndex + 1;
    } else {
      this.paginationConfig.paginator.firstPage();
      this.leadsOptions.page = 1;
      this.leadsOptions.item_per_page = data.pageSize;
    }
    this.getCloverLeads();
  }

  ApplyFilter($event) {
    let value = $event.target.value && $event.target.value.trim();
    if(value && value.length === 13 && this.searchMerchantId !== value) {
      this.searchMerchantId = value;
      this.paginationConfig.paginator.pageIndex = 0;
      this.leadsOptions.merchant_uuid = value;
      this.getCloverLeads();
    }
  }

  refreshLeads() {
    this.searchMerchantId = '';
    this.filterFormGroup.reset();

    this.leadsOptions.merchant_uuid = '';
    this.leadsOptions.page = 1;
    this.leadsOptions.item_per_page = 25;
    
    this.getCloverLeads();
  }

}
