import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { cloverLead } from '../../../pointofsale';
import { PointofsaleService } from '../../../pointofsale.service';
import { LoaderService } from '../../../../../service/loader.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent implements OnInit {

  public cloverLead: cloverLead;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private loaderService: LoaderService,
    private posService: PointofsaleService
  ) {
    const state = this.router.getCurrentNavigation().extras.state
    state && state.cloverlead ? this.cloverLead = state.cloverlead : '';
  }

  ngOnInit() {
    if (!this.cloverLead) {
      this.getCloverLead(+this.activatedRoute.snapshot.paramMap.get('leadId'));
    }
  }

  getCloverLead(cloverLeadId: number) {
    this.loaderService.show();
    this.posService.getCloverLead(cloverLeadId).subscribe(cloverlead => {
      this.cloverLead = cloverlead;
    }).add(() => {
      this.loaderService.hide();
    });
  }

}
