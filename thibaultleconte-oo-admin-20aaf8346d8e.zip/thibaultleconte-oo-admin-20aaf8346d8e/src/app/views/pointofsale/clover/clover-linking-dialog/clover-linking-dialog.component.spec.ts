import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CloverLinkingDialogComponent } from './clover-linking-dialog.component';

describe('CloverLinkingDialogComponent', () => {
  let component: CloverLinkingDialogComponent;
  let fixture: ComponentFixture<CloverLinkingDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CloverLinkingDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CloverLinkingDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
