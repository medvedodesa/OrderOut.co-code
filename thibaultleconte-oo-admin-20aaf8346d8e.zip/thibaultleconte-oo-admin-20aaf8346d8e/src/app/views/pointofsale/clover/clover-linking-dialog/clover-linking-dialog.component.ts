import { Component, EventEmitter, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-clover-linking-dialog',
  templateUrl: './clover-linking-dialog.component.html',
  styleUrls: ['./clover-linking-dialog.component.scss']
})
export class CloverLinkingDialogComponent {

  public cloverLeadFormGroup: FormGroup;
  public cloverLeadId: string = '';
  public title: string = '';
  public btnText: string = '';
  public event: EventEmitter<any> = new EventEmitter();

  constructor(
    public dialogRef: MatDialogRef<CloverLinkingDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) { 
    this.title = data && data.title ? data.title : 'Link to Clover';
    this.btnText = data && data.btnText ? data.btnText: 'Save';
  }

  ngOnInit() {
    const nonWhitespaceRegExp: RegExp = new RegExp("\\S");
    this.cloverLeadFormGroup = new FormGroup({
      cloverLeadId: new FormControl(this.cloverLeadId, [Validators.required, Validators.pattern(nonWhitespaceRegExp)]),
    });
  }

  onSubmit(value): void {
    let cloverLeadId = value && value.cloverLeadId && value.cloverLeadId.trim();
    if(cloverLeadId && cloverLeadId.length > 0) {
      this.cloverLeadId = cloverLeadId;
      this.event.emit({"cloverLeadId": this.cloverLeadId});
      this.dialogRef.close();
    }
  }
}
