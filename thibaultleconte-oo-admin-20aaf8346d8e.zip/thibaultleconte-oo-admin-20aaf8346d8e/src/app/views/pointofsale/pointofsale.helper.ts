import { PointofsaleService } from './pointofsale.service';
import { MessageDgService } from '../common/message-dg/message-dg.service';

export abstract class posHelper {

    public isPOSAvailable;
    public loading = false;
    public msgTooltip = '';

    public constructor(
        private posService: PointofsaleService,
        private msgDgService: MessageDgService
    ) {}

    public testConnection(posId) {
        this.loading = true;
        this.posService.testConnection(posId).subscribe((res) => {
            let message = res.status || 'NO STATUS';
            this.msgTooltip = message;
            if (res && res.status && res.status.indexOf('SUCCESSFUL') === -1) {
                this.msgDgService.openMsgDialog(message, {negative: true});
                this.isPOSAvailable = false;
            } else {
                this.isPOSAvailable = true;
            }
        }).add(() => {
            this.loading = false;
        });
    }
 }