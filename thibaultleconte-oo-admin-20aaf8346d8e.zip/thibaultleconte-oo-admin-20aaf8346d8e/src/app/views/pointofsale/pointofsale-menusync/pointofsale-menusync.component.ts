import { Component, OnInit, Input } from '@angular/core';
import { Restaurant } from '../../restaurant/restaurant';
import { PointOfSale } from '../pointofsale';
import { PointofsaleService } from '../pointofsale.service';
import { MenusyncComponent } from '../../common/menusync/menusync.component';

@Component({
  selector: 'app-pointofsale-menusync',
  templateUrl: './pointofsale-menusync.component.html',
  styleUrls: ['./pointofsale-menusync.component.scss']
})
export class PointofsaleMenusyncComponent extends MenusyncComponent implements OnInit {

  @Input() restaurant: Restaurant;
  @Input() pointofsale: PointOfSale;

  public data: PointOfSale;
  public getMenuSync: string = 'getPointOfSale';
  public menusyncService: PointofsaleService;
  public menuSyncMapDisplayedColumns: string[] = ['items', 'modifiers', 'elements'];

  constructor(
    protected pointofsaleService: PointofsaleService
  ) {
    super();
    this.menusyncService = this.pointofsaleService;
  }

  ngOnInit() {
    this.data = this.pointofsale;
    super.ngOnInit();
  }

}
