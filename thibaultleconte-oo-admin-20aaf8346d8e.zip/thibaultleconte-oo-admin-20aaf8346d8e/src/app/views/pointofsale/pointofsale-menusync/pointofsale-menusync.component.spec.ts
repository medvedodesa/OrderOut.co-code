import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PointofsaleMenusyncComponent } from './pointofsale-menusync.component';

describe('PointofsaleMenusyncComponent', () => {
  let component: PointofsaleMenusyncComponent;
  let fixture: ComponentFixture<PointofsaleMenusyncComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PointofsaleMenusyncComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PointofsaleMenusyncComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
