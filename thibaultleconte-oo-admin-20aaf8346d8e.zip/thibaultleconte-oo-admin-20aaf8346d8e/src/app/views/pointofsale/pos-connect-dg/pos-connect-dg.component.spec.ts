import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PosConnectDgComponent } from './pos-connect-dg.component';

describe('PosConnectDgComponent', () => {
  let component: PosConnectDgComponent;
  let fixture: ComponentFixture<PosConnectDgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PosConnectDgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PosConnectDgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
