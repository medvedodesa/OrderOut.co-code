import { Component, OnInit, EventEmitter, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { const_pos } from '../pointofsale';

@Component({
  selector: 'app-pos-connect-dg',
  templateUrl: './pos-connect-dg.component.html',
  styleUrls: ['./pos-connect-dg.component.scss']
})
export class PosConnectDgComponent implements OnInit {

  public posConnectFormGroup: FormGroup;
  public posId: string = '';
  public title: string = 'Link To POS';
  public placeholder: string = "POS Lead ID";
  public okBtn: string = 'Save';
  public clBtn: string = 'Cancel';
  public event: EventEmitter<any> = new EventEmitter();

  constructor(
    public dialogRef: MatDialogRef<PosConnectDgComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {
    if (data) {
      this.title = data.title || this.title;
      this.okBtn = data.okBtn || this.okBtn;
      this.posId = data.posId;

      switch(data.type) {
        case const_pos.CLOVER:
          this.placeholder = data.type + ' Lead ID';
          break;
        case const_pos.NEWTEK:
        case const_pos.TABIT:
          this.placeholder = data.type + ' Store UUID';
          break;
      }
    }
  }

  ngOnInit() {
    const nonWhitespaceRegExp: RegExp = new RegExp("\\S");
    this.posConnectFormGroup = new FormGroup({
      posId: new FormControl(this.posId, [Validators.required, Validators.pattern(nonWhitespaceRegExp)]),
    });
  }

  onSubmit(value): void {
    this.posId = value.posId;
    this.event.emit(this.posId);
    this.dialogRef.close();
  }

}
