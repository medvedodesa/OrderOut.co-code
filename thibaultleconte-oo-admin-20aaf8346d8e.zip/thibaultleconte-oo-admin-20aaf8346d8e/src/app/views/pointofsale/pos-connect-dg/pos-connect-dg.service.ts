import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';

import { Restaurant } from '../../restaurant/restaurant';

import { PointofsaleService } from '../pointofsale.service';

import { PosConnectDgComponent } from './pos-connect-dg.component';


@Injectable({
  providedIn: 'root'
})
export class PosConnectDgService {

  constructor(
    private router: Router,
    private dialog: MatDialog,
    private pointOfSaleService: PointofsaleService
  ) { }

  connectToPOS(type: string, restaurant: Restaurant) {

    const dialogRef = this.dialog.open(PosConnectDgComponent, {
        width: '600px',
        data: {
          title: 'Link to '+ type,
          type: type
        }
    });
    dialogRef.componentInstance.event.subscribe((posId) => {
      this.pointOfSaleService.connectToPOS(type, posId, restaurant).subscribe((pointofsale) => {
        this.router.navigate(['restaurant', restaurant.id, 'pos', pointofsale.id]);
      });
    });

  }
}
