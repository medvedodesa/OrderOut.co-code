import { TestBed } from '@angular/core/testing';

import { PosConnectDgService } from './pos-connect-dg.service';

describe('PosConnectDgService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PosConnectDgService = TestBed.get(PosConnectDgService);
    expect(service).toBeTruthy();
  });
});
