import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Account } from '../../account/account';
import { AccountRestaurant, Restaurant } from '../../restaurant/restaurant';
import { PointOfSale } from '../pointofsale';

@Component({
  selector: 'app-pointofsale',
  templateUrl: './pointofsale.component.html',
  styleUrls: ['./pointofsale.component.scss']
})
export class PointofsaleComponent implements OnInit {

  public accountRestaurant: AccountRestaurant;
  public account: Account;
  public restaurant: Restaurant;
  public pointofsale: PointOfSale;

  public isCloverPOS = false;
  constructor(
    private route: ActivatedRoute,
  ) { }

  ngOnInit() {
    this.accountRestaurant = this.route.snapshot.data.accountRestaurant;
    this.account = this.accountRestaurant.account;
    this.restaurant = this.accountRestaurant.restaurant;
    this.pointofsale = this.route.snapshot.data.pointofsale;

    this.isCloverPOS = this.pointofsale && this.pointofsale.type === 'CLOVER';
  }


  // fetchMenu(pointOfSale: PointOfSale) {
  //   console.log('Sync Menu now...');
  //   this.pointofsaleService.fetchMenu(pointOfSale.id).subscribe();
  // }

  // disconnect(pointOfSale: PointOfSale) {
  //   console.log('disconnectFromClover');
  //   this.pointofsaleService.disconnect(pointOfSale.id).subscribe(() => {
  //     this.getPointOfSales();
  //   });
  // }

}
