import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { DeliveryService } from './deliveryservice';
import { DeliveryserviceService } from './deliveryservice.service';

@Injectable()
export class DeliveryServiceResolve implements Resolve<DeliveryService> {

  constructor(private deliveryserviceService: DeliveryserviceService) {}

  resolve(route: ActivatedRouteSnapshot) {
    return this.deliveryserviceService.getDeliveryService(route.params.deliveryServiceId);
  }
}