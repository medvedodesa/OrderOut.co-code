import { Component, OnInit, Input, Inject } from '@angular/core';

import { Account } from '../../account/account';
import { Restaurant } from '../../restaurant/restaurant';
import { breadcrumb } from '../../common/breadcrumb/breadcrumb';
import { DeliveryService } from '../deliveryservice';

import { DeliveryserviceService } from '../deliveryservice.service';
import { BreadcrumbService } from '../../common/breadcrumb/breadcrumb.service';
import { DsConnectDgService } from '../deliveryservice-connect-dialog/ds-connect-dg.service';
import { AppService } from '../../../service/app.service';
import { dsHelper } from '../deliveryservice.helper';


@Component({
  selector: 'app-deliveryservice-details',
  templateUrl: './deliveryservice-details.component.html',
  styleUrls: ['./deliveryservice-details.component.scss']
})
export class DeliveryserviceDetailsComponent extends dsHelper implements OnInit {

  @Input() account: Account
  @Input() restaurant: Restaurant;
  @Input() deliveryService?: DeliveryService;

  public breadcrumbList: breadcrumb[] = [];
  public isGHDD;

  constructor(
    @Inject(DeliveryserviceService) dsService: DeliveryserviceService,
    private breadcrumbService: BreadcrumbService,
    private dsConnectDgService: DsConnectDgService,
    public appService: AppService,
  ) {
    super(dsService);
  }

  ngOnInit() {
    this.breadcrumbService.resetBreadcrumbList();
    this.breadcrumbList = this.breadcrumbService.getDeliveryService(
      this.account,
      this.restaurant,
      this.deliveryService
    );

    this.isGHDD = this.deliveryService && this.deliveryService.service_username &&
      (this.deliveryService.type === 'GRUBHUB' || this.deliveryService.type === 'DOORDASH')
    if (this.isGHDD) {
      super.testConnection(this.deliveryService);
    }
  }

  openReConnectDSDialog() {
    let title = "Update " + this.deliveryService.type + " Menu Service URL";
    this.dsConnectDgService.openConnectDSDialog(this.deliveryService, this.restaurant.id, title);
  }

}
