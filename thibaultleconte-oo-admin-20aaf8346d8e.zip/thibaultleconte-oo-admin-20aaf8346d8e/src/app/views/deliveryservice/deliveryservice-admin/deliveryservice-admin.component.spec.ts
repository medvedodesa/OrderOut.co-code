import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryserviceAdminComponent } from './deliveryservice-admin.component';

describe('DeliveryserviceAdminComponent', () => {
  let component: DeliveryserviceAdminComponent;
  let fixture: ComponentFixture<DeliveryserviceAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliveryserviceAdminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryserviceAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
