import { Component, OnDestroy, Input } from '@angular/core';
import { ISubscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';

import { DeliveryService } from '../deliveryservice';
import { DeliveryserviceService } from '../deliveryservice.service';
import { Restaurant } from '../../restaurant/restaurant';
import { ConfirmationDialogService } from '../../common/confirmation-dialog/confirmation-dialog.service';
import { DeliveryserviceDisconnectDgComponent } from '../deliveryservice-disconnect-dg/deliveryservice-disconnect-dg.component';

@Component({
  selector: 'app-deliveryservice-admin',
  templateUrl: './deliveryservice-admin.component.html',
  styleUrls: ['./deliveryservice-admin.component.scss']
})
export class DeliveryserviceAdminComponent implements OnDestroy {

  @Input() restaurant: Restaurant;
  @Input() deliveryService: DeliveryService;

  private subscription: ISubscription;

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private deliveryserviceService: DeliveryserviceService,
    public cdService: ConfirmationDialogService,
    ) { }

  ngOnDestroy() {
    if (!this.subscription) { return; }
    this.subscription.unsubscribe();
  }

  deleteDeliveryservice() {

    this.cdService.confirm({
      message: {
        name: this.deliveryService.type,
        type: 'Delivery Service'
      }
    }).subscribe(result => {
      if (result) {
        if (this.deliveryService.type.toLocaleLowerCase() === 'ubereats') {
          const dgRef = this.dialog.open(DeliveryserviceDisconnectDgComponent);
          this.disableIntegration(dgRef);
        } else {
          this.subscription = this.deliveryserviceService.disconnect(this.deliveryService.id).subscribe(() => {
            this.router.navigate(['restaurant', this.restaurant.id]);
          });
        }
      }
    });

  }

  disableIntegration(dgRef) {
    let dpHasError = true;
    let dsIntegrationStatus = this.deliveryService.integration_enabled;
    this.deliveryService.integration_enabled = false; // Disabled UberEats Integration
    this.deliveryserviceService.updateDeliveryService(this.deliveryService).subscribe((dpRes) => {
      if (dpRes.integration_enabled === false) {
        dpHasError = false;
        dgRef.componentInstance.dpLabel = "De-provisioned";
        dgRef.componentInstance.next();
        this.updatePOSData(dgRef);
      }
    }).add(() => {
      if (dpHasError) {
        dgRef.componentInstance.dpHasError = true;
        this.deliveryService.integration_enabled = dsIntegrationStatus;
      }
    });
  }

  updatePOSData(dgRef) {
    let pdHasError = true;
    this.deliveryserviceService.updatePosStatus(this.deliveryService.id, false).subscribe(status => {
      if (status === true) {
        pdHasError = false;
        dgRef.componentInstance.pdLabel = "Disabled UberEats POS Data";
        dgRef.componentInstance.next();
        this.disconnectUberEats(dgRef);
      }
    }).add(() => {
      if (pdHasError) {
        dgRef.componentInstance.pdHasError = true;
      }
    });
  }

  disconnectUberEats(dgRef) {
    let dsHasError = true;
    this.subscription = this.deliveryserviceService.disconnect(this.deliveryService.id).subscribe((dsRes) => {
      if (dsRes.status === 'Disconnected Delivery Service successfully') {
        dsHasError = false;
        dgRef.componentInstance.dsSuccess = true;
        dgRef.componentInstance.dsLabel = "Disconnected";
        dgRef.componentInstance.complete();
        this.router.navigate(['restaurant', this.restaurant.id]);
      }
    }).add(() => {
      if (dsHasError) {
        dgRef.componentInstance.dsHasError = true;
      }
    });
  }
}