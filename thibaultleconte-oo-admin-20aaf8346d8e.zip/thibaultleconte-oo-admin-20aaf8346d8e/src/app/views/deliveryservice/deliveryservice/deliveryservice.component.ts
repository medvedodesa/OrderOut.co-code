import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { Account } from '../../account/account';
import { AccountRestaurant, Restaurant } from '../../restaurant/restaurant';
import { DeliveryService } from '../deliveryservice';

@Component({
  selector: 'app-deliveryservice',
  templateUrl: './deliveryservice.component.html',
  styleUrls: ['./deliveryservice.component.scss']
})
export class DeliveryserviceComponent implements OnInit {

  public accountRestaurant: AccountRestaurant;
  public account: Account;
  public restaurant: Restaurant;
  public deliveryService: DeliveryService;

  constructor(
    private route: ActivatedRoute,
  ) { }

  ngOnInit() {
    this.accountRestaurant = this.route.snapshot.data.accountRestaurant;
    this.account = this.accountRestaurant.account;
    this.restaurant = this.accountRestaurant.restaurant;
    this.deliveryService = this.route.snapshot.data.deliveryService;
  }

}
