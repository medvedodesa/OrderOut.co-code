import { Component, OnInit, ViewEncapsulation, ViewChild, Inject } from '@angular/core';
import { STEPPER_GLOBAL_OPTIONS } from "@angular/cdk/stepper";
import { MatStepper } from '@angular/material/stepper';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';


@Component({
  selector: 'app-deliveryservice-enable-dg',
  templateUrl: './deliveryservice-enable-dg.component.html',
  styleUrls: ['./deliveryservice-enable-dg.component.scss'],
  providers: [
    {
      provide: STEPPER_GLOBAL_OPTIONS,
      useValue: { displayDefaultIndicatorType: false }
    }
  ],
  encapsulation: ViewEncapsulation.None
})
export class DeliveryserviceEnableDgComponent implements OnInit {

  public isEditable: boolean = false;
  public showPushMenuStep: boolean = false;
  public showPOSDataStep: boolean = false;
  public dsName: string;

  public pmLabel: string = 'Push Menu for Real';
  public pmHasError: boolean = false;

  public pdLabel: string;
  public pdHasError: boolean = false;

  public psLabel: string;
  public psHasError: boolean = false;
  public psSuccess: boolean = false;

  @ViewChild('stepper') private myStepper: MatStepper;

  constructor(
    public dialogRef: MatDialogRef<DeliveryserviceEnableDgComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.psLabel = data.state + ' ' + data.dsName + ' Integration';
    this.pdLabel = data.state + ' ' + data.dsName + ' POS Data';
    this.showPushMenuStep = data.showPushMenuStep;
    this.showPOSDataStep = data.showPOSDataStep;
    this.dsName = data.dsName;
  }

  ngOnInit() {
  }

  next() {
    this.myStepper.next();
  }

  complete() {
    this.myStepper.selected.completed = true;
    this.myStepper.selected.state = "done";
  }

}
