import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryserviceEnableDgComponent } from './deliveryservice-enable-dg.component';

describe('DeliveryserviceEnableDgComponent', () => {
  let component: DeliveryserviceEnableDgComponent;
  let fixture: ComponentFixture<DeliveryserviceEnableDgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliveryserviceEnableDgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryserviceEnableDgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
