import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

import { environment } from '../../../environments/environment';
import { ApiService } from './../../core/api.service';

import { Account } from '../account/account';
import { Restaurant } from '../restaurant/restaurant';
import { DeliveryService, DeliveryServiceStatus } from './deliveryservice';
import { MenuItem } from '../menu/menu';
import { delay } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class DeliveryserviceService {

  restaurantUrl = environment.backend_url + 'restaurant';
  deliveryserviceUrl = environment.backend_url + 'ds';
  menusyncUrl = environment.backend_url + 'menusync';

  constructor(private api: ApiService) { }

  getDeliveryServices(restaurantId: number): Observable<[DeliveryService]> {
    const url = `${this.restaurantUrl}/${restaurantId}/ds`;
    return this.api.get(url);
  }

  getDeliveryService(deliveryServiceId: number): Observable<DeliveryService> {
    const url = `${this.deliveryserviceUrl}/${deliveryServiceId}`;
    return this.api.get(url);
  }

  connectToDeliveryService(restaurantId: number, type: string, params?: {}) {
    const url = `${this.restaurantUrl}/${restaurantId}/ds/${type}/connect`;
    return this.api.post(url, params);
  }

  fetchMenu(deliveryServiceId: number) {
    const url = `${this.deliveryserviceUrl}/${deliveryServiceId}/menu/fetch`;
    return this.api.get(url);
  }

  pushMenu(deliveryServiceId: number, testOnBiscayneBakery: boolean) {
    const url = `${this.deliveryserviceUrl}/${deliveryServiceId}/menu/push`;
    const params = { testOnBiscayneBakery };
    return this.api.put(url, params);
  }

  fetchPosStatus(deliveryServiceId: number): Observable<DeliveryServiceStatus> {
    const url = `${this.deliveryserviceUrl}/${deliveryServiceId}/pos/status`;
    return this.api.get(url);
  }

  updatePosStatus(deliveryServiceId: number, enable): Observable<boolean> {
    let posStatus = (enable && enable === true) ? 'enable' : 'disable';
    const url = `${this.deliveryserviceUrl}/${deliveryServiceId}/pos/${posStatus}`;
    return this.api.put(url);
  }

  sendTestOrder(deliveryServiceId: number) {
    const url = `${this.deliveryserviceUrl}/${deliveryServiceId}/order/test`;
    return this.api.post(url, {});
  }

  sendSetupInstructions(restaurantId: number, recipientEmail: string): Observable<Restaurant> {
    const url = `${this.restaurantUrl}/${restaurantId}/email/ds_setup_instructions`;
    const params = {
      "recipient_email": recipientEmail
    };
    return this.api.post(url, params);
  }

  verifySettings(deliveryServiceId: number) {
    const url = `${this.deliveryserviceUrl}/${deliveryServiceId}/settings/verify`;
    return this.api.get(url);
  }

  updateDeliveryService(ds: DeliveryService): Observable<DeliveryService> {
    const url = `${this.deliveryserviceUrl}/${ds.id}`;
    const params = {
      "integration_enabled": ds.integration_enabled,
      "service_menu_url": ds.service_menu_url || "",
      "serviceLocationId": ds.serviceLocationId || ""
      // "service_username": ds.service_username || ""
    };
    //ds.service_password ? params['service_password'] = ds.service_password : '';
    return this.api.put(url, params);
  }

  disconnect(deliveryServiceId: number) {
    const url = `${this.deliveryserviceUrl}/${deliveryServiceId}/disconnect`;
    return this.api.delete(url);
  }

  grubhubCredentials(restaurantId: number, credential) {
    const url = `${this.restaurantUrl}/${restaurantId}/ds/grubhub/credential`;
    const params = {
      'username': credential.username,
      'password': credential.password
    };
    return this.api.post(url, params);
  }

  doordashCredentials(restaurantId: number, credential) {
    const url = `${this.restaurantUrl}/${restaurantId}/ds/doordash/credential`;
    const params = {
      'username': credential.username,
      'password': credential.password
    };
    credential.pincode ? params['pincode'] = credential.pincode : '';
    return this.api.post(url, params);
  }

  /** 
   * Get new Menu items list with specific format to support CSV or dialog view on onboarding
  */
  getNewMenuItems(menuItems: MenuItem[], ds?: DeliveryService, account?: Account, restaurant?: Restaurant) {
    let newMenuItems = [];
    if (menuItems && menuItems.length > 0) {
      menuItems.forEach(menuItem => {
        let objMenuItem = {};
        objMenuItem['item_id'] = menuItem.id;
        account && account.name ? objMenuItem['account_name'] = account.name : '';
        restaurant && restaurant.name ? objMenuItem['restaurant_name'] = restaurant.name : '';
        ds && ds.type ? objMenuItem['delivery_service_type'] = ds.type : '';
        objMenuItem['item_name'] = menuItem.name;
        objMenuItem['mappedToMenuItem'] = menuItem.mappedToMenuItem;
        objMenuItem['modifier_name'] = '';
        objMenuItem['modifier_id'] = '';
        objMenuItem['mappedToMenuItemModifier'] = null;

        /* Modifier List */
        let modifier_list = [];
        if (menuItem.modifier_groups && menuItem.modifier_groups.length > 0) {
          menuItem.modifier_groups.forEach(modifier_group => {
            if (modifier_group.modifiers && modifier_group.modifiers.length > 0) {
              modifier_group.modifiers.forEach(modifier => {
                let clonedMenuItem = { ...objMenuItem };
                clonedMenuItem['modifier_name'] = modifier.name;
                clonedMenuItem['modifier_id'] = modifier.id;
                clonedMenuItem['mappedToMenuItemModifier'] = modifier.mappedToMenuItemModifier;
                modifier_list.push(clonedMenuItem)
              });
            }
          });
        }

        newMenuItems.push(objMenuItem);
        if (modifier_list.length > 0) {
          newMenuItems = newMenuItems.concat(modifier_list);
        }
      });
    }
    return newMenuItems;
  }

  getUnMappedMenuList(itemsList) {
    let unMappedMenuList = itemsList.filter(function (menuItem) {
      return menuItem.modifier_id ? menuItem.mappedToMenuItemModifier === null : menuItem.mappedToMenuItem === null;
    });
    return unMappedMenuList;
  }

  testConnection(dsId: number) {
    const url = `${this.deliveryserviceUrl}/${dsId}/test/connection`;
    return this.api.post(url, {});
  }

}
