import { MenuSync } from '../menu/menuSync';

export interface DeliveryService {
    id: number;
    type: string;
    serviceLocationId: string;
    service_account_id?: string;
    service_menu_url: string;
    service_username: string;
    service_password: string;
    status: number;
    menuSync: MenuSync;
    incomingOrderEmailVerification: IncomingOrderEmailVerification;
    integration_enabled: boolean;
    api_created_at: Date;
}

export interface DeliveryServiceStatus {
    online_status: string;
    pos_integration_enabled: boolean;
    order_release_enabled: boolean;
    auto_accept_enabled: boolean;
}

export interface IncomingOrderEmailVerification {
    id: number;
    recipientEmail: string;
    success: boolean;
    api_created_at: Date;
}

export const const_ds = {
    UBEREATS: "UBEREATS",
    POSTMATES: "POSTMATES",
    WIX: "WIX",
    GRUBHUB: "GRUBHUB",
    DOORDASH: "DOORDASH",
    CHOWNOW: "CHOWNOW",
    ubereats: {
        name: 'ubereats',
        enable: true
    },
    postmates: {
        name: 'postmates',
        enable: true
    },
    wix: {
        name: 'wix',
        enable: true
    },
    grubhub: {
        name: 'grubhub',
        enable: true
    },
    doordash: {
        name: 'doordash',
        enable: true
    },
    chownow: {
        name: 'chownow',
        enable: false
    },
    deliverycom: {
        name: 'deliverycom',
        enable: false
    },
    caviar: {
        name: 'caviar',
        enable: false
    },
    slice: {
        name: 'slice',
        enable: false
    },
    DS_INFO_LIST: []
}

const_ds.DS_INFO_LIST = [
    {
        "name": const_ds.UBEREATS,
        "weburl": 'https://www.ubereats.com/',
        "menuurl":'https://www.ubereats.com/miami/food-delivery/biscayne-bakery/sUraxJE4RUqqcrKZqHMvhA',
        "regex": "^(https?:\\/\\/www\\.|www\\.)?ubereats\\.com(\\/[A-Za-z0-9\\-\\._~:\\/\\?#\\[\\]@!$&'\\(\\)\\*\\+,;\\=]*)?"
    },
    {
        "name": const_ds.POSTMATES,
        "weburl": 'https://postmates.com/',
        "menuurl":'https://postmates.com/merchant/biscayne-bakery-miami',
        "regex": "^(https?:\\/\\/(www\\.)?|www\\.)?postmates\\.com\\/merchant(\\/[A-Za-z0-9\\-\\._~:\\/\\?#\\[\\]@!$&'\\(\\)\\*\\+,;\\=]*)?"
    },
    {
        "name": const_ds.WIX,
        "weburl": '',
        "menuurl":'Your WIX website URL',
        "regex": "(http(s)?:\\/\\/.)?(www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{2,256}\\.[a-z]{2,6}\\b([-a-zA-Z0-9@:%_\\+.~#?&//=]*)"
    },
    {
        "name": const_ds.GRUBHUB,
        "weburl": 'https://www.grubhub.com/',
        "menuurl":'https://www.grubhub.com/restaurant/biscayne-bakery-400-nw-26th-st-miami/1217107',
        "regex": "^(https?:\\/\\/(www\\.)?|www\\.)?grubhub\\.com\\/restaurant(\\/[A-Za-z0-9\\-\\._~:\\/\\?#\\[\\]@!$&'\\(\\)\\*\\+,;\\=]*)?"
    },
    {
        "name": const_ds.DOORDASH,
        "weburl": 'https://www.doordash.com/',
        "menuurl":'https://www.doordash.com/store/biscayne-bakery-miami-622565',
        "regex": "^(https?:\\/\\/(www\\.)?|www\\.)?doordash\\.com\\/store(\\/[A-Za-z0-9\\-\\._~:\\/\\?#\\[\\]@!$&'\\(\\)\\*\\+,;\\=]*)?"
    },
    {
        "name": const_ds.CHOWNOW,
        "weburl": 'https://eat.chownow.com/discover/',
        "menuurl":'https://eat.chownow.com/discover/restaurant/xxx/menu/yyy',
        "regex": "^(https?:\\/\\/)?eat\\.chownow\\.com\\/discover\\/restaurant\\/[0-9]{2,8}\\/menu\\/[0-9]{10,15}(\\/[A-Za-z0-9\\-\\._~:\\/\\?#\\[\\]@!$&'\\(\\)\\*\\+,;\\=]*)?"
    }
];
