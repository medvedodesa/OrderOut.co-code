import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryservicePosIntegrationComponent } from './deliveryservice-pos-integration.component';

describe('DeliveryservicePosIntegrationComponent', () => {
  let component: DeliveryservicePosIntegrationComponent;
  let fixture: ComponentFixture<DeliveryservicePosIntegrationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliveryservicePosIntegrationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryservicePosIntegrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
