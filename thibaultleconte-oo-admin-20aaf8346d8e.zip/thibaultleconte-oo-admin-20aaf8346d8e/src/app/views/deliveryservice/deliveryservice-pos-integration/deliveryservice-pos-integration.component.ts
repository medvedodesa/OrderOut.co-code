import { Component, OnInit, Input } from '@angular/core';
import { DeliveryService, DeliveryServiceStatus } from '../deliveryservice';
import { DeliveryserviceService } from '../deliveryservice.service';

@Component({
  selector: 'app-deliveryservice-pos-integration',
  templateUrl: './deliveryservice-pos-integration.component.html',
  styleUrls: ['./deliveryservice-pos-integration.component.scss']
})
export class DeliveryservicePosIntegrationComponent implements OnInit {

  @Input() deliveryService: DeliveryService;
  deliveryServiceStatus: DeliveryServiceStatus;

  constructor(private deliveryserviceService: DeliveryserviceService) { }

  ngOnInit() {
    this.fetchPosStatus();
  }

  fetchPosStatus() {
    this.deliveryserviceService.fetchPosStatus(this.deliveryService.id).subscribe(status => {
      console.log(status);
      this.deliveryServiceStatus = status;
    });
  }

  updatePosStatus(posStatus) {
    this.deliveryserviceService.updatePosStatus(this.deliveryService.id, posStatus).subscribe(status => {
      if (status === true) {
        this.deliveryServiceStatus.pos_integration_enabled = true;
      }
    });
  }

}
