import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { STEPPER_GLOBAL_OPTIONS } from "@angular/cdk/stepper";
import { MatStepper } from '@angular/material/stepper';

@Component({
  selector: 'app-deliveryservice-disconnect-dg',
  templateUrl: './deliveryservice-disconnect-dg.component.html',
  styleUrls: ['./deliveryservice-disconnect-dg.component.scss'],
  providers: [
    {
      provide: STEPPER_GLOBAL_OPTIONS,
      useValue: { displayDefaultIndicatorType: false }
    }
  ],
  encapsulation: ViewEncapsulation.None
})
export class DeliveryserviceDisconnectDgComponent implements OnInit {

  public isEditable = false;

  public dpLabel = 'De-provision';
  public dpHasError = false;

  public pdLabel = 'Disable UberEats POS Data';
  public pdHasError = false;

  public dsLabel = 'Disconnect';
  public dsHasError = false;
  public dsSuccess = false;

  @ViewChild('stepper') private myStepper: MatStepper;

  constructor() { }

  ngOnInit() {
  }

  next() {
    this.myStepper.next();
  }

  complete() {
    this.myStepper.selected.completed = true;
    this.myStepper.selected.state = "done";
  }

}
