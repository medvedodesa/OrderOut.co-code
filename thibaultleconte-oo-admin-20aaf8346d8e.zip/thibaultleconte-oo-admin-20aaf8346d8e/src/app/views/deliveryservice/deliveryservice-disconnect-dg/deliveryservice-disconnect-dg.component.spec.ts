import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryserviceDisconnectDgComponent } from './deliveryservice-disconnect-dg.component';

describe('DeliveryserviceDisconnectDgComponent', () => {
  let component: DeliveryserviceDisconnectDgComponent;
  let fixture: ComponentFixture<DeliveryserviceDisconnectDgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliveryserviceDisconnectDgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryserviceDisconnectDgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
