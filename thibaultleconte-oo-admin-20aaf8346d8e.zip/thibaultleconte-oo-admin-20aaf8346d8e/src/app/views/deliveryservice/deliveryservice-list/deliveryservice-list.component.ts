import { Component, OnInit, Input, Output, EventEmitter, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { MatSlideToggleChange } from '@angular/material';
import { forkJoin, of } from 'rxjs';
import { map, skip } from 'rxjs/operators';
import { MatDialog } from '@angular/material';

import { dsHelper } from '../deliveryservice.helper';
import { DeliveryserviceService } from '../deliveryservice.service';
import { DeliveryService, const_ds } from '../deliveryservice';

import { Account } from '../../account/account';
import { Restaurant } from '../../restaurant/restaurant';
import { RestaurantHelper } from '../../restaurant/restaurant.helper';
import { MenuService } from '../../menu/menu.service';

import { AppService } from '../../../service/app.service';
import { LoaderService } from '../../../service/loader.service';

import { ConfirmationDialogService } from '../../common/confirmation-dialog/confirmation-dialog.service';
import { MessageDgService } from '../../common/message-dg/message-dg.service';
import { DeliveryserviceEnableDgComponent } from '../deliveryservice-enable-dg/deliveryservice-enable-dg.component';
import { PointOfSale, const_pos } from '../../pointofsale/pointofsale';
import { MenuItem } from '../../menu/menu';

@Component({
  selector: 'app-deliveryservice-list',
  templateUrl: './deliveryservice-list.component.html',
  styleUrls: ['./deliveryservice-list.component.scss']
})
export class DeliveryserviceListComponent extends dsHelper implements OnInit {

  @Input() account: Account;
  @Input() restaurant: Restaurant;

  @Output() emitDeliveryServicesList = new EventEmitter<any>();

  public columnsToDisplay = ['type', 'total_items', 'mapped_items',
    'total_modifiers', 'mapped_modifiers',
    'api_created_at', 'integration_enabled', 'credentials'];
  public deliveryServices: DeliveryService[];
  public allDSList: DeliveryService[];
  public isUnMappedMenuItems: boolean = false;
  public isDeliveryServices: boolean = false;
  public integrationState: string;

  public pos: PointOfSale;
  public isTabitPOS: boolean = false;
  public isCloverPOS: boolean = false;
  public posItemsList: MenuItem[];
  public showDSTable: boolean = false;

  constructor(
    @Inject(DeliveryserviceService) dsService: DeliveryserviceService,
    private router: Router,
    public dialog: MatDialog,
    private deliveryserviceService: DeliveryserviceService,
    private menuService: MenuService,
    private appService: AppService,
    private loaderService: LoaderService,
    public cdService: ConfirmationDialogService,
    public restaurantHelper: RestaurantHelper,
    private msgDgService: MessageDgService
  ) {
    super(dsService);
  }

  ngOnInit() {
    this.restaurantHelper.pos$.pipe(skip(1)).subscribe(pos => {
      this.pos = pos;
      this.isTabitPOS = (this.pos && this.pos.type && this.pos.type.toLowerCase()) === const_pos.TABIT.toLowerCase();
      this.isCloverPOS = (this.pos && this.pos.type && this.pos.type.toLowerCase()) === const_pos.CLOVER.toLowerCase();
      if (this.isCloverPOS) {
        this.columnsToDisplay = ['type', 'total_items', 'total_modifiers', 'api_created_at', 'integration_enabled', 'credentials'];
      }
      this.showDSTable = true;
    });
    this.getDeliveryServices();
  }

  private getDeliveryServices() {
    this.deliveryserviceService.getDeliveryServices(this.restaurant.id).subscribe(deliveryServices => {
      this.restaurantHelper.setDeliveryServices(deliveryServices);
      this.allDSList = deliveryServices;
      const noMenuSyncDSList = deliveryServices.filter(deliveryService => {
        return deliveryService.menuSync === null;
      });
      this.emitDeliveryServicesList.emit(noMenuSyncDSList);

      const MenuSyncDSList = deliveryServices.filter(deliveryService => {
        return deliveryService.menuSync !== null;
      });
      this.deliveryServices = MenuSyncDSList;

      if (deliveryServices && deliveryServices.length > 0) {
        this.isDeliveryServices = true;
        this.isUnMappedMenuItems = true; // Enabled List Un-Mapped Items button temporarily
        deliveryServices.forEach((deliveryService) => {
          if (deliveryService.menuSync && deliveryService.menuSync.map_unmapped_menu_items > 0) {
            this.isUnMappedMenuItems = true;
          }
        });
      }

      if (this.deliveryServices && this.deliveryServices.length > 0) {
        this.deliveryServices.forEach((ds) => {

          // GRUBHUB and DOORDASH connection check
          const isGHDD = ds.type === 'GRUBHUB' || ds.type === 'DOORDASH';
          if (isGHDD && ds.service_username) {
            super.testConnection(ds);
          }

          // Physical Store ID check
          if (ds && !ds.serviceLocationId) {
            const message = `${ds.type} not connected with any physical location. No serviceLocationId found. Please reconnect again!`;
            this.msgDgService.openMsgDialog(message, { negative: true });
          }
        });
      }

    });
  }

  addDeliveryService() {
    this.router.navigate(['restaurant', this.restaurant.id, 'ds'], { state: { dsList: this.allDSList } });
  }

  rowSelected(deliveryservice: DeliveryService) {
    if (deliveryservice.menuSync) {
      this.router.navigate(['restaurant', this.restaurant.id, 'ds', deliveryservice.id]);
    }
  }

  fetchMenu(deliveryService: DeliveryService) {
    console.log('Fetch Menu now...');
    this.deliveryserviceService.fetchMenu(deliveryService.id).subscribe(() => {
      console.log(`Fetching menu for restaurant ${this.restaurant.id} for ${deliveryService.type}`);
    });
  }

  integrationEnableChange(ob: MatSlideToggleChange, ds: DeliveryService) {
    this.integrationState = ob.checked === true ? 'Enable' : 'Disable';
    const isUberEatsDS = ds.type.toLowerCase() === const_ds.ubereats.name ? true : false;
    const isUberEatsDSEnable = isUberEatsDS && ob.checked === true ? true : false;
    let note = '<b>' + this.integrationState + '</b> ' + ds.type + ' integration?';

    const uberNote = '<span class="negative">It will do "Push menu for real" and  "Enable UberEats integration".</span><br/><br/>';
    note = isUberEatsDSEnable ? uberNote + note : note;

    this.cdService.confirm({
      type: 'general-confirm',
      note: note
    }).subscribe(result => {
      if (result && result === true) {
        const dgRef = this.dialog.open(DeliveryserviceEnableDgComponent, {
          data: {
            state: this.integrationState,
            dsName: ds.type,
            showPushMenuStep: isUberEatsDSEnable,
            showPOSDataStep: isUberEatsDS
          }
        });
        if (isUberEatsDSEnable) {
          this.pushMenuUberEats(ds, dgRef);
        } else if (isUberEatsDS) {
          this.updatePOSData(ds, dgRef, false);
        } else {
          this.updateDeliveryService(ds, dgRef);
        }
      } else {
        ds.integration_enabled = !ob.checked;
      }
    });
  }

  pushMenuUberEats(ds, dgRef) {
    const testOnBiscayneBakery = false; // true - Push menu to Biscayne Bakery. false - push menu to live UberEats Store
    let pmHasError = true;
    this.deliveryserviceService.pushMenu(ds.id, testOnBiscayneBakery).subscribe((pmRes) => {
      if (pmRes.status === 'Pushing Delivery Service Menu started') {
        pmHasError = false;
        dgRef.componentInstance.pmLabel = "Started Pushing Menu for Real";
        dgRef.componentInstance.next();
        this.updatePOSData(ds, dgRef, true);
      }
    }).add(() => {
      if (pmHasError) {
        dgRef.componentInstance.pmHasError = true;
        ds.integration_enabled = !ds.integration_enabled;
      }
    });
  }

  updatePOSData(ds, dgRef, posStatus) {
    let pdHasError = true;
    this.deliveryserviceService.updatePosStatus(ds.id, posStatus).subscribe(status => {
      if (status === true) {
        pdHasError = false;
        dgRef.componentInstance.pdLabel = this.integrationState + "d " + ds.type + " POS Data";
        dgRef.componentInstance.next();
        this.updateDeliveryService(ds, dgRef);
      }
    }).add(() => {
      if (pdHasError) {
        dgRef.componentInstance.pdHasError = true;
        ds.integration_enabled = !ds.integration_enabled;
      }
    });
  }

  updateDeliveryService(ds, dgRef) {
    let psHasError = true;
    this.deliveryserviceService.updateDeliveryService(ds).subscribe((dsRes: DeliveryService) => {
      if (dsRes && dsRes.integration_enabled === ds.integration_enabled) {
        psHasError = false;
        dgRef.componentInstance.psLabel = this.integrationState + "d " + ds.type + " Integration";
        dgRef.componentInstance.psSuccess = true;
        dgRef.componentInstance.complete();
      }
    }).add(() => {
      if (psHasError) {
        dgRef.componentInstance.psHasError = true;
        ds.integration_enabled = !ds.integration_enabled;
      }
    });
  }

  exportCSV() {
    this.getMenuItems().subscribe(dsItemsList => {
      console.log(dsItemsList);
      if (dsItemsList && dsItemsList.length > 0) {
        if (this.isTabitPOS) {
          this.getTabitItems(dsItemsList);
        } else {
          this.getUnmappedItems(dsItemsList);
        }
      }
      this.loaderService.hide();
    });
  }

  getUnmappedItems(dsItemsList) {
    const unmappedItems = this.deliveryserviceService.getUnMappedMenuList(dsItemsList);
    const headerList = ['account_name', 'restaurant_name', 'delivery_service_type',
      'item_id', 'item_name', 'modifier_id', 'modifier_name'];
    this.downloadFile(unmappedItems, [headerList, headerList], '-unmapped_menu_items');
  }

  getTabitItems(dsItemsList) {
    const menuItemsMapList = this.getMenuItemsMapList(dsItemsList);
    const titleList = ['account_name', 'restaurant_name', 'delivery_service_type',
      'delivery_service_item_id', 'delivery_service_item_name',
      'delivery_service_modifier_id', 'delivery_service_modifier_name',
      'mapped_to_point_of_sale_item_id', 'mapped_to_point_of_sale_item_uuid', 'mapped_to_point_of_sale_item_name',
      'mapped_to_point_of_sale_modifier_id', 'mapped_to_point_of_sale_modifier_uuid', 'mapped_to_point_of_sale_modifier_name'];
    const keyList = ['account_name', 'restaurant_name', 'delivery_service_type',
      'item_id', 'item_name', 'modifier_id', 'modifier_name',
      'pos_item_id', 'pos_item_uuid', 'pos_item_name',
      'pos_modifier_id', 'pos_modifier_uuid', 'pos_modifier_name'];

    this.downloadFile(menuItemsMapList, [titleList, keyList], '-all_menu_items');
  }

  getMenuItemsMapList(dsItemsList) {
    if (this.posItemsList && this.posItemsList.length > 0) {
      const posModifiersList = this.getPOSModifiersList();
      console.log(posModifiersList);
      dsItemsList.forEach(dsLineItem => {
        // Set DS to POS Menu Items
        if (dsLineItem.mappedToMenuItem) {
          dsLineItem['pos_item_id'] = dsLineItem.mappedToMenuItem;
          this.posItemsList.forEach(posItem => {
            if (dsLineItem.mappedToMenuItem === posItem.id) {
              //dsLineItem['pos_item_id'] = posItem.id;
              dsLineItem['pos_item_uuid'] = posItem.uuid;
              dsLineItem['pos_item_name'] = posItem.name;
            }
          });
        } else {
          dsLineItem['pos_item_id'] = '-';
          dsLineItem['pos_item_uuid'] = '-';
          dsLineItem['pos_item_name'] = 'MISSING';
        }

        // Set DS to POS Menu Items Modifiers
        if (dsLineItem.mappedToMenuItemModifier) {
          dsLineItem['pos_modifier_id'] = dsLineItem.mappedToMenuItemModifier;
          posModifiersList.forEach(posModifier => {
            if (dsLineItem.mappedToMenuItemModifier === posModifier.id) {
              //dsLineItem['pos_modifier_id'] = posModifier.id;
              dsLineItem['pos_modifier_uuid'] = posModifier.uuid;
              dsLineItem['pos_modifier_name'] = posModifier.name;
            }
          });
        } else if (dsLineItem.modifier_id) {
          dsLineItem['pos_modifier_id'] = '-';
          dsLineItem['pos_modifier_uuid'] = '-';
          dsLineItem['pos_modifier_name'] = 'MISSING';
        }
      });
    }
    return dsItemsList;
  }

  getPOSModifiersList() {
    let posModifiersList = [];
    if (this.posItemsList && this.posItemsList.length > 0) {
      this.posItemsList.forEach(posItem => {
        if (posItem.modifier_groups && posItem.modifier_groups.length > 0) {
          posItem.modifier_groups.forEach(modifier_group => {
            if (modifier_group.modifiers && modifier_group.modifiers.length > 0) {
              posModifiersList = posModifiersList.concat(modifier_group.modifiers);
            }
          });
        }
      })
    }
    return posModifiersList;
  }

  downloadFile(rows, headerList, fileNameText) {
    const fileName = this.getFileName(fileNameText);
    this.appService.downloadFile(rows, headerList, fileName);
  }

  getMenuItems() {
    if (this.deliveryServices && this.deliveryServices.length > 0) {
      this.loaderService.show();
      let dsItemsList = [];
      const menuItemsObservables = [];

      // Delivery Services Menu Items
      this.deliveryServices.forEach((deliveryService) => {
        menuItemsObservables.push(
          this.menuService.getByDeliveryService(deliveryService.id)
            .pipe(map(value => ({ category: 'ds', type: deliveryService.type, value: value }))));
      });

      // Point Of Sale Menu Items
      if (this.isTabitPOS && this.pos && this.pos.id) {
        menuItemsObservables.push(
          this.menuService.getByPointOfSale(this.pos.id)
            .pipe(map(value => ({ category: 'pos', type: this.pos.type, value: value }))));
      }

      return forkJoin(menuItemsObservables).pipe(
        map(results => {
          results.forEach((result) => {
            if (result.category === 'ds') {
              const menuItems = result.value;
              const newMenuItems = this.deliveryserviceService.getNewMenuItems(menuItems, result, this.account, this.restaurant);
              dsItemsList = dsItemsList.concat(newMenuItems);
            } else if (result.category === 'pos') {
              this.posItemsList = result.value;
            }
          });
          return dsItemsList;
        })
      );
    } else {
      return of([]);
    }
  }

  getFileName(fileNameText) {
    const accountName = this.appService.ConvertToSnakeCaseString(this.account.name),
      restaurantName = this.appService.ConvertToSnakeCaseString(this.restaurant.name),
      today = this.appService.formatDate();
    return accountName + '-' + restaurantName + '-' + today + fileNameText;
  }

  sendSetupInstructions() {
    this.cdService.confirm({
      type: 'email-setup-instructions-confirm'
    }).subscribe(result => {
      if (result && result.recipientEmail) {
        this.loaderService.show();
        this.deliveryserviceService.sendSetupInstructions(this.restaurant.id, result.recipientEmail).subscribe((restaurant) => {
          this.loaderService.hide();
        });
      }
    });

  }

}
