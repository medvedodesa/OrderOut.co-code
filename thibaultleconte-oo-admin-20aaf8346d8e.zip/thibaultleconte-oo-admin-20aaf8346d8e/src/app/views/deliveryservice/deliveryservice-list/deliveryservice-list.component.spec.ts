import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryserviceListComponent } from './deliveryservice-list.component';

describe('DeliveryserviceListComponent', () => {
  let component: DeliveryserviceListComponent;
  let fixture: ComponentFixture<DeliveryserviceListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliveryserviceListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryserviceListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
