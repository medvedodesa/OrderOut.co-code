import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryserviceMenusyncComponent } from './deliveryservice-menusync.component';

describe('DeliveryserviceMenusyncComponent', () => {
  let component: DeliveryserviceMenusyncComponent;
  let fixture: ComponentFixture<DeliveryserviceMenusyncComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliveryserviceMenusyncComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryserviceMenusyncComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
