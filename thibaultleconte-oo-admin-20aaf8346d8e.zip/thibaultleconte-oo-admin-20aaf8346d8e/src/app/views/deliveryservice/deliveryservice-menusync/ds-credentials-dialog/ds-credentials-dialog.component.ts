import { Component, OnInit, EventEmitter, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { const_ds, DeliveryService } from '../../../deliveryservice/deliveryservice';

@Component({
  selector: 'app-ds-credentials-dialog',
  templateUrl: './ds-credentials-dialog.component.html',
  styleUrls: ['./ds-credentials-dialog.component.scss']
})
export class DsCredentialsDialogComponent implements OnInit {

  public dsCredentialsFormGroup: FormGroup;
  public ds: DeliveryService;
  public event: EventEmitter<any> = new EventEmitter();
  public hide: boolean = true;
  public const_ds = const_ds;

  constructor(
    public dialogRef: MatDialogRef<DsCredentialsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {
    this.ds = data.ds;
  }

  ngOnInit() {
    const nonWhitespaceRegExp: RegExp = new RegExp("\\S");
    const pincodeRegExp: RegExp = new RegExp("^[0-9]{4,8}$");
    this.dsCredentialsFormGroup = new FormGroup({
      username: new FormControl('', [Validators.pattern(nonWhitespaceRegExp)]),
      password: new FormControl('', [Validators.pattern(nonWhitespaceRegExp)]),
      pincode: new FormControl('', [Validators.pattern(nonWhitespaceRegExp), Validators.pattern(pincodeRegExp)])
    });
  }

  get usernameInput() { 
    return this.dsCredentialsFormGroup.get('username'); 
  }

  get passwordInput() { 
    return this.dsCredentialsFormGroup.get('password'); 
  }

  get pincodeInput() { 
    return this.dsCredentialsFormGroup.get('pincode'); 
  }

  onSubmit(value): void {
    this.event.emit({
      "username": value.username,
      "password": value.password,
      "pincode": value.pincode
    });
    this.dialogRef.close();
  }

}
