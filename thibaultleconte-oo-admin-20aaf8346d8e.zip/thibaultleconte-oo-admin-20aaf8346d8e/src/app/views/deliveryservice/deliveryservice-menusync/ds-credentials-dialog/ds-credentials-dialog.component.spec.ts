import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DsCredentialsDialogComponent } from './ds-credentials-dialog.component';

describe('DsCredentialsDialogComponent', () => {
  let component: DsCredentialsDialogComponent;
  let fixture: ComponentFixture<DsCredentialsDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DsCredentialsDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DsCredentialsDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
