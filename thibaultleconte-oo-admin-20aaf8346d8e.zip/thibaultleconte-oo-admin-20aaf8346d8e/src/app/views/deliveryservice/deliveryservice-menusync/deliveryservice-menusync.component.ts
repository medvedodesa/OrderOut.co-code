import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';

import { Restaurant } from '../../restaurant/restaurant';
import { DeliveryService } from '../deliveryservice';

import { DeliveryserviceService } from '../deliveryservice.service';
import { MenusyncComponent } from '../../common/menusync/menusync.component';
import { LoaderService } from '../../../service/loader.service';
import { MessageService } from '../../../service/messages/message.service';

import { DsCredentialsDialogComponent } from './ds-credentials-dialog/ds-credentials-dialog.component';

@Component({
  selector: 'app-deliveryservice-menusync',
  templateUrl: './deliveryservice-menusync.component.html',
  styleUrls: ['./deliveryservice-menusync.component.scss']
})
export class DeliveryserviceMenusyncComponent extends MenusyncComponent implements OnInit {

  @Input() restaurant: Restaurant;
  @Input() deliveryService: DeliveryService;

  public data: DeliveryService;
  public getMenuSync: string = 'getDeliveryService';
  public menusyncService: DeliveryserviceService;
  public menuSyncMapDisplayedColumns: string[] = ['total_items', 'mapped_items','total_modifiers', 'mapped_modifiers'];

  public isBB: boolean = false;
  public isGrubhub: boolean = false;
  public isDoordash: boolean = false;

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private loaderService: LoaderService,
    protected deliveryserviceService: DeliveryserviceService,
    private messageService: MessageService
  ) {
    super();
    this.menusyncService = this.deliveryserviceService;
  }

  ngOnInit() {
    this.data = this.deliveryService;
    this.isBB = this.deliveryService.type === 'UBEREATS' || this.deliveryService.type === 'POSTMATES' ? true : false;
    this.isGrubhub = this.deliveryService.type === 'GRUBHUB' ? true : false;
    this.isDoordash = this.deliveryService.type === 'DOORDASH' ? true : false;
    super.ngOnInit();
  }

  pushMenuOnBiscayneBakery() {
    const testOnBiscayneBakery = true;
    this.deliveryserviceService.pushMenu(this.deliveryService.id, testOnBiscayneBakery).subscribe(() => {
      console.log(`Pushing menu on Biscayne Bakery for ${this.deliveryService.type}`);
    });
  }

  pushMenuForReal() {
    const testOnBiscayneBakery = false;
    this.deliveryserviceService.pushMenu(this.deliveryService.id, testOnBiscayneBakery).subscribe(() => {
      console.log(`Pushing menu on Real Restaurant for ${this.deliveryService.type}`);
    });
  }

  viewMenu() {
    this.router.navigate(['restaurant', this.restaurant.id, 'ds', this.deliveryService.id, 'menu']);
  }

  sendTestOrder() {
    this.deliveryserviceService.sendTestOrder(this.deliveryService.id).subscribe(() => {
      console.log(`Sent a TEST ORDER for restaurant ${this.restaurant.id} for ${this.deliveryService.type}`);
    });
  }

  addUpdateCredentials() {
    const dialogRef = this.dialog.open(DsCredentialsDialogComponent, {
      width: "600px",
      data : {
        ds: this.deliveryService
      }
    });
    dialogRef.componentInstance.event.subscribe(credential => {
      this.loaderService.show();

      if (credential.username && credential.password) {

        const callback = {
          next: res => {
            if (res && res.success === 'True') {
              this.messageService.openSnackBar("Your credentials has been added or updated!");
            }
          },
          error: err => console.error('Observer got an error: ' + err),
          complete: () => {
            this.loaderService.hide();
          },
        }

        if (this.isGrubhub) {
          this.deliveryserviceService.grubhubCredentials(this.restaurant.id, credential).subscribe(callback);
        } else if (this.isDoordash) {
          this.deliveryserviceService.doordashCredentials(this.restaurant.id, credential).subscribe(callback);
        }
        
      }
    });
  }

}
