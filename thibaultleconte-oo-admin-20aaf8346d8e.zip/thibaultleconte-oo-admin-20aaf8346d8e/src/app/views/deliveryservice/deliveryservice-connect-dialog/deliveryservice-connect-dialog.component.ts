import { Component, OnInit, EventEmitter, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { const_ds, DeliveryService } from '../../deliveryservice/deliveryservice';

@Component({
  selector: 'app-deliveryservice-connect-dialog',
  templateUrl: './deliveryservice-connect-dialog.component.html',
  styleUrls: ['./deliveryservice-connect-dialog.component.scss']
})
export class DeliveryserviceConnectDialogComponent implements OnInit {

  public dsConnectFormGroup: FormGroup;
  public ds: DeliveryService;
  public selectedDS;
  public event: EventEmitter<any> = new EventEmitter();
  public hide: boolean = true;
  public title: string = 'Add Delivery Service';
  public const_ds = const_ds;
  
  constructor(
    public dialogRef: MatDialogRef<DeliveryserviceConnectDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) {
    this.ds = data.ds;
    data.title ? this.title = data.title : '';
    const result = this.const_ds.DS_INFO_LIST.filter(dsInfo => {
      return dsInfo.name == this.ds.type;
    });
    this.selectedDS = result[0];
  }

  ngOnInit() {
    const nonWhitespaceRegExp: RegExp = new RegExp("\\S");
    this.dsConnectFormGroup = new FormGroup({
      restaurantId: new FormControl(this.ds.serviceLocationId, [Validators.pattern(nonWhitespaceRegExp)]),
      accountId: new FormControl(this.ds.service_account_id, [Validators.pattern(nonWhitespaceRegExp)]),
      restaurantUrl: new FormControl(this.ds.service_menu_url, [Validators.pattern(nonWhitespaceRegExp)])
      // username: new FormControl(this.ds.service_username, [Validators.pattern(nonWhitespaceRegExp)]),
      // password: new FormControl(this.ds.service_password, [Validators.pattern(nonWhitespaceRegExp)])
    });
  }

  get usernameInput() { 
    return this.dsConnectFormGroup.get('username'); 
  }

  get passwordInput() { 
    return this.dsConnectFormGroup.get('password'); 
  }

  onSubmit(value): void {
    this.ds.serviceLocationId = value.restaurantId;
    this.ds.service_account_id = value.accountId
    this.ds.service_menu_url = value.restaurantUrl;
    this.ds.service_username = value.username;
    this.ds.service_password = value.password === "******" ? '' : value.password;
    this.event.emit(this.ds);
    this.dialogRef.close();
  }

}
