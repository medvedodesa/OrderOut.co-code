import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';

import { DeliveryService } from '../../deliveryservice/deliveryservice';

import { LoaderService } from '../../../service/loader.service';
import { DeliveryserviceService } from '../../deliveryservice/deliveryservice.service';
import { DeliveryserviceConnectDialogComponent } from '../../deliveryservice/deliveryservice-connect-dialog/deliveryservice-connect-dialog.component';

import { const_ds } from '../../deliveryservice/deliveryservice';

@Injectable({
  providedIn: 'root'
})
export class DsConnectDgService {

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private loaderService: LoaderService,
    private deliveryserviceService: DeliveryserviceService,
  ) { }

  openConnectDSDialog(ds: DeliveryService, restaurantId: number, title?: string) {
    const dialogRef = this.dialog.open(DeliveryserviceConnectDialogComponent, {
      width: "600px",
      data: {
        'ds': ds,
        'title': title
      }
    });
    dialogRef.componentInstance.event.subscribe(deliveryService => {
      this.loaderService.show();
      const callback = {
        next: deliveryservice => {
          this.loaderService.hide();
          this.router.navigate(['restaurant', restaurantId, 'ds', deliveryservice.id]);
        }
      }
      if (deliveryService.type === const_ds.POSTMATES) {
        const params = {
          place_id: deliveryService.serviceLocationId,
          account_id: deliveryService.service_account_id
        }
        this.deliveryserviceService.connectToDeliveryService(restaurantId, 'postmates', params).subscribe(callback);
      } else {
        this.deliveryserviceService.updateDeliveryService(deliveryService).subscribe(callback);
      }

    });
  }
}
