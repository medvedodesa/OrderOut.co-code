import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryserviceConnectDialogComponent } from './deliveryservice-connect-dialog.component';

describe('DeliveryserviceConnectDialogComponent', () => {
  let component: DeliveryserviceConnectDialogComponent;
  let fixture: ComponentFixture<DeliveryserviceConnectDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliveryserviceConnectDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryserviceConnectDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
