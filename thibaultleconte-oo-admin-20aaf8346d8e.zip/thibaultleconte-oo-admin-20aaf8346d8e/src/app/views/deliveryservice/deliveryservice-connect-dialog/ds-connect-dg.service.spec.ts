import { TestBed } from '@angular/core/testing';

import { DsConnectDgService } from './ds-connect-dg.service';

describe('DsConnectDgService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DsConnectDgService = TestBed.get(DsConnectDgService);
    expect(service).toBeTruthy();
  });
});
