import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryserviceSettingsComponent } from './deliveryservice-settings.component';

describe('DeliveryserviceSettingsComponent', () => {
  let component: DeliveryserviceSettingsComponent;
  let fixture: ComponentFixture<DeliveryserviceSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliveryserviceSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryserviceSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
