import { Component, OnInit, Input } from '@angular/core';
import { Restaurant } from '../../restaurant/restaurant';
import { DeliveryService } from '../deliveryservice';
import { DeliveryserviceService } from '../deliveryservice.service';

@Component({
  selector: 'app-deliveryservice-settings',
  templateUrl: './deliveryservice-settings.component.html',
  styleUrls: ['./deliveryservice-settings.component.scss', '../../../app.component.scss']
})
export class DeliveryserviceSettingsComponent implements OnInit {

  @Input() restaurant: Restaurant;
  @Input() deliveryService: DeliveryService;

  constructor(private deliveryserviceService: DeliveryserviceService) { }

  ngOnInit() {
  }

  verifySettings() {
    this.deliveryserviceService.verifySettings(this.deliveryService.id).subscribe(deliveryService => {
      console.log(deliveryService);
      this.deliveryService = deliveryService;
    });
  }

}
