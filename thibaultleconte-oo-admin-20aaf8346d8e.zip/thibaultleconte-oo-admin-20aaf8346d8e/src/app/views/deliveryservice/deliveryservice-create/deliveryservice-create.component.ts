import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ISubscription } from 'rxjs/Subscription';
import { Router } from '@angular/router';

import { Account } from '../../account/account';
import { AccountRestaurant, Restaurant } from '../../restaurant/restaurant';
import { DeliveryService } from '../deliveryservice';

import { DeliveryserviceService } from '../deliveryservice.service';
import { LoaderService } from '../../../service/loader.service';
import { const_ds } from '../deliveryservice';


@Component({
  selector: 'app-deliveryservice-create',
  templateUrl: './deliveryservice-create.component.html',
  providers: [DeliveryserviceService],
  styleUrls: ['./deliveryservice-create.component.scss']
})
export class DeliveryserviceCreateComponent implements OnInit, OnDestroy {

  private subscription: ISubscription;

  public accountRestaurant: AccountRestaurant;
  public account: Account;
  public restaurant: Restaurant;
  public deliveryServiceList: any;
  public selected: any;
  public dsList: DeliveryService[];
  public hide: boolean = true;

  ds = {
    ubereats: { storeId: '' },
    grubhub: { restaurantUrl: '', username: '', password: '' },
    doordash: { restaurantUrl: '', username: '', password: '', pincode: '' },
    postmates: { placeId: '', accountId: '' },
    deliverycom: { username: '', password: '' },
    wix: { storeId: '' },
    chownow: { restaurantUrl: '' },
    caviar: { restaurantUrl: '' },
    slice: { restaurantUrl: '' }
  };

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private deliveryserviceService: DeliveryserviceService,
    private loaderService: LoaderService
  ) {
    const state = this.router.getCurrentNavigation().extras.state
    state && state.dsList ? this.dsList = state.dsList : '';
  }

  ngOnInit() {
    this.accountRestaurant = this.route.snapshot.data.accountRestaurant;
    this.account = this.accountRestaurant.account;
    this.restaurant = this.accountRestaurant.restaurant;

    if(!this.dsList) {
      this.loaderService.show();
      this.deliveryserviceService.getDeliveryServices(this.restaurant.id).subscribe(deliveryServices => {
        this.loaderService.hide();
        this.dsList = deliveryServices;
        this.hideConnectedDS();
      });
    } else {
      this.hideConnectedDS();
    }
  }

  ngOnDestroy() {
    if (!this.subscription) { return; }
    this.subscription.unsubscribe();
  }


  hideConnectedDS() {

    this.deliveryServiceList = [
      { value: 'ubereats', viewValue: 'UberEats', type: 'UBEREATS', enable: const_ds.ubereats.enable },
      { value: 'grubhub', viewValue: 'GrubHub', type: 'GRUBHUB', enable: const_ds.grubhub.enable },
      { value: 'doordash', viewValue: 'DoorDash', type: 'DOORDASH', enable: const_ds.doordash.enable },
      { value: 'postmates', viewValue: 'Postmates', type: 'POSTMATES', enable: const_ds.postmates.enable },
      { value: 'deliverycom', viewValue: 'Delivery.com', type: 'DELIVERYCOM', enable: const_ds.deliverycom.enable },
      { value: 'wix', viewValue: 'Wix', type: 'WIX', enable: const_ds.wix.enable },
      { value: 'chownow', viewValue: 'ChowNow', type: 'CHOWNOW', enable: const_ds.chownow.enable },
      { value: 'caviar', viewValue: 'Caviar', type: 'CAVIAR', enable: const_ds.caviar.enable },
      { value: 'slice', viewValue: 'Slice', type: 'SLICE', enable: const_ds.slice.enable }
    ];

    this.deliveryServiceList = this.deliveryServiceList.filter(function(obj) {
      return !this.has(obj.type) && obj.enable; // Filtered enable delivery services too
    }, new Set(this.dsList.map(obj => obj.type)));

  }

  onSubmit(type) {
    let params = {} as any;
    switch(type){
      case "ubereats":
        params.storeId = this.ds.ubereats.storeId;
        break;
      case "postmates":
        params.place_id = this.ds.postmates.placeId
        params.account_id = this.ds.postmates.accountId
        break;
      case "wix":
        params.storeId = this.ds.wix.storeId;
        break;
      case "grubhub":
        params.restaurantUrl = this.ds.grubhub.restaurantUrl;
        params.username = this.ds.grubhub.username;
        params.password = this.ds.grubhub.password;
        break;
      case "doordash":
        params.restaurantUrl = this.ds.doordash.restaurantUrl;
        params.username = this.ds.doordash.username;
        params.password = this.ds.doordash.password;
        params.pincode = this.ds.doordash.pincode;
        break;
      case "chownow":
        params.restaurantUrl = this.ds.chownow.restaurantUrl;
        break;
      default:
        type = '';
    }
    
    if (type !== '') {
      this.loaderService.show();
      this.deliveryserviceService.connectToDeliveryService(this.restaurant.id, type, params).subscribe(deliveryservice => {
        this.loaderService.hide();
        this.router.navigate(['restaurant', this.restaurant.id, 'ds', deliveryservice.id]);
      });
    }
  }

}
