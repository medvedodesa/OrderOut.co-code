import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryserviceCreateComponent } from './deliveryservice-create.component';

describe('DeliveryserviceCreateComponent', () => {
  let component: DeliveryserviceCreateComponent;
  let fixture: ComponentFixture<DeliveryserviceCreateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeliveryserviceCreateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeliveryserviceCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
