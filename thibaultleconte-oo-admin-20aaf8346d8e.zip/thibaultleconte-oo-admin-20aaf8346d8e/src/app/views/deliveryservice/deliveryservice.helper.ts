import { DeliveryserviceService } from './deliveryservice.service';
import { DeliveryService } from './deliveryservice';

export abstract class dsHelper {

    public ds = {
        'GRUBHUB': {},
        'DOORDASH': {}
    };

    public constructor(
        private dsService: DeliveryserviceService
    ) { }

    public testConnection(ds: DeliveryService) {
        this.ds[ds.type].loading = true;
        this.dsService.testConnection(ds.id).subscribe((res: any) => {
            if (res && res.status === false) {
                const message = res && res.message;
                this.ds[ds.type].credValid = false;
                this.ds[ds.type].msgTooltip = message;
            } else {
                this.ds[ds.type].credValid = true;
                this.ds[ds.type].msgTooltip = 'Valid Credentials';
            }
        }).add(() => {
            this.ds[ds.type].loading = false;
            this.ds[ds.type].isServerError = this.ds[ds.type].msgTooltip ? false : true;
        });
    }
}