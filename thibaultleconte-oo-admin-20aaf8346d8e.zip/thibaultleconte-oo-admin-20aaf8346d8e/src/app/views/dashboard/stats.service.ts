import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { environment } from 'src/environments/environment';
import { ApiService } from 'src/app/core/api.service';
import { Statistics } from './stats';

@Injectable({
  providedIn: 'root'
})
export class StatsService {

  statisticsUrl = environment.backend_url + 'stats/';

  constructor(private api: ApiService) {}

  getStatistics(): Observable<Statistics> {
    const url = `${this.statisticsUrl}`;
    return this.api.get(url);
  }
}
