export interface Statistics {
order_total: number;
order_last_30_days: number;
order_last_7_days: number;
order_yesterday: number;
order_today: number;
}