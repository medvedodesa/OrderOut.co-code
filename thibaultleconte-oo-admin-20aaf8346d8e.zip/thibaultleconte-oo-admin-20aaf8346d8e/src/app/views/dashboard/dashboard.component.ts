import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from "@angular/router";
import { ISubscription } from 'rxjs/Subscription';
import { BehaviorSubject } from 'rxjs';

import { AccountRestaurant } from '../restaurant/restaurant';
import { Statistics } from './stats';

import { StatsService } from './stats.service';
import { LoaderService } from '../../service/loader.service';
import { VisitedAccountService } from '../account/visited-account.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit, OnDestroy {

  public columnsToDisplay = ["accountName", "restaurantName"];
  public noRecord: boolean;
  public statistics: Statistics;
  public recentAccountList: AccountRestaurant[];
  private subscription: ISubscription;

  private loadingSubject = new BehaviorSubject<boolean>(false);
  public loading$ = this.loadingSubject.asObservable();

  constructor(
    private router: Router,
    private statisticsService: StatsService,
    private loaderService: LoaderService,
    private vaService: VisitedAccountService
  ) { }

  ngOnInit() {
    //this.getStatistics();
    this.getRecentAccountList();
  }

  ngOnDestroy() {
    if (!this.subscription) { return; }
    console.log(this.subscription);
    this.subscription.unsubscribe();
  }

  private getStatistics() {
    this.loadingSubject.next(true);
    this.subscription = this.statisticsService.getStatistics().subscribe(statistics => {
      this.statistics = statistics;
    }).add(() => {
      this.loadingSubject.next(false);
    });
  }

  private getRecentAccountList() {
    this.recentAccountList = this.vaService.getLSVisitedAccountList();
    this.noRecord = this.recentAccountList.length === 0 ? true : false;
  }

  public navAccount(oAccountRestaurant: AccountRestaurant) {
    this.router.navigate(["account", oAccountRestaurant.account.id]);
  }

  public navRestaurant(oAccountRestaurant: AccountRestaurant) {
    this.router.navigate(['restaurant', oAccountRestaurant.restaurant.id]);
  }
}
