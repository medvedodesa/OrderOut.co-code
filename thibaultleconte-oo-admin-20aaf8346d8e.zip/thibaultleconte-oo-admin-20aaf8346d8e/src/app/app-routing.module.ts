import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuardService as AuthGuard } from './service/auth-guard.service';
import { NegateAuthGuardService as NegateAuthGuard } from './service/negate-auth-guard.service';

import { WelcomeComponent } from './views/welcome/welcome.component';
import { DashboardComponent } from './views/dashboard/dashboard.component';
import { AccountListComponent } from './views/account/account-list/account-list.component';
import { AccountComponent } from './views/account/account/account.component';
import { RestaurantComponent } from './views/restaurant/restaurant/restaurant.component';
import { DeliveryserviceCreateComponent } from './views/deliveryservice/deliveryservice-create/deliveryservice-create.component';
import { MenuComponent } from './views/menu/menu/menu.component';
import { MenuCategoryPageComponent } from './views/menu/menu-category-page/menu-category-page.component';
import { MenuModifierPageComponent } from './views/menu/menu-modifier-page/menu-modifier-page.component';
import { MenuCategoryResolve } from './views/menu/menu-category-page/menu-category.resolve';
import { MenuModifierResolve } from './views/menu/menu-modifier-page/menu-modifier-resolve';
import { MenuResolve } from './views/menu/menu.resolve';
import { MenuSyncComponent } from './views/menu/menu-sync/menu-sync.component';
import { AccountResolve } from './views/account/account.resolve';
import { AccountRestaurantResolve } from './views/restaurant/accountRestaurant.resolve';
import { DeliveryServiceResolve } from './views/deliveryservice/deliveryservice.resolve';
import { OrderListComponent } from './views/order/order-list/order-list.component';
import { OrderComponent } from './views/order/order/order.component';
import { OrderResolve } from './views/order/order.resolve';
import { PointofsaleCreateComponent } from './views/pointofsale/pointofsale-create/pointofsale-create.component';
import { PrinterCreateComponent } from './views/printer/printer-create/printer-create.component';
import { PrinterResolve } from './views/printer/printerResolve';
import { DeliveryserviceComponent } from './views/deliveryservice/deliveryservice/deliveryservice.component';
import { PointofsaleComponent } from './views/pointofsale/pointofsale/pointofsale.component';
import { LeadsComponent } from './views/pointofsale/clover/leads/leads.component';
import { DetailsComponent } from './views/pointofsale/clover/leads/details/details.component';
import { PointOfSaleResolve } from './views/pointofsale/pointofsale.resolve';
import { PrinterComponent } from './views/printer/printer/printer.component';
import { PrinterJobsAllComponent } from './views/printer/printer-jobs-all/printer-jobs-all.component';
import { PrinterJobsDetailsComponent } from './views/printer/printer-jobs-details/printer-jobs-details.component';
import { PrintJobResolve } from './views/printer/printJobResolve';
import { PrinterStatsComponent } from './views/printer/printer-stats/printer-stats.component';
import { SetupComponent } from './views/setup/setup/setup.component';
import { ComingsoonComponent } from './views/dashboard/comingsoon/comingsoon.component';
import { Auth0CallbackComponent } from './views/auth0-callback/auth0-callback.component';
import { CloverCallbackComponent } from './views/pointofsale/clover-callback/clover-callback.component';
import { NotFoundComponent } from './error/not-found/not-found.component';
import { UnauthorizedComponent } from './error/unauthorized/unauthorized.component';
import { OnboardComponent } from './views/onboard/onboard/onboard.component';
import { OnboardStatsComponent } from './views/onboard/onboard-stats/onboard-stats.component';
import { CoreEventsPageComponent } from './views/events/core-events-page/core-events-page.component';
import { RequestsPageComponent } from './views/requests/requests-page/requests-page.component';

const routes: Routes = [

  // OrderOut - Not Logged In
  ///////////////////////////
  { path: '', component: WelcomeComponent,
    canActivate: [NegateAuthGuard]
  },

  // Auth0
  { path: 'callback/auth', component: Auth0CallbackComponent },

  {path: 'unauthorized', component: UnauthorizedComponent},

  // Clover
  { path: 'callback/clover', component: CloverCallbackComponent },

  { 
    path: 'restaurant/:restaurantId/onboarding',
    component: OnboardComponent,
  },

  // OrderOut - Logged In
  ///////////////////////

  {
    path: 'dashboard', component: DashboardComponent,
    canActivate: [AuthGuard]
  },

  {
    path: 'comingsoon', component: ComingsoonComponent,
    canActivate: [AuthGuard]
  },

  {
    path: 'setup', component: SetupComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'leads', component: LeadsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'lead/:leadId', component: DetailsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'onboarding', component: OnboardStatsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'printing', component: PrinterStatsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'events/:name/:id', component: CoreEventsPageComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'requests/:name/:id', component: RequestsPageComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'accounts', component: AccountListComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'account/:accountId', component: AccountComponent,
    resolve: { account: AccountResolve },
    canActivate: [AuthGuard]
  },

  {
    path: 'orders', component: OrderListComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'order/:orderId', component: OrderComponent,
    resolve: { order: OrderResolve },
    canActivate: [AuthGuard]
  },

  {
    path: 'restaurant/:restaurantId', component: RestaurantComponent,
    resolve: { accountRestaurant: AccountRestaurantResolve },
    canActivate: [AuthGuard]
  },
  {
    path: 'restaurant/:restaurantId/pos', component: PointofsaleCreateComponent,
    resolve: { accountRestaurant: AccountRestaurantResolve },
    canActivate: [AuthGuard]
  },
  {
    path: 'restaurant/:restaurantId/pos/:pointofsaleId', component: PointofsaleComponent,
    resolve: {
      accountRestaurant: AccountRestaurantResolve,
      pointofsale: PointOfSaleResolve
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'restaurant/:restaurantId/ds', component: DeliveryserviceCreateComponent,
    resolve: { accountRestaurant: AccountRestaurantResolve },
    canActivate: [AuthGuard]
  },
  {
    path: 'restaurant/:restaurantId/ds/:deliveryServiceId', component: DeliveryserviceComponent,
    resolve: {
      accountRestaurant: AccountRestaurantResolve,
      deliveryService: DeliveryServiceResolve
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'restaurant/:restaurantId/ds/:deliveryServiceId/menu', component: MenuSyncComponent,
    resolve: {
      accountRestaurant: AccountRestaurantResolve,
      deliveryService: DeliveryServiceResolve
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'restaurant/:restaurantId/menu/:menuId', component: MenuComponent,
    resolve: { 
      accountRestaurant: AccountRestaurantResolve,
      menu: MenuResolve
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'restaurant/:restaurantId/menu/:menuId/edit', component: MenuComponent,
    resolve: { 
      accountRestaurant: AccountRestaurantResolve,
      menu: MenuResolve,
    },
    data: {
      edit: true
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'restaurant/:restaurantId/menu/:menuId/category/:categoryId', component: MenuCategoryPageComponent,
    resolve: { 
      accountRestaurant: AccountRestaurantResolve,
      menu: MenuResolve,
      categoryId: MenuCategoryResolve
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'restaurant/:restaurantId/menu/:menuId/category/:categoryId/edit', component: MenuCategoryPageComponent,
    resolve: { 
      accountRestaurant: AccountRestaurantResolve,
      menu: MenuResolve,
      categoryId: MenuCategoryResolve
    },
    data: {
      edit: true
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'restaurant/:restaurantId/menu/:menuId/category/:categoryId/item/:itemId', component: MenuModifierPageComponent,
    resolve: { 
      accountRestaurant: AccountRestaurantResolve,
      menu: MenuResolve,
      categoryId: MenuCategoryResolve,
      itemId: MenuModifierResolve
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'restaurant/:restaurantId/menu/:menuId/category/:categoryId/item/:itemId/edit', component: MenuModifierPageComponent,
    resolve: { 
      accountRestaurant: AccountRestaurantResolve,
      menu: MenuResolve,
      categoryId: MenuCategoryResolve,
      itemId: MenuModifierResolve
    },
    data: {
      edit: true
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'restaurant/:restaurantId/printer', component: PrinterCreateComponent,
    resolve: { 
      accountRestaurant: AccountRestaurantResolve
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'restaurant/:restaurantId/printer/:printerId', component: PrinterComponent,
    resolve: {
      accountRestaurant: AccountRestaurantResolve,
      printer: PrinterResolve
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'restaurant/:restaurantId/printer/:printerId/jobs', component: PrinterJobsAllComponent,
    resolve: {
      accountRestaurant: AccountRestaurantResolve,
      printer: PrinterResolve
    },
    canActivate: [AuthGuard]
  },
  {
    path: 'restaurant/:restaurantId/printjob/:printJobId', component: PrinterJobsDetailsComponent,
    resolve: {
      accountRestaurant: AccountRestaurantResolve,
      printJob: PrintJobResolve 
    },
    canActivate: [AuthGuard]
  },
  {
    path: '**',
    component: NotFoundComponent
  }
];

@NgModule({
  // imports: [RouterModule.forRoot(routes, { enableTracing: true })],
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [AuthGuard, NegateAuthGuard]
})
export class AppRoutingModule { }
