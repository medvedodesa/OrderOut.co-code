import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-error-dialog',
  templateUrl: './error-dialog.component.html',
  styleUrls: ['./error-dialog.component.scss']
})
export class ErrorDialogComponent implements OnInit {

  public showMessageOnly: boolean = false;

  constructor(
    public dialogRef: MatDialogRef<ErrorDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
  ) { }

  ngOnInit() {
    let matchUrl = this.data.url.substring(this.data.url.indexOf('/api') + 5);
    switch(matchUrl) {
      case 'printer/pairing':
        this.showMessageOnly = this.data.status === 410 ? true : false;
        break;
      default:
        // code block
    }

  }

}
