import { ErrorHandler, Injectable, Injector } from '@angular/core';
import { MessageService } from '../service/messages/message.service';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {

  constructor( private messageService: MessageService ) { }

  handleError(error: any ) {
    console.log(error);
    let message = this.messageService.getClientMessage(error);
    this.messageService.showError(message);
  }
}
