import { Injectable } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { Observable, EMPTY } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { MatDialog } from "@angular/material";

import { ErrorDialogComponent } from './error-dialog/error-dialog.component';
import { LoaderService } from '../service/loader.service';

@Injectable()
export class HttpErrorInterceptor implements HttpInterceptor {

  constructor(
    private dialog: MatDialog,
    private loaderService: LoaderService
  ) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request)
      .pipe(
        retry(1),
        catchError((error: HttpErrorResponse) => {
          let errorMessage = '';
          if (error.error instanceof ErrorEvent) {
            // client-side error
            errorMessage = `Error: ${error.error.message}`;
          } else {
            // server-side error
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
          }
          this.openErrorDialog(error);
          return EMPTY;
        })
      )
  }

  openErrorDialog(error: HttpErrorResponse) {
    this.dialog.open(ErrorDialogComponent, {
      data: error
    });
    this.loaderService.hide();
  }
}