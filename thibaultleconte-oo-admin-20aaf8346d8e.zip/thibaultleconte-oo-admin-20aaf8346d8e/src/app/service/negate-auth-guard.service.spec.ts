import { TestBed } from '@angular/core/testing';

import { NegateAuthGuardService } from './negate-auth-guard.service';

describe('NegateAuthGuardService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: NegateAuthGuardService = TestBed.get(NegateAuthGuardService);
    expect(service).toBeTruthy();
  });
});
