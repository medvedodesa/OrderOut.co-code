import { Injectable } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, NavigationError, NavigationCancel } from '@angular/router';
import { LoaderService } from './loader.service';

@Injectable({
  providedIn: 'root'
})
export class NavService {

  constructor(private router: Router, private loaderService: LoaderService) { }

  init() {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        this.loaderService.show();
      }
      if ((event instanceof NavigationEnd) || (event instanceof NavigationError) || (event instanceof NavigationCancel)) {
        this.scrollUp();
        this.loaderService.hide();
      }
    })
  }

  scrollUp() {
    const element = document.querySelector('#top-nav');
    element.scrollIntoView({ behavior: 'smooth'});
  }
  
}
