import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class NegateAuthGuardService implements CanActivate {

  constructor(public auth: AuthService, public router: Router) { }

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    return this.auth.isAuthenticated$.pipe(
      map(loggedIn => {
        if (loggedIn) {
          console.log('[NegateAuthGuard] - Logged In -> Redirect to "dashboard"');
          this.router.navigate(['dashboard']);
          return false;
        }
        return true;
      })
    );
  }
}
