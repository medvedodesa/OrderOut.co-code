import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { MatSnackBarRef, MAT_SNACK_BAR_DATA } from '@angular/material/snack-bar';

@Component({
  selector: 'app-messages',
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.scss']
})
export class MessagesComponent implements OnInit {

  @ViewChild('snackbar') snackbar: ElementRef;

  constructor(
    public snackBarRef: MatSnackBarRef<MessagesComponent>,
    @Inject(MAT_SNACK_BAR_DATA) public data: any
  ) { }

  ngOnInit() {
    console.log(this.data);
  }

  dismiss() {
    this.snackBarRef.dismiss();

    // In case dismiss not work: When JS (Client Side) Error occur, snackBar does not dismiss.
    let cdkOverLay = this.snackbar.nativeElement.closest(".cdk-overlay-container");
    if(cdkOverLay) {
      cdkOverLay.innerHTML = '';
    }
  }

}