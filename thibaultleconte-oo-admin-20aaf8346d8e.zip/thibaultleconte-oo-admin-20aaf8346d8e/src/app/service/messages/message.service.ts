import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material';

import { MessagesComponent } from './messages.component';

@Injectable()
export class MessageService {
  messages: string[] = [];
  public snackBarRef;

  constructor(private snackBar: MatSnackBar){}

  openSnackBar(message: string, options?: {}){
    options = Object.assign({},{
      horizontalPosition: "center",
      verticalPosition: 'top',
      panelClass: 'success',
      duration: 5000,
      data: {
        message: message
      }
    }, options);
    this.snackBarRef = this.snackBar.openFromComponent(MessagesComponent, options);
  }

  showError(message: string) {
    if(!this.snackBarRef) {
      this.openSnackBar(message, {panelClass: 'error'});
    }
  }

  getClientMessage(error: Error): string {
    if (!navigator.onLine) {
        return 'No Internet Connection';
    }
    return error.message ? error.message : error.toString();
  }

}
