import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoaderService {

  constructor() { }

  show() {
    const body = document.querySelector('body');
    body.classList.add('show-spinner');
  }

  hide() {
    const body = document.querySelector('body');
    body.classList.remove('show-spinner');
  }
}
