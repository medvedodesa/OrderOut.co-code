import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  constructor() { }

  /** CSV Export **/
  downloadFile(data, headerList, filename = 'data') {
    let csvData = this.ConvertToCSV(data, headerList);
    let blob = new Blob(['\ufeff' + csvData], { type: 'text/csv;charset=utf-8;' });
    let dwldLink = document.createElement("a");
    let url = URL.createObjectURL(blob);
    let isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1;
    if (isSafariBrowser) {  //if Safari open in new window to save file with random filename.
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", filename + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
  }

  ConvertToCSV(objArray, headerList) {
    let titleList = headerList[0];
    let headList = headerList[1];
    let array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
    let str = '';
    let row = '';
    let noData = '';

    for (let index in titleList) {
      let title = this.ucFirstAllWords(titleList[index], '_');
      row += title + ',';
      noData += ' ,';
    }
    row = row.slice(0, -1);
    noData = noData.slice(0, -1);
    str += row + '\r\n';

    if (array.length !== 0) {
      for (let i = 0; i < array.length; i++) {
        let line = '';
        for (let index in headList) {
          let head = headList[index];
          line += '"' + this.sanitizeString(array[i][head]) + '"' + ',';
        }
        line = line.slice(0, -1);
        str += line + '\r\n';
      }
    } else {
      str += noData + '\r\n';
    }
    return str;
  }

  ucFirstAllWords(str: string, delimiter: string = ' ') {
    var pieces = str.split(delimiter);
    for (var i = 0; i < pieces.length; i++) {
      var j = pieces[i].charAt(0).toUpperCase();
      pieces[i] = j + pieces[i].substr(1);
    }
    return pieces.join(" ");
  }

  sanitizeString(str: string) {
    if (str) {
      if (typeof str === 'string') {
        str = str.replace(/(\r\n|\n|\r|\s+|\t|&nbsp;)/gm, ' ');
        str = str.replace(/"/g, '""');
        str = str.replace(/ +(?= )/g, '');
      }
    } else {
      str = '';
    }
    return str;
  }

  ConvertToSnakeCaseString(str: string, delimiter = [' ', ',', '.']) {
    if (!str) return;
    str = str.trim();
    if (str && str.length > 0) {
      str = str.length > 15 ? str.substring(0, 15) : str;
      let replace = '[' + delimiter.join("") + ']+';
      let re = new RegExp(replace, "g");
      str = str.replace(re, '_');
      return str;
    }
    return str;
  }

  formatDate(date: Date = new Date()) {
    let d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

    if (month.length < 2)
      month = '0' + month;
    if (day.length < 2)
      day = '0' + day;

    return [year, month, day].join('_');
  }

  copyText(val: string) {
    let selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = val;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
  }

  openExternalURL(url: string) {
    let re = new RegExp("^(http|https)://", "i");
    if (!re.test(url)) {
      url = "http://" + url;
    }
    window.open(url, '_blank');
  }

}
