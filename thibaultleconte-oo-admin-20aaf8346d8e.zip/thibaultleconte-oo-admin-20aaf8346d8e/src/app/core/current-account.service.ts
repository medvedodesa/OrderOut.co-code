import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

import { Account } from '../views/account/account';
const LOCAL_STORAGE_KEY_CURRENT_ACCOUNT = 'current_account';

@Injectable({
  providedIn: 'root'
})
export class CurrentAccountService {

  private currentAccount: Account;
  private _currentAccount: Subject<any> = new Subject<any>();
  public currentAccountObs = this._currentAccount.asObservable();

  constructor() { 
    this.currentAccount = this.getLSAccount();
  }

  setCurrentAccount(account: Account) {
    this.currentAccount = account;
    localStorage.setItem(LOCAL_STORAGE_KEY_CURRENT_ACCOUNT,  JSON.stringify(account));
    this._currentAccount.next(account);
  }

  getCurrentAccount() {
    return this.currentAccount;
  }

  getLSAccount() {
    let account = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY_CURRENT_ACCOUNT));
    /**
     * TODO
     * Check whether account is exist or not through server call
     */
    return ((account && account.name && account.id) ? account : {});
  }
}
