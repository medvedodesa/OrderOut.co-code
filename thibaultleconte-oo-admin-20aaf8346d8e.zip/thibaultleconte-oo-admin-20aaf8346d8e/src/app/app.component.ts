import { Component, OnInit, ChangeDetectorRef, ViewEncapsulation } from '@angular/core';
import { AuthService } from './service/auth.service';
import { CurrentAccountService } from './core/current-account.service';
import { Account } from './views/account/account';

import { NavService } from './service/nav.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnInit {

  currentAccount: Account;
  title = 'OrderOut Admin';

  constructor(
    public auth: AuthService,
    private _caService: CurrentAccountService,
    private ref: ChangeDetectorRef,
    private navService: NavService
  ) {
    // auth.handleAuthentication();
    // auth.scheduleRenewal();

    this._caService.currentAccountObs.subscribe((account) => {
      this.currentAccount = account;
      this.ref.detectChanges();
    });

    this.navService.init();
  }

  ngOnInit() {
    // if (this.auth.isAuthenticated()) {
    //   console.log('ap.component.ts - ngOnInit - isAuthenticated');
    //   this.auth.renewToken();
    // } else {
    //   console.log('ap.component.ts - ngOnInit - NOT isAuthenticated');
    // }
    
    this.currentAccount = this._caService.getCurrentAccount();
  }

}
