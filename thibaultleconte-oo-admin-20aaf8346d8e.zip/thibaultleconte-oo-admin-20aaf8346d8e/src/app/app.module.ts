import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { IntercomModule } from 'ng-intercom';
import { NgxJsonViewerModule } from 'ngx-json-viewer';
import { environment } from '../environments/environment';

import { MaterialModule } from './material.module';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { ApiService } from './core/api.service';

import { GlobalErrorHandler } from './error/basic-error-handler';
import { HttpErrorInterceptor } from './error/http-error.interceptor';
import { AuthInterceptorService } from './service/auth-interceptor.service';

import { MessageService } from './service/messages/message.service';
import { MessagesComponent } from './service/messages/messages.component';
import { ErrorDialogComponent } from './error/error-dialog/error-dialog.component';
import { NotFoundComponent } from './error/not-found/not-found.component';
import { UnauthorizedComponent } from './error/unauthorized/unauthorized.component';

import { DashboardComponent } from './views/dashboard/dashboard.component';
import { WelcomeComponent } from './views/welcome/welcome.component';

import { ConfirmationDialogComponent } from './views/common/confirmation-dialog/confirmation-dialog.component';
import { ConfirmationDialogService } from './views/common/confirmation-dialog/confirmation-dialog.service';
import { DataFilterComponent } from './views/common/data-filter/data-filter.component';
import { MenusyncComponent } from './views/common/menusync/menusync.component';
import { InlineEditComponent } from './views/common/inline-edit/inline-edit.component';
import { BreadcrumbComponent } from './views/common/breadcrumb/breadcrumb.component';
import { BreadcrumbService } from './views/common/breadcrumb/breadcrumb.service';
import { CoreEventsPageComponent } from './views/events/core-events-page/core-events-page.component';
import { CoreEventsComponent } from './views/events/core-events/core-events.component';
import { CoreEventsTableComponent } from './views/events/core-events-table/core-events-table.component';
import { CoreEventsService } from './views/events/core-events.service';
import { RequestsPageComponent } from './views/requests/requests-page/requests-page.component';
import { RequestsComponent } from './views/requests/requests/requests.component';
import { RequestsTableComponent } from './views/requests/requests-table/requests-table.component';
import { RequestsService } from './views/requests/requests.service';
import { MessageDgComponent } from './views/common/message-dg/message-dg.component';
import { MessageDgService } from './views/common/message-dg/message-dg.service';

import { AuthService } from './service/auth.service';
import { AppService } from './service/app.service';

import { AccountService } from './views/account/account.service';
import { AccountResolve } from './views/account/account.resolve';

import { RestaurantService } from './views/restaurant/restaurant.service';
import { RestaurantHelper } from './views/restaurant/restaurant.helper';
import { RestaurantResolve } from './views/restaurant/restaurant.resolve';
import { AccountRestaurantResolve } from './views/restaurant/accountRestaurant.resolve';

import { DeliveryserviceService } from './views/deliveryservice/deliveryservice.service';
import { DeliveryServiceResolve } from './views/deliveryservice/deliveryservice.resolve';

import { AccountDialogComponent } from './views/account/account-dialog/account-dialog.component';
import { RestaurantDialogComponent } from './views/restaurant/restaurant-dialog/restaurant-dialog.component';
import { AccountListComponent } from './views/account/account-list/account-list.component';
import { AccountComponent } from './views/account/account/account.component';
import { AccountDetailsComponent } from './views/account/account-details/account-details.component';
import { RestaurantListComponent } from './views/restaurant/restaurant-list/restaurant-list.component';
import { RestaurantOnboardingComponent } from './views/restaurant/restaurant-onboarding/restaurant-onboarding.component';
import { RestaurantDetailsComponent } from './views/restaurant/restaurant-details/restaurant-details.component';
import { RestaurantMerchantComponent } from './views/restaurant/restaurant-merchant/restaurant-merchant.component';
import { RestaurantContactsComponent } from './views/restaurant/restaurant-contacts/restaurant-contacts.component';
import { RestaurantUsersComponent } from './views/restaurant/restaurant-users/restaurant-users.component';
import { RestaurantContactDgComponent } from './views/restaurant/restaurant-contact-dg/restaurant-contact-dg.component';
import { RestaurantUsersDgComponent } from './views/restaurant/restaurant-users-dg/restaurant-users-dg.component';
import { RestaurantProcessDgComponent } from './views/restaurant/restaurant-process-dg/restaurant-process-dg.component';
import { DeliveryserviceListComponent } from './views/deliveryservice/deliveryservice-list/deliveryservice-list.component';
import { DeliveryserviceCreateComponent } from './views/deliveryservice/deliveryservice-create/deliveryservice-create.component';
import { RestaurantComponent } from './views/restaurant/restaurant/restaurant.component';
import { MenuComponent } from './views/menu/menu/menu.component';
import { MenuService } from './views/menu/menu.service';
import { MenuHelperService } from './views/menu/menu-helper.service';
import { MenuResolve } from './views/menu/menu.resolve';
import { MenuCategoryResolve } from './views/menu/menu-category-page/menu-category.resolve';
import { MenuModifierResolve } from './views/menu/menu-modifier-page/menu-modifier-resolve';
import { MenuDialogComponent } from './views/menu/menu-dialog/menu-dialog.component'
import { MenuDetailsComponent } from './views/menu/menu/menu-details/menu-details.component';
import { MenuSectionComponent } from './views/menu/menu/menu-section/menu-section.component';
import { MenuSectionAvailabilityDialogComponent } from './views/menu/menu/menu-section/menu-section-availability-dialog/menu-section-availability-dialog.component';
import { MenuCategoryComponent } from './views/menu/menu/menu-section/menu-category/menu-category.component';
import { MenuAdminComponent } from './views/menu/menu/menu-admin/menu-admin.component';
import { MenuCategoryPageComponent } from './views/menu/menu-category-page/menu-category-page.component';
import { MenuCategoryPageDetailsComponent } from './views/menu/menu-category-page/menu-category-page-details/menu-category-page-details.component';
import { MenuCategoryPageMenuComponent } from './views/menu/menu-category-page/menu-category-page-menu/menu-category-page-menu.component';
import { MenuModifierPageComponent } from './views/menu/menu-modifier-page/menu-modifier-page.component';
import { MenuModifierPageDetailsComponent } from './views/menu/menu-modifier-page/menu-modifier-page-details/menu-modifier-page-details.component';
import { MenuModifierPageModifierGroupComponent } from './views/menu/menu-modifier-page/menu-modifier-page-modifier-group/menu-modifier-page-modifier-group.component';
import { MenuModifierPageModifierComponent } from './views/menu/menu-modifier-page/menu-modifier-page-modifier/menu-modifier-page-modifier.component';
import { MenuSummaryComponent } from './views/menu/menu-summary/menu-summary.component';
import { MenuSyncComponent } from './views/menu/menu-sync/menu-sync.component';
import { RestaurantAdminComponent } from './views/restaurant/restaurant-admin/restaurant-admin.component';
import { AccountAdminComponent } from './views/account/account-admin/account-admin.component';
import { MenuSyncModifierComponent } from './views/menu/menu-sync-modifier/menu-sync-modifier.component';
import { MenuMapDialogComponent } from './views/menu/menu-map-dialog/menu-map-dialog.component';
import { OrderListComponent } from './views/order/order-list/order-list.component';
import { OrderComponent } from './views/order/order/order.component';
import { OrderService } from './views/order/order.service';
import { OrderResolve } from './views/order/order.resolve';
import { OrderDetailsComponent } from './views/order/order-details/order-details.component';
import { OrderInfoComponent } from './views/order/order-info/order-info.component';

import { PrinterCreateComponent } from './views/printer/printer-create/printer-create.component';
import { PrinterListComponent } from './views/printer/printer-list/printer-list.component';
import { StarmicronicsAddComponent } from './views/printer/starmicronics-add/starmicronics-add.component';
import { PrinterDetailsComponent } from './views/printer/printer-details/printer-details.component';
import { PrinterService } from './views/printer/printer.service';
import { PrinterResolve } from './views/printer/printerResolve';
import { PrinterAdminComponent } from './views/printer/printer-admin/printer-admin.component';
import { DeliveryserviceComponent } from './views/deliveryservice/deliveryservice/deliveryservice.component';
import { DeliveryserviceDetailsComponent } from './views/deliveryservice/deliveryservice-details/deliveryservice-details.component';
import { DeliveryserviceMenusyncComponent } from './views/deliveryservice/deliveryservice-menusync/deliveryservice-menusync.component';
import { DeliveryserviceAdminComponent } from './views/deliveryservice/deliveryservice-admin/deliveryservice-admin.component';
import { DeliveryservicePosIntegrationComponent } from './views/deliveryservice/deliveryservice-pos-integration/deliveryservice-pos-integration.component';
import { OrderItemsComponent } from './views/order/order-items/order-items.component';
import { PointofsaleComponent } from './views/pointofsale/pointofsale/pointofsale.component';
import { PointofsaleService } from './views/pointofsale/pointofsale.service';
import { PointOfSaleResolve } from './views/pointofsale/pointofsale.resolve';
import { PointofsaleDetailsComponent } from './views/pointofsale/pointofsale-details/pointofsale-details.component';
import { PointofsaleSettingsComponent } from './views/pointofsale/pointofsale-settings/pointofsale-settings.component';
import { PointofsaleAdminComponent } from './views/pointofsale/pointofsale-admin/pointofsale-admin.component';
import { PointofsaleMenusyncComponent } from './views/pointofsale/pointofsale-menusync/pointofsale-menusync.component';
import { CloverLinkingDialogComponent } from './views/pointofsale/clover/clover-linking-dialog/clover-linking-dialog.component';
import { LeadsComponent } from './views/pointofsale/clover/leads/leads.component';
import { DetailsComponent } from './views/pointofsale/clover/leads/details/details.component';
import { CloverCallbackComponent } from './views/pointofsale/clover-callback/clover-callback.component';
import { PointofsaleListComponent } from './views/pointofsale/pointofsale-list/pointofsale-list.component';
import { PointofsaleCreateComponent } from './views/pointofsale/pointofsale-create/pointofsale-create.component';
import { PosConnectDgComponent } from './views/pointofsale/pos-connect-dg/pos-connect-dg.component';

import { PrinterComponent } from './views/printer/printer/printer.component';
import { PrinterJobsRecentComponent } from './views/printer/printer-jobs-recent/printer-jobs-recent.component';
import { PrinterJobsAllComponent } from './views/printer/printer-jobs-all/printer-jobs-all.component';
import { PrinterJobsDetailsComponent } from './views/printer/printer-jobs-details/printer-jobs-details.component';
import { PrinterStatsComponent } from './views/printer/printer-stats/printer-stats.component';
import { PrintJobResolve } from './views/printer/printJobResolve';
import { DeliveryserviceSettingsComponent } from './views/deliveryservice/deliveryservice-settings/deliveryservice-settings.component';
import { PrinterSettingsComponent } from './views/printer/printer-settings/printer-settings.component';
import { SetupComponent } from './views/setup/setup/setup.component';
import { ComingsoonComponent } from './views/dashboard/comingsoon/comingsoon.component';
import { Auth0CallbackComponent } from './views/auth0-callback/auth0-callback.component';
import { OnboardDsDialogComponent } from './views/onboard/onboard-ds-dialog/onboard-ds-dialog.component';
import { OnboardMenuListDgComponent } from './views/onboard/onboard-menu-list-dg/onboard-menu-list-dg.component';
import { OnboardDsSuccessDgComponent } from './views/onboard/onboard-ds-success-dg/onboard-ds-success-dg.component';
import { OnboardUbereatsStoresDgComponent } from './views/onboard/onboard-ubereats-stores-dg/onboard-ubereats-stores-dg.component';
import { OnboardComponent } from './views/onboard/onboard/onboard.component';
import { OnboardStatsComponent } from './views/onboard/onboard-stats/onboard-stats.component';
import { OnboardService } from './views/onboard/onboard.service';
import { DsCredentialsDialogComponent } from './views/deliveryservice/deliveryservice-menusync/ds-credentials-dialog/ds-credentials-dialog.component';
import { DeliveryserviceConnectDialogComponent } from './views/deliveryservice/deliveryservice-connect-dialog/deliveryservice-connect-dialog.component';
import { DeliveryserviceDisconnectDgComponent } from './views/deliveryservice/deliveryservice-disconnect-dg/deliveryservice-disconnect-dg.component';
import { DeliveryserviceEnableDgComponent } from './views/deliveryservice/deliveryservice-enable-dg/deliveryservice-enable-dg.component';

// Pipes
import { SortByPipe } from './pipes/sort-by.pipe';
import { UTCFormatPipe } from './pipes/utcformat.pipe';
import { Time24to12Pipe } from './pipes/time24to12.pipe';
import { HoursPipe } from './pipes/hours.pipe';
import { MinutesPipe } from './pipes/minutes.pipe';
import { PeriodPipe } from './pipes/period.pipe';
import { NextDayPipe } from './pipes/next-day.pipe';

// Directives
import { MatRowKeyEventsDirective } from './directive/mat-row-key-events.directive';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    WelcomeComponent,
    MessagesComponent,
    ErrorDialogComponent,
    MessageDgComponent,
    NotFoundComponent,
    UnauthorizedComponent,
    MenusyncComponent,
    InlineEditComponent,
    BreadcrumbComponent,
    CoreEventsPageComponent,
    CoreEventsComponent,
    CoreEventsTableComponent,
    RequestsPageComponent,
    RequestsComponent,
    RequestsTableComponent,
    AccountDialogComponent,
    RestaurantDialogComponent,
    AccountComponent,
    AccountListComponent,
    AccountDetailsComponent,
    RestaurantListComponent,
    RestaurantOnboardingComponent,
    RestaurantDetailsComponent,
    RestaurantMerchantComponent,
    RestaurantContactsComponent,
    RestaurantUsersComponent,
    RestaurantContactDgComponent,
    RestaurantUsersDgComponent,
    RestaurantProcessDgComponent,
    DeliveryserviceListComponent,
    DeliveryserviceCreateComponent,
    RestaurantComponent,
    MenuComponent,
    MenuSummaryComponent,
    ConfirmationDialogComponent,
    MenuDialogComponent,
    MenuDetailsComponent,
    MenuSectionComponent,
    MenuSectionAvailabilityDialogComponent,
    MenuCategoryComponent,
    MenuCategoryPageComponent,
    MenuCategoryPageDetailsComponent,
    MenuCategoryPageMenuComponent,
    MenuModifierPageComponent,
    MenuModifierPageDetailsComponent,
    MenuModifierPageModifierGroupComponent,
    MenuModifierPageModifierComponent,
    MenuSyncComponent,
    MenuAdminComponent,
    RestaurantAdminComponent,
    AccountAdminComponent,
    MenuSyncModifierComponent,
    MenuMapDialogComponent,
    OrderListComponent,
    OrderComponent,
    OrderDetailsComponent,
    OrderInfoComponent,
    DataFilterComponent,
    CloverCallbackComponent,
    PointofsaleListComponent,
    PointofsaleCreateComponent,
    PrinterCreateComponent,
    PrinterListComponent,
    StarmicronicsAddComponent,
    PrinterDetailsComponent,
    PrinterAdminComponent,
    DeliveryserviceComponent,
    DeliveryserviceDetailsComponent,
    DeliveryserviceMenusyncComponent,
    DeliveryserviceAdminComponent,
    DeliveryservicePosIntegrationComponent,
    OrderItemsComponent,
    PointofsaleComponent,
    PointofsaleDetailsComponent,
    PointofsaleSettingsComponent,
    PointofsaleAdminComponent,
    PointofsaleMenusyncComponent,
    LeadsComponent,
    DetailsComponent,
    PrinterComponent,
    PrinterJobsRecentComponent,
    PrinterJobsAllComponent,
    PrinterJobsDetailsComponent,
    PrinterStatsComponent,
    DeliveryserviceSettingsComponent,
    PrinterSettingsComponent,
    SetupComponent,
    ComingsoonComponent,
    Auth0CallbackComponent,
    CloverLinkingDialogComponent,
    PosConnectDgComponent,
    OnboardDsDialogComponent,
    OnboardMenuListDgComponent,
    OnboardDsSuccessDgComponent,
    OnboardUbereatsStoresDgComponent,
    OnboardComponent,
    OnboardStatsComponent,
    DsCredentialsDialogComponent,
    DeliveryserviceConnectDialogComponent,
    DeliveryserviceDisconnectDgComponent,
    DeliveryserviceEnableDgComponent,
    SortByPipe,
    UTCFormatPipe,
    Time24to12Pipe,
    HoursPipe,
    MinutesPipe,
    PeriodPipe,
    NextDayPipe,
    MatRowKeyEventsDirective
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MaterialModule,
    FlexLayoutModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    DragDropModule,
    IntercomModule.forRoot({
      appId: environment.INTERCOM_APP_ID,
      updateOnRouterChange: true
    }),
    NgxJsonViewerModule
  ],
  providers: [
    // GlobalErrorHandler,
    { provide: ErrorHandler, useClass: GlobalErrorHandler },
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptorService, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: HttpErrorInterceptor, multi: true },
    AuthService,
    AppService,
    ApiService,
    MessageService,
    AccountService,
    AccountResolve,
    RestaurantService,
    RestaurantHelper,
    RestaurantResolve,
    AccountRestaurantResolve,
    MenuService,
    MenuHelperService,
    MenuResolve,
    MenuCategoryResolve,
    MenuModifierResolve,
    DeliveryserviceService,
    DeliveryServiceResolve,
    OrderService,
    OrderResolve,
    PrinterService,
    PrinterResolve,
    PrintJobResolve,
    PointofsaleService,
    PointOfSaleResolve,
    ConfirmationDialogService,
    BreadcrumbService,
    OnboardService,
    CoreEventsService,
    RequestsService,
    MessageDgService
  ],
  bootstrap: [
    AppComponent
  ],
  entryComponents: [
    AccountDialogComponent,
    RestaurantDialogComponent,
    RestaurantContactDgComponent,
    RestaurantUsersDgComponent,
    RestaurantProcessDgComponent,
    MenuDialogComponent,
    MenuSyncModifierComponent,
    MenuMapDialogComponent,
    StarmicronicsAddComponent,
    CloverLinkingDialogComponent,
    PosConnectDgComponent,
    OnboardDsDialogComponent,
    OnboardMenuListDgComponent,
    OnboardDsSuccessDgComponent,
    OnboardUbereatsStoresDgComponent,
    DsCredentialsDialogComponent,
    DeliveryserviceConnectDialogComponent,
    DeliveryserviceDisconnectDgComponent,
    DeliveryserviceEnableDgComponent,
    ConfirmationDialogComponent,
    ErrorDialogComponent,
    MessageDgComponent,
    MenuSectionAvailabilityDialogComponent,
    MessagesComponent
  ],
})
export class AppModule { }
