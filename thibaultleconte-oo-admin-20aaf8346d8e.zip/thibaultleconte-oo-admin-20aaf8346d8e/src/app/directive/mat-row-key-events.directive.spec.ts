import { MatRowKeyEventsDirective } from './mat-row-key-events.directive';

describe('MatRowKeyEventsDirective', () => {
  it('should create an instance', () => {
    const directive = new MatRowKeyEventsDirective();
    expect(directive).toBeTruthy();
  });
});
