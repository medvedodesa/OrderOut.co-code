import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'nextDay'
})
export class NextDayPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if (value && value.start_time && value.end_time) {
      return new Date("1990-01-01T" + value.start_time + "Z") > new Date("1990-01-01T" + value.end_time + "Z");
    }
    return false;
  }

}
