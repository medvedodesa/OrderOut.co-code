import { Pipe, PipeTransform } from '@angular/core';
import { Injectable } from '@angular/core';
import * as _ from 'lodash';

// Added Injectable to inject or import pipe into component
@Injectable({
  providedIn: 'root'
})

// Pipe declaration
@Pipe({
  name: 'sortBy'
})

export class SortByPipe implements PipeTransform {

  // First Param - Array to sort, Second Param - Column name, Third Param (optional) - Sort type (asc|desc)
  transform(value: any[], column: string, order: any = 'asc'): any[] {
    if (!value || !column || column === '') { return value; } // no array
    if (value.length <= 1) { return value; } // array with only one item
    return _.orderBy(value, [column], [order]);
  }

}
