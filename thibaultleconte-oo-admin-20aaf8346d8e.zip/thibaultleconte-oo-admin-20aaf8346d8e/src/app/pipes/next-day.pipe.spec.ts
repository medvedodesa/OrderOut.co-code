import { NextDayPipe } from './next-day.pipe';

describe('NextDayPipe', () => {
  it('create an instance', () => {
    const pipe = new NextDayPipe();
    expect(pipe).toBeTruthy();
  });
});
