import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'period'
})
export class PeriodPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    var getPeriod = function(a) {
      return (new Date("1990-01-01T" + a + "Z")).toLocaleTimeString("en-US", {
          timeZone: "UTC",
          hour12: true,
          hour: "numeric",
      });
    };
    return getPeriod(value).replace(/[0-9]/g, "").trim();
  }

}
