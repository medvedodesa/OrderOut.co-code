import { PeriodPipe } from './period.pipe';

describe('PeriodPipe', () => {
  it('create an instance', () => {
    const pipe = new PeriodPipe();
    expect(pipe).toBeTruthy();
  });
});
