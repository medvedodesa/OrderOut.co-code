import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'minutes'
})
export class MinutesPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    var getMinutes = function(a) {
      return (new Date("1990-01-01T" + a + "Z")).toLocaleTimeString("en-US", {
          timeZone: "UTC",
          hour12: true,
          minute: "numeric",
      });
    };
    return parseInt(getMinutes(value), 10);
  }

}
