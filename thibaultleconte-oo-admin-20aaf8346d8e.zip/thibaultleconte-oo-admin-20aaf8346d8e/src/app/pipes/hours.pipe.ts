import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'hours'
})
export class HoursPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    var getHours = function(a) {
      return (new Date("1990-01-01T" + a + "Z")).toLocaleTimeString("en-US", {
          timeZone: "UTC",
          hour12: true,
          hour: "numeric",
      });
    };

    return parseInt(getHours(value).replace(/\D/g, ""), 10);
  }

}
