import { Time24to12Pipe } from './time24to12.pipe';

describe('Time24to12Pipe', () => {
  it('create an instance', () => {
    const pipe = new Time24to12Pipe();
    expect(pipe).toBeTruthy();
  });
});
