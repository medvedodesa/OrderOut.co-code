import { HoursPipe } from './hours.pipe';

describe('HoursPipe', () => {
  it('create an instance', () => {
    const pipe = new HoursPipe();
    expect(pipe).toBeTruthy();
  });
});
