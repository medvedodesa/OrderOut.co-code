import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'time24to12'
})
export class Time24to12Pipe implements PipeTransform {

  transform(value: any, args?: any): any {

    var time24To12 = function(a) {
      return (new Date("1990-01-01T" + a + "Z")).toLocaleTimeString("en-US", {
          timeZone: "UTC",
          hour12: true,
          hour: "numeric",
          minute: "numeric"
      });
    };
    return time24To12(value);
  }

}
