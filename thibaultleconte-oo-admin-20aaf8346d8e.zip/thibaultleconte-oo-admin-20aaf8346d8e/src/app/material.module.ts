// #!/bin/sh
//
// thibault@orderout.co
//
// 03/31/2019
//

import { NgModule } from '@angular/core';

import {
  MatSidenavModule,
  MatToolbarModule,
  MatIconModule,
  MatListModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatDialogModule,
  MatInputModule,
  MatSelectModule,
  MatTableModule,
  MatSortModule,
  MatPaginatorModule,
  MatProgressSpinnerModule,
  MatProgressBarModule,
  MatCardModule,
  MatFormFieldModule,
  MatAutocompleteModule,
  MatGridListModule,
  MatExpansionModule,
  MatStepperModule,
  MatMenuModule,
  MatSlideToggleModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatSnackBarModule,
  MatCheckboxModule,
  MatChipsModule,
  MatTooltipModule,
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MatTabsModule
} from '@angular/material';

import { PaginationConfigComponent } from './views/common/pagination-config/pagination-config.component';

@NgModule({
  imports: [
    MatSidenavModule,
    MatToolbarModule,
    MatIconModule,
    MatListModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatDialogModule,
    MatInputModule,
    MatSelectModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    MatCardModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatGridListModule,
    MatExpansionModule,
    MatStepperModule,
    MatMenuModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSnackBarModule,
    MatCheckboxModule,
    MatChipsModule,
    MatTooltipModule,
    MatTabsModule
  ],
  exports: [
    MatSidenavModule,
    MatToolbarModule,
    MatIconModule,
    MatListModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatDialogModule,
    MatInputModule,
    MatSelectModule,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
    MatCardModule,
    MatFormFieldModule,
    MatAutocompleteModule,
    MatGridListModule,
    MatExpansionModule,
    MatStepperModule,
    MatMenuModule,
    MatSlideToggleModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSnackBarModule,
    PaginationConfigComponent,
    MatCheckboxModule,
    MatChipsModule,
    MatTooltipModule,
    MatTabsModule
  ],
  entryComponents: [PaginationConfigComponent],
  declarations: [PaginationConfigComponent],
  providers: [ 
    PaginationConfigComponent,
    {
      provide: MAT_TOOLTIP_DEFAULT_OPTIONS,
      useValue: { position: 'above' }
    }
  ],
})
export class MaterialModule { }
