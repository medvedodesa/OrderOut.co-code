#!/bin/sh
#
# thibault@orderout.co
#
# 03/31/2019
#

ng build --prod

gcloud config configurations activate orderout-admin

# Automatic - No confirmation
gcloud app deploy --quiet
