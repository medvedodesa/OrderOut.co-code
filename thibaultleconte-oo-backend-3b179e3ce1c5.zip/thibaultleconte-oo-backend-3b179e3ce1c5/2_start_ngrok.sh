#!/bin/sh
#
# thibault@orderout.co
#
# 04/23/2019
#

# ~/Dropbox/Projects/ngrok http 8080 -subdomain orderout-tibo
~/Dropbox/Projects/ngrok http 8080 -subdomain orderout-tibo -host-header="localhost:8080"
 
