** SETUP **

Preliminary check: Check you have python 2.7.*

- git fetch origin develop
- git checkout develop
- gcloud init
- "virtualenv env" if you have python 2.7 by default otherwise "python2 -m virtualenv env"
- source env/bin/activate
- pip install -r requirements.txt -t lib
- ./0_start_development_server.sh

For initial project setup, check the following
- secret_keys -> "python" "import os" "os.urandom(24)" for the 2 keys
- application/config.py

IF GETTING AN ERROR with Python 2.7 ctypes invalid int base 10
got to ctypres/__init__.py around line 29
-
# TIBO-FIX - GAE replace Mac Os X OS invo with ('Linux', '', '', '', '') so '' cast to int fails
#import logging
#logging.info(_os.uname())
_version = _os.uname()[2].split('.')[0]
if _version == '': _version = '1'
if _version < 8: # if int(_os.uname()[2].split('.')[0]) < 8:
-

** TO READ **
1. http://flask.pocoo.org
2. https://flask-restful.readthedocs.io/en/0.3.5/index.html
3. https://cloud.google.com/appengine/docs/standard/python/datastore/
4. https://cloud.google.com/appengine/docs/standard/python/ndb/modelclass#instance_methods
5. https://flask-restful.readthedocs.io/en/0.3.5/intermediate-usage.html#project-structure
6. Google Swagger UI
7. https://orderout-backend.appspot.com/infrastructure/admin/

** TO DO **
- implement at the application level (not the endpoint.controller level) the exception handling -> Great example for expected result with Apify https://apify.com/docs/api/v2#/introduction/response-structure
- write test function name and return AssertTrue(False) for core.model.base core.event api.user
- check decorator for required_auth
- verify why we need import dev_appserver in unittest_runner.google.py
- add test for core.urlFetch, core.task, core.authentication
- in application.apis.menu.service.creator, make the put async
- identify all the sendgrid email template from master and implement
- Clover menu fetch has a hard set 1000 limit for menu items: It should not have a limit and start a new request for the next offset

** AUTH0 - User Authentication **
https://auth0.com/docs/architecture-scenarios/spa-api

** APIFY **

Slack from Ondra 2019/03/28

1. “https://api.apify.com/v2/key-value-stores/order-out~ubereats-monitor-store-v2/records/%s?token=%s” % (str(delivery_service_key.id()), str(_apify_token)) (edited)
2. “https://api.apify.com/v2/acts/order-out~ubereats-monitor-v2/runs?token=%s” % (str(_apify_token))
3. “https://api.apify.com/v2/key-value-stores/order-out~ubereats-%s/records/MENU?token=%s” % (str(delivery_service_key.id()), str(_apify_token))
The number 3 always returns
```<?xml version="1.0" encoding="UTF-8"?> <Error><Code>SignatureDoesNotMatch</Code><Message>The request signature we calculated does not match the signature you provided. Check your key and signing method.</Message><AWSAccessKeyId>AKIAJTQHBVH6QKNNBOIQ</AWSAccessKeyId><StringToSign>GET

application/json 1554426928 /apifier-key-value-store-prod/MkGx4WNxu5W3rDWq9/MENU</StringToSign><SignatureProvided>m+x508vgqGgtR5q+8hZGhkod8FY=</SignatureProvided><StringToSignBytes>47 45 54 0a 0a 61 70 70 6c 69 63 61 74 69 6f 6e 2f 6a 73 6f 6e 0a 31 35 35 34 34 32 36 39 32 38 0a 2f 61 70 69 66 69 65 72 2d 6b 65 79 2d 76 61 6c 75 65 2d 73 74 6f 72 65 2d 70 72 6f 64 2f 4d 6b 47 78 34 57 4e 78 75 35 57 33 72 44 57 71 39 2f 4d 45 4e 55</StringToSignBytes><RequestId>BA112DB24D6DB12C</RequestId><HostId>SiSmgxbnDVpA9f69jetLkSKUL81Z+VjFY1yTaq0cYcVar3hKdwDpDTBTlVittrXh4EnWremHp3s=</HostId></Error>```
so I use “https://api.apify.com/v2/key-value-stores/MkGx4WNxu5W3rDWq9/records/MENU?disableRedirect=1” instead
From a high level, what do you know about these 3 queries?

Ondra [9:10 AM]
Ok, the 1. and 3. are requests going to our Key Value Store storage. https://apify.com/docs/api/v2#/reference/key-value-stores

The first one, depending on whether it's a GET or PUT or DELETE, will either download, save or delete data from the `ubereats-monitor-store-v2`. https://apify.com/docs/api/v2#/reference/key-value-stores/record/get-record We use that store to keep information about restaurants being monitored. To start monitoring a restaurant, you push its information into the store, to stop monitoring it, you delete it from the store. The `ubereats-monitor` actor monitors this store and manages the restaurants in there.

The third one retrieves a MENU item from a key value store named `ubereats-{RESTAURANT_ID}` where we keep restaurant scoped information. It's essentially the same endpoint as the first, just hitting a different key value store.

The second one is just a simple call that requests a list of all the runs of the `ubereats-monitor-v2` actor. https://apify.com/docs/api/v2#/reference/actors/run-collection/get-list-of-runs
The third one is not working because it's missing a token query parameter. If you're using the ID of any storage on Apify, you can use it without token, but if you're using a `username~store-name` combination in place of the ID, you need to use the token.
It's just a security measure.
