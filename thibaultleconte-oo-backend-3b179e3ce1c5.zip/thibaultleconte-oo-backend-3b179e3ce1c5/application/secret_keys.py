# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

# "python" "import os" "os.urandom(24)" for the 2 keys 

CSRF_SECRET_KEY = b"9C\xf4\x98\xb6UH\xb7K'\xc6\xd3lLl\xaf\xad\xd1?\x8c\xdd\x1dn\xb0"
SESSION_KEY = b"\x03\xd1\xbb\xfc\xc5\x9c\xf8\xd3~\xdc \x0eb\x07@.\x92\x04\x83\x86\xad\xf1\xd4\x80"
