# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/04/2019
#

import os
import unittest
from application.test.base import BaseTestCase




class TestAccountExceptions(BaseTestCase):

    def test_post_with_repeated_name(self):
        from application.apis.account.service import check_name_and_create
        from application.core.exception import ConflictResourceAlreadyExistsError
        check_name_and_create("test_name")
        self.assertRaises(ConflictResourceAlreadyExistsError, check_name_and_create,"test_name")

    def test_delete_with_wrong_account_id(self):
        from application.core.model.Base import Base
        from application.core.exception import NotFound
        from application.apis.account.model import Account

        _account1 = Account.create(name='test_account1')
        account_id  = '007'
        self.assertFalse(str(_account1.key.id()) == account_id)
        self.assertRaises(NotFound, Account.delete_by_id, account_id)

    def test_put_with_same_name(self):
        from application.apis.account.service import get_by_id_and_populate
        from application.core.exception import NameNotChanged
        from application.apis.account.model import Account
        _account = Account.create(name='test_account')
        account_id = _account.key.id()
        json_dict = {"name": "test_account"}
        self.assertRaises(NameNotChanged, get_by_id_and_populate, account_id, json_dict)

    def test_put_with_repeated_name(self):
        from application.apis.account.service import get_by_id_and_populate
        from application.core.exception import ConflictResourceAlreadyExistsError
        from application.apis.account.model import Account
        _account1 = Account.create(name='test_account1')
        _account2 = Account.create(name='test_account2')
        account_id = _account1.key.id()
        json_dict = {"name": "test_account2"}
        self.assertRaises(ConflictResourceAlreadyExistsError, get_by_id_and_populate, account_id, json_dict)


if __name__ == '__main__':
    unittest.main()
