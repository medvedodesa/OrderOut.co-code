# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/21/2019
#

import os
import unittest
from application.test.base import BaseTestCase
from flask import abort


class TestCoreErrorReportAbort(BaseTestCase):

    def test_core_event_create(self):
        from application.core.error import report_and_abort
        from werkzeug import exceptions
        with self.assertRaises(exceptions.InternalServerError):
            report_and_abort(message='Test')

if __name__ == '__main__':
    unittest.main()
