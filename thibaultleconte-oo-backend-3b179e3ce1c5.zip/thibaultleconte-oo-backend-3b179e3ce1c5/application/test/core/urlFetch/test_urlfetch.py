# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/20/2019
#

import os
import unittest
from application.test.base import BaseTestCase


# class TestCoreUrlFetch(BaseTestCase):

# def test_core_urlfetch_to_do(self):
#     raise NotImplementedError

if __name__ == '__main__':
    unittest.main()
