import pytest

from application.apis.account.model import Account
from application.apis.restaurant.model import Restaurant
from application.core.google_search_api.search import (
    get_accounts_ids_by_account_or_restaurant_name,
)
from application.test.api.account.factories import AccountFactory
from application.test.api.restaurant.factories import RestaurantFactory


class TestGoogleSearchApi(object):
    @pytest.fixture
    def accounts(self):
        names = ["Bobs", "Giraffas", "Texano Grill"]
        accounts = []
        for name in names:
            account = AccountFactory(name=name).put().get()
            accounts.append(account)

        return accounts

    @pytest.fixture
    def index(self, accounts):
        for account in accounts:
            Account.put_search_document(account.id)

    @pytest.mark.usefixtures("index")
    def test_get_accounts_by_account_name(self, accounts):
        accounts_on_db = Account.query().filter().fetch()
        assert len(accounts_on_db) >= len(accounts)

        account = accounts[0]

        found_accounts_ids = get_accounts_ids_by_account_or_restaurant_name(
            account.name
        )
        assert len(found_accounts_ids) == 1

        found_account_id = found_accounts_ids[0]
        found_account = Account.get_by_id(found_account_id)
        assert found_account.name == account.name
        assert found_account.id == account.id

    @pytest.mark.usefixtures("index")
    def test_get_accounts_by_restaurant_name(self, accounts):
        names = ["OTAO", "Sushinami", "Temakin"]
        assert len(names) == len(accounts)

        restaurants = []
        for account, name in zip(accounts, names):
            restaurant = RestaurantFactory(account=account.key, name=name).put().get()
            restaurants.append(restaurant)

        for restaurant in restaurants:
            Restaurant.put_search_document(restaurant.id)

        restaurants_on_db = Restaurant.query().filter().fetch()

        assert len(restaurants_on_db) >= len(restaurants)

        restaurant = restaurants[0]
        account = restaurant.account.get()

        found_accounts_ids = get_accounts_ids_by_account_or_restaurant_name(
            restaurant.name
        )
        assert len(found_accounts_ids) == 1

        found_account_id = found_accounts_ids[0]
        found_account = Account.get_by_id(found_account_id)
        assert found_account.name == account.name
        assert found_account.id == account.id
