# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/04/2019
#

import os
import unittest
from application.test.base import BaseTestCase
from application.core.event.model import CoreEvent, CoreEventCategory


class TestCoreEventCrud(BaseTestCase):

    def test_coreevent_get_by_id_class_name(self):
        _obj = CoreEvent(category=CoreEventCategory.UNKNOWN, name="Finished")
        _obj.put()
        _obj_id = _obj.key.id()
        _fetched_obj = CoreEvent.get_by_id(_obj_id)
        self.assertTrue(_obj.__class__.__name__ == _fetched_obj.__class__.__name__)

if __name__ == '__main__':
    unittest.main()
