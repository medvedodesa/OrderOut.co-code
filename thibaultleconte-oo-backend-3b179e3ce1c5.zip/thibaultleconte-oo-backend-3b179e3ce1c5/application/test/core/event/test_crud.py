# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/04/2019
#

import os
import unittest
from application.test.base import BaseTestCase


class TestCoreEventCrud(BaseTestCase):

    def test_core_event_create(self):
        from application.core.event.model import CoreEvent, CoreEventCategory
        from application.core.event.service import create_event

        category = CoreEventCategory.UNKNOWN
        name = "Finished"
        success = True

        create_event(category, name, success)
        event = CoreEvent.query().get()

        self.assertTrue(event.category == category)
        self.assertTrue(event.name == name)
        self.assertTrue(event.success == success)

    def test_core_event_create_with_payload(self):
        from application.core.event.model import CoreEvent, CoreEventCategory
        from application.core.event.service import create_event

        category = CoreEventCategory.UNKNOWN
        name = "Finished"
        success = True

        test_key = "testkey"
        test_value = "testvalue"
        payload = {test_key: test_value}

        create_event(category, name, success, payload=payload)
        event = CoreEvent.query().get()

        json_formatted = event.to_dict()["payload"]
        self.assertTrue(json_formatted[test_key] == test_value)

if __name__ == '__main__':
    unittest.main()
