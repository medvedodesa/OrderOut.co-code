import pytest

from application.core.notification_hub.sender.factory import NotificationSenderGroupFactory
from application.test.api.account.factories import AccountFactory
from application.test.api.restaurant.factories import RestaurantFactory
from application.test.api.user.factories import UserFactory


@pytest.mark.usefixtures("db")
class TestNotificationSender(object):
    @pytest.fixture
    def mock_send_email(self, mocker):
        mocked_send_sms = mocker.patch(
            "application.core.notification_hub.sender.email_sender.send_support_email"
        )

        return mocked_send_sms

    @pytest.fixture
    def mock_send_sms(self, mocker):
        mocked_send_email = mocker.patch(
            "application.core.notification_hub.sender.sms_sender.send_sms"
        )

        return mocked_send_email

    @pytest.fixture
    def mock_send_slack(self, mocker):
        mocked_send_email = mocker.patch(
            "application.core.notification_hub.sender.slack_sender.requests"
        )

        return mocked_send_email

    @pytest.fixture
    def restaurant(self):
        account_key = AccountFactory(name="Acme").put()
        restaurant_key = RestaurantFactory(
            name="Saint Theresa Street, 354",
            account=account_key,
        ).put()

        restaurant = restaurant_key.get()

        return restaurant

    @pytest.fixture
    def full_contacts(self, restaurant):
        restaurant.users = []
        restaurant.put()
        u1 = UserFactory(email="a@example.org", phone="999 999", receives_notification=True).put()
        u2 = UserFactory(email="b@example.org", phone="888 888", receives_notification=True).put()

        restaurant.add_users([u1, u2])
        return [u1, u2]

    @pytest.fixture
    def contact_wo_phone(self, restaurant):
        restaurant.users = []
        restaurant.put()
        u1 = UserFactory(email="c@example.org", receives_notification=True).put()
        restaurant.add_user(u1)
        return u1

    @pytest.fixture
    def full_contacts_no_notification(self, restaurant):
        restaurant.users = []
        restaurant.put()
        u1 = UserFactory(email="a@example.org", phone="999 999", receives_notification=False).put()
        u2 = UserFactory(email="b@example.org", phone="888 888", receives_notification=False).put()

        restaurant.add_users([u1, u2])
        return [u1, u2]

    @pytest.fixture
    def notification(self, mocker):
        notification = mocker.Mock()
        notification.summary = "Notification Summary"
        notification.subject = "Notification Subject"
        notification.message = "Notification Message"
        del notification.slack_links

        return notification

    @pytest.fixture
    def slack_notification(self, mocker):
        notification = mocker.Mock()
        notification.summary = "Notification Summary"
        notification.subject = "Notification Subject"
        notification.message = "Notification Message"
        notification.slack_links = [{"title": "Link", "url": "https://u.r.l"}]

        return notification

    def test_dispatch(
        self,
        restaurant,
        full_contacts,
        notification,
        mock_send_sms,
        mock_send_email,
        mock_send_slack,
    ):
        notification_sender_group = NotificationSenderGroupFactory(restaurant).create()
        notification_sender_group.dispatch(notification)

        phone_numbers = []
        emails = []
        for contact_key in full_contacts:
            contact = contact_key.get()
            emails.append(contact.email)
            phone_numbers.append(contact.phone_number)

        expected_sms_args = (phone_numbers, notification.summary)
        expected_email_args = (emails, notification.subject, notification.message)

        send_sms_args = mock_send_sms.call_args_list[0][0]
        send_email_args = mock_send_email.call_args_list[0][0]

        assert send_sms_args == expected_sms_args
        assert send_email_args == expected_email_args

    def test_dispatch_user_dont_receive_notification(
        self,
        restaurant,
        full_contacts_no_notification,
        notification,
        mock_send_sms,
        mock_send_email,
        mock_send_slack,
    ):
        notification_sender_group = NotificationSenderGroupFactory(restaurant).create()
        notification_sender_group.dispatch(notification)

        phone_numbers = []
        emails = []
        for contact_key in full_contacts_no_notification:
            contact = contact_key.get()
            emails.append(contact.email)
            phone_numbers.append(contact.phone_number)

        mock_send_email.assert_not_called()
        mock_send_sms.assert_not_called()

    def test_dispatch_only_email_when_contact_has_no_phone_number(
        self,
        restaurant,
        contact_wo_phone,
        notification,
        mock_send_sms,
        mock_send_email,
        mock_send_slack,
    ):
        contact_wo_phone_number = contact_wo_phone.get()

        notification_sender_group = NotificationSenderGroupFactory(restaurant).create()
        notification_sender_group.dispatch(notification)

        email = contact_wo_phone_number.email

        expected_email_args = ([email], notification.subject, notification.message)
        send_email_args = mock_send_email.call_args_list[0][0]

        assert send_email_args == expected_email_args
        mock_send_sms.assert_not_called()
        mock_send_slack.assert_not_called()

    def test_no_contacts(
        self, restaurant, notification, mock_send_sms, mock_send_email, mock_send_slack
    ):
        notification_sender_group = NotificationSenderGroupFactory(restaurant).create()
        notification_sender_group.dispatch(notification)

        mock_send_sms.assert_not_called()
        mock_send_email.assert_not_called()
        mock_send_slack.assert_not_called()

    @pytest.mark.usefixtures("mock_send_sms", "mock_send_email")
    def test_monitored_notification(self, full_contacts, restaurant, notification, mock_send_slack):
        notification_sender_group = NotificationSenderGroupFactory(restaurant).create(
            monitored_channel="order-alerts"
        )

        notification_sender_group.dispatch(notification)

        phone_numbers = []
        emails = []
        for contact_key in full_contacts:
            contact = contact_key.get()
            emails.append(contact.email)
            phone_numbers.append(contact.phone_number)

        expected_message = """Message Summary: 'Notification Summary'
SMS sent to: [u'999 999', u'888 888']
Email sent to: [u'a@example.org', u'b@example.org']"""

        expected_json = {"text": expected_message}

        send_slack_calls = mock_send_slack.post.call_args_list
        args, kwargs = send_slack_calls[0]

        assert kwargs["json"] == expected_json

    @pytest.mark.usefixtures("mock_send_sms", "mock_send_email")
    def test_monitored_notification_with_slack_links(self, restaurant, slack_notification, mock_send_slack):
        notification_sender_group = NotificationSenderGroupFactory(restaurant).create(
            monitored_channel="order-alerts"
        )

        notification_sender_group.dispatch(slack_notification)

        expected_json = {
            "text": "Message Summary: 'Notification Summary'\nhas not been sent to anyone",
            "blocks": [{
                'text': {
                    'text': "Message Summary: 'Notification Summary'\nhas not been sent to anyone",
                    'type': 'mrkdwn'
                },
                'type': 'section'
            },{
                'fields': [{
                    'text': '*Link*\nhttps://u.r.l',
                    'type': 'mrkdwn'
                }],
                'type': 'section'
            }],
        }

        send_slack_calls = mock_send_slack.post.call_args_list
        args, kwargs = send_slack_calls[0]

        assert kwargs["json"] == expected_json
