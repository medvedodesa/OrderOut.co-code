# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/29/2019
#

import unittest
from application.test.base import BaseTestCase
from application.core.parser.price import sanitize_price

class TestCoreParserPrice(BaseTestCase):

    def test_price_as_float_instead_of_str(self):
        _str_to_test = 1.10
        _str_expected = 1.10
        _str_result = sanitize_price(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    def test_price_already_formatted(self):
        _str_to_test = u'1.10'
        _str_expected = 1.10
        _str_result = sanitize_price(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    def test_price_dollar_sign(self):
        _str_to_test = u'$1'
        _str_expected = 1.00
        _str_result = sanitize_price(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    def test_price_dollar_sign_round_down_up(self):
        _str_to_test = u'$18.74'
        _str_expected = 1874
        _str_result = sanitize_price(_str_to_test)
        _str_result = int(sanitize_price(_str_result * 100))
        self.assertTrue(_str_result == _str_expected)

    def test_price_dollar_currency_first_position(self):
        _str_to_test = u'US20.25'
        _str_expected = 20.25
        _str_result = sanitize_price(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    def test_price_dollar_text(self):
        _str_to_test = u'8.95 US'
        _str_expected = 8.95
        _str_result = sanitize_price(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    def test_price_dollar_text_lower(self):
        _str_to_test = u'8.95 uS'
        _str_expected = 8.95
        _str_result = sanitize_price(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    def test_price_comma_cent(self):
        _str_to_test = u'1,10'
        _str_expected = 1.10
        _str_result = sanitize_price(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    def test_price_point_cent(self):
        _str_to_test = u'1.10'
        _str_expected = 1.10
        _str_result = sanitize_price(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    def test_price_point_cent_one_digit(self):
        _str_to_test = u'0.5'
        _str_expected = 0.50
        _str_result = sanitize_price(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    def test_price_invalid_literal_for_float(self):
        _str_to_test = "12.40   "
        _str_expected = 12.4
        _str_result = sanitize_price(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    def test_price_invalid_literal_semicolon_space_for_float(self):
        _str_to_test = "21:25 "
        _str_expected = 21.25
        _str_result = sanitize_price(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    def test_price_ascii_character(self):
        _str_to_test = u'37.80\xc2\xa0'
        _str_expected = 37.80
        _str_result = sanitize_price(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

if __name__ == '__main__':
    unittest.main()
