# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/29/2019
#

import unittest
from application.test.base import BaseTestCase
from application.core.parser.string import sanitize_str

class TestCoreParserString(BaseTestCase):

    def test_string_sanitize_whitespaces(self):
        _str_to_test = u'   3 whitespaces before    4 in the middle and  2 at the end  '
        _str_expected = '3 whitespaces before 4 in the middle and 2 at the end'
        _str_result = sanitize_str(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    def test_string_sanitize_doordash_dashes_1(self):
        _str_to_test = u'51320803 \u2013 2593329'
        _str_expected = '51320803 - 2593329'
        _str_result = sanitize_str(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    # def test_string_sanitize_doordash_dashes_2(self):
    #     _str_to_test = u'07800826 — 6210183'
    #     _str_expected = '07800826 - 6210183'
    #     _str_result = sanitize_str(_str_to_test)
    #     print(_str_to_test)
    #     print(_str_expected)
    #     print(_str_result)
    #     self.assertTrue(_str_result == _str_expected)

    def test_string_sanitize_menu_item_cafe(self):
        _str_to_test = u'Café'
        _str_expected = 'café'
        _str_result = sanitize_str(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    def test_string_sanitize_menu_item_jamon(self):
        _str_to_test = u'jamón'
        _str_expected = 'jamón'
        _str_result = sanitize_str(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    def test_string_sanitize_menu_item_sandwich(self):
        _str_to_test = u'Sándwiche'
        _str_expected = 'sándwiche'
        _str_result = sanitize_str(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    def test_string_sanitize_menu_item_bunueleos(self):
        _str_to_test = u'Buñuelos'
        _str_expected = 'buñuelos'
        _str_result = sanitize_str(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    def test_string_sanitize_menu_item_almibar(self):
        _str_to_test = u'almíbar'
        _str_expected = 'almíbar'
        _str_result = sanitize_str(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

    def test_string_sanitize_menu_item_utf8_characters(self):
        _str_to_test = u'almíbar\xc2\xa0'
        _str_expected = 'almíbar'
        _str_result = sanitize_str(_str_to_test)
        self.assertTrue(_str_result == _str_expected)

if __name__ == '__main__':
    unittest.main()
