import pytest


from application.core.delivery_services.grubhub.factories import GrubHubApiClientFactory
from application.core.settings.app import get_config_for_key


@pytest.mark.integration_test
class TestPostmatesApi(object):
    def test_login(self):
        username = get_config_for_key("GRUBHUB_EMAIL")
        password = get_config_for_key("GRUBHUB_PASSWORD")
        grubhub_api = GrubHubApiClientFactory.instantiate_api_client(
            username=username, password=password
        )
        response = grubhub_api.authenticate()
        assert response
        assert "access_token" in response
        assert "merchant_ids" in response
        assert response["merchant_ids"]

    def test_get_orders(self):
        username = get_config_for_key("GRUBHUB_EMAIL")
        password = get_config_for_key("GRUBHUB_PASSWORD")
        grubhub_api = GrubHubApiClientFactory.instantiate_api_client(
            username=username, password=password
        )
        response = grubhub_api.get_active_orders()
        assert response
