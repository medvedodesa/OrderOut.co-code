import pytest


from application.core.delivery_services.ubereats.factories import UberEatsApiClientFactory


REFRESH_TOKEN = ""


@pytest.mark.integration_test
class TestUberEatsApi(object):
    @pytest.fixture
    def ubereats_client(self):
        return UberEatsApiClientFactory.instantiate_api_client(refresh_token=REFRESH_TOKEN)

    def test_list_stores(self, ubereats_client):
        response = ubereats_client.list_stores()
        assert response
