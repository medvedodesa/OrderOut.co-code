import pytest

@pytest.mark.usefixtures("db")
class TestPostmatesApi(object):
    pass