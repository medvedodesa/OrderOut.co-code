import pytest

from application.core.delivery_services.doordash.factories import DoorDashApiClientFactory


EMAIL = ""
PASSWORD = ""
MERCHANT_ID = ""
STORE_ID = ""
ORDER_ID = ""


@pytest.mark.skip
@pytest.mark.integration_test
class TestDoordashApi(object):

    @pytest.fixture
    def doordash_client(self):
        return DoorDashApiClientFactory.instantiate_api_client(EMAIL, PASSWORD)

    def test_get_store(self, doordash_client):
        response = doordash_client.get_store(
            merchant_id=MERCHANT_ID,
        )
        assert response

    def test_get_active_orders(self, doordash_client):
        response = doordash_client.get_active_orders(
            store_id=STORE_ID,
        )
        assert response
        assert "kitchen" in response
        assert isinstance(response.get("kitchen"), list)

    def test_get_order(self, doordash_client):
        response = doordash_client.get_order(
            order_id=ORDER_ID,
        )
        assert response
        assert "order" in response
        assert isinstance(response, dict)
