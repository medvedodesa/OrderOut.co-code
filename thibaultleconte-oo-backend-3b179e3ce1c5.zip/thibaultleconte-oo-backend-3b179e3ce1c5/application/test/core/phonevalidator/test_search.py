# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2020
#

import unittest
from application.test.base import BaseTestCase
from application.core.phonevalidator.search import process_phone_validator_response
import json

class TestCorePhoneValidatorSearch(BaseTestCase):

    def test_number_not_found(self):
        _test_json = json.loads('{"PhoneBasic": {"ReportDate": "2020-03-02T08:29:17.2104495-08:00", "ErrorDescription": "NOT FOUND", "PhoneCompany": null, "ErrorCode": "404", "PhoneLocation": null, "LineType": null, "PhoneNumber": "8098945073"}, "PhoneDeactivation": null, "Phone": "8098945073", "SearchDate": "2020-03-02T08:29:17.2104495-08:00", "Cost": 0.004, "PhoneDetail": null, "StatusMessage": "OK", "StatusCode": "200"}')
        _result = process_phone_validator_response(_test_json)
        self.assertFalse(_result)

    def test_number_valid(self):
        _test_json = json.loads('{"PhoneBasic": {"ReportDate": "2020-03-02T08:29:17.2104495-08:00", "ErrorDescription": "", "PhoneCompany": null, "ErrorCode": "", "PhoneLocation": "SAN FRANCISCO, CA", "LineType": "CELL PHONE", "PhoneNumber": "8098945073"}, "PhoneDeactivation": null, "Phone": "8098945073", "SearchDate": "2020-03-02T08:29:17.2104495-08:00", "Cost": 0.004, "PhoneDetail": null, "StatusMessage": "OK", "StatusCode": "200"}')
        _result = process_phone_validator_response(_test_json)
        self.assertTrue(_result)

if __name__ == '__main__':
    unittest.main()
