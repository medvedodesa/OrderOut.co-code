# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/13/2019
#

import unittest
from application.test.base import BaseTestCase
from application.core.model.Base import Base

class TestCoreModelBaseCreate(BaseTestCase):

    def test_base_create(self):
        _obj = Base()
        _result_key = _obj.put()
        self.assertTrue(_result_key)

if __name__ == '__main__':
    unittest.main()
