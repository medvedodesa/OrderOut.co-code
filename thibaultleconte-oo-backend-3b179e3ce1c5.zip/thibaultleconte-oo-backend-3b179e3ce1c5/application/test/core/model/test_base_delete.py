# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/13/2019
#

import unittest
from application.test.base import BaseTestCase
from application.core.model.Base import Base
from google.appengine.api import memcache
from google.appengine.ext import ndb


class TestCoreModelBaseDelete(BaseTestCase):

    def test_base_delete(self):
        _obj = Base()
        _obj.put()
        _obj_id = _obj.key.id()
        self.assertTrue(_obj.api_status)
        _obj.delete()
        self.assertFalse(_obj.api_status)
        mc_key = Base.get_mc_key_for_entity(key_id=_obj_id)
        mc_client = memcache.Client()
        entity = mc_client.get(mc_key)
        self.assertIsNone(entity)
        key = Base.get_key(_obj_id)
        entity = key.get()
        self.assertIsNotNone(entity)
        self.assertFalse(entity.api_status)

if __name__ == '__main__':
    unittest.main()
