# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/13/2019
#

import unittest
from application.test.base import BaseTestCase
from application.core.model.Base import Base

class TestCoreModelBaseRead(BaseTestCase):

    def test_base_get_by_id(self):
        _obj = Base()
        _obj.put()
        _obj_id = _obj.key.id()
        _fetched_obj = Base.get_by_id(_obj_id)
        self.assertTrue(_obj.key == _fetched_obj.key)

    def test_base_get_by_id_class_name(self):
        _obj = Base()
        _obj.put()
        _obj_id = _obj.key.id()
        _fetched_obj = Base.get_by_id(_obj_id)
        self.assertTrue(_obj.key.__class__ == _fetched_obj.key.__class__)

if __name__ == '__main__':
    unittest.main()
