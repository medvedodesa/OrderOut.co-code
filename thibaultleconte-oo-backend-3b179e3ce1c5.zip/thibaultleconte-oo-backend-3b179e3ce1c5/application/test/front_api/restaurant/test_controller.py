import pytest

from flask import url_for

from application.apis.restaurant.model import Restaurant
from application.test.api.menu.seed import full_delivery_service_menu


@pytest.mark.usefixtures("db")
class TestController:
    def test_get_my_restaurant(self, user, front_api_client, full_delivery_service_menu):
        all_restaurants = Restaurant.query().fetch()
        assert len(all_restaurants) >= 1

        response = front_api_client.get(url_for("front_api.restaurant_restaurant_root"))
        assert response.json == []
        assert response.status_code == 200

        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.add_user(user.put())

        response = front_api_client.get(url_for("front_api.restaurant_restaurant_root"))

        assert len(response.json) == 1
        assert response.status_code == 200

        user.restaurants = []
        user.put()
        restaurant.users = []
        restaurant.put()


class TestUserManagerController:
    def test_get_users(self, manager_user, front_api_manager_client, full_delivery_service_menu):
        manager_user.restaurants = []
        manager_user.put()

        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.users = []
        restaurant.put()

        all_restaurants = Restaurant.query().fetch()
        assert len(all_restaurants) >= 1

        response = front_api_manager_client.get(
            url_for("front_api.restaurant_restaurant_user_get_post", restaurant_id=restaurant.id)
        )
        assert response.status_code == 401

        restaurant.add_user(manager_user.put())

        response = front_api_manager_client.get(
            url_for("front_api.restaurant_restaurant_user_get_post", restaurant_id=restaurant.id)
        )
        assert len(response.json) == 1
        assert response.status_code == 200

        manager_user.restaurants = []
        manager_user.put()
        restaurant.users = []
        restaurant.put()

    def test_add_user(self, manager_user, front_api_manager_client, full_delivery_service_menu):
        manager_user.restaurants = []
        manager_user.put()

        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.users = []
        restaurant.put()

        all_restaurants = Restaurant.query().fetch()
        assert len(all_restaurants) >= 1

        response = front_api_manager_client.post(
            url_for("front_api.restaurant_restaurant_user_get_post", restaurant_id=restaurant.id),
            json={"email": "newuser@example.org"}
        )
        assert response.status_code == 401

        restaurant.add_user(manager_user.put())

        response = front_api_manager_client.post(
            url_for("front_api.restaurant_restaurant_user_get_post", restaurant_id=restaurant.id),
            json={"email": "newuser@example.org"}
        )

        assert response.status_code == 200

        restaurant = Restaurant.get_by_id(restaurant.id)

        manager_user.restaurants = []
        manager_user.put()
        restaurant.users = []
        restaurant.put()
