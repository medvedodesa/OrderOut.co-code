from datetime import datetime

import pytest
from flask import url_for

from application.test.api.menu.seed import full_delivery_service_menu
from application.test.api.order.factories import OrderFactory


@pytest.mark.usefixtures("db")
class TestOrderReport(object):
    @pytest.fixture
    def account_restaurant_ds(self, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu

        account = delivery_service.account.get()
        restaurant = delivery_service.restaurant.get()

        return account, restaurant, delivery_service

    @pytest.fixture
    def expected_response(self):
        return {
            u"2": {
                u"report": [
                    {
                        u"date": datetime.today().strftime('%Y-%m-%d'),
                        u"amount": 100.0,
                        u"orders": 4,
                        u"summary": {u"UBEREATS": {u"amount": 100.0, u"orders": 4}},
                    }
                ],
                u"summary": {u"UBEREATS": {u"amount": 100.0, u"orders": 4}},
            }
        }

    @pytest.fixture
    def orders(self, account_restaurant_ds):
        account, restaurant, ds = account_restaurant_ds

        orders = []
        for i in range(1, 5):
            order = OrderFactory(
                api_created_at=datetime.now(),
                account=account.key,
                restaurant=restaurant.key,
                delivery_service=ds.key,
                charge_total=i * 10,
            ).put()
            orders.append(order)

    @pytest.mark.usefixtures("orders")
    def test_total(self, user, front_api_client, account_restaurant_ds, expected_response):
        account, restaurant, ds = account_restaurant_ds
        restaurant.add_user(user.key)

        response = front_api_client.get(
            url_for(
                "front_api.front_order_report_order_list",
                account_id=account.id,
                count_days=1,
            ),
        )

        assert response.status_code == 200
        assert response.json == expected_response
