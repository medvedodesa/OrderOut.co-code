import pytest

from flask import url_for

from application.apis.menu.service.fetch.section import fetch_all_sections
from application.test.api.menu.seed import full_delivery_service_menu


@pytest.mark.usefixtures("db")
class TestController:

    def test_get_section_categories(self, user, front_api_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.add_user(user.put())
        restaurant.put()

        section = fetch_all_sections(delivery_service.menuSync)[0]

        response = front_api_client.get(url_for("front_api.menu_category_section_id_category", section_id=section.key.id()))
        assert response.status_code == 200
        assert len(response.json) == 2

    def test_create_section_category(self, user, front_api_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.add_user(user.put())
        restaurant.put()

        section = fetch_all_sections(delivery_service.menuSync)[0]

        response = front_api_client.post(
            url_for("front_api.menu_category_section_id_category", section_id=section.key.id()),
            json={
                "name": "menu category name",
            },
        )
        assert response.status_code == 200

        response = front_api_client.get(url_for("front_api.menu_category_section_id_category", section_id=section.key.id()))
        assert response.status_code == 200
        assert len(response.json) == 3

    def test_edit_category(self, user, front_api_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.add_user(user.put())
        restaurant.put()

        section = fetch_all_sections(delivery_service.menuSync)[0]

        response = front_api_client.post(
            url_for("front_api.menu_category_section_id_category", section_id=section.key.id()),
            json={
                "name": "menu section name",
            },
        )
        assert response.status_code == 200

        response = front_api_client.put(
            url_for("front_api.menu_category_category_id", category_id=response.json["id"]),
            json={
                "position": 2,
                "enabled": False,
            }
        )
        assert response.status_code == 200

        response = front_api_client.get(url_for("front_api.menu_category_category_id", category_id=response.json["id"]))
        assert response.status_code == 200
        assert response.json["position"] == 2
        assert response.json["enabled"] == False

    def test_delete_category(self, user, front_api_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.add_user(user.put())
        restaurant.put()

        section = fetch_all_sections(delivery_service.menuSync)[0]

        response = front_api_client.post(
            url_for("front_api.menu_category_section_id_category", section_id=section.key.id()),
            json={
                "name": "menu section name",
            },
        )
        category_id = response.json["id"]
        assert response.status_code == 200

        response = front_api_client.delete(url_for("front_api.menu_category_category_id", category_id=category_id))
        assert response.status_code == 200

        response = front_api_client.get(url_for("front_api.menu_category_category_id", category_id=category_id))
        assert response.status_code == 401
