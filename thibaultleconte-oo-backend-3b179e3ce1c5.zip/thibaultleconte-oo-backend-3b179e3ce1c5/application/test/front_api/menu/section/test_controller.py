import pytest

from flask import url_for

from application.test.api.menu.seed import full_delivery_service_menu


@pytest.mark.usefixtures("db")
class TestController:

    def test_get_menu_sections(self, user, front_api_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.add_user(user.put())
        restaurant.put()

        response = front_api_client.get(url_for("front_api.menu_section_menu_id_section", menu_id=delivery_service.menuSync.id()))
        assert response.status_code == 200
        assert len(response.json) == 1
        assert response.json[0].get("categories")

    def test_create_menu_section(self, user, front_api_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.add_user(user.put())
        restaurant.put()

        response = front_api_client.post(
            url_for("front_api.menu_section_menu_id_section", menu_id=delivery_service.menuSync.id()),
            json={
                "name": "menu section name",
            },
        )
        assert response.status_code == 200

        response = front_api_client.get(url_for("front_api.menu_section_section_id", section_id=response.json["id"]))
        assert response.status_code == 200

    def test_edit_menu_section(self, user, front_api_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.add_user(user.put())
        restaurant.put()

        response = front_api_client.post(
            url_for("front_api.menu_section_menu_id_section", menu_id=delivery_service.menuSync.id()),
            json={
                "name": "menu section name",
            },
        )
        assert response.status_code == 200

        response = front_api_client.put(
            url_for("front_api.menu_section_section_id", section_id=response.json["id"]),
            json={
                "position": 2,
                "enabled": False,
            }
        )
        assert response.status_code == 200

        response = front_api_client.get(url_for("front_api.menu_section_section_id", section_id=response.json["id"]))
        assert response.status_code == 200
        assert response.json["position"] == 2
        assert response.json["enabled"] == False

    def test_delete_menu_section(self, user, front_api_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.add_user(user.put())
        restaurant.put()

        response = front_api_client.post(
            url_for("front_api.menu_section_menu_id_section", menu_id=delivery_service.menuSync.id()),
            json={
                "name": "menu section name",
            },
        )
        section_id = response.json["id"]
        assert response.status_code == 200

        response = front_api_client.delete(url_for("front_api.menu_section_section_id", section_id=section_id))
        assert response.status_code == 200

        response = front_api_client.get(url_for("front_api.menu_section_section_id", section_id=section_id))
        assert response.status_code == 401

    def test_update_availability(self, user, front_api_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.add_user(user.put())
        restaurant.put()

        response = front_api_client.post(
            url_for("front_api.menu_section_menu_id_section", menu_id=delivery_service.menuSync.id()),
            json={
                "name": "menu section name",
            },
        )
        section_id = response.json["id"]
        assert response.status_code == 200

        response = front_api_client.post(
            url_for("front_api.menu_section_section_id_availability", section_id=section_id),
            json={
                "availability": [
                    {
                        "time_periods": [
                            {
                                "start_time": "01:00",
                                "end_time": "02:00"
                            }
                        ],
                        "enabled": True,
                        "day_of_week": "monday"
                    }
                ]
            }
        )
        assert response.status_code == 200

    def test_update_positions(self, user, front_api_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.add_user(user.put())
        restaurant.put()

        response = front_api_client.get(
            url_for("front_api.menu_section_menu_id_section", menu_id=delivery_service.menuSync.id()))
        assert response.status_code == 200
        assert len(response.json) == 3

        section_ids = []
        section_positions = {}
        for section in response.json:
            section_ids.append(section.get("id"))
            section_positions[section.get("id")] = len(section_ids) - 1

        front_api_client.post(
            url_for("front_api.menu_section_menu_id_section_positions", menu_id=delivery_service.menuSync.id()),
            json={
                "positions": [
                    {
                        "id": section_ids[0],
                        "position": section_positions[section_ids[0]]
                    },
                    {
                        "id": section_ids[1],
                        "position": section_positions[section_ids[1]]
                    },
                    {
                        "id": section_ids[2],
                        "position": section_positions[section_ids[2]]
                    },
                ]
            }
        )
        assert response.status_code == 200

        response = front_api_client.get(
            url_for("front_api.menu_section_menu_id_section", menu_id=delivery_service.menuSync.id()))
        assert response.status_code == 200
        assert len(response.json) == 3

        for section in response.json:
            assert section.get("position") == section_positions[section.get("id")]
