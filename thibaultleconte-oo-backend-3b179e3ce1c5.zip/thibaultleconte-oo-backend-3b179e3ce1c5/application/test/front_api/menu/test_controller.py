import pytest

from flask import url_for

from application.apis.menu.model.MenuSync import MenuSync
from application.apis.restaurant.model import Restaurant
from application.test.api.menu.seed import full_delivery_service_menu


@pytest.mark.usefixtures("db")
class TestController:

    def test_get_restaurant_menus(self, user, front_api_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.put()

        all_restaurants = Restaurant.query().fetch()
        assert len(all_restaurants) >= 1

        response = front_api_client.get(url_for("front_api.menu_restaurant_menu", restaurant_id=restaurant.id))

        assert response.status_code == 401

        restaurant.add_user(user.put())
        restaurant.put()

        response = front_api_client.get(url_for("front_api.menu_restaurant_menu", restaurant_id=restaurant.id))

        assert response.status_code == 200
        assert len(response.json) == 1

    def test_create_restaurant_menu(self, user, front_api_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.add_user(user.put())
        restaurant.put()

        response = front_api_client.post(url_for("front_api.menu_restaurant_menu", restaurant_id=restaurant.id))

        assert response.status_code == 200
        assert response.json.get("id")
        assert response.json.get("author")

    def test_create_menu_with_description(self, user, front_api_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.add_user(user.put())
        restaurant.put()

        response = front_api_client.post(
            url_for("front_api.menu_restaurant_menu", restaurant_id=restaurant.id),
            json={
                "name":"menu name",
                "description":"menu description",
            },
        )

        assert response.status_code == 200
        assert response.json.get("id")
        assert response.json["name"] == "menu name"
        assert response.json["description"] == "menu description"

    def test_delete_menu(self, user, front_api_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.add_user(user.put())
        restaurant.put()

        response = front_api_client.get(url_for("front_api.menu_menu", menu_id=delivery_service.menuSync.id()))

        assert response.status_code == 200
        assert response.json.get("id")

        response = front_api_client.delete(url_for("front_api.menu_menu", menu_id=delivery_service.menuSync.id()))

        assert response.status_code == 200

        response = front_api_client.get(url_for("front_api.menu_menu", menu_id=delivery_service.menuSync.id()))

        assert response.status_code == 401

        ms = MenuSync.get_by_id(delivery_service.menuSync.id(), ignore_status=True)
        ms.api_status = True
        ms.put()

    def test_copy_menu(self, user, front_api_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.add_user(user.put())
        restaurant.put()

        response = front_api_client.get(url_for("front_api.menu_menu", menu_id=delivery_service.menuSync.id()))

        assert response.status_code == 200
        assert response.json.get("id")

        response = front_api_client.post(
            url_for("front_api.menu_menu_copy", menu_id=delivery_service.menuSync.id()),
            json={"name": "menu name"}
        )

        assert response.status_code == 200
        assert response.json.get("id")
        assert response.json["name"] == "menu name"

    def test_batch_delete(self, user, front_api_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        restaurant_key = delivery_service.restaurant

        restaurant = restaurant_key.get()
        restaurant.add_user(user.put())
        restaurant.put()

        response = front_api_client.get(url_for("front_api.menu_menu", menu_id=delivery_service.menuSync.id()))

        assert response.status_code == 200
        assert response.json.get("id")

        response = front_api_client.post(
            url_for("front_api.menu_restaurant_menu_batch_delete", restaurant_id=restaurant.id),
            json={
                "ids": [
                    delivery_service.menuSync.id(),
                    999999
                ]
            }
        )

        assert response.status_code == 200
        assert len(response.json.get("deleted")) == 1
        assert len(response.json.get("error")) == 1

        response = front_api_client.get(url_for("front_api.menu_menu", menu_id=delivery_service.menuSync.id()))

        assert response.status_code == 401

        ms = MenuSync.get_by_id(delivery_service.menuSync.id(), ignore_status=True)
        ms.api_status = True
        ms.put()
