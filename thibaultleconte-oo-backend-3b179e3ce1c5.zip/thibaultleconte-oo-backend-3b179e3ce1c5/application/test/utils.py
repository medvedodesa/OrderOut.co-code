def remove_keys_from_dict(data, keys):
    if type(data) == dict:
        for key in keys:
            data.pop(key, None)

    for key, value in data.items():
        if type(value) == dict:
            remove_keys_from_dict(value, keys)

        if type(value) == list:
            for nested_dict in value:
                remove_keys_from_dict(nested_dict, keys)

    return data
