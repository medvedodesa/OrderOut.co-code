import factory


from application.apis.pointofsale.model.PointOfSale import PointOfSale, PointOfSaleType


class PointOfSaleFactory(factory.Factory):
    class Meta:
        model = PointOfSale

    account = None
    restaurant = None
    type = PointOfSaleType.CLOVER
    access_token = "access_token"
    menuSync = None
