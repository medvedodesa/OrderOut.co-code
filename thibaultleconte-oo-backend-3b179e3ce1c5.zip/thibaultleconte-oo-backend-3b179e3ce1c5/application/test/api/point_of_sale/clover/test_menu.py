import json

import pytest

from application.apis.pointofsale.service.clover.menu import processTaskToFetchMenuFromClover
from application.test.api.account.factories import AccountFactory
from application.test.api.menu.factories import MenuSyncFactory
from application.test.api.point_of_sale.factories import PointOfSaleFactory
from application.test.api.restaurant.factories import RestaurantFactory


@pytest.mark.usefixtures("db")
class TestCloverMenu(object):

    def _get_result_json(self, elements):
        element_json = """
                {
                    "name": "our poke",
                    "price": 1300,
                    "categories": {
                        "elements": []
                    }
                }
        """
        result_json = """{{"elements": [{elements}],"href": "URL"}}""".format(
            elements=",".join([element_json] * elements)
        )
        return json.loads(result_json)

    @pytest.fixture(autouse=True)
    def mock_item_task(self, mocker):
        mocker.patch(
            "application.apis.pointofsale.service.clover.menu.startTaskToCreateOrUpdateMenuItemsAndModifiers",
        )

    @pytest.fixture(autouse=True)
    def menu_sync_key_for_clover(self):
        account_key = AccountFactory().put()

        restaurant_key = RestaurantFactory(
            account=account_key,
        ).put()

        pos_key = PointOfSaleFactory(
            account=account_key,
            restaurant=restaurant_key,
        ).put()

        menu_sync_key = MenuSyncFactory(
            restaurant=restaurant_key,
            service=pos_key,
        ).put()

        return menu_sync_key

    def test_menu_fetch_pagination_5_items(self, menu_sync_key_for_clover, mocker):
        mocker.patch(
            "application.apis.pointofsale.service.clover.menu.__start_fetch_menu_request",
            side_effect=[
                ("URL", 200, self._get_result_json(5)),
            ],
        )

        task_result = processTaskToFetchMenuFromClover(menu_sync_key_for_clover.id(), 10)
        requests = task_result.get("requests")

        assert len(requests) == 1

    def test_menu_fetch_pagination_10_items(self, menu_sync_key_for_clover, mocker):
        mocker.patch(
            "application.apis.pointofsale.service.clover.menu.__start_fetch_menu_request",
            side_effect=[
                ("URL", 200, self._get_result_json(10)),
                ("URL", 200, self._get_result_json(0)),
            ],
        )

        task_result = processTaskToFetchMenuFromClover(menu_sync_key_for_clover.id(), 10)
        requests = task_result.get("requests")

        assert len(requests) == 2

    def test_menu_fetch_pagination_15_items(self, menu_sync_key_for_clover, mocker):
        mocker.patch(
            "application.apis.pointofsale.service.clover.menu.__start_fetch_menu_request",
            side_effect=[
                ("URL", 200, self._get_result_json(10)),
                ("URL", 200, self._get_result_json(5)),
            ],
        )

        task_result = processTaskToFetchMenuFromClover(menu_sync_key_for_clover.id(), 10)
        requests = task_result.get("requests")

        assert len(requests) == 2

    def test_menu_fetch_pagination_30_items(self, menu_sync_key_for_clover, mocker):
        mocker.patch(
            "application.apis.pointofsale.service.clover.menu.__start_fetch_menu_request",
            side_effect=[
                ("URL", 200, self._get_result_json(10)),
                ("URL", 200, self._get_result_json(10)),
                ("URL", 200, self._get_result_json(10)),
                ("URL", 200, self._get_result_json(0)),
            ],
        )

        task_result = processTaskToFetchMenuFromClover(menu_sync_key_for_clover.id(), 10)
        requests = task_result.get("requests")

        assert len(requests) == 4
