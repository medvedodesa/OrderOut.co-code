import pytest

from application.apis.pointofsale.model.PointOfSale import PointOfSale, PointOfSaleType
from application.apis.pointofsale.service.clover.employee.employee import (
    create_or_update_clover_support_employee,
    delete_clover_support_employee,
    SUPPORT_EMAIL,
)
from application.test.api.account.factories import AccountFactory
from application.test.api.restaurant.factories import RestaurantFactory


MAKE_API_REQUEST_PATH = "application.apis.pointofsale.service.clover.employee.employee_api.make_api_request"


@pytest.mark.usefixtures("db")
class TestApiPOSCLoverEmployee(object):

    @pytest.fixture(autouse=True)
    def pos(self):
        pos = PointOfSale()
        pos.account = AccountFactory().put()
        pos.restaurant = RestaurantFactory(account=pos.account).put()
        pos.type = PointOfSaleType.CLOVER
        pos.put()
        return pos

    def test_error_getting_employee(self, pos, mocker):
        mocker.patch(
            MAKE_API_REQUEST_PATH,
            side_effect=[
                ({}, 404),
            ],
        )

        with pytest.raises(Exception):
            create_or_update_clover_support_employee(pos)

    def test_error_creating_employee(self, pos, mocker):
        mocker.patch(
            MAKE_API_REQUEST_PATH,
            side_effect=[
                ({"elements": []}, 200),
                ({"id": "EMPLOYEE_ID"}, 400),
            ],
        )

        with pytest.raises(Exception):
            create_or_update_clover_support_employee(pos)

    def test_error_deleting_employees(self, pos, mocker):
        pos.support_employee_id = "ANY_ID"
        pos.put()

        mocker.patch(
            MAKE_API_REQUEST_PATH,
            side_effect=[
                ({
                    "elements": [{
                        "id": "EMPLOYEE_ID",
                        "email": "another@e.mail",
                    },{
                        "id": "EMPLOYEE_ID_2",
                        "email": SUPPORT_EMAIL,
                    },{
                        "id": "EMPLOYEE_ID_3",
                        "email": SUPPORT_EMAIL,
                    }],
                 }, 200),
                ({}, 400),
            ],
        )

        with pytest.raises(Exception):
            delete_clover_support_employee(pos)

    def test_no_employees(self, pos, mocker):
        mocker.patch(
            MAKE_API_REQUEST_PATH,
            side_effect=[
                ({"elements": []}, 200),
                ({"id": "EMPLOYEE_ID"}, 200),
            ],
        )

        create_or_update_clover_support_employee(pos)

        assert pos.support_employee_id == "EMPLOYEE_ID"

    def test_employee_exists(self, pos, mocker):
        mocker.patch(
            MAKE_API_REQUEST_PATH,
            side_effect=[
                ({
                    "elements": [{
                        "id": "EMPLOYEE_ID",
                        "email": SUPPORT_EMAIL,
                    }],
                 }, 200),
            ],
        )

        create_or_update_clover_support_employee(pos)

        assert pos.support_employee_id == "EMPLOYEE_ID"

    def test_delete_employees(self, pos, mocker):
        pos.support_employee_id = "ANY_ID"
        pos.put()

        mocker.patch(
            MAKE_API_REQUEST_PATH,
            side_effect=[
                ({
                    "elements": [{
                        "id": "EMPLOYEE_ID",
                        "email": "another@e.mail",
                    },{
                        "id": "EMPLOYEE_ID_2",
                        "email": SUPPORT_EMAIL,
                    },{
                        "id": "EMPLOYEE_ID_3",
                        "email": SUPPORT_EMAIL,
                    }],
                 }, 200),
                ({}, 200),
                ({
                     "elements": [{
                         "id": "EMPLOYEE_ID",
                         "email": "another@e.mail",
                     }, {
                         "id": "EMPLOYEE_ID_3",
                         "email": SUPPORT_EMAIL,
                     }],
                 }, 200),
                ({}, 200),
                ({
                     "elements": [{
                         "id": "EMPLOYEE_ID",
                         "email": "another@e.mail",
                     }],
                 }, 200),
            ],
        )

        delete_clover_support_employee(pos)

        assert not pos.support_employee_id