# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/28/2020
#

import unittest
from application.test.base import BaseTestCase
from application.apis.pointofsale.service.clover.lead import fetch_by_merchant_id, create, link_restaurant_to_clover_lead
from application.apis.restaurant.model import Restaurant
from application.apis.account.model import Account
from application.apis.pointofsale.model.PointOfSale import PointOfSaleType
from application.apis.pointofsale.service.common import createPointOfSale, disconnect


CLOVER_MERCHANT_ID = 'merch_123'
CLOVER_EMPLOYEE_ID = 'emp_123'
CLOVER_ACCESS_TOKEN = 'qwerty'
CLOVER_RAW_JSON = {"orderTypes": {"href": "https://www.clover.com/v3/merchants/VN9J9SVRQZ8CY/order_types"}, "name": "LINEAS DE NASKA", "reseller": {"id": "S4D3ADCVE6GAY"}, "shifts": {"href": "https://www.clover.com/v3/merchants/VN9J9SVRQZ8CY/shifts"}, "orders": {"href": "https://www.clover.com/v3/merchants/VN9J9SVRQZ8CY/orders"}, "opening_hours": {"href": "https://www.clover.com/v3/merchants/VN9J9SVRQZ8CY/opening_hours"}, "billingInfo": {"planBillable": True, "appBillable": True, "wmBillable": True}, "printers": {"href": "https://www.clover.com/v3/merchants/VN9J9SVRQZ8CY/printers"}, "isBillable": True, "tenders": {"href": "https://www.clover.com/v3/merchants/VN9J9SVRQZ8CY/tenders"}, "gateway": {}, "createdTime": 1424301075000, "href": "https://www.clover.com/v3/merchants/VN9J9SVRQZ8CY", "phoneNumber": "9146367900", "merchantPlan": {"id": "Q94B0SXGP7JJ6"}, "address": {"city": "NEW ROCHELLE", "zip": "10801", "country": "US", "state": "NY", "href": "https://www.clover.com/v3/merchants/VN9J9SVRQZ8CY/address", "phoneNumber": "9146367900", "address1": "148 NORTH AVE"}, "owner": {"name": "HECTOR AMAYA", "inviteSent": True, "orders": {"href": "https://www.clover.com/v3/merchants/VN9J9SVRQZ8CY/employees/CSETPVNZAEG0R/orders"}, "id": "CSETPVNZAEG0R", "isOwner": True, "href": "https://www.clover.com/v3/merchants/VN9J9SVRQZ8CY/employees/CSETPVNZAEG0R", "role": "ADMIN", "pin": "520602", "customId": "", "email": "HECTORAMAYA52@YAHOO.COM", "claimedTime": 1477146483000}, "taxRates": {"href": "https://www.clover.com/v3/merchants/VN9J9SVRQZ8CY/tax_rates"}, "modifierGroups": {"href": "https://www.clover.com/v3/merchants/VN9J9SVRQZ8CY/modifier_groups"}, "id": "VN9J9SVRQZ8CY", "payments": {"href": "https://www.clover.com/v3/merchants/VN9J9SVRQZ8CY/payments"}}

class TestApiPOSCLoverlead(BaseTestCase):

    def test_pos_clover_lead_no_pos_no_lead(self):
        _clover_lead = fetch_by_merchant_id(clover_merchant_id=CLOVER_MERCHANT_ID, clover_employee_id=CLOVER_EMPLOYEE_ID)
        self.assertFalse(_clover_lead)

    def test_pos_clover_lead_no_pos_with_lead(self):
        _new_clover_lead = create(clover_merchant_id=CLOVER_MERCHANT_ID, clover_employee_id=CLOVER_EMPLOYEE_ID, clover_access_token=CLOVER_ACCESS_TOKEN, raw_json=CLOVER_RAW_JSON)
        _clover_lead = fetch_by_merchant_id(clover_merchant_id=CLOVER_MERCHANT_ID, clover_employee_id=CLOVER_EMPLOYEE_ID)
        self.assertTrue(_clover_lead.key == _new_clover_lead.key)

    def test_pos_clover_lead_pos_with_lead(self):
        _new_clover_lead = create(clover_merchant_id=CLOVER_MERCHANT_ID, clover_employee_id=CLOVER_EMPLOYEE_ID, clover_access_token=CLOVER_ACCESS_TOKEN, raw_json=CLOVER_RAW_JSON)

        _tibo_account = Account.create("Tibo Industries")
        _restaurant = Restaurant.create(name="Tibo Restaurant", account_key=_tibo_account.key)
        _new_pos = createPointOfSale(type=PointOfSaleType.CLOVER, account_key=_tibo_account.key, restaurant_key=_restaurant.key, service_merchant_id=CLOVER_MERCHANT_ID, access_token=CLOVER_ACCESS_TOKEN)

        _clover_lead = fetch_by_merchant_id(clover_merchant_id=CLOVER_MERCHANT_ID, clover_employee_id=CLOVER_EMPLOYEE_ID)
        self.assertTrue(_clover_lead.key == _new_clover_lead.key)

    def test_pos_clover_lead_pos_disconnected_with_lead(self):
        _new_clover_lead = create(clover_merchant_id=CLOVER_MERCHANT_ID, clover_employee_id=CLOVER_EMPLOYEE_ID, clover_access_token=CLOVER_ACCESS_TOKEN, raw_json=CLOVER_RAW_JSON)

        _tibo_account = Account.create("Tibo Industries")
        _restaurant = Restaurant.create(name="Tibo Restaurant", account_key=_tibo_account.key)
        _new_pos = createPointOfSale(type=PointOfSaleType.CLOVER, account_key=_tibo_account.key, restaurant_key=_restaurant.key, service_merchant_id=CLOVER_MERCHANT_ID, access_token=CLOVER_ACCESS_TOKEN)
        disconnect(point_of_sale_key=_new_pos.key)

        _clover_lead = fetch_by_merchant_id(clover_merchant_id=CLOVER_MERCHANT_ID, clover_employee_id=CLOVER_EMPLOYEE_ID)
        self.assertFalse(_clover_lead)

if __name__ == '__main__':
    unittest.main()
