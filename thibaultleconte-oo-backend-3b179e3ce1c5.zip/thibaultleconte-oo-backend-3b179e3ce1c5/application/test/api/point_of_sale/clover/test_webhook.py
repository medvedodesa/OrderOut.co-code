# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 09/25/2019
#

import unittest
from application.test.base import BaseTestCase
from application.apis.pointofsale.service.clover.webhook import get_webhook_action_type_object_type, CLOVER_WEBHOOK_ACTION_TYPE_CREATE, CLOVER_WEBHOOK_OBJECT_TYPE_APP


class TestApiPOSCLoverWebhookActionCreate(BaseTestCase):

    def test_webhook_action_create(self):
        _payload = {"merchants": {"XCST1NEWACRQ1": [{"type": "CREATE", "ts": 1569377728495, "objectId": "A:NWHCH32XVYV40"}]}, "appId": "NWHCH32XVYV40"}
        _action_type, _object_type = get_webhook_action_type_object_type(_payload)
        self.assertTrue(_action_type == CLOVER_WEBHOOK_ACTION_TYPE_CREATE)
        self.assertTrue(_object_type == CLOVER_WEBHOOK_OBJECT_TYPE_APP)

if __name__ == '__main__':
    unittest.main()
