from application.apis.pointofsale.service.clover.order import _format_item_for_clover


class TestCloverOrder(object):

    TWO_CHAR_NAME = "12"
    THREE_CHAR_NAME = "123"
    TEN_CHAR_NAME = "1234567890"
    ONE_HUNDRED_AND_TEN_CHAR_NAME = (
        "12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890"
    )
    ONE_HUNDRED_AND_TWELVE_CHAR_NAME = (
        "12345678901234567890123456789012345678901234567890"
        "12345678901234567890123456789012345678901234567890123456789012"
    )

    @staticmethod
    def mock_item_modifier(mocker, name, price):
        modifier_key = mocker.Mock()
        modifier = mocker.Mock()
        menu_item_modifier = mocker.Mock()
        modifier.menu_item_modifier.get.return_value = menu_item_modifier
        menu_item_modifier.name = name
        menu_item_modifier.price = price
        modifier_key.get.return_value = modifier
        return modifier_key

    @staticmethod
    def mock_order_item(mocker, name, price, modifiers=None, note=None):
        item = mocker.Mock()
        item.store_instructions = note
        if modifiers:
            item.selected_modifier = modifiers
        else:
            item.selected_modifier = []

        menu_item = mocker.Mock()
        menu_item.name = name
        menu_item.price = price
        item.unit_price = price
        item.menu_item.get.return_value = menu_item

        return item

    def test_format_item_name_without_modifiers(self, mocker):
        order_item = self.mock_order_item(mocker=mocker, name="Any name", price=1.0)

        item_json = _format_item_for_clover(order_item, None)

        assert item_json == {"name": "Any name", "price": 100}

    def test_format_item_name_with_less_than_127_chars(self, mocker):
        item_modifiers = [self.mock_item_modifier(mocker, self.TEN_CHAR_NAME, 0.0)]
        order_item = self.mock_order_item(mocker=mocker, name=self.TEN_CHAR_NAME, price=1.0, modifiers=item_modifiers)

        item_json = _format_item_for_clover(order_item, None)

        assert item_json == {"name": self.TEN_CHAR_NAME + " (" + self.TEN_CHAR_NAME + ")", "price": 100}

    def test_format_item_name_with_127_chars(self, mocker):
        item_modifiers = [
            self.mock_item_modifier(mocker, self.ONE_HUNDRED_AND_TWELVE_CHAR_NAME, 0.0),
        ]
        order_item = self.mock_order_item(mocker=mocker, name=self.TEN_CHAR_NAME, price=1.0, modifiers=item_modifiers)

        item_json = _format_item_for_clover(order_item, None)

        assert item_json == {
            "name": self.TEN_CHAR_NAME + " (" + self.ONE_HUNDRED_AND_TWELVE_CHAR_NAME + ")",
            "price": 100,
        }

    def test_format_item_name_with_more_than_127_chars(self, mocker):
        item_modifiers = [
            self.mock_item_modifier(mocker, self.ONE_HUNDRED_AND_TEN_CHAR_NAME, 0.0),
            self.mock_item_modifier(mocker, self.THREE_CHAR_NAME, 0.0),
        ]
        order_item = self.mock_order_item(mocker=mocker, name=self.TEN_CHAR_NAME, price=1.0, modifiers=item_modifiers)

        item_json = _format_item_for_clover(order_item, None)

        assert item_json == {
            "name": self.TEN_CHAR_NAME + " (" + self.ONE_HUNDRED_AND_TEN_CHAR_NAME + "...",
            "note": "... " + self.THREE_CHAR_NAME + ")",
            "price": 100,
        }

    def test_format_item_name_with_more_than_127_chars_and_notes(self, mocker):
        item_modifiers = [
            self.mock_item_modifier(mocker, self.ONE_HUNDRED_AND_TEN_CHAR_NAME, 0.0),
            self.mock_item_modifier(mocker, self.THREE_CHAR_NAME, 0.0),
            self.mock_item_modifier(mocker, self.TWO_CHAR_NAME, 0.0),
        ]
        order_item = self.mock_order_item(
            mocker=mocker, name=self.TEN_CHAR_NAME, price=1.0, modifiers=item_modifiers, note="Any note"
        )

        item_json = _format_item_for_clover(order_item, None)

        assert item_json == {
            "name": self.TEN_CHAR_NAME + " (" + self.ONE_HUNDRED_AND_TEN_CHAR_NAME + "...",
            "note": "... " + self.THREE_CHAR_NAME + ", " + self.TWO_CHAR_NAME + "). Any note",
            "price": 100,
        }

    def test_format_item_name_with_less_than_127_chars_and_notes(self, mocker):
        item_modifiers = [self.mock_item_modifier(mocker, self.TEN_CHAR_NAME, 0.0)]
        order_item = self.mock_order_item(
            mocker=mocker, name=self.TEN_CHAR_NAME, price=1.0, modifiers=item_modifiers, note="Any note"
        )

        item_json = _format_item_for_clover(order_item, None)

        assert item_json == {
            "name": self.TEN_CHAR_NAME + " (" + self.TEN_CHAR_NAME + ")",
            "note": "Any note",
            "price": 100,
        }
