from unittest import TestCase

from application.apis.pointofsale.service.clover.settings.factory import CloverSettingsFactory


class TestCloverSettingsFactory(TestCase):
    def test_should_create_custom_settings(self):
        settings_dict = {
            "send_taxes": True,
            "send_tips": False,
            "send_fees": True,
            "send_items_as_revenue": False
        }
        settings = CloverSettingsFactory().create(settings_dict)

        assert settings.send_taxes
        assert not settings.send_tips
        assert settings.send_fees
        assert not settings.send_items_as_revenue

    def test_should_return_default_settings(self):
        settings = CloverSettingsFactory().create(None)

        assert settings == CloverSettingsFactory.DEFAULT_CLOVER_SETTINGS
