import pytest

from application.apis.pointofsale.service.clover.fees.fee_sender import FeeSender


class TestFeeSender(object):
    @pytest.fixture
    def mock_equivalent_percentage_rate_function(self, mocker):
        mock_send_fee = mocker.patch(
            "application.apis.pointofsale.service.clover.fees.fee_sender.FeeSender._equivalent_percentage_rate"
        )
        return mock_send_fee

    @pytest.fixture
    def mock_make_api_request(self, mocker):
        mock_make_api_request = mocker.patch("application.apis.pointofsale.service.clover.request.make_api_request")
        mock_make_api_request.return_value = (mocker.Mock(), mocker.Mock())
        return mock_make_api_request

    @pytest.fixture
    def mock_pos(self, mocker):
        mock_pos = mocker.Mock()
        mock_pos.service_merchant_id = "any-id"
        return mock_pos

    @pytest.fixture
    def mock_service_charge_id(self):
        return "any-id"

    @staticmethod
    def mock_order_fees(mocker, subtotal, charge_customer_delivery_fee, charge_fee):
        mock_order = mocker.Mock()
        mock_order.key = "any-key"
        mock_order.point_of_sale_uuid = "any-uuid"
        mock_order.charge_subtotal = subtotal
        mock_order.charge_customer_delivery_fee = charge_customer_delivery_fee
        mock_order.charge_fee = charge_fee
        return mock_order

    def test_no_call_if_there_are_no_fees(self, mocker, mock_pos, mock_make_api_request, mock_service_charge_id):
        mock_order = self.mock_order_fees(
            mocker=mocker, subtotal=10.0, charge_customer_delivery_fee=0.0, charge_fee=0.0
        )

        fee_sender = FeeSender(
            request_tool=mock_make_api_request, order=mock_order, pos=mock_pos, service_charge_id=mock_service_charge_id
        )
        fee_sender.send_fees()

        assert mock_make_api_request.call_count == 0

    def test_no_call_if_no_service_charge_id_was_given(
        self, mocker, mock_pos, mock_make_api_request, mock_service_charge_id
    ):
        mock_order = self.mock_order_fees(
            mocker=mocker, subtotal=10.0, charge_customer_delivery_fee=1.0, charge_fee=2.0
        )

        fee_sender = FeeSender(
            request_tool=mock_make_api_request, order=mock_order, pos=mock_pos, service_charge_id=None
        )
        fee_sender.send_fees()

        assert mock_make_api_request.call_count == 0

    def test_name_contains_customer_delivery_fee(self, mocker, mock_pos, mock_make_api_request, mock_service_charge_id):
        mock_order = self.mock_order_fees(
            mocker=mocker, subtotal=10.0, charge_customer_delivery_fee=1.0, charge_fee=0.0
        )

        fee_sender = FeeSender(
            request_tool=mock_make_api_request, order=mock_order, pos=mock_pos, service_charge_id=mock_service_charge_id
        )
        fee_sender.send_fees()

        payload = mock_make_api_request.call_args[1].get("data")
        assert "Customer Delivery Fee" in payload.get("name")

    def test_name_contains_service_fee(self, mocker, mock_pos, mock_make_api_request, mock_service_charge_id):
        mock_order = self.mock_order_fees(
            mocker=mocker, subtotal=10.0, charge_customer_delivery_fee=0.0, charge_fee=2.0
        )

        fee_sender = FeeSender(
            request_tool=mock_make_api_request, order=mock_order, pos=mock_pos, service_charge_id=mock_service_charge_id
        )
        fee_sender.send_fees()

        payload = mock_make_api_request.call_args[1].get("data")
        assert "Service Fee" in payload.get("name")

    def test_name_contains_both_fees(self, mocker, mock_pos, mock_make_api_request, mock_service_charge_id):
        mock_order = self.mock_order_fees(
            mocker=mocker, subtotal=10.0, charge_customer_delivery_fee=1.0, charge_fee=2.0
        )

        fee_sender = FeeSender(
            request_tool=mock_make_api_request, order=mock_order, pos=mock_pos, service_charge_id=mock_service_charge_id
        )
        fee_sender.send_fees()

        payload = mock_make_api_request.call_args[1].get("data")
        assert "Service Fee" in payload.get("name")
        assert "Customer Delivery Fee" in payload.get("name")

    def test_service_charge_id_is_sent(self, mocker, mock_pos, mock_make_api_request, mock_service_charge_id):
        mock_order = self.mock_order_fees(
            mocker=mocker, subtotal=10.0, charge_customer_delivery_fee=1.0, charge_fee=2.0
        )

        fee_sender = FeeSender(
            request_tool=mock_make_api_request, order=mock_order, pos=mock_pos, service_charge_id=mock_service_charge_id
        )
        fee_sender.send_fees()

        payload = mock_make_api_request.call_args[1].get("data")
        assert payload.get("id") == mock_service_charge_id

    def test_customer_delivery_fee_is_considered(
        self, mocker, mock_pos, mock_make_api_request, mock_service_charge_id, mock_equivalent_percentage_rate_function
    ):
        mock_order = self.mock_order_fees(
            mocker=mocker, subtotal=10.0, charge_customer_delivery_fee=1.0, charge_fee=0.0
        )

        fee_sender = FeeSender(
            request_tool=mock_make_api_request, order=mock_order, pos=mock_pos, service_charge_id=mock_service_charge_id
        )

        fee_sender.send_fees()

        expected_absolute_value = mock_equivalent_percentage_rate_function.call_args[1].get("expected_absolute_value")
        assert expected_absolute_value == 1.0

    def test_service_fee_is_considered(
        self, mocker, mock_pos, mock_make_api_request, mock_service_charge_id, mock_equivalent_percentage_rate_function
    ):
        mock_order = self.mock_order_fees(
            mocker=mocker, subtotal=10.0, charge_customer_delivery_fee=0.0, charge_fee=2.0
        )

        fee_sender = FeeSender(
            request_tool=mock_make_api_request, order=mock_order, pos=mock_pos, service_charge_id=mock_service_charge_id
        )

        fee_sender.send_fees()

        expected_absolute_value = mock_equivalent_percentage_rate_function.call_args[1].get("expected_absolute_value")
        assert expected_absolute_value == 2.0

    def test_both_fee_values_are_considered(
        self, mocker, mock_pos, mock_make_api_request, mock_service_charge_id, mock_equivalent_percentage_rate_function
    ):
        mock_order = self.mock_order_fees(
            mocker=mocker, subtotal=10.0, charge_customer_delivery_fee=1.0, charge_fee=2.0
        )

        fee_sender = FeeSender(
            request_tool=mock_make_api_request, order=mock_order, pos=mock_pos, service_charge_id=mock_service_charge_id
        )

        fee_sender.send_fees()

        expected_absolute_value = mock_equivalent_percentage_rate_function.call_args[1].get("expected_absolute_value")
        assert expected_absolute_value == 3.0

    def test_subtotal_is_considered_to_calculate_equivalent_percentage_rate(
        self, mocker, mock_pos, mock_make_api_request, mock_service_charge_id, mock_equivalent_percentage_rate_function
    ):
        mock_order = self.mock_order_fees(
            mocker=mocker, subtotal=10.0, charge_customer_delivery_fee=1.0, charge_fee=2.0
        )

        fee_sender = FeeSender(
            request_tool=mock_make_api_request, order=mock_order, pos=mock_pos, service_charge_id=mock_service_charge_id
        )

        fee_sender.send_fees()

        subtotal = mock_equivalent_percentage_rate_function.call_args[1].get("subtotal")
        assert subtotal == 10.0

    def test_equivalent_percentage_rate_function_edge_cases(self):
        equivalent_percentage_rate = FeeSender._equivalent_percentage_rate(subtotal=0, expected_absolute_value=4.99)
        assert equivalent_percentage_rate == 0

        equivalent_percentage_rate = FeeSender._equivalent_percentage_rate(subtotal=30, expected_absolute_value=4.99)
        assert equivalent_percentage_rate == 166333

        equivalent_percentage_rate = FeeSender._equivalent_percentage_rate(subtotal=33, expected_absolute_value=3.78)
        assert equivalent_percentage_rate == 114545

        equivalent_percentage_rate = FeeSender._equivalent_percentage_rate(subtotal=33, expected_absolute_value=3.73)
        assert equivalent_percentage_rate == 113030
