# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/11/2020
#

import unittest
from application.test.base import BaseTestCase
from application.apis.pointofsale.service.tabit.order import _get_eta
from application.apis.deliveryservice.model.DeliveryService import DeliveryServiceType
import datetime

class TestApiPOSCLoverlead(BaseTestCase):

    def test_pos_tabit_ubereats_eta(self):
        _eta = _get_eta(DeliveryServiceType.UBEREATS,"11/10/20, 12:27 PM")
        self.assertTrue(_eta == "2020-11-10T12:27:00.000000Z")
    
    def test_pos_tabit_ubereats_eta(self):
        _eta = _get_eta(DeliveryServiceType.GRUBHUB,"nov 9, 2020, 11:50 am")
        self.assertTrue(_eta == "2020-11-09T11:50:00.000000Z")

    def test_pos_tabit_ubereats_eta(self):
        _eta = _get_eta(DeliveryServiceType.DOORDASH,"today at 12:19 pm")
        today_date = datetime.datetime.now()
        today_date = today_date.replace(hour=12,minute=19,second=0,microsecond=0)
        final_eta = today_date.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
        self.assertTrue(_eta == final_eta)

if __name__ == '__main__':
    unittest.main()
