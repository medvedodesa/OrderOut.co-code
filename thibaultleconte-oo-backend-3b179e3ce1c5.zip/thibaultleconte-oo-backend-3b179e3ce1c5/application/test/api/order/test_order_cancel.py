# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/03/2019
#

import unittest
from application.test.base import BaseTestCase
from application.apis.restaurant.model import Restaurant
from application.apis.account.model import Account
from application.apis.deliveryservice.model.DeliveryService import DeliveryService, DeliveryServiceType
from application.apis.order.model.Order import Order, OrderStatus, OrderType
from application.apis.order.service.cancel import order_is_canceled


class TestApiOrderCancel(BaseTestCase):

    def test_order_cancel(self):
        _tibo_account = Account.create("Tibo Industries")
        _restaurant = Restaurant.create(name="Tibo Restaurant", account_key=_tibo_account.key)
        _delivery_service = DeliveryService.create(type=DeliveryServiceType.UBEREATS,
                                                   account_key=_tibo_account.key,
                                                   restaurant_key=_restaurant.key)
        _order = Order.create(account_key=_tibo_account.key,
                              restaurant_key=_restaurant.key,
                              status=OrderStatus.RECEIVED,
                              type=OrderType.DELIVERY,
                              delivery_service_key=_delivery_service.key,
                              delivery_service_uuid="order_123456")
        self.assertTrue(_order.status == OrderStatus.RECEIVED)
        _order = order_is_canceled(_order.key)
        self.assertTrue(_order.status == OrderStatus.CANCELLED)


if __name__ == '__main__':
    unittest.main()
