import uuid

import factory

from application.apis.order.model.Order import Order
from application.apis.order.model.Order import OrderStatus, OrderType


class OrderFactory(factory.Factory):
    class Meta:
        model = Order

    account = None
    restaurant = None
    delivery_service = None
    delivery_service_uuid = str(uuid.uuid4())

    status = OrderStatus.CONFIRMED
    type = OrderType.DELIVERY
