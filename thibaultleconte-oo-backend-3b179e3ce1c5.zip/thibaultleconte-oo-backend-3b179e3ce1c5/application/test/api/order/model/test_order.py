from application.test.api.order.factories import OrderFactory


class TestTotalChargeWithoutTip(object):
    def test_zero_if_there_are_no_charges(self):
        order = OrderFactory(
            charge_subtotal=0.0,
            charge_tax=0.0,
            charge_fee=0.0,
            charge_customer_delivery_fee=0.0,
            charge_tip=0.0,
        )
        assert order.total_charge_without_tip == 0.0

    def test_zero_if_there_is_only_tip(self):
        order = OrderFactory(
            charge_tip=1.0,
        )
        assert order.total_charge_without_tip == 0.0

    def test_whether_all_charges_are_considered(self):
        order = OrderFactory(
            charge_subtotal=10.0,
            charge_tax=20.0,
            charge_fee=30.0,
            charge_customer_delivery_fee=40.0,
        )
        assert order.total_charge_without_tip == 100.0

    def test_whether_all_charges_are_considered_except_for_tip(self):
        order = OrderFactory(
            charge_subtotal=10.0,
            charge_tax=20.0,
            charge_fee=30.0,
            charge_customer_delivery_fee=40.0,
            charge_tip=1.0,
        )
        assert order.total_charge_without_tip == 100.0
