import factory

from application.apis.account.model import Account


class AccountFactory(factory.Factory):
    class Meta:
        model = Account

    name = "Account Name"
    owner = None
    users = []
    groups = []
    restaurants = []
