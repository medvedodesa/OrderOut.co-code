# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/14/2019
#

import unittest
from application.test.base import BaseTestCase
from application.apis.account.model import Account
from application.apis.account.service import exists_with_name, check_name_and_create, add_user_to_account, get_by_id_and_populate, remove_user_from_account
from application.apis.user.model.User import User


class TestApiAccountList(BaseTestCase):

    def test_account_list(self):
        _account_name = "Tibo Industries"
        _account = check_name_and_create(_account_name)
        _accounts, _previous_cursor, _next_cursor, _more, _count = Account.list_with_pagination(keys_only=False)
        self.assertTrue(len(_accounts) == 1)

    def test_account_create(self):
        _account_name = "Tibo Industries"
        self.assertFalse(exists_with_name(name=_account_name))
        _tibo_account = Account.create(_account_name)
        self.assertTrue(exists_with_name(name=_account_name))

    def test_account_rename(self):
        _account_name_origin = "Tibo Industries"
        _account_name_new = "Tibo Industries New World"
        _tibo_account = check_name_and_create(_account_name_origin)
        self.assertTrue(_tibo_account.name == _account_name_origin)
        self.assertTrue(exists_with_name(_account_name_origin))
        _json_dict = {'name': _account_name_new}
        _tibo_account = get_by_id_and_populate(_tibo_account.key.id(), _json_dict)
        self.assertTrue(_tibo_account.name == _account_name_new)

    def test_account_delete(self):
        _account_name = "Tibo Industries"
        _tibo_account = check_name_and_create(_account_name)
        self.assertTrue(exists_with_name(name=_account_name))
        _tibo_account.delete()
        self.assertFalse(exists_with_name(name=_account_name))

    def test_account_add_user(self):
        _account_name = "Tibo Industries"
        provider_uuid, provider_payload, email, firstname, lastname = self.generate_fake_user_properties()
        _user = User.create(provider_uuid, provider_payload, email, firstname, lastname)
        _tibo_account = check_name_and_create(_account_name)
        self.assertTrue(len(_tibo_account.users) == 0)
        add_user_to_account(_user.key, _tibo_account.key)
        self.assertTrue(len(_tibo_account.users) == 1)

    def test_account_remove_user(self):
        _account_name = "Tibo Industries"
        provider_uuid, provider_payload, email, firstname, lastname = self.generate_fake_user_properties()
        _user = User.create(provider_uuid, provider_payload, email, firstname, lastname)
        _tibo_account = check_name_and_create(_account_name)
        self.assertTrue(len(_tibo_account.users) == 0)
        add_user_to_account(_user.key, _tibo_account.key)
        self.assertTrue(len(_tibo_account.users) == 1)
        remove_user_from_account(_user.key, _tibo_account.key)
        self.assertTrue(len(_tibo_account.users) == 0)

if __name__ == '__main__':
    unittest.main()
