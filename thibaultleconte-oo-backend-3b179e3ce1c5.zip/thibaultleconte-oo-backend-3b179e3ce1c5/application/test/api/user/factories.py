import uuid

import factory

from application.apis.user.model.User import User


class UserFactory(factory.Factory):
    class Meta:
        model = User

    provider_uuid = str(uuid.uuid4())
    email = "johndoe@example.org"
