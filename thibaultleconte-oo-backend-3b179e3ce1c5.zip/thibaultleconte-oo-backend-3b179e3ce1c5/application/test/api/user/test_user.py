# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/12/2019
#

import unittest
from application.test.base import BaseTestCase
from application.apis.user.model.User import User


class TestApiUser(BaseTestCase):
    def test_user_create_and_exist(self):
        (
            provider_uuid,
            provider_payload,
            email,
            firstname,
            lastname,
        ) = self.generate_fake_user_properties()
        _obj = User.create(provider_uuid, provider_payload, email, firstname, lastname)
        u = User.get_by_email(email)
        self.assertTrue(u.email == email)

    def test_user_list_with_pagination(self):
        limit_to_fetch = 10
        for i in range(0, 19):
            provider_uuid = "uuid_" + str(i)
            provider_payload = {"key": "value"}
            email = "test" + str(i) + "@gmail.com"
            firstname = "fn_" + str(i)
            lastname = "ln_" + str(i)
            User.create(provider_uuid, provider_payload, email, firstname, lastname)
        _objs, _previous_cursor, _next_cursor, _more, _count = User.list_with_pagination(
            limit=limit_to_fetch, keys_only=False
        )
        self.assertTrue(len(_objs) == limit_to_fetch)
        self.assertTrue(_next_cursor)
        self.assertTrue(_previous_cursor)
        self.assertTrue(_more == True)
        _random_idx = 5
        _random_obj = _objs[_random_idx]
        self.assertTrue(_random_obj.email == "test" + str(_random_idx) + "@gmail.com")

    def test_user_exists_with_email(self):
        (
            provider_uuid,
            provider_payload,
            email,
            firstname,
            lastname,
        ) = self.generate_fake_user_properties()
        User.create(provider_uuid, provider_payload, email, firstname, lastname)
        self.assertTrue(User.exists_with_email(email))

    # def test_user_get_by_id_and_populate(self):
    #     self.assertTrue(False)

    # def test_user_get_by_email(self):
    #     self.assertTrue(False)

    # def test_user_create(self):
    #     self.assertTrue(False)


if __name__ == "__main__":
    unittest.main()
