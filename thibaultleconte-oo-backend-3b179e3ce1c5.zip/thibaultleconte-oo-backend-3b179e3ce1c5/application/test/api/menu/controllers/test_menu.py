import json

from freezegun import freeze_time

import pytest
from flask import url_for


from application.test.api.account.factories import AccountFactory
from application.test.api.deliveryservice.factories import DeliveryServiceFactory
from application.test.api.menu.factories import (
    MenuSectionFactory,
    MenuSyncFactory,
    get_default_availability,
)
from application.test.api.point_of_sale.factories import PointOfSaleFactory

from application.test.api.menu.seed import full_delivery_service_menu
from application.test.api.restaurant.factories import RestaurantFactory


@pytest.mark.usefixtures("db")
class TestMenuSectionController(object):

    @pytest.fixture(scope="class")
    @freeze_time("2020-01-30T23:06:00Z")
    def point_of_sale(self, full_delivery_service_menu):
        account_key = AccountFactory().put()
        restaurant_key = RestaurantFactory(account=account_key).put()

        delivery_service = full_delivery_service_menu
        delivery_service_key = delivery_service.key

        ds = delivery_service_key.get()
        menu_sync_key = ds.menuSync

        point_of_sale = PointOfSaleFactory(account=account_key, restaurant=restaurant_key, menuSync=menu_sync_key)
        point_of_sale.put()

        return point_of_sale

    @freeze_time("2020-01-30T23:06:00Z")
    def test_get_menu_by_point_of_sale(self, admin_client, point_of_sale):
        response = admin_client.get(
            url_for(
                "api.menu_menu_get_by_point_of_sale", point_of_sale_id=point_of_sale.id
            )
        )
        assert response.status_code == 200

        expected_response = [{
            u"uuid": u"7ec5cefa-5e20-11ea-8de1-276fc7dce234",
            u"price": 12.34,
            u"name": u"Coffee",
            u"is_available": True,
            u"category_name": None,
            u"modifier_groups": [{
                u"modifiers": [{
                    u"mappedToMenuItemModifier": None,
                    u"price": 1.1,
                    u"uuid": u"b30f355c-5e20-11ea-80f3-b3789bae7a7e",
                    u"name": u"Gift package",
                    u"is_available": True,
                    u"id": 13,
                }, {
                    u"mappedToMenuItemModifier": None,
                    u"price": 2.2,
                    u"uuid": u"c1544cba-5e20-11ea-9a59-bb183ce877b3",
                    u"name": u"Full cutlery",
                    u"is_available": True,
                    u"id": 14,
                }, {
                    u"mappedToMenuItemModifier": None,
                    u"price": 10.12,
                    u"uuid": u"c683d7fa-5e20-11ea-ba66-2b3a054f7a67",
                    u"name": u"Random stuff",
                    u"is_available": True,
                    u"id": 15,
                }],
                u"uuid": u"3124f958-5e22-11ea-a209-bfc70e0667d7",
                u"max_permitted": 2,
                u"is_available": True,
                u"min_permitted": 0,
                u"id": 12,
                u"name": u"General Extras"
            }, {
                u"modifiers": [{
                    u"mappedToMenuItemModifier": None,
                    u"price": 2.3,
                    u"uuid": u"c799638a-5e20-11ea-970c-27db128ea549",
                    u"name": u"Volcanic Suggar",
                    u"is_available": True,
                    u"id": 17,
                }, {
                    u"mappedToMenuItemModifier": None,
                    u"price": 3.21,
                    u"uuid": u"c8106d18-5e20-11ea-bb36-6fbbf42eca74",
                    u"name": u"Himalaia Suggar",
                    u"is_available": True,
                    u"id": 18,
                }],
                u"uuid": u"c724a6f8-5e20-11ea-b816-7f6a1c0937a5",
                u"max_permitted": 2,
                u"is_available": True,
                u"min_permitted": 0,
                u"id": 16,
                u"name": u"Coffee extras"
            }],
            u"id": 8,
            u"mappedToMenuItem": None,
        }, {
            u"uuid": u"97e99a6a-5e20-11ea-be41-efead2745647",
            u"price": 12.34,
            u"name": u"Milk",
            u"is_available": True,
            u"category_name": None,
            u"modifier_groups": [{
                u"modifiers": [{
                    u"mappedToMenuItemModifier": None,
                    u"price": 1.1,
                    u"uuid": u"b30f355c-5e20-11ea-80f3-b3789bae7a7e",
                    u"name": u"Gift package",
                    u"is_available": True,
                    u"id": 13,
                }, {
                    u"mappedToMenuItemModifier": None,
                    u"price": 2.2,
                    u"uuid": u"c1544cba-5e20-11ea-9a59-bb183ce877b3",
                    u"name": u"Full cutlery",
                    u"is_available": True,
                    u"id": 14,
                }, {
                    u"mappedToMenuItemModifier": None,
                    u"price": 10.12,
                    u"uuid": u"c683d7fa-5e20-11ea-ba66-2b3a054f7a67",
                    u"name": u"Random stuff",
                    u"is_available": True,
                    u"id": 15,
                }],
                u"uuid": u"3124f958-5e22-11ea-a209-bfc70e0667d7",
                u"max_permitted": 2,
                u"is_available": True,
                u"min_permitted": 0,
                u"id": 12,
                u"name": u"General Extras"
            }, {
                u"modifiers": [{
                    u"mappedToMenuItemModifier": None,
                    u"price": 2.3,
                    u"uuid": u"c799638a-5e20-11ea-970c-27db128ea549",
                    u"name": u"Volcanic Suggar",
                    u"is_available": True,
                    u"id": 17,
                }, {
                    u"mappedToMenuItemModifier": None,
                    u"price": 3.21,
                    u"uuid": u"c8106d18-5e20-11ea-bb36-6fbbf42eca74",
                    u"name": u"Himalaia Suggar",
                    u"is_available": True,
                    u"id": 18,
                }],
                u"uuid": u"c724a6f8-5e20-11ea-b816-7f6a1c0937a5",
                u"max_permitted": 2,
                u"is_available": True,
                u"min_permitted": 0,
                u"id": 16,
                u"name": u"Coffee extras"
            }],
            u"id": 9,
            u"mappedToMenuItem": None,
        }, {
            u"uuid": u"9e156fae-5e20-11ea-810e-cbc95b5675b7",
            u"price": 12.34,
            u"name": u"Bread",
            u"is_available": True,
            u"category_name": None,
            u"modifier_groups": [{
                u"modifiers": [{
                    u"mappedToMenuItemModifier": None,
                    u"price": 1.1,
                    u"uuid": u"b30f355c-5e20-11ea-80f3-b3789bae7a7e",
                    u"name": u"Gift package",
                    u"is_available": True,
                    u"id": 13,
                }, {
                    u"mappedToMenuItemModifier": None,
                    u"price": 2.2,
                    u"uuid": u"c1544cba-5e20-11ea-9a59-bb183ce877b3",
                    u"name": u"Full cutlery",
                    u"is_available": True,
                    u"id": 14,
                }, {
                    u"mappedToMenuItemModifier": None,
                    u"price": 10.12,
                    u"uuid": u"c683d7fa-5e20-11ea-ba66-2b3a054f7a67",
                    u"name": u"Random stuff",
                    u"is_available": True,
                    u"id": 15,
                }],
                u"uuid": u"3124f958-5e22-11ea-a209-bfc70e0667d7",
                u"max_permitted": 2,
                u"is_available": True,
                u"min_permitted": 0,
                u"id": 12,
                u"name": u"General Extras"
            }],
            u"id": 10,
            u"mappedToMenuItem": None,
        }, {
            u"uuid": u"a5daea48-5e20-11ea-b604-5f8c7b7cd3ac",
            u"price": 12.34,
            u"name": u"Cake",
            u"is_available": True,
            u"category_name": None,
            u"modifier_groups": [{
                u"modifiers": [{
                    u"mappedToMenuItemModifier": None,
                    u"price": 1.1,
                    u"uuid": u"b30f355c-5e20-11ea-80f3-b3789bae7a7e",
                    u"name": u"Gift package",
                    u"is_available": True,
                    u"id": 13,
                }, {
                    u"mappedToMenuItemModifier": None,
                    u"price": 2.2,
                    u"uuid": u"c1544cba-5e20-11ea-9a59-bb183ce877b3",
                    u"name": u"Full cutlery",
                    u"is_available": True,
                    u"id": 14,
                }, {
                    u"mappedToMenuItemModifier": None,
                    u"price": 10.12,
                    u"uuid": u"c683d7fa-5e20-11ea-ba66-2b3a054f7a67",
                    u"name": u"Random stuff",
                    u"is_available": True,
                    u"id": 15,
                }],
                u"uuid": u"3124f958-5e22-11ea-a209-bfc70e0667d7",
                u"max_permitted": 2,
                u"is_available": True,
                u"min_permitted": 0,
                u"id": 12,
                u"name": u"General Extras"
            }],
            u"id": 11,
            u"mappedToMenuItem": None,
        }]

        response_data = response.json
        for menu in response_data:
            for modifier_group in menu["modifier_groups"]:
                for modifier in modifier_group["modifiers"]:
                    modifier.pop("api_created_at")
                modifier_group.pop("api_created_at")
            menu.pop("api_created_at")

        assert response_data == expected_response
