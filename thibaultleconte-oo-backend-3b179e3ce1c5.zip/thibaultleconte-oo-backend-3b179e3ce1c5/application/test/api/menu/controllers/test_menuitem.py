from freezegun import freeze_time

import pytest
from flask import url_for


from application.test.api.account.factories import AccountFactory
from application.test.api.point_of_sale.factories import PointOfSaleFactory

from application.test.api.menu.seed import full_delivery_service_menu
from application.test.api.restaurant.factories import RestaurantFactory


@pytest.mark.usefixtures("db")
class TestMenuSectionController(object):
    @pytest.fixture(scope="class")
    @freeze_time("2020-01-30T23:06:00Z")
    def point_of_sale(self, full_delivery_service_menu):
        account_key = AccountFactory().put()
        restaurant_key = RestaurantFactory(account=account_key).put()

        delivery_service = full_delivery_service_menu
        delivery_service_key = delivery_service.key

        ds = delivery_service_key.get()
        menu_sync_key = ds.menuSync

        point_of_sale = PointOfSaleFactory(
            account=account_key, restaurant=restaurant_key, menuSync=menu_sync_key
        )
        point_of_sale.put()

        return point_of_sale

    @freeze_time("2020-01-30T23:06:00Z")
    def test_get_menu_auto_map_get_by_delivery_service(
        self, api_key_admin_client, point_of_sale
    ):
        delivery_service_id = point_of_sale.menuSync.get().service.id()
        response = api_key_admin_client.get(
            url_for(
                "api.menuitem_menu_auto_map_get_by_delivery_servicev2",
                point_of_sale_id=point_of_sale.id,
                delivery_service_id=delivery_service_id,
            )
        )
        assert response.status_code == 200
