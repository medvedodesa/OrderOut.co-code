import json

from freezegun import freeze_time

import pytest
from flask import url_for

from application.apis.menu.model.MenuSection import MenuSection
from application.test.api.account.factories import AccountFactory
from application.test.api.deliveryservice.factories import DeliveryServiceFactory
from application.test.api.menu.factories import (
    MenuSectionFactory,
    MenuSyncFactory,
    get_default_availability,
)
from application.test.api.restaurant.factories import RestaurantFactory


@pytest.mark.usefixtures("db")
class TestMenuSectionController(object):
    @pytest.fixture(scope="class")
    def menu_section_data(self):
        return {
            "name": "Brunch",
            "position": 0,
            "uuid": "fd0b40aa-43cd-11ea-b2c5-17ca3e3c1f32",
            "description": "Breakfast and Lunch menu",
            "enabled": True,
            "availability": get_default_availability(),
        }

    @pytest.fixture(scope="class")
    @freeze_time("2020-01-30T23:06:00Z")
    def menu_section(self, menu_section_data):
        account_key = AccountFactory().put()
        restaurant_key = RestaurantFactory(account=account_key).put()

        delivery_service = DeliveryServiceFactory(
            account=account_key, restaurant=restaurant_key
        )
        delivery_service_key = delivery_service.put()
        ds_menu_sync_key = MenuSyncFactory(
            restaurant=restaurant_key, service=delivery_service_key
        ).put()

        menu_section = MenuSectionFactory(
            menuSync=ds_menu_sync_key, **menu_section_data
        )
        menu_section.put()
        return menu_section

    @freeze_time("2020-01-30T23:06:00Z")
    def test_get_menu_section(self, api_key_admin_client, menu_section_data, menu_section):
        response = api_key_admin_client.get(
            url_for(
                "api.menusync_menu_section_get_put_delete", section_id=menu_section.id
            )
        )
        assert response.status_code == 200
        response_data = response.json
        assert response_data["api_created_at"] == "2020-01-30T23:06:00"
        assert response_data["name"] == menu_section_data["name"]
        assert response_data["availability"] == menu_section_data["availability"]
        assert type(response_data["availability"]) == list
        assert response_data["uuid"] == menu_section_data["uuid"]
        assert response_data["description"] == menu_section_data["description"]
        assert response_data["enabled"] == menu_section_data["enabled"]

    @freeze_time("2020-01-30T23:06:00Z")
    def test_get_menu_section_string_availability(
        self, api_key_admin_client, menu_section_data, menu_section
    ):
        menu_section.availability = json.dumps(menu_section.availability)
        menu_section.put()

        response = api_key_admin_client.get(
            url_for(
                "api.menusync_menu_section_get_put_delete", section_id=menu_section.id
            )
        )
        assert response.status_code == 200
        response_data = response.json
        assert response_data["api_created_at"] == "2020-01-30T23:06:00"
        assert response_data["name"] == menu_section_data["name"]
        assert response_data["availability"] == menu_section_data["availability"]
        assert type(response_data["availability"]) == list
        assert response_data["uuid"] == menu_section_data["uuid"]
        assert response_data["description"] == menu_section_data["description"]
        assert response_data["enabled"] == menu_section_data["enabled"]

    @freeze_time("2020-02-03T18:26:00Z")
    def test_put_menu_section(self, api_key_admin_client, menu_section_data, menu_section):
        menu_section_data["name"] = "New name"
        menu_section_data["description"] = "New description"
        menu_section_data["position"] = 1
        menu_section_data["enabled"] = False
        menu_section_data["availability"] = [
            {
                u"day_of_week": u"monday",
                u"enabled": True,
                u"time_periods": [{u"end_time": u"14:00", u"start_time": u"09:00"}],
            },
            {
                u"day_of_week": u"tuesday",
                u"enabled": True,
                u"time_periods": [{u"end_time": u"23:59", u"start_time": u"22:05"}],
            },
            {
                u"day_of_week": u"wednesday",
                u"enabled": True,
                u"time_periods": [{u"end_time": u"23:54", u"start_time": u"00:05"}],
            },
        ]

        response = api_key_admin_client.put(
            url_for(
                "api.menusync_menu_section_get_put_delete", section_id=menu_section.id
            ),
            data=json.dumps(menu_section_data),
            content_type="application/json",
        )

        assert response.status_code == 200
        response_data = response.json
        assert response_data["name"] == menu_section_data["name"]
        assert response_data["availability"] == menu_section_data["availability"]
        assert type(response_data["availability"]) == list
        assert response_data["uuid"] == menu_section_data["uuid"]
        assert response_data["description"] == menu_section_data["description"]
        assert response_data["enabled"] == menu_section_data["enabled"]

        menu_section = (
            MenuSection.query()
            .filter(MenuSection.name == menu_section_data["name"])
            .fetch()
        )
        assert type(menu_section[0].availability) == list
