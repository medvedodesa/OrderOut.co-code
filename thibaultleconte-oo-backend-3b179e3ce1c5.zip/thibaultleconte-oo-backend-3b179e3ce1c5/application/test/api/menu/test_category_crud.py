# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/25/2019
#

import unittest
from application.test.base import BaseTestCase
from application.apis.account.model import Account
from application.apis.restaurant.model import Restaurant
from application.apis.deliveryservice.model.DeliveryService import DeliveryService, DeliveryServiceType
from application.apis.menu.model.MenuSync import MenuSync
from application.apis.menu.model.MenuSection import MenuSection
from application.apis.menu.model.MenuCategory import MenuCategory
from application.apis.menu.service.fetch.category import fetch_category
from application.apis.menu.service.crud.category import update_category, delete_category


class TestApiCategoryCrud(BaseTestCase):

    def setUp(self):
        super(TestApiCategoryCrud, self).setUp()
        self.account = Account.create("Tibo Industries")
        self.restaurant = Restaurant.create(name="Tibo Restaurant", account_key=self.account.key)
        self.delivery_service = DeliveryService.create(type=DeliveryServiceType.UBEREATS, account_key=self.account.key, restaurant_key=self.restaurant.key)
        self.menu_sync = MenuSync.create(restaurant_key=self.restaurant.key, service_key=self.delivery_service.key)
        self.section = MenuSection.create(menu_sync_key=self.menu_sync.key, name="Section Name")
        self.category_name = 'Category name'

    def test_category_create(self):
        self.assertFalse(fetch_category(menu_sync_key=self.menu_sync.key, section_key=self.section.key, name=self.category_name))
        _category = MenuCategory.create(menu_sync_key=self.menu_sync.key, section_key=self.section.key, name=self.category_name)
        self.assertTrue(fetch_category(menu_sync_key=self.menu_sync.key, section_key=self.section.key, name=self.category_name))

    def test_category_get(self):
        MenuCategory.create(menu_sync_key=self.menu_sync.key, section_key=self.section.key, name=self.category_name)
        _category = fetch_category(menu_sync_key=self.menu_sync.key, section_key=self.section.key, name=self.category_name)
        self.assertIsNotNone(_category)

    def test_category_update(self):
        _new_name = 'New updated name'
        _category = MenuCategory.create(menu_sync_key=self.menu_sync.key, section_key=self.section.key, name=self.category_name)
        self.assertFalse(_category.name == _new_name)
        _category = update_category(category_key=_category.key, name=_new_name)
        self.assertTrue(_category.name == _new_name)

    def test_category_delete(self):
        _category = MenuCategory.create(menu_sync_key=self.menu_sync.key, section_key=self.section.key, name=self.category_name)
        self.assertTrue(fetch_category(menu_sync_key=self.menu_sync.key, section_key=self.section.key, name=self.category_name))
        delete_category(category_key=_category.key)
        self.assertFalse(fetch_category(menu_sync_key=self.menu_sync.key, section_key=self.section.key, name=self.category_name))

if __name__ == '__main__':
    unittest.main()
