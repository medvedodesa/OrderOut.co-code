# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/19/2019
#

import unittest
from application.test.base import BaseTestCase
from application.apis.account.model import Account
from application.apis.restaurant.model import Restaurant
from application.apis.deliveryservice.model.DeliveryService import DeliveryService, DeliveryServiceType
from application.apis.menu.model.MenuSync import MenuSync
from application.apis.menu.model.MenuSection import MenuSection
from application.apis.menu.service.fetch.section import fetch_section, fetch_all_sections
from application.apis.menu.service.crud.section import update_section


class TestApiSectionCrud(BaseTestCase):

    def setUp(self):
        super(TestApiSectionCrud, self).setUp()
        self.account = Account.create("Tibo Industries")
        self.restaurant = Restaurant.create(name="Tibo Restaurant", account_key=self.account.key)
        self.delivery_service = DeliveryService.create(type=DeliveryServiceType.UBEREATS, account_key=self.account.key, restaurant_key=self.restaurant.key)
        self.menu_sync = MenuSync.create(restaurant_key=self.restaurant.key, service_key=self.delivery_service.key)
        self.section_name = "Section Name"

    def test_get_all_sections(self):
        _sections = fetch_all_sections(menu_sync_key=self.menu_sync.key)
        self.assertTrue(len(_sections) == 0)
        _section = MenuSection.create(menu_sync_key=self.menu_sync.key, name=self.section_name)
        _sections = fetch_all_sections(menu_sync_key=self.menu_sync.key)
        self.assertTrue(len(_sections) == 1)

    def test_section_create(self):
        self.assertFalse(fetch_section(menu_sync_key=self.menu_sync.key, name=self.section_name))
        _section = MenuSection.create(menu_sync_key=self.menu_sync.key, name=self.section_name)
        self.assertTrue(fetch_section(menu_sync_key=self.menu_sync.key, name=self.section_name))

    def test_section_get(self):
        MenuSection.create(menu_sync_key=self.menu_sync.key, name=self.section_name)
        _section = fetch_section(menu_sync_key=self.menu_sync.key, name=self.section_name)
        self.assertIsNotNone(_section)

    def test_section_update(self):
        _new_name = 'New updated name'
        _section = MenuSection.create(menu_sync_key=self.menu_sync.key, name=self.section_name)
        self.assertFalse(_section.name == _new_name)
        _section = update_section(section_key=_section.key, name=_new_name)
        self.assertTrue(_section.name == _new_name)

    def test_section_delete(self):
        _section = MenuSection.create(menu_sync_key=self.menu_sync.key, name=self.section_name)
        self.assertTrue(fetch_section(menu_sync_key=self.menu_sync.key, name=self.section_name))
        _section.delete()
        self.assertFalse(fetch_section(menu_sync_key=self.menu_sync.key, name=self.section_name))

if __name__ == '__main__':
    unittest.main()
