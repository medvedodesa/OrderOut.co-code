from uuid import uuid4

import factory


from application.apis.menu.model.MenuCategory import MenuCategory
from application.apis.menu.model.MenuItem import MenuItem
from application.apis.menu.model.MenuItemModifier import MenuItemModifier
from application.apis.menu.model.MenuModifierGroup import MenuModifierGroup
from application.apis.menu.model.MenuSection import MenuSection
from application.apis.menu.model.MenuSync import MenuSync


# TODO: remove when implements MenuSectionEntity
def get_default_availability():
    availability = []
    days_of_week = [
        "monday",
        "tuesday",
        "wednesday",
        "thursday",
        "friday",
        "saturday",
        "sunday",
    ]
    for day_of_week in days_of_week:
        time_period = {"start_time": "00:00", "end_time": "23:59"}
        day_availability = {
            "day_of_week": day_of_week.lower(),
            "enabled": True,
            "time_periods": [time_period],
        }
        availability.append(day_availability)
    return availability


class MenuSyncFactory(factory.Factory):
    class Meta:
        model = MenuSync

    restaurant = None
    service = None


class MenuSectionFactory(factory.Factory):
    class Meta:
        model = MenuSection

    name = "Brunch"
    availability = get_default_availability()
    position = 0
    uuid = "ab955ca8-534d-11ea-8576-53330e2e3d2d"
    description = "Breakfast and Lunch menu"
    enabled = True
    categories = []


class MenuCategoryFactory(factory.Factory):
    class Meta:
        model = MenuCategory

    section = None
    name = "Drinks"
    uuid = "a5ae0fc4-534d-11ea-8546-5bbb3cb21e24"
    enabled = True


class MenuItemFactory(factory.Factory):
    class Meta:
        model = MenuItem

    name = "Coffee"
    uuid = "fae28a9d-3e78-48da-8d9d-2519e6aedb01"
    price = 12.34
    is_available = True
    mappedToMenuItem = None
    description = "Plain coffee"
    currency = "USD"
    is_alcohol = False
    tax_rate = 0.24
    vat_rate_percentage = 3.45
    disable_instructions = False
    image_url = "http://example.com/image-url"

    categories = []
    modifier_groups = []


class MenuModifierGroupFactory(factory.Factory):
    class Meta:
        model = MenuModifierGroup

    name = "Extras"
    uuid = "90c127ab-3d74-49c7-a478-0a449d41e239"
    min_permitted = 0
    max_permitted = 2
    is_available = True
    items = []
    modifiers = []


class MenuItemModifierFactory(factory.Factory):
    class Meta:
        model = MenuItemModifier

    name = "Volcanic Suggar"
    uuid = "eee9d5f6-616c-4af3-b7d5-abc28feb0356"
    is_available = True
    price = 4.56
    mappedToMenuItemModifier = None
    groups = []
