import pytest


from application.test.api.account.factories import AccountFactory
from application.test.api.deliveryservice.factories import DeliveryServiceFactory
from application.test.api.menu.factories import (
    MenuSectionFactory,
    MenuCategoryFactory,
    MenuItemFactory,
    MenuItemModifierFactory,
    MenuModifierGroupFactory,
    MenuSyncFactory,
)
from application.test.api.restaurant.factories import RestaurantFactory


@pytest.fixture(scope="class")
def menu_sync_key():
    account_key = AccountFactory().put()
    restaurant_key = RestaurantFactory(account=account_key).put()

    delivery_service = DeliveryServiceFactory(
        account=account_key, restaurant=restaurant_key
    )
    delivery_service_key = delivery_service.put()
    ds_menu_sync_key = MenuSyncFactory(
        restaurant=restaurant_key, service=delivery_service_key
    ).put()
    restaurant = restaurant_key.get()
    restaurant.delivery_services.append(delivery_service_key)
    restaurant.put()
    delivery_service.menuSync = ds_menu_sync_key
    delivery_service.put()
    return ds_menu_sync_key


@pytest.fixture(scope="class")
def full_delivery_service_menu():
    account_key = AccountFactory().put()
    restaurant_key = RestaurantFactory(account=account_key).put()

    delivery_service = DeliveryServiceFactory(
        account=account_key, restaurant=restaurant_key
    )
    delivery_service_key = delivery_service.put()
    ds_menu_sync_key = MenuSyncFactory(
        restaurant=restaurant_key, service=delivery_service_key
    ).put()
    delivery_service.menuSync = ds_menu_sync_key
    delivery_service.put()

    menu_section_key = MenuSectionFactory(menuSync=ds_menu_sync_key).put()
    menu_section = menu_section_key.get()
    category_key_1 = MenuCategoryFactory(
        menuSync=ds_menu_sync_key, section=menu_section_key, name="Drinks", uuid="8a820696-5e20-11ea-b85c-3bca604d7cf9",
    ).put()
    category_key_2 = MenuCategoryFactory(
        menuSync=ds_menu_sync_key, section=menu_section_key, name="Foods", uuid="8fcedff2-5e20-11ea-8b64-abae6d0905f0",
    ).put()
    categories = [category_key_1, category_key_2]

    menu_section.categories = categories
    menu_section.put()

    menu_item_key_1 = MenuItemFactory(
        menuSync=ds_menu_sync_key,
        name="Coffee",
        description="Plain coffee",
        categories=[category_key_1],
        uuid="7ec5cefa-5e20-11ea-8de1-276fc7dce234",
    ).put()

    menu_item_key_2 = MenuItemFactory(
        menuSync=ds_menu_sync_key,
        name="Milk",
        description="Plain milk",
        categories=[category_key_1],
        uuid="97e99a6a-5e20-11ea-be41-efead2745647",
    ).put()

    menu_item_key_3 = MenuItemFactory(
        menuSync=ds_menu_sync_key,
        name="Bread",
        description="Plain bread",
        categories=[category_key_2],
        uuid="9e156fae-5e20-11ea-810e-cbc95b5675b7",
    ).put()

    menu_item_key_4 = MenuItemFactory(
        menuSync=ds_menu_sync_key,
        name="Cake",
        description="Plain cake",
        categories=[category_key_2],
        uuid="a5daea48-5e20-11ea-b604-5f8c7b7cd3ac",
    ).put()

    items = [menu_item_key_1, menu_item_key_2, menu_item_key_3, menu_item_key_4]

    menu_modifier_group_key = MenuModifierGroupFactory(
        menuSync=ds_menu_sync_key, name="General Extras", items=items, uuid="3124f958-5e22-11ea-a209-bfc70e0667d7",
    ).put()
    menu_modifier_group = menu_modifier_group_key.get()

    menu_item_modifier_key_1 = MenuItemModifierFactory(
        menuSync=ds_menu_sync_key,
        name="Gift package",
        price=1.10,
        groups=[menu_modifier_group_key],
        uuid="b30f355c-5e20-11ea-80f3-b3789bae7a7e",
    ).put()
    menu_item_modifier_key_2 = MenuItemModifierFactory(
        menuSync=ds_menu_sync_key,
        name="Full cutlery",
        price=2.20,
        groups=[menu_modifier_group_key],
        uuid="c1544cba-5e20-11ea-9a59-bb183ce877b3",
    ).put()
    menu_item_modifier_key_3 = MenuItemModifierFactory(
        menuSync=ds_menu_sync_key,
        name="Random stuff",
        price=10.12,
        groups=[menu_modifier_group_key],
        uuid="c683d7fa-5e20-11ea-ba66-2b3a054f7a67",
    ).put()

    modifiers = [
        menu_item_modifier_key_1,
        menu_item_modifier_key_2,
        menu_item_modifier_key_3,
    ]
    menu_modifier_group.modifiers = modifiers
    menu_modifier_group.put()

    for item_key in menu_modifier_group.items:
        item = item_key.get()
        item.modifier_groups = [menu_modifier_group_key]
        item.put()

    menu_modifier_group_key_2 = MenuModifierGroupFactory(
        menuSync=ds_menu_sync_key,
        name="Coffee extras",
        items=[menu_item_key_1, menu_item_key_2],
        uuid="c724a6f8-5e20-11ea-b816-7f6a1c0937a5",
    ).put()
    menu_modifier_group_2 = menu_modifier_group_key_2.get()

    menu_item_modifier_key_1 = MenuItemModifierFactory(
        menuSync=ds_menu_sync_key,
        name="Volcanic Suggar",
        price=2.30,
        groups=[menu_modifier_group_key_2],
        uuid="c799638a-5e20-11ea-970c-27db128ea549",
    ).put()
    menu_item_modifier_key_2 = MenuItemModifierFactory(
        menuSync=ds_menu_sync_key,
        name="Himalaia Suggar",
        price=3.21,
        groups=[menu_modifier_group_key_2],
        uuid="c8106d18-5e20-11ea-bb36-6fbbf42eca74",
    ).put()

    modifiers = [menu_item_modifier_key_1, menu_item_modifier_key_2]
    menu_modifier_group_2.modifiers = modifiers
    menu_modifier_group_2.put()

    for item_key in menu_modifier_group_2.items:
        item = item_key.get()
        item.modifier_groups = [menu_modifier_group_key]
        item.put()

    return delivery_service
