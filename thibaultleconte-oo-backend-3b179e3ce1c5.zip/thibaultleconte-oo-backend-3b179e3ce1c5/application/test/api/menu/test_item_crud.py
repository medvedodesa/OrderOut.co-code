# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 12/05/2019
#

import unittest

import mock

from application.test.base import BaseTestCase
from application.apis.account.model import Account
from application.apis.restaurant.model import Restaurant
from application.apis.deliveryservice.model.DeliveryService import (
    DeliveryService,
    DeliveryServiceType,
)
from application.apis.menu.model.MenuSync import MenuSync
from application.apis.menu.model.MenuSection import MenuSection
from application.apis.menu.model.MenuCategory import MenuCategory
from application.apis.menu.model.MenuItem import MenuItem
from application.apis.menu.service.fetch.item import fetch_first_by_uuid
from application.apis.menu.service.crud.item import (
    update_item,
    delete_item,
    create_update_item,
)


class TestApiItemCrud(BaseTestCase):
    def setUp(self):
        super(TestApiItemCrud, self).setUp()
        self.account = Account.create("Tibo Industries")
        self.restaurant = Restaurant.create(
            name="Tibo Restaurant", account_key=self.account.key
        )
        self.delivery_service = DeliveryService.create(
            type=DeliveryServiceType.UBEREATS,
            account_key=self.account.key,
            restaurant_key=self.restaurant.key,
        )
        self.menu_sync = MenuSync.create(
            restaurant_key=self.restaurant.key, service_key=self.delivery_service.key
        )
        self.section = MenuSection.create(
            menu_sync_key=self.menu_sync.key, name="Section Name"
        )
        self.category = MenuCategory.create(
            menu_sync_key=self.menu_sync.key,
            section_key=self.section.key,
            name="Category name",
        )
        self.item_name = "item name"
        self.item_uuid = "123"

    def test_item_create(self):
        self.assertFalse(fetch_first_by_uuid(menu_sync_key=self.menu_sync.key, uuid=self.item_uuid, category_key=self.category.key))
        _item = MenuItem.create(menu_sync_key=self.menu_sync.key, category_key=self.category.key, name=self.item_name, uuid=self.item_uuid)
        self.assertTrue(fetch_first_by_uuid(menu_sync_key=self.menu_sync.key, uuid=self.item_uuid, category_key=self.category.key))

    def test_item_get(self):
        MenuItem.create(menu_sync_key=self.menu_sync.key, category_key=self.category.key, name=self.item_name, uuid=self.item_uuid)
        _item = fetch_first_by_uuid(menu_sync_key=self.menu_sync.key, uuid=self.item_uuid, category_key=self.category.key)
        self.assertIsNotNone(_item)

    def test_item_update(self):
        _new_name = "New updated name"
        _item = MenuItem.create(
            menu_sync_key=self.menu_sync.key,
            category_key=self.category.key,
            name=self.item_name,
            uuid=self.item_uuid,
        )
        self.assertFalse(_item.name == _new_name)
        _item = update_item(item_key=_item.key, name=_new_name)
        self.assertTrue(_item.name == _new_name)

    def test_item_delete(self):
        _item = MenuItem.create(menu_sync_key=self.menu_sync.key, category_key=self.category.key, name=self.item_name, uuid=self.item_uuid)
        self.assertTrue(fetch_first_by_uuid(menu_sync_key=self.menu_sync.key, uuid=self.item_uuid, category_key=self.category.key))
        delete_item(item_key=_item.key)
        self.assertFalse(fetch_first_by_uuid(menu_sync_key=self.menu_sync.key, uuid=self.item_uuid, category_key=self.category.key))

if __name__ == "__main__":
    unittest.main()
