from uuid import uuid4

from application.test.base import BaseTestCase
from application.apis.menu.serializers.menu_section_serializers import MenuSectionSchema


class TestMenuSectionSerializer(BaseTestCase):
    @property
    def valid_menu_section_payload(self):
        return {
            "name": "Brunch",
            "position": 2,
            "uuid": uuid4(),
            "description": "Lunch and breakfast menu",
        }

    @property
    def valid_availability_payload(self):
        payload = self.valid_menu_section_payload
        payload["availability"] = [
            {
                "day_of_week": "monday",
                "enabled": False,
                "time_periods": [{"start_time": "22:00", "end_time": "03:00"}],
            }
        ]
        return payload

    @property
    def overlapping_availability_payload(self):
        payload = self.valid_menu_section_payload
        payload["availability"] = [
            {
                "day_of_week": "monday",
                "enabled": True,
                "time_periods": [
                    {"start_time": "22:00", "end_time": "03:00"},
                    {"start_time": "07:00", "end_time": "08:00"},
                    {"start_time": "23:00", "end_time": "00:00"},
                ],
            },
            {
                "day_of_week": "tuesday",
                "enabled": False,
                "time_periods": [
                    {"start_time": "22:00", "end_time": "23:00"},
                    {"start_time": "07:00", "end_time": "08:00"},
                ],
            },
        ]
        return payload

    @property
    def invalid_availability_payload(self):
        payload = self.valid_menu_section_payload
        payload["availability"] = [
            {
                "day_of_week": "moonday",
                "enabled": False,
                "time_periods": [{"start_time": "22:60", "end_time": "03:00"}],
            }
        ]
        return payload

    def test_valid_payload(self):
        schema = MenuSectionSchema()
        menu_section, errors = schema.load(self.valid_menu_section_payload)
        assert not errors

    def test_valid_availability(self):
        schema = MenuSectionSchema()
        menu_section, errors = schema.load(self.valid_availability_payload)

        assert not errors

    def test_invalid_payload(self):
        schema = MenuSectionSchema()
        menu_section, errors = schema.load(self.invalid_availability_payload)

        assert (
            "Invalid value."
            in errors["availability"][0]["time_periods"][0]["start_time"]
        )
        assert "Invalid value." in errors["availability"][0]["day_of_week"]

    def test_fix_overlapping_data(self):
        expected_uuid = "3424a97c-2eaa-4e16-bfb9-d66b1fdc145c"
        payload = self.overlapping_availability_payload
        payload["uuid"] = expected_uuid
        schema = MenuSectionSchema()
        menu_section, errors = schema.load(payload)

        assert not errors
        expected_payload = {
            "position": 2,
            "description": "Lunch and breakfast menu",
            "availability": [
                {
                    "enabled": True,
                    "time_periods": [
                        {"start_time": "22:00", "end_time": "23:59"},
                        {"start_time": "07:00", "end_time": "08:00"},
                        {"start_time": "23:00", "end_time": "23:59"},
                    ],
                    "day_of_week": "monday",
                },
                {
                    "enabled": False,
                    "time_periods": [
                        {"start_time": "22:00", "end_time": "23:00"},
                        {"start_time": "07:00", "end_time": "08:00"},
                    ],
                    "day_of_week": "tuesday",
                },
                {
                    "time_periods": [{"start_time": "00:00", "end_time": "03:00"}],
                    "enabled": True,
                    "day_of_week": "tuesday",
                },
            ],
            "uuid": expected_uuid,
            "name": "Brunch",
        }

        assert menu_section == expected_payload
        assert type(menu_section["availability"]) == list
