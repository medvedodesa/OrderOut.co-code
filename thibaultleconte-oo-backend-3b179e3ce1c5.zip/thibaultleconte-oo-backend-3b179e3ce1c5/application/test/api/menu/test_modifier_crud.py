# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 12/16/2019
#

import unittest

import mock

from application.test.base import BaseTestCase
from application.apis.account.model import Account
from application.apis.restaurant.model import Restaurant
from application.apis.deliveryservice.model.DeliveryService import (
    DeliveryService,
    DeliveryServiceType,
)
from application.apis.menu.model.MenuSync import MenuSync
from application.apis.menu.model.MenuSection import MenuSection
from application.apis.menu.model.MenuCategory import MenuCategory
from application.apis.menu.model.MenuItem import MenuItem
from application.apis.menu.model.MenuModifierGroup import MenuModifierGroup
from application.apis.menu.model.MenuItemModifier import MenuItemModifier
from application.apis.menu.service.fetch.modifier import fetch_first_by_uuid
from application.apis.menu.service.crud.modifier import (
    update_modifier,
    delete_modifier,
    create_update_modifier,
)


class TestApiModifierCrud(BaseTestCase):
    def setUp(self):
        super(TestApiModifierCrud, self).setUp()
        self.account = Account.create("Tibo Industries")
        self.restaurant = Restaurant.create(
            name="Tibo Restaurant", account_key=self.account.key
        )
        self.delivery_service = DeliveryService.create(
            type=DeliveryServiceType.UBEREATS,
            account_key=self.account.key,
            restaurant_key=self.restaurant.key,
        )
        self.menu_sync = MenuSync.create(
            restaurant_key=self.restaurant.key, service_key=self.delivery_service.key
        )
        self.section = MenuSection.create(
            menu_sync_key=self.menu_sync.key, name="Section Name"
        )
        self.category = MenuCategory.create(
            menu_sync_key=self.menu_sync.key,
            section_key=self.section.key,
            name="Category name",
        )
        self.item = MenuItem.create(
            menu_sync_key=self.menu_sync.key,
            category_key=self.category.key,
            name="Item name",
            uuid="123",
        )
        self.modifier_group = MenuModifierGroup.create(
            menu_sync_key=self.menu_sync.key,
            item_key=self.item.key,
            name="Modifier group name",
            uuid="1234",
        )
        self.modifier_name = "Modifier name"
        self.modifier_uuid = "1234"

    def test_item_create(self):
        self.assertFalse(
            fetch_first_by_uuid(
                menu_sync_key=self.menu_sync.key, uuid=self.modifier_uuid
            )
        )
        _m = MenuItemModifier.create(
            menu_sync_key=self.menu_sync.key,
            modifier_group_key=self.modifier_group.key,
            name=self.modifier_name,
            uuid=self.modifier_uuid,
        )
        self.assertTrue(
            fetch_first_by_uuid(
                menu_sync_key=self.menu_sync.key, uuid=self.modifier_uuid
            )
        )

    def test_item_get(self):
        MenuItemModifier.create(
            menu_sync_key=self.menu_sync.key,
            modifier_group_key=self.modifier_group.key,
            name=self.modifier_name,
            uuid=self.modifier_uuid,
        )
        _mg = fetch_first_by_uuid(
            menu_sync_key=self.menu_sync.key, uuid=self.modifier_uuid
        )
        self.assertIsNotNone(_mg)

    def test_item_update(self):
        _new_name = "New updated name"
        _m = MenuItemModifier.create(
            menu_sync_key=self.menu_sync.key,
            modifier_group_key=self.modifier_group.key,
            name=self.modifier_name,
            uuid=self.modifier_uuid,
        )
        self.assertFalse(_m.name == _new_name)
        _mg = update_modifier(modifier_key=_m.key, name=_new_name)
        self.assertTrue(_m.name == _new_name)

    def test_item_delete(self):
        _m = MenuItemModifier.create(
            menu_sync_key=self.menu_sync.key,
            modifier_group_key=self.modifier_group.key,
            name=self.modifier_name,
            uuid=self.modifier_uuid,
        )
        self.assertTrue(
            fetch_first_by_uuid(
                menu_sync_key=self.menu_sync.key, uuid=self.modifier_uuid
            )
        )
        delete_modifier(modifier_key=_m.key)
        self.assertFalse(
            fetch_first_by_uuid(
                menu_sync_key=self.menu_sync.key, uuid=self.modifier_uuid
            )
        )

    @mock.patch("application.apis.menu.service.crud.modifier.add_modifier_to_group")
    @mock.patch("application.apis.menu.service.crud.modifier.update_modifier")
    def test_create_update_item(self, mock_add_modifier, mock_update_modifier):
        menu_sync_key = mock.Mock()
        category_key = mock.Mock()
        name = "name"

        with mock.patch(
            "application.apis.menu.service.crud.modifier.MenuItemModifier"
        ) as mock_menu_item_modifier:
            create_update_modifier(menu_sync_key, category_key, name, uuid=None)
            assert mock_menu_item_modifier.create.called


if __name__ == "__main__":
    unittest.main()
