import unittest
from application.test.base import BaseTestCase
from application.apis.deliveryservice.service.chownow.order import build_items_array_from_raw_menu_items

class TestApiDSChownowOrderParsing(BaseTestCase):

    # Sample 1 - With unitPrice key
    def test_build_items_array_sample_unitPrice_key(self):
        raw_menu_items = [{"quantity":"1","unitPrice":None,"description":"Two Large 16\" Cheese Pizzas"},
                            {"quantity":None,"unitPrice":"$17.99","description":"Regular"},
                            {"quantity":"1","unitPrice":None,"description":"Curbside Pickup- Add To Cart!"},
                            {"quantity":None,"unitPrice":"$0.00","description":"Regular"},
                            {"quantity":"1","unitPrice":None,"description":"Fountain Drink"},
                            {"quantity":None,"unitPrice":"$1.75","description":"Regular"},
                            {"quantity":"1","unitPrice":None,"description":"Garlic Knots with Sauce"},
                            {"quantity":None,"unitPrice":"$1.95","description":"Regular"},
                            {"quantity":"--","unitPrice":"($5.00)","description":"$5.00 off orders over $20.00, all day every day, for a limited time only, once per customer"}]
        items_array = build_items_array_from_raw_menu_items(raw_menu_items)
        self.assertTrue(len(items_array) == 4)
        first_item = items_array[0]
        first_item_modifiers_list = first_item.get('modifiers_list')
        self.assertTrue(len(first_item_modifiers_list) == 0)

    # Sample 2 - With price key
    def test_build_items_array_sample_price_key(self):
        raw_menu_items = [{"price":None,"quantity":"1","description":"Curbside Pickup- Add To Cart!"},
                            {"price":"$0.00","quantity":None,"description":"Regular"},
                            {"price":None,"quantity":"1","description":"Cheese Ravioli"},
                            {"price":"$9.95","quantity":None,"description":"Regular"},
                            {"price":None,"quantity":"1","description":"Meat Lasagna"},
                            {"price":"$11.95","quantity":None,"description":"Regular"},
                            {"price":"($5.00)","quantity":"--","description":"$5.00 off orders over $20.00, all day every day, for a limited time only, once per customer"}]
        items_array = build_items_array_from_raw_menu_items(raw_menu_items)
        self.assertTrue(len(items_array) == 3)
        first_item = items_array[0]
        first_item_modifiers_list = first_item.get('modifiers_list')
        self.assertTrue(len(first_item_modifiers_list) == 0)

    # Sample 3 - No Modifier
    def test_build_items_array_sample_no_modifiers(self):
        raw_menu_items = [{"price":None,"quantity":"1","description":"Curbside Pickup- Add To Cart!"},
                            {"price":"$0.00","quantity":None,"description":"Regular"},
                            {"price":None,"quantity":"1","description":"Cheese Ravioli"},
                            {"price":"$9.95","quantity":None,"description":"Regular"},
                            {"price":"($5.00)","quantity":"--","description":"$5.00 off orders over $20.00, all day every day, for a limited time only, once per customer"}]
        items_array = build_items_array_from_raw_menu_items(raw_menu_items)
        self.assertTrue(len(items_array) == 2)
        first_item = items_array[0]
        first_item_modifiers_list = first_item.get('modifiers_list')
        self.assertTrue(len(first_item_modifiers_list) == 0)
        second_item = items_array[1]
        second_item_modifiers_list = second_item.get('modifiers_list')
        self.assertTrue(len(second_item_modifiers_list) == 0)

    # Sample 4 - Single Modifier
    def test_build_items_array_sample_single_modifiers(self):
        raw_menu_items = [{"price":None,"quantity":"1","description":"Cheese Ravioli"},
                            {"price":"$9.95","quantity":None,"description":"Regular"},
                            {"price":None,"quantity":None,"description":"Salad Dressings"},
                            {"price":"-","quantity":None,"description":"Light Balsamic Dressing"},
                            {"price":None,"quantity":"1","description":"Meat Lasagna"},
                            {"price":"$11.95","quantity":None,"description":"Regular"},
                            {"price":None,"quantity":None,"description":"Salad Dressings"},
                            {"price":"-","quantity":None,"description":"No Dressing"},
                            {"price":"($5.00)","quantity":"--","description":"$5.00 off orders over $20.00, all day every day, for a limited time only, once per customer"}]
        items_array = build_items_array_from_raw_menu_items(raw_menu_items)
        self.assertTrue(len(items_array) == 2)
        first_item = items_array[0]
        first_item_modifiers_list = first_item.get('modifiers_list')
        self.assertTrue(len(first_item_modifiers_list) == 1)
        self.assertTrue(first_item_modifiers_list[0] == 'light balsamic dressing')
        second_item = items_array[1]
        second_item_modifiers_list = second_item.get('modifiers_list')
        self.assertTrue(len(second_item_modifiers_list) == 1)
        self.assertTrue(second_item_modifiers_list[0] == 'no dressing')

    # Sample 5 - Multiple Modifiers
    def test_build_items_array_sample_multiple_modifiers(self):
        raw_menu_items = [{"quantity":"1","description":"Garlic Knots with Sauce","unitPrice":None},
                            {"quantity":None,"description":"Regular","unitPrice":"$1.95"},
                            {"quantity":"1","description":"Tuna Melt Baguette","unitPrice":None},
                            {"quantity":None,"description":"Regular","unitPrice":"$7.95"},
                            {"quantity":None,"description":"Sandwich options","unitPrice":None},
                            {"quantity":None,"description":"Baked in oven","unitPrice":"-"},
                            {"quantity":"1","description":"Cheese Pizza 18\" X-Large","unitPrice":None},
                            {"quantity":None,"description":"18\" X-Large","unitPrice":"$14.95"},
                            {"quantity":None,"description":"Sandwich options","unitPrice":None},
                            {"quantity":None,"description":"Baked in oven","unitPrice":"-"},
                            {"quantity":None,"description":"No onions","unitPrice":"-"},
                            {"quantity":"--","description":"$5.00 off orders over $20.00, all day every day, for a limited time only, once per customer","unitPrice":"($5.00)"}]
        items_array = build_items_array_from_raw_menu_items(raw_menu_items)
        self.assertTrue(len(items_array) == 3)
        first_item = items_array[0]
        first_item_modifiers_list = first_item.get('modifiers_list')
        self.assertTrue(len(first_item_modifiers_list) == 0)
        second_item = items_array[1]
        second_item_modifiers_list = second_item.get('modifiers_list')
        self.assertTrue(len(second_item_modifiers_list) == 1)
        self.assertTrue(second_item_modifiers_list[0] == 'baked in oven')
        third_item = items_array[2]
        third_item_modifiers_list = third_item.get('modifiers_list')
        self.assertTrue(len(third_item_modifiers_list) == 2)
        self.assertTrue(third_item_modifiers_list[0] == 'baked in oven')
        self.assertTrue(third_item_modifiers_list[1] == 'no onions')

    # Sample 6 - Modifier has price
    def test_build_items_array_sample_modifiers_has_price(self):
        raw_menu_items = [{"quantity":"1","description":"Garlic Knots with Sauce","unitPrice":None},
                            {"quantity":None,"description":"Regular","unitPrice":"$1.95"},
                            {"quantity":None,"description":"Extra Marinara Sauce","unitPrice":None},
                            {"quantity":None,"description":"Extra Marinara Sauce","unitPrice":"$0.50"},
                            {"quantity":"1","description":"Tuna Melt Baguette","unitPrice":None},
                            {"quantity":None,"description":"Regular","unitPrice":"$7.95"},
                            {"quantity":"1","description":"Cheese Pizza 18\" X-Large","unitPrice":None},
                            {"quantity":None,"description":"18\" X-Large","unitPrice":"$14.95"},
                            {"quantity":"--","description":"$5.00 off orders over $20.00, all day every day, for a limited time only, once per customer","unitPrice":"($5.00)"}]
        items_array = build_items_array_from_raw_menu_items(raw_menu_items)
        self.assertTrue(len(items_array) == 3)
        first_item = items_array[0]
        first_item_modifiers_list = first_item.get('modifiers_list')
        self.assertTrue(len(first_item_modifiers_list) == 1)
        first_item_modifier_group = first_item.get('modifier_group')
        first_item_modifiers = first_item_modifier_group[0].get('modifiers')
        first_item_first_modifier_price = first_item_modifiers[0].get('price')
        self.assertTrue(first_item_first_modifier_price == 0.5)

    # Sample 7 - Modifier has no price
    def test_build_items_array_sample_modifiers_no_price(self):
        raw_menu_items = [{"quantity":"1","description":"Garlic Knots with Sauce","unitPrice":None},
                            {"quantity":None,"description":"Regular","unitPrice":"$1.95"},
                            {"quantity":None,"description":"Extra Marinara Sauce","unitPrice":None},
                            {"quantity":None,"description":"Extra Marinara Sauce","unitPrice":"-"},
                            {"quantity":"1","description":"Tuna Melt Baguette","unitPrice":None},
                            {"quantity":None,"description":"Regular","unitPrice":"$7.95"},
                            {"quantity":"1","description":"Cheese Pizza 18\" X-Large","unitPrice":None},
                            {"quantity":None,"description":"18\" X-Large","unitPrice":"$14.95"},
                            {"quantity":"--","description":"$5.00 off orders over $20.00, all day every day, for a limited time only, once per customer","unitPrice":"($5.00)"}]
        items_array = build_items_array_from_raw_menu_items(raw_menu_items)
        self.assertTrue(len(items_array) == 3)
        first_item = items_array[0]
        first_item_modifiers_list = first_item.get('modifiers_list')
        self.assertTrue(len(first_item_modifiers_list) == 1)
        first_item_modifier_group = first_item.get('modifier_group')
        first_item_modifiers = first_item_modifier_group[0].get('modifiers')
        first_item_first_modifier_price = first_item_modifiers[0].get('price')
        self.assertTrue(first_item_first_modifier_price == 0.0)

    # Sample 8 - instructions
    def test_build_items_array_sample_no_modifiers_instructions(self):
        raw_menu_items = [{"price":None,"quantity":"1","description":"Curbside Pickup- Add To Cart!"},
                            {"price":"$0.00","quantity":None,"description":"Regular"},
                            {"price":None,"quantity":None,"description":"* Grey bmw 328"},
                            {"price":None,"quantity":"1","description":"Cheese Ravioli"},
                            {"price":"$9.95","quantity":None,"description":"Regular"},
                            {"price":None,"quantity":None,"description":"Salad Dressings"},
                            {"price":"-","quantity":None,"description":"Light Balsamic Dressing"},
                            {"price":None,"quantity":None,"description":"* On side please"},
                            {"price":None,"quantity":"1","description":"Meat Lasagna"},
                            {"price":"$11.95","quantity":None,"description":"Regular"},
                            {"price":None,"quantity":None,"description":"Salad Dressings"},
                            {"price":"-","quantity":None,"description":"Light Balsamic Dressing"},
                            {"price":"-","quantity":None,"description":"No onions"},
                            {"price":None,"quantity":None,"description":"* Hot spicy please"},
                            {"price":"($5.00)","quantity":"--","description":"$5.00 off orders over $20.00, all day every day, for a limited time only, once per customer"}]
        items_array = build_items_array_from_raw_menu_items(raw_menu_items)
        self.assertTrue(len(items_array) == 3)
        # No Modifier with instruction
        first_item = items_array[0]
        self.assertTrue(first_item.get('name') == 'curbside pickup- add to cart!')
        self.assertTrue(first_item.get('price') == 0.0)
        self.assertTrue(first_item.get('quantity') == '1')
        self.assertTrue(len(first_item.get('modifiers_list')) == 0)
        self.assertTrue(first_item.get('instructions') == 'grey bmw 328')
        # Single Modifier with instruction
        second_item = items_array[1]
        self.assertTrue(second_item.get('name') == 'cheese ravioli')
        self.assertTrue(second_item.get('price') == 9.95)
        self.assertTrue(second_item.get('quantity') == '1')
        self.assertTrue(len(second_item.get('modifiers_list')) == 1)
        self.assertTrue(second_item.get('instructions') == 'on side please')
        # Multiple Modifier with instruction
        third_item = items_array[2]
        self.assertTrue(third_item.get('name') == 'meat lasagna')
        self.assertTrue(third_item.get('price') == 11.95)
        self.assertTrue(third_item.get('quantity') == '1')
        self.assertTrue(len(third_item.get('modifiers_list')) == 2)
        self.assertTrue(third_item.get('instructions') == 'hot spicy please')

if __name__ == '__main__':
    unittest.main()