# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/17/2020
#

import unittest
from application.test.base import BaseTestCase
from application.apis.deliveryservice.service.common.parseur import get_store_id_from_incoming_email


class TestApiDeliveryServiceParseurIncomingEmail(BaseTestCase):

    def test_ds_parseur_incoming_email_grubhub(self):
        _store_id = '1234'
        _to_test_email = 'oogh+%s@in.parseur.com' % (str(_store_id))
        _final = get_store_id_from_incoming_email(_to_test_email, source_entity_key=None)
        self.assertTrue(_final == _store_id)

    def test_ds_parseur_incoming_email_doordash(self):
        _store_id = '1234'
        _to_test_email = 'oodd+%s@in.parseur.com' % (str(_store_id))
        _final = get_store_id_from_incoming_email(_to_test_email, source_entity_key=None)
        self.assertTrue(_final == _store_id)

    def test_ds_parseur_incoming_email_chownow(self):
        _store_id = '1234'
        _to_test_email = 'oocn+%s@in.parseur.com' % (str(_store_id))
        _final = get_store_id_from_incoming_email(_to_test_email, source_entity_key=None)
        self.assertTrue(_final == _store_id)

    def test_ds_parseur_incoming_email_incorrect(self):
        _store_id = '1234'
        _to_test_email = 'ooxx+@in.parseur.com'
        _final = get_store_id_from_incoming_email(_to_test_email, source_entity_key=None)
        self.assertFalse(_final == _store_id)


if __name__ == '__main__':
    unittest.main()
