import pytest
from google.appengine.ext import ndb
from mock.mock import Mock

from application.apis.deliveryservice.service.common.events import *
from application.apis.deliveryservice.model.DeliveryService import DeliveryServiceType
from application.core.event.model import CoreEvent, CoreEventCategory


@pytest.mark.usefixtures("db")
class TestDeliveryServiceCoreEvents(object):

    @pytest.fixture(autouse=True)
    def mock_user(self, mocker):
        user_key = Mock()
        user_key.key = ndb.Key('user', 5)
        mocker.patch(
            "application.apis.deliveryservice.service.common.events.get_current_user",
            return_value=user_key
        )

    def test_save_connect_event(self):
        save_connect_event(
            ds_type=DeliveryServiceType.UBEREATS,
            success=True,
            account=ndb.Key('account', 1),
            restaurant=ndb.Key('restaurant', 2),
            ds=ndb.Key('deliveryservice', 3),
            pos=ndb.Key('pointofsale', 4),
        )

        query = CoreEvent.query()
        query = query.filter(CoreEvent.category == CoreEventCategory.DS_CONNECT)
        event = query.get()

        assert event.message == 'Delivery Service CONNECT'
        assert event.name == 'UBEREATS'
        assert event.user_key.id() == 5

    def test_save_disconnect_event(self):
        save_disconnect_event(
            ds_type=DeliveryServiceType.UBEREATS,
            success=True,
            account=ndb.Key('account', 1),
            restaurant=ndb.Key('restaurant', 2),
            ds=ndb.Key('deliveryservice', 3),
            pos=ndb.Key('pointofsale', 4),
        )

        query = CoreEvent.query()
        query = query.filter(CoreEvent.category == CoreEventCategory.DS_DISCONNECT)
        event = query.get()

        assert event.message == 'Delivery Service DISCONNECT'
        assert event.name == 'UBEREATS'
        assert event.user_key.id() == 5

    def test_save_enable_event(self):
        save_status_event(
            enabled=True,
            ds_type=DeliveryServiceType.UBEREATS,
            success=True,
            account=ndb.Key('account', 1),
            restaurant=ndb.Key('restaurant', 2),
            ds=ndb.Key('deliveryservice', 3),
            pos=ndb.Key('pointofsale', 4),
        )

        query = CoreEvent.query()
        query = query.filter(CoreEvent.category == CoreEventCategory.DS_ENABLE)
        event = query.get()

        assert event.message == 'Delivery Service ENABLE'
        assert event.name == 'UBEREATS'
        assert event.user_key.id() == 5

    def test_save_disable_event(self):
        save_status_event(
            enabled=False,
            ds_type=DeliveryServiceType.UBEREATS,
            success=True,
            account=ndb.Key('account', 1),
            restaurant=ndb.Key('restaurant', 2),
            ds=ndb.Key('deliveryservice', 3),
            pos=ndb.Key('pointofsale', 4),
        )

        query = CoreEvent.query()
        query = query.filter(CoreEvent.category == CoreEventCategory.DS_DISABLE)
        event = query.get()

        assert event.message == 'Delivery Service DISABLE'
        assert event.name == 'UBEREATS'
        assert event.user_key.id() == 5
