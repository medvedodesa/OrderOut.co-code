import factory


from application.apis.deliveryservice.model.DeliveryService import (
    DeliveryService,
    DeliveryServiceType,
)


class DeliveryServiceFactory(factory.Factory):
    class Meta:
        model = DeliveryService

    type = DeliveryServiceType(1)
    account = None
    restaurant = account
    serviceLocationId = ""
    serviceData = None
    point_of_sale_tender_id = None
    point_of_sale_order_type_id = None
    menuSync = None
    incomingOrderEmailVerification = None
    integration_enabled = False
