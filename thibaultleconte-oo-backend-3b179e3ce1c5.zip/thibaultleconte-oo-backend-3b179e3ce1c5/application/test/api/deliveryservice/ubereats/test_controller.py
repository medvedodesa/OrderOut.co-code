import pytest
from flask import url_for
from google.appengine.ext import ndb
from mock.mock import Mock

from application.core.event.model import CoreEvent, CoreEventCategory
from application.test.api.menu.seed import full_delivery_service_menu


@pytest.mark.usefixtures("db")
class TestDeliveryServiceUberEatsConnect(object):

    @pytest.fixture(autouse=True)
    def mock_task_to_fetch_menu(self, mocker):
        mocker.patch("application.apis.deliveryservice.controller.ubereats.startTaskToFetchMenu")

    @pytest.fixture(autouse=True)
    def mock_user(self, mocker):
        user_key = Mock()
        user_key.key = ndb.Key('user', 1)
        mocker.patch(
            "application.apis.deliveryservice.service.common.events.get_current_user",
            return_value=user_key
        )

    def test_connect_core_event(self, api_key_admin_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        delivery_service.put()

        restaurant = delivery_service.restaurant.get()
        payload = {
            "storeId": 'storeId',
        }

        api_key_admin_client.post(
            url_for(
                "api.DS-ubereats_delivery_service_uber_eats_connect",
                restaurant_id=restaurant.id,
            ),
            json=payload,
        )

        query = CoreEvent.query()
        query = query.filter(CoreEvent.category == CoreEventCategory.DS_CONNECT)
        event = query.get()

        assert event.message == 'Delivery Service CONNECT'
        assert event.name == 'UBEREATS'
        assert event.user_key.id() == 1
