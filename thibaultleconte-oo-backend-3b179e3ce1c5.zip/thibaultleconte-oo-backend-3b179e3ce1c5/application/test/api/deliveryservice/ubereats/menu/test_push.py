import pytest

from application.apis.deliveryservice.service.ubereats.menu.push import processTaskToPushMenuToUberEats
from application.test.api.account.factories import AccountFactory
from application.test.api.deliveryservice.factories import DeliveryServiceFactory
from application.test.api.menu.factories import (
    MenuSyncFactory,
    MenuSectionFactory,
    MenuCategoryFactory,
    MenuItemFactory,
    MenuModifierGroupFactory,
    MenuItemModifierFactory,
)
from application.test.api.restaurant.factories import RestaurantFactory


class UrlRequestFetch(object):
    pass


@pytest.mark.usefixtures("db")
@pytest.mark.integration_test
class TestMenuPush(object):

    def fetch(self, method, url, service, headers, data):
        import requests
        import json
        response = requests.put(url, json.dumps(data), headers=headers)
        print json.dumps(data, indent=4)
        print response.content
        return response.content, response.status_code, None

    @pytest.fixture(autouse=True)
    def mocks(self, mocker):
        mocker.patch(
            "application.apis.pointofsale.service.clover.menu.startTaskToCreateOrUpdateMenuItemsAndModifiers",
        )
        mocker.patch(
            "application.apis.deliveryservice.service.ubereats.menu.push.fetch_with_json_data",
            side_effect=self.fetch
        )

    def delivery_service(self, item_id, modifier_group_id):
        account_key = AccountFactory().put()
        restaurant_key = RestaurantFactory(
            account=account_key,
        ).put()
        delivery_service_key = DeliveryServiceFactory(
            account=account_key,
            restaurant=restaurant_key,
        ).put()
        menu_sync_key = MenuSyncFactory(
            restaurant=restaurant_key,
            service=delivery_service_key,
        ).put()
        menu_section_key = MenuSectionFactory(
            menuSync=menu_sync_key,
        ).put()
        menu_category_key = MenuCategoryFactory(
            menuSync=menu_sync_key,
            section=menu_section_key,
        ).put()
        menu_item_key = MenuItemFactory(
            menuSync=menu_sync_key,
            categories=[menu_category_key],
            uuid=item_id,
        ).put()
        menu_modifier_group_key = MenuModifierGroupFactory(
            menuSync=menu_sync_key,
            items=[menu_item_key],
            uuid=modifier_group_id,
        ).put()
        menu_modifier_item_key = MenuItemModifierFactory(
            menuSync=menu_sync_key,
            groups=[menu_modifier_group_key],
        ).put()

        menu_modifier_group = menu_modifier_group_key.get()
        menu_modifier_group.modifiers = [menu_modifier_item_key]
        menu_modifier_group.put()

        menu_item = menu_item_key.get()
        menu_item.modifier_groups = [menu_modifier_group_key]
        menu_item.put()

        menu_section = menu_section_key.get()
        menu_section.categories = [menu_category_key]
        menu_section.put()

        delivery_service = delivery_service_key.get()
        delivery_service.menuSync = menu_sync_key
        delivery_service.put()

        return delivery_service_key

    def test_push_no_duplicates(self):
        delivery_service_key = self.delivery_service(
            item_id="ID_1",
            modifier_group_id="ID_2"
        )

        status_code, result_json = processTaskToPushMenuToUberEats(
            delivery_service_key.id()
        )

        assert status_code == 204

    def test_push_duplicate_id(self):
        delivery_service_key = self.delivery_service(
            item_id="ID_1",
            modifier_group_id="ID_1",
        )

        status_code, result_json = processTaskToPushMenuToUberEats(
            delivery_service_key.id()
        )

        assert status_code == 204
