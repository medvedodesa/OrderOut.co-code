import json
import pytest

from application.apis.deliveryservice.service.ubereats.menu.generator import (
    generate_menu_for_ubereats,
)
from application.apis.menu.model.MenuSection import MenuSection
from application.apis.menu.model.MenuItem import MenuItem

from application.test.api.menu.seed import full_delivery_service_menu

from application.apis.deliveryservice.service.ubereats.menu.fetch import _enable_service_availability

@pytest.mark.usefixtures("db")
class TestMenuSectionController(object):
    @pytest.fixture
    def expected_payload(self):
        return {
            "menus": [
                {
                    "service_availability": [
                        {
                            "enabled": True,
                            "time_periods": [
                                {
                                    "start_time": "00:00",
                                    "end_time": "23:59"
                                }
                            ],
                            "day_of_week": "monday"
                        },
                        {
                            "enabled": True,
                            "time_periods": [
                                {
                                    "start_time": "00:00",
                                    "end_time": "23:59"
                                }
                            ],
                            "day_of_week": "tuesday"
                        },
                        {
                            "enabled": True,
                            "time_periods": [
                                {
                                    "start_time": "00:00",
                                    "end_time": "23:59"
                                }
                            ],
                            "day_of_week": "wednesday"
                        },
                        {
                            "enabled": True,
                            "time_periods": [
                                {
                                    "start_time": "00:00",
                                    "end_time": "23:59"
                                }
                            ],
                            "day_of_week": "thursday"
                        },
                        {
                            "enabled": True,
                            "time_periods": [
                                {
                                    "start_time": "00:00",
                                    "end_time": "23:59"
                                }
                            ],
                            "day_of_week": "friday"
                        },
                        {
                            "enabled": True,
                            "time_periods": [
                                {
                                    "start_time": "00:00",
                                    "end_time": "23:59"
                                }
                            ],
                            "day_of_week": "saturday"
                        },
                        {
                            "enabled": True,
                            "time_periods": [
                                {
                                    "start_time": "00:00",
                                    "end_time": "23:59"
                                }
                            ],
                            "day_of_week": "sunday"
                        }
                    ],
                    "category_ids": [
                        "8a820696-5e20-11ea-b85c-3bca604d7cf9",
                        "8fcedff2-5e20-11ea-8b64-abae6d0905f0"
                    ],
                    "id": "ab955ca8-534d-11ea-8576-53330e2e3d2d",
                    "title": {
                        "translations": {
                            "en": "Brunch"
                        }
                    }
                }
            ],
            "modifier_groups": [
                {
                    "quantity_info": {
                        "overrides": [

                        ],
                        "quantity": {
                            "max_permitted": 2,
                            "min_permitted": 0
                        }
                    },
                    "modifier_options": [
                        {
                            "type": "ITEM",
                            "id": "b30f355c-5e20-11ea-80f3-b3789bae7a7e"
                        },
                        {
                            "type": "ITEM",
                            "id": "c1544cba-5e20-11ea-9a59-bb183ce877b3"
                        },
                        {
                            "type": "ITEM",
                            "id": "c683d7fa-5e20-11ea-ba66-2b3a054f7a67"
                        }
                    ],
                    "id": "3124f958-5e22-11ea-a209-bfc70e0667d7",
                    "title": {
                        "translations": {
                            "en": "General extras"
                        }
                    }
                },
                {
                    "quantity_info": {
                        "overrides": [

                        ],
                        "quantity": {
                            "max_permitted": 2,
                            "min_permitted": 0
                        }
                    },
                    "modifier_options": [
                        {
                            "type": "ITEM",
                            "id": "c799638a-5e20-11ea-970c-27db128ea549"
                        },
                        {
                            "type": "ITEM",
                            "id": "c8106d18-5e20-11ea-bb36-6fbbf42eca74"
                        }
                    ],
                    "id": "c724a6f8-5e20-11ea-b816-7f6a1c0937a5",
                    "title": {
                        "translations": {
                            "en": "Coffee extras"
                        }
                    }
                }
            ],
            "display_options": {
                "disable_item_instructions": True
            },
            "categories": [
                {
                    "entities": [
                        {
                            "type": "ITEM",
                            "id": "7ec5cefa-5e20-11ea-8de1-276fc7dce234"
                        },
                        {
                            "type": "ITEM",
                            "id": "97e99a6a-5e20-11ea-be41-efead2745647"
                        }
                    ],
                    "id": "8a820696-5e20-11ea-b85c-3bca604d7cf9",
                    "title": {
                        "translations": {
                            "en": "Drinks"
                        }
                    }
                },
                {
                    "entities": [
                        {
                            "type": "ITEM",
                            "id": "9e156fae-5e20-11ea-810e-cbc95b5675b7"
                        },
                        {
                            "type": "ITEM",
                            "id": "a5daea48-5e20-11ea-b604-5f8c7b7cd3ac"
                        }
                    ],
                    "id": "8fcedff2-5e20-11ea-8b64-abae6d0905f0",
                    "title": {
                        "translations": {
                            "en": "Foods"
                        }
                    }
                }
            ],
            "items": [
                {
                    "price_info": {
                        "overrides": [

                        ],
                        "price": 321
                    },
                    "title": {
                        "translations": {
                            "en": "Himalaia suggar"
                        }
                    },
                    "id": "c8106d18-5e20-11ea-bb36-6fbbf42eca74",
                    "external_data": "18"
                },
                {
                    "price_info": {
                        "overrides": [

                        ],
                        "price": 110
                    },
                    "title": {
                        "translations": {
                            "en": "Gift package"
                        }
                    },
                    "id": "b30f355c-5e20-11ea-80f3-b3789bae7a7e",
                    "external_data": "13"
                },
                {
                    "modifier_group_ids": {
                        "overrides": [

                        ],
                        "ids": [
                            "3124f958-5e22-11ea-a209-bfc70e0667d7"
                        ]
                    },
                    "image_url": "http://example.com/image-url",
                    "description": {
                        "translations": {
                            "en": "Plain cake"
                        }
                    },
                    "title": {
                        "translations": {
                            "en": "Cake"
                        }
                    },
                    "price_info": {
                        "overrides": [

                        ],
                        "price": 1234
                    },
                    "dish_info": {
                        "classifications": {
                            "alcoholic_items": 0
                        }
                    },
                    "tax_info": {
                        "tax_rate": 0.24,
                        "vat_rate_percentage": 3.45
                    },
                    "id": "a5daea48-5e20-11ea-b604-5f8c7b7cd3ac",
                    "external_data": "11"
                },
                {
                    "price_info": {
                        "overrides": [

                        ],
                        "price": 220
                    },
                    "title": {
                        "translations": {
                            "en": "Full cutlery"
                        }
                    },
                    "id": "c1544cba-5e20-11ea-9a59-bb183ce877b3",
                    "external_data": "14"
                },
                {
                    "modifier_group_ids": {
                        "overrides": [

                        ],
                        "ids": [
                            "3124f958-5e22-11ea-a209-bfc70e0667d7"
                        ]
                    },
                    "image_url": "http://example.com/image-url",
                    "description": {
                        "translations": {
                            "en": "Plain bread"
                        }
                    },
                    "title": {
                        "translations": {
                            "en": "Bread"
                        }
                    },
                    "price_info": {
                        "overrides": [

                        ],
                        "price": 1234
                    },
                    "dish_info": {
                        "classifications": {
                            "alcoholic_items": 0
                        }
                    },
                    "tax_info": {
                        "tax_rate": 0.24,
                        "vat_rate_percentage": 3.45
                    },
                    "id": "9e156fae-5e20-11ea-810e-cbc95b5675b7",
                    "external_data": "10"
                },
                {
                    "modifier_group_ids": {
                        "overrides": [

                        ],
                        "ids": [
                            "3124f958-5e22-11ea-a209-bfc70e0667d7"
                        ]
                    },
                    "image_url": "http://example.com/image-url",
                    "description": {
                        "translations": {
                            "en": "Plain milk"
                        }
                    },
                    "title": {
                        "translations": {
                            "en": "Milk"
                        }
                    },
                    "price_info": {
                        "overrides": [

                        ],
                        "price": 1234
                    },
                    "dish_info": {
                        "classifications": {
                            "alcoholic_items": 0
                        }
                    },
                    "tax_info": {
                        "tax_rate": 0.24,
                        "vat_rate_percentage": 3.45
                    },
                    "id": "97e99a6a-5e20-11ea-be41-efead2745647",
                    "external_data": "9"
                },
                {
                    "modifier_group_ids": {
                        "overrides": [

                        ],
                        "ids": [
                            "3124f958-5e22-11ea-a209-bfc70e0667d7"
                        ]
                    },
                    "image_url": "http://example.com/image-url",
                    "description": {
                        "translations": {
                            "en": "Plain coffee"
                        }
                    },
                    "title": {
                        "translations": {
                            "en": "Coffee"
                        }
                    },
                    "price_info": {
                        "overrides": [

                        ],
                        "price": 1234
                    },
                    "dish_info": {
                        "classifications": {
                            "alcoholic_items": 0
                        }
                    },
                    "tax_info": {
                        "tax_rate": 0.24,
                        "vat_rate_percentage": 3.45
                    },
                    "id": "7ec5cefa-5e20-11ea-8de1-276fc7dce234",
                    "external_data": "8"
                },
                {
                    "price_info": {
                        "overrides": [

                        ],
                        "price": 1012
                    },
                    "title": {
                        "translations": {
                            "en": "Random stuff"
                        }
                    },
                    "id": "c683d7fa-5e20-11ea-ba66-2b3a054f7a67",
                    "external_data": "15"
                },
                {
                    "price_info": {
                        "overrides": [

                        ],
                        "price": 230
                    },
                    "title": {
                        "translations": {
                            "en": "Volcanic suggar"
                        }
                    },
                    "id": "c799638a-5e20-11ea-970c-27db128ea549",
                    "external_data": "17"
                }
            ],
            "service_availability": [
                {
                    "enabled": False,
                    "time_periods": [],
                    "day_of_week": "monday"
                },
                {
                    "enabled": False,
                    "time_periods": [],
                    "day_of_week": "tuesday"
                },
                {
                    "enabled": False,
                    "time_periods": [],
                    "day_of_week": "wednesday"
                },
                {
                    "enabled": False,
                    "time_periods": [],
                    "day_of_week": "thursday"
                },
                {
                    "enabled": False,
                    "time_periods": [],
                    "day_of_week": "friday"
                },
                {
                    "enabled": False,
                    "time_periods": [],
                    "day_of_week": "saturday"
                },
                {
                    "enabled": False,
                    "time_periods": [],
                    "day_of_week": "sunday"
                }
            ]
        }

    def test_ubereats_json_service_availability(self, expected_payload):
        actual_service_availability = _enable_service_availability(None)
        assert expected_payload["service_availability"] == actual_service_availability

    def test_generate_menu_for_ubereats_json_service_availability(
        self, expected_payload, full_delivery_service_menu
    ):
        delivery_service = full_delivery_service_menu
        delivery_service_key = delivery_service.key

        response = generate_menu_for_ubereats(delivery_service_key)

        assert response["menus"] == expected_payload["menus"]
        assert response["modifier_groups"] == expected_payload["modifier_groups"]
        assert response["display_options"] == expected_payload["display_options"]
        assert response["categories"] == expected_payload["categories"]
        assert response["items"] == expected_payload["items"]

    def test_generate_menu_for_ubereats_string_service_availability(
        self, expected_payload, full_delivery_service_menu
    ):
        delivery_service = full_delivery_service_menu
        delivery_service_key = delivery_service.key

        _query = MenuSection.query()
        sections = _query.fetch()

        for section in sections:
            section.availability = json.dumps(section.availability)
            section.put()

        response = generate_menu_for_ubereats(delivery_service_key)

        assert response["menus"] == expected_payload["menus"]
        assert response["modifier_groups"] == expected_payload["modifier_groups"]
        assert response["display_options"] == expected_payload["display_options"]
        assert response["categories"] == expected_payload["categories"]
        assert response["items"] == expected_payload["items"]

    def test_generate_menu_with_duplicated_item(
        self, expected_payload, full_delivery_service_menu
    ):
        delivery_service = full_delivery_service_menu
        delivery_service_key = delivery_service.key

        _query = MenuItem.query()
        menu_items = _query.fetch()
        menu_item = menu_items[0]
        menu_item.uuid = menu_items[1].uuid
        menu_item.put()

        response = generate_menu_for_ubereats(delivery_service_key)
        assert len(response["items"]) == len(expected_payload["items"]) - 1

    def test_generate_menu_with_disabled_category(
        self, expected_payload, full_delivery_service_menu
    ):
        delivery_service = full_delivery_service_menu
        delivery_service_key = delivery_service.key
        _query = MenuSection.query()
        sections = _query.fetch()
        section = sections[0]
        disabled_category = section.categories[0].get()
        disabled_category.enabled = False
        disabled_category.put()

        len_all_categories = len(expected_payload["categories"])
        response = generate_menu_for_ubereats(delivery_service_key)
        assert len(response["menus"][0]["category_ids"]) == len_all_categories - 1
        assert len(response["categories"]) == len_all_categories - 1
        assert len(response["items"]) == len(expected_payload["items"]) - 4
