import pytest

from application.apis.deliveryservice.service.ubereats.serializers.menu_serializer import (
    PushMenuSchema,
)
from application.apis.menu.model.MenuSection import MenuSection
from application.test.api.menu.seed import full_delivery_service_menu


@pytest.mark.usefixtures("db")
class TestMenuSerializer(object):
    def test_generate_menu_for_ubereats_based_on_menu_sections(
        self, full_delivery_service_menu
    ):
        delivery_service = full_delivery_service_menu
        delivery_service_key = delivery_service.key

        ds = delivery_service_key.get()
        menu_sync_key = ds.menuSync

        query = MenuSection.query()
        query = query.filter(MenuSection.menuSync == menu_sync_key)
        menu_sections = query.fetch()

        delivery_service.menu_sections = menu_sections

        schema = PushMenuSchema()
        response, errors = schema.dump(delivery_service)

        assert not errors

        expected_payload = {
            u"sections": [
                {
                    u"service_availability": [
                        {
                            u"enabled": True,
                            u"time_periods": [
                                {u"start_time": u"00:00", u"end_time": u"23:59"}
                            ],
                            u"day_of_week": u"monday",
                        },
                        {
                            u"enabled": True,
                            u"time_periods": [
                                {u"start_time": u"00:00", u"end_time": u"23:59"}
                            ],
                            u"day_of_week": u"tuesday",
                        },
                        {
                            u"enabled": True,
                            u"time_periods": [
                                {u"start_time": u"00:00", u"end_time": u"23:59"}
                            ],
                            u"day_of_week": u"wednesday",
                        },
                        {
                            u"enabled": True,
                            u"time_periods": [
                                {u"start_time": u"00:00", u"end_time": u"23:59"}
                            ],
                            u"day_of_week": u"thursday",
                        },
                        {
                            u"enabled": True,
                            u"time_periods": [
                                {u"start_time": u"00:00", u"end_time": u"23:59"}
                            ],
                            u"day_of_week": u"friday",
                        },
                        {
                            u"enabled": True,
                            u"time_periods": [
                                {u"start_time": u"00:00", u"end_time": u"23:59"}
                            ],
                            u"day_of_week": u"saturday",
                        },
                        {
                            u"enabled": True,
                            u"time_periods": [
                                {u"start_time": u"00:00", u"end_time": u"23:59"}
                            ],
                            u"day_of_week": u"sunday",
                        },
                    ],
                    u"subtitle": u"Breakfast and lunch menu",
                    u"subsections": [
                        {
                            u"items": [
                                {
                                    u"item_description": u"Plain coffee",
                                    u"title": u"Coffee",
                                    u"external_id": u"8",
                                    u"price": 12.34,
                                    u"customizations": [
                                        {
                                            u"customization_options": [
                                                {
                                                    u"price": 1.1,
                                                    u"external_id": u"13",
                                                    u"title": u"Gift package",
                                                },
                                                {
                                                    u"price": 2.2,
                                                    u"external_id": u"14",
                                                    u"title": u"Full cutlery",
                                                },
                                                {
                                                    u"price": 10.12,
                                                    u"external_id": u"15",
                                                    u"title": u"Random stuff",
                                                },
                                            ],
                                            u"max_permitted": 2,
                                            u"min_permitted": 0,
                                            u"title": u"General extras",
                                        }
                                    ],
                                    u"vat_rate_percentage": 3.45,
                                    u"image_url": u"http://example.com/image-url",
                                    u"is_alcohol": False,
                                    u"tax_rate": 0.24,
                                    u"disable_instructions": False,
                                    u"currency_code": u"USD",
                                },
                                {
                                    u"item_description": u"Plain milk",
                                    u"title": u"Milk",
                                    u"external_id": u"9",
                                    u"price": 12.34,
                                    u"customizations": [
                                        {
                                            u"customization_options": [
                                                {
                                                    u"price": 1.1,
                                                    u"external_id": u"13",
                                                    u"title": u"Gift package",
                                                },
                                                {
                                                    u"price": 2.2,
                                                    u"external_id": u"14",
                                                    u"title": u"Full cutlery",
                                                },
                                                {
                                                    u"price": 10.12,
                                                    u"external_id": u"15",
                                                    u"title": u"Random stuff",
                                                },
                                            ],
                                            u"max_permitted": 2,
                                            u"min_permitted": 0,
                                            u"title": u"General extras",
                                        }
                                    ],
                                    u"vat_rate_percentage": 3.45,
                                    u"image_url": u"http://example.com/image-url",
                                    u"is_alcohol": False,
                                    u"tax_rate": 0.24,
                                    u"disable_instructions": False,
                                    u"currency_code": u"USD",
                                },
                            ],
                            u"title": u"Drinks",
                        },
                        {
                            u"items": [
                                {
                                    u"item_description": u"Plain bread",
                                    u"title": u"Bread",
                                    u"external_id": u"10",
                                    u"price": 12.34,
                                    u"customizations": [
                                        {
                                            u"customization_options": [
                                                {
                                                    u"price": 1.1,
                                                    u"external_id": u"13",
                                                    u"title": u"Gift package",
                                                },
                                                {
                                                    u"price": 2.2,
                                                    u"external_id": u"14",
                                                    u"title": u"Full cutlery",
                                                },
                                                {
                                                    u"price": 10.12,
                                                    u"external_id": u"15",
                                                    u"title": u"Random stuff",
                                                },
                                            ],
                                            u"max_permitted": 2,
                                            u"min_permitted": 0,
                                            u"title": u"General extras",
                                        }
                                    ],
                                    u"vat_rate_percentage": 3.45,
                                    u"image_url": u"http://example.com/image-url",
                                    u"is_alcohol": False,
                                    u"tax_rate": 0.24,
                                    u"disable_instructions": False,
                                    u"currency_code": u"USD",
                                },
                                {
                                    u"item_description": u"Plain cake",
                                    u"title": u"Cake",
                                    u"external_id": u"11",
                                    u"price": 12.34,
                                    u"customizations": [
                                        {
                                            u"customization_options": [
                                                {
                                                    u"price": 1.1,
                                                    u"external_id": u"13",
                                                    u"title": u"Gift package",
                                                },
                                                {
                                                    u"price": 2.2,
                                                    u"external_id": u"14",
                                                    u"title": u"Full cutlery",
                                                },
                                                {
                                                    u"price": 10.12,
                                                    u"external_id": u"15",
                                                    u"title": u"Random stuff",
                                                },
                                            ],
                                            u"max_permitted": 2,
                                            u"min_permitted": 0,
                                            u"title": u"General extras",
                                        }
                                    ],
                                    u"vat_rate_percentage": 3.45,
                                    u"image_url": u"http://example.com/image-url",
                                    u"is_alcohol": False,
                                    u"tax_rate": 0.24,
                                    u"disable_instructions": False,
                                    u"currency_code": u"USD",
                                },
                            ],
                            u"title": u"Foods",
                        },
                    ],
                    u"title": u"Brunch",
                }
            ]
        }

        assert (
            response["sections"][0]["title"] == expected_payload["sections"][0]["title"]
        )
        assert (
            response["sections"][0]["subtitle"]
            == expected_payload["sections"][0]["subtitle"]
        )
        assert (
            response["sections"][0]["service_availability"]
            == expected_payload["sections"][0]["service_availability"]
        )
        assert (
            response["sections"][0]["subsections"]
            == expected_payload["sections"][0]["subsections"]
        )

        errors = schema.validate(response)
        assert not errors
