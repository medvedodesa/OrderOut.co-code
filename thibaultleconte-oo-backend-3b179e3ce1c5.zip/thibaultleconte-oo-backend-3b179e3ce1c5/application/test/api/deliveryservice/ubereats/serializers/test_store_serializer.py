from collections import defaultdict

import pytest

from application.apis.deliveryservice.service.ubereats.serializers.menu_serializer import (
    PushMenuSchema,
)
from application.apis.deliveryservice.service.ubereats.serializers.store_serializer import (
    StoreSerializerSchema,
)
from application.apis.menu.model.MenuSection import MenuSection
from application.test.api.menu.seed import full_delivery_service_menu


@pytest.mark.usefixtures("db")
class TestStoreSerializer(object):
    @pytest.fixture
    def stores_payload(self):
        return [
            {
                "name": "East Coast Sushi",
                "store_id": "7e973b58-40b7-4bd8-b01c-c7d1cbd194f6",
                "location": {
                    "address": "636 W 28th Street",
                    "address_2": "Floor 3",
                    "city": "New York",
                    "country": "US",
                    "postal_code": "10001",
                    "state": "NY",
                    "latitude": 40.7527198,
                    "longitude": -74.00635,
                },
                "contact_emails": [
                    "owner@example.com",
                    "announcements+uber@example.com",
                    "store-east@example.com",
                ],
                "raw_hero_url": "https://www.example.com/hero_url_east.png",
                "price_bucket": "$$$",
                "avg_prep_time": 5,
                "status": "active",
                "partner_store_id": "541324",
            },
            {
                "name": "West Coast Sushi",
                "store_id": "d8ce1955-d78a-469b-91a4-01f0b23f9213",
                "location": {
                    "address": "1455 Market Street",
                    "address_2": "Floor 4",
                    "city": "San Francisco",
                    "country": "US",
                    "postal_code": "94103",
                    "state": "CA",
                    "latitude": 37.775232,
                    "longitude": -122.417528,
                },
                "contact_emails": [
                    "owner@example.com",
                    "announcements+uber@example.com",
                    "store-west@example.com",
                ],
                "raw_hero_url": "https://www.example.com/hero_url_west.png",
                "price_bucket": "$$",
                "avg_prep_time": 10,
                "status": "active",
                "partner_store_id": "786541",
            },
        ]

    def test_store_serializer(self, stores_payload):
        schema = StoreSerializerSchema(many=True)
        restaurants, errors = schema.load(stores_payload)

        assert not errors
        assert restaurants

        flat_data = defaultdict(list)
        for store in stores_payload:
            location = store["location"]
            store_name = "{address_1} {address_2}, {city}, {state}, {zipcode}".format(
                address_1=location["address"],
                address_2=location["address_2"],
                city=location["city"],
                state=location["state"],
                zipcode=location["postal_code"],
            )
            flat_data["name"].append(store_name)
            flat_data["street_address_1"].append(store["location"]["address"])
            flat_data["street_address_2"].append(store["location"]["address_2"])
            flat_data["city"].append(store["location"]["city"])
            flat_data["country"].append(store["location"]["country"])
            flat_data["zipcode"].append(store["location"]["postal_code"])
            flat_data["state"].append(store["location"]["state"])


        for restaurant in restaurants:
            assert restaurant.name in flat_data["name"]
            assert restaurant.street_address_1 in flat_data["street_address_1"]
            assert restaurant.street_address_2 in flat_data["street_address_2"]
            assert restaurant.city in flat_data["city"]
            assert restaurant.country in flat_data["country"]
            assert restaurant.zipcode in flat_data["zipcode"]
            assert restaurant.state in flat_data["state"]

