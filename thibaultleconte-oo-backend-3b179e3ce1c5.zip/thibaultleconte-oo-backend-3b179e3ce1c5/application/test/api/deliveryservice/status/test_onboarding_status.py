# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/14/2019
#

import unittest
from application.test.base import BaseTestCase
from application.apis.restaurant.model import Restaurant
from application.apis.account.model import Account
from application.apis.deliveryservice.service.common.crud import create_from_public_menu_url
from application.apis.deliveryservice.model.DeliveryService import DeliveryServiceType, DeliveryServiceStatus
from application.apis.deliveryservice.service.common.status import compute_status
from application.apis.menu.service.menusync.creator import create_menu_sync

TEST_PUBLIC_MENU_URL = "https://www.ubereats.com/tibo-pizzeria-1234"

class TestApiDeliveryStatusForOnboarding(BaseTestCase):

    def test_deliveryServiceStatusSelfOnboarded(self):
        _tibo_account = Account.create("Tibo Industries")
        _restaurant = Restaurant.create(name="Tibo Restaurant", account_key=_tibo_account.key)
        _ds = create_from_public_menu_url(restaurant_key=_restaurant.key, delivery_service_type=DeliveryServiceType.UBEREATS, public_menu_url=TEST_PUBLIC_MENU_URL)
        _ds_status = compute_status(_ds.key)
        self.assertTrue(_ds_status == DeliveryServiceStatus.CONNECTING)

    def test_deliveryServiceStatusConnectingNoItem(self):
        _tibo_account = Account.create("Tibo Industries")
        _restaurant = Restaurant.create(name="Tibo Restaurant", account_key=_tibo_account.key)
        _ds = create_from_public_menu_url(restaurant_key=_restaurant.key, delivery_service_type=DeliveryServiceType.UBEREATS, public_menu_url=TEST_PUBLIC_MENU_URL)
        _ms = create_menu_sync(restaurant_key=_restaurant.key, service_key=_ds.key)
        _ms.map_total_menu_items = 0
        _ms.map_mapped_menu_items = 0
        _ms.map_unmapped_menu_items = 0
        _ms.put()
        _ds.menuSync = _ms.key
        _ds.put()
        _ds_status = compute_status(_ds.key)
        self.assertTrue(_ds_status == DeliveryServiceStatus.EMPTY_MENU)

    def test_deliveryServiceStatusConnectingWithItem(self):
        _tibo_account = Account.create("Tibo Industries")
        _restaurant = Restaurant.create(name="Tibo Restaurant", account_key=_tibo_account.key)
        _ds = create_from_public_menu_url(restaurant_key=_restaurant.key, delivery_service_type=DeliveryServiceType.UBEREATS, public_menu_url=TEST_PUBLIC_MENU_URL)
        _ms = create_menu_sync(restaurant_key=_restaurant.key, service_key=_ds.key)
        _ms.map_total_menu_items = 10
        _ms.map_mapped_menu_items = 0
        _ms.map_unmapped_menu_items = 10
        _ms.put()
        _ds.menuSync = _ms.key
        _ds.put()
        _ds_status = compute_status(_ds.key)
        self.assertTrue(_ds_status == DeliveryServiceStatus.MAPPING)

    def test_deliveryServiceStatusReady(self):
        _tibo_account = Account.create("Tibo Industries")
        _restaurant = Restaurant.create(name="Tibo Restaurant", account_key=_tibo_account.key)
        _ds = create_from_public_menu_url(restaurant_key=_restaurant.key, delivery_service_type=DeliveryServiceType.UBEREATS, public_menu_url=TEST_PUBLIC_MENU_URL)
        _ms = create_menu_sync(restaurant_key=_restaurant.key, service_key=_ds.key)
        _ms.map_total_menu_items = 10
        _ms.map_mapped_menu_items = 10
        _ms.map_unmapped_menu_items = 0
        _ms.put()
        _ds.menuSync = _ms.key
        _ds.put()
        _ds_status = compute_status(_ds.key)
        self.assertTrue(_ds_status == DeliveryServiceStatus.READY)

    def test_deliveryServiceStatusLive(self):
        _tibo_account = Account.create("Tibo Industries")
        _restaurant = Restaurant.create(name="Tibo Restaurant", account_key=_tibo_account.key)
        _ds = create_from_public_menu_url(restaurant_key=_restaurant.key, delivery_service_type=DeliveryServiceType.UBEREATS, public_menu_url=TEST_PUBLIC_MENU_URL)
        _ms = create_menu_sync(restaurant_key=_restaurant.key, service_key=_ds.key)
        _ms.map_total_menu_items = 10
        _ms.map_mapped_menu_items = 10
        _ms.map_unmapped_menu_items = 0
        _ms.put()
        _ds.menuSync = _ms.key
        _ds.integration_enabled = True
        _ds.put()
        _ds_status = compute_status(_ds.key)
        self.assertTrue(_ds_status == DeliveryServiceStatus.LIVE)

if __name__ == '__main__':
    unittest.main()
