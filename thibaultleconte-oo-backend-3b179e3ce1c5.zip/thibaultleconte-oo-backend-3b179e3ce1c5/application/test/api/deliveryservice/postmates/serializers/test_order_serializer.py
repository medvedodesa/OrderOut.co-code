import pytest

from application.apis.deliveryservice.service.postmates.serializers.order_serializer import (
    OrderSchema,
)
from application.apis.order.model.Order import OrderStatus, OrderType, Order
from application.test.api.menu.factories import MenuItemModifierFactory, MenuItemFactory
from application.test.api.menu.seed import menu_sync_key


@pytest.mark.usefixtures("db")
class TestOrderSerializer(object):
    @pytest.fixture
    def payload(self):
        return {
            u"created": u"2020-04-08T18:29:50.840799Z",
            u"data": {
                u"errors": [],
                u"external_order_id": u"",
                u"pickup_details": {
                    u"estimated_ready_time": None,
                    u"display_name": u"Gabriel",
                    u"order_number": 107,
                },
                u"place_details": {
                    u"external_place_id": u"orderout_api",
                    u"place_id": u"plc_X22MSGw3RdKUXi6M3BdvYg",
                    u"timezone": u"America/Los_Angeles",
                },
                u"order_id": u"ord_3Lo9QBRoSxSA1IA_9mY4Ow",
                u"subtotal": 28.44,
                u"kind": u"order",
                u"delivery_id": u"del_McsL9EprAuH4Ik",
                u"tax": 2.28,
                u"tip": 0.0,
                u"fee": 0.0,
                u"customer_delivery_fee": 0.0,
                u"status": u"created",
                u"items": [
                    {
                        u"base_price": 23.44,
                        u"name": u"holi purple bowl (gf) + live juice #3",
                        u"external_id": u"4bf3bb8f-57a2-4cf5-9d37-ae3e92455575",
                        u"id": u"oi_FyDVJOI7XlGKSpL0XAM4Ng",
                        u"modifier_lists": [
                            {
                                u"name": u"bowls options: for holi purple bowl (gf)",
                                u"modifiers": [
                                    {
                                        u"external_id": u"35639f31-9031-42b9-b679-3e05b80854fe",
                                        u"id": u"oi_hSTGFT92W66KPRyXkuOXpA",
                                        u"price": 2.5,
                                        u"modifier_lists": [],
                                        u"name": u"marinated tempeh jerk",
                                    },
                                    {
                                        u"external_id": u"aebb6fd0-d485-4185-a84d-7373fe6714bb",
                                        u"id": u"oi_CtLyeEJbUgGcClbxwR4jXw",
                                        u"price": 2.5,
                                        u"modifier_lists": [],
                                        u"name": u"roasted tofu cubes",
                                    },
                                ],
                            }
                        ],
                        u"category_name": u"popular pairs",
                        u"quantity": 1,
                    }
                ],
            },
            u"developer_id": u"dev_aDqiJ4QgQiSkVSxxYea65g",
            u"order_id": u"ord_3Lo9QBRoSxSA1IA_9mY4Ow",
            u"account_id": u"act_vV2vBWwUR9G06peyUjfy2w",
            u"id": u"evt_DrsEz4EyRUe0hPPB5F9CTw",
            u"kind": u"event.order_created",
            u"customer_id": u"cus_MXY2KJu4bWkrw-",
            u"status": u"created",
        }

    @pytest.fixture
    def delivery_service(self, payload, menu_sync_key):
        store_id = payload["data"]["place_details"]["place_id"]
        menu_sync = menu_sync_key.get()
        delivery_service = menu_sync.service.get()
        delivery_service.serviceLocationId = store_id
        delivery_service.put()
        return delivery_service

    @pytest.fixture
    def menu_item_modifiers(self, payload, delivery_service):
        menu_sync_key = delivery_service.menuSync
        menu_item_modifier_1 = MenuItemModifierFactory(
            uuid=payload["data"]["items"][0]["modifier_lists"][0]["modifiers"][0][
                "external_id"
            ],
            menuSync=menu_sync_key,
        )
        menu_item_modifier_1.put()
        menu_item_modifier_2 = MenuItemModifierFactory(
            uuid=payload["data"]["items"][0]["modifier_lists"][0]["modifiers"][1][
                "external_id"
            ],
            menuSync=menu_sync_key,
        )
        menu_item_modifier_2.put()
        return [menu_item_modifier_1, menu_item_modifier_2]

    @pytest.fixture
    def menu_item(self, payload, delivery_service):
        menu_sync_key = delivery_service.menuSync
        menu_item = MenuItemFactory(
            uuid=payload["data"]["items"][0]["external_id"], menuSync=menu_sync_key
        )
        menu_item.put()
        return menu_item

    def test_create_order(
        self, payload, menu_item, menu_item_modifiers, delivery_service
    ):
        schema = OrderSchema()
        schema.context["raw_data"] = payload
        order, errors = schema.load(payload)
        assert not errors
        assert order.account == delivery_service.account
        assert order.restaurant == delivery_service.restaurant
        assert order.status == OrderStatus.RECEIVED
        assert order.type == OrderType.DELIVERY
        assert order.delivery_service == delivery_service.key
        assert (
            order.delivery_service_uuid == payload["order_id"].encode("utf-8").strip()
        )
        assert order.customer_name == payload["data"]["pickup_details"]["display_name"]
        assert order.delivery_service_raw_data == payload
        assert order.charge_tax == float(payload["data"].get("tax"))
        assert order.charge_subtotal == float(payload["data"].get("subtotal"))
        assert order.charge_tip == float(payload["data"].get("tip"))
        assert order.charge_fee == float(payload["data"].get("fee"))
        assert order.charge_customer_delivery_fee == float(payload["data"].get("customer_delivery_fee"))
        assert order.charge_total == order.charge_tax + order.charge_subtotal
        assert len(order.order_items) == len(payload["data"]["items"])

        for i, order_item_key in enumerate(order.order_items):
            jorder_item = payload["data"]["items"][i]
            order_item = order_item_key.get()
            assert order_item.order == order.key
            assert order_item.unit_price == jorder_item["base_price"]
            assert order_item.quantity == jorder_item["quantity"]
            assert order_item.price == jorder_item["base_price"]
            assert order_item.menu_item.get() == menu_item

            jmodifiers = []
            jmodifiers_list = jorder_item["modifier_lists"]
            for jmodifier_list in jmodifiers_list:
                for jmodifier in jmodifier_list["modifiers"]:
                    jmodifiers.append(jmodifier)

            assert len(order_item.selected_modifier) == len(jmodifiers)
            for j, modifier_key in enumerate(order_item.selected_modifier):
                modifier = modifier_key.get()
                assert modifier.order == order.key
                assert modifier.order_item == order_item_key
                assert modifier.menu_item_modifier.get() == menu_item_modifiers[j]
                assert modifier.price == jmodifiers[j]["price"]

    def test_dont_duplicate_order(
        self, payload, menu_item, menu_item_modifiers, delivery_service
    ):
        payload["order_id"] = "new_order"

        orders = Order.query().fetch()
        len_orders = len(orders)

        schema = OrderSchema()
        schema.context["raw_data"] = payload
        schema.load(payload)

        orders = Order.query().fetch()
        assert len(orders) == len_orders + 1

        schema = OrderSchema()
        schema.context["raw_data"] = payload
        schema.load(payload)

        orders = Order.query().fetch()
        assert len(orders) == len_orders + 1
