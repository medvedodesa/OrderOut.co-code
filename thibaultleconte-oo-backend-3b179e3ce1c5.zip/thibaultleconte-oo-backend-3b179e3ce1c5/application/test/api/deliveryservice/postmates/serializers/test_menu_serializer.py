import pytest

from application.apis.deliveryservice.service.postmates.serializers.menu_serializer import (
    CatalogSchema,
)
from application.apis.menu.model.MenuSection import MenuSection
from application.test.api.menu.seed import full_delivery_service_menu
from application.test.utils import remove_keys_from_dict


@pytest.mark.usefixtures("db")
class TestMenuSerializer(object):
    @pytest.fixture
    def expected_response(self):
        expected_response = {
            u"external_id": u"da678510-8598-11ea-9423-93d1bd303a8f",
            u"name": u"Brunch",
            u"kind": u"catalog",
            u"categories": [
                {
                    u"name": u"Drinks",
                    u"items": [
                        {
                            u"price_currency": u"USD",
                            u"description": u"Plain coffee",
                            u"price": 12.34,
                            u"kind": u"item",
                            u"tax_rate": 0.24,
                            u"modifier_groups": [
                                {
                                    u"modifiers": [
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Gift package",
                                            u"price": 1.1,
                                            u"kind": u"modifier",
                                            u"id": u"b30f355c-5e20-11ea-80f3-b3789bae7a7e",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Full cutlery",
                                            u"price": 2.2,
                                            u"kind": u"modifier",
                                            u"id": u"c1544cba-5e20-11ea-9a59-bb183ce877b3",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Random stuff",
                                            u"price": 10.12,
                                            u"kind": u"modifier",
                                            u"id": u"c683d7fa-5e20-11ea-ba66-2b3a054f7a67",
                                        },
                                    ],
                                    u"name": u"General Extras",
                                    u"kind": u"modifier_group",
                                    u"min_allowed": 0,
                                    u"max_allowed": 2,
                                    u"id": u"3124f958-5e22-11ea-a209-bfc70e0667d7",
                                },
                                {
                                    u"modifiers": [
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Volcanic Suggar",
                                            u"price": 2.3,
                                            u"kind": u"modifier",
                                            u"id": u"c799638a-5e20-11ea-970c-27db128ea549",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Himalaia Suggar",
                                            u"price": 3.21,
                                            u"kind": u"modifier",
                                            u"id": u"c8106d18-5e20-11ea-bb36-6fbbf42eca74",
                                        },
                                    ],
                                    u"name": u"Coffee extras",
                                    u"kind": u"modifier_group",
                                    u"min_allowed": 0,
                                    u"max_allowed": 2,
                                    u"id": u"c724a6f8-5e20-11ea-b816-7f6a1c0937a5",
                                },
                            ],
                            u"is_available": True,
                            u"photo_url": u"http://example.com/image-url",
                            u"id": u"7ec5cefa-5e20-11ea-8de1-276fc7dce234",
                            u"name": u"Coffee",
                        },
                        {
                            u"price_currency": u"USD",
                            u"description": u"Plain milk",
                            u"price": 12.34,
                            u"kind": u"item",
                            u"tax_rate": 0.24,
                            u"modifier_groups": [
                                {
                                    u"modifiers": [
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Gift package",
                                            u"price": 1.1,
                                            u"kind": u"modifier",
                                            u"id": u"b30f355c-5e20-11ea-80f3-b3789bae7a7e",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Full cutlery",
                                            u"price": 2.2,
                                            u"kind": u"modifier",
                                            u"id": u"c1544cba-5e20-11ea-9a59-bb183ce877b3",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Random stuff",
                                            u"price": 10.12,
                                            u"kind": u"modifier",
                                            u"id": u"c683d7fa-5e20-11ea-ba66-2b3a054f7a67",
                                        },
                                    ],
                                    u"name": u"General Extras",
                                    u"kind": u"modifier_group",
                                    u"min_allowed": 0,
                                    u"max_allowed": 2,
                                    u"id": u"3124f958-5e22-11ea-a209-bfc70e0667d7",
                                },
                                {
                                    u"modifiers": [
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Volcanic Suggar",
                                            u"price": 2.3,
                                            u"kind": u"modifier",
                                            u"id": u"c799638a-5e20-11ea-970c-27db128ea549",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Himalaia Suggar",
                                            u"price": 3.21,
                                            u"kind": u"modifier",
                                            u"id": u"c8106d18-5e20-11ea-bb36-6fbbf42eca74",
                                        },
                                    ],
                                    u"name": u"Coffee extras",
                                    u"kind": u"modifier_group",
                                    u"min_allowed": 0,
                                    u"max_allowed": 2,
                                    u"id": u"c724a6f8-5e20-11ea-b816-7f6a1c0937a5",
                                },
                            ],
                            u"is_available": True,
                            u"photo_url": u"http://example.com/image-url",
                            u"id": u"97e99a6a-5e20-11ea-be41-efead2745647",
                            u"name": u"Milk",
                        },
                    ],
                    u"kind": u"category",
                    u"id": u"8a820696-5e20-11ea-b85c-3bca604d7cf9",
                },
                {
                    u"name": u"Foods",
                    u"items": [
                        {
                            u"price_currency": u"USD",
                            u"description": u"Plain bread",
                            u"price": 12.34,
                            u"kind": u"item",
                            u"tax_rate": 0.24,
                            u"modifier_groups": [
                                {
                                    u"modifiers": [
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Gift package",
                                            u"price": 1.1,
                                            u"kind": u"modifier",
                                            u"id": u"b30f355c-5e20-11ea-80f3-b3789bae7a7e",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Full cutlery",
                                            u"price": 2.2,
                                            u"kind": u"modifier",
                                            u"id": u"c1544cba-5e20-11ea-9a59-bb183ce877b3",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Random stuff",
                                            u"price": 10.12,
                                            u"kind": u"modifier",
                                            u"id": u"c683d7fa-5e20-11ea-ba66-2b3a054f7a67",
                                        },
                                    ],
                                    u"name": u"General Extras",
                                    u"kind": u"modifier_group",
                                    u"min_allowed": 0,
                                    u"max_allowed": 2,
                                    u"id": u"3124f958-5e22-11ea-a209-bfc70e0667d7",
                                }
                            ],
                            u"is_available": True,
                            u"photo_url": u"http://example.com/image-url",
                            u"id": u"9e156fae-5e20-11ea-810e-cbc95b5675b7",
                            u"name": u"Bread",
                        },
                        {
                            u"price_currency": u"USD",
                            u"description": u"Plain cake",
                            u"price": 12.34,
                            u"kind": u"item",
                            u"tax_rate": 0.24,
                            u"modifier_groups": [
                                {
                                    u"modifiers": [
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Gift package",
                                            u"price": 1.1,
                                            u"kind": u"modifier",
                                            u"id": u"b30f355c-5e20-11ea-80f3-b3789bae7a7e",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Full cutlery",
                                            u"price": 2.2,
                                            u"kind": u"modifier",
                                            u"id": u"c1544cba-5e20-11ea-9a59-bb183ce877b3",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Random stuff",
                                            u"price": 10.12,
                                            u"kind": u"modifier",
                                            u"id": u"c683d7fa-5e20-11ea-ba66-2b3a054f7a67",
                                        },
                                    ],
                                    u"name": u"General Extras",
                                    u"kind": u"modifier_group",
                                    u"min_allowed": 0,
                                    u"max_allowed": 2,
                                    u"id": u"3124f958-5e22-11ea-a209-bfc70e0667d7",
                                }
                            ],
                            u"is_available": True,
                            u"photo_url": u"http://example.com/image-url",
                            u"id": u"a5daea48-5e20-11ea-b604-5f8c7b7cd3ac",
                            u"name": u"Cake",
                        },
                    ],
                    u"kind": u"category",
                    u"id": u"8fcedff2-5e20-11ea-8b64-abae6d0905f0",
                },
            ],
        }

        for category in expected_response["categories"]:
            for item in category["items"]:
                item["availability"] = [
                    {
                        u"start_time": u"22:00:00.000",
                        u"kind": u"availability",
                        u"day_of_week": 0,
                        u"end_time": u"23:59:00.000",
                    },
                    {
                        u"start_time": u"07:00:00.000",
                        u"kind": u"availability",
                        u"day_of_week": 0,
                        u"end_time": u"08:00:00.000",
                    },
                    {
                        u"start_time": u"22:00:00.000",
                        u"kind": u"availability",
                        u"day_of_week": 1,
                        u"end_time": u"23:00:00.000",
                    },
                    {
                        u"start_time": u"07:00:00.000",
                        u"kind": u"availability",
                        u"day_of_week": 1,
                        u"end_time": u"08:00:00.000",
                    },
                    {
                        u"start_time": u"00:00:00.000",
                        u"kind": u"availability",
                        u"day_of_week": 1,
                        u"end_time": u"03:00:00.000",
                    },
                ]

        return expected_response

    def test_generate_catalog_payload(
        self, full_delivery_service_menu, expected_response
    ):
        delivery_service = full_delivery_service_menu
        delivery_service_key = delivery_service.key

        ds = delivery_service_key.get()
        menu_sync_key = ds.menuSync

        query = MenuSection.query()
        query = query.filter(MenuSection.menuSync == menu_sync_key)
        menu_section = query.get()
        menu_section.uuid = expected_response["external_id"]
        menu_section.availability = [
            {
                "day_of_week": "monday",
                "enabled": True,
                "time_periods": [
                    {"start_time": "22:00", "end_time": "23:59"},
                    {"start_time": "07:00", "end_time": "08:00"},
                ],
            },
            {
                "day_of_week": "tuesday",
                "enabled": False,
                "time_periods": [
                    {"start_time": "22:00", "end_time": "23:00"},
                    {"start_time": "07:00", "end_time": "08:00"},
                ],
            },
            {
                "day_of_week": "tuesday",
                "enabled": True,
                "time_periods": [{"start_time": "00:00", "end_time": "03:00"}, ],
            },
        ]
        menu_section.put()

        schema = CatalogSchema()
        response, errors = schema.dump(menu_section)

        assert not errors

        response = remove_keys_from_dict(response, ("created", "updated"))
        response.pop("availability")
        assert response == expected_response

    def test_load_catalog(self, full_delivery_service_menu, expected_response):
        delivery_service = full_delivery_service_menu
        delivery_service_key = delivery_service.key

        ds = delivery_service_key.get()
        menu_sync_key = ds.menuSync

        query = MenuSection.query()
        query = query.filter(MenuSection.menuSync == menu_sync_key)
        menu_section = query.get()
        menu_section.uuid = expected_response["external_id"]
        menu_section.availability = [
            {
                "day_of_week": "monday",
                "enabled": True,
                "time_periods": [
                    {"start_time": "22:00", "end_time": "23:59"},
                    {"start_time": "07:00", "end_time": "08:00"},
                ],
            },
            {
                "day_of_week": "tuesday",
                "enabled": False,
                "time_periods": [
                    {"start_time": "22:00", "end_time": "23:00"},
                    {"start_time": "07:00", "end_time": "08:00"},
                ],
            },
            {
                "day_of_week": "tuesday",
                "enabled": True,
                "time_periods": [{"start_time": "00:00", "end_time": "03:00"},],
            },
        ]
        menu_section.put()

        schema = CatalogSchema()
        schema.context["menu_sync_key"] = menu_sync_key
        response, errors = schema.dump(menu_section)
        assert not errors

        new_menu_section, errors = schema.load(response)
        assert new_menu_section.availability == menu_section.availability
        assert not errors

        response, errors = schema.dump(menu_section)
        response.pop("availability")
        assert not errors

        response = remove_keys_from_dict(response, ("created", "updated"))
        assert response == expected_response

    def test_load_catalog_with_dumped_response(self, full_delivery_service_menu):
        response = {
            u"updated": "2020-04-25T18:33:55.119001+00:00",
            u"name": u"dinner",
            u"created": "2020-04-25T18:33:53.533457+00:00",
            u"kind": "catalog",
            u"external_id": "ca7d58ab-815e-4503-8950-20a6b03f3d46",
            u"categories": [
                {
                    u"updated": "2020-04-25T18:33:53.780531+00:00",
                    u"name": u"chicken and veal specialties",
                    u"created": "2020-04-25T18:33:53.658308+00:00",
                    u"items": [
                        {
                            u"price_currency": u"usd",
                            u"updated": "2020-04-25T18:34:10.235197+00:00",
                            u"name": u"osso buco siciliana with rosemary potatoes and asparagus",
                            u"created": "2020-04-25T18:34:09.435511+00:00",
                            u"price": 32.95,
                            u"description": u"braised veal shank with cremolata topping sauce, onions, carrots, garlic, and wine. served with garlic bread and choice of soup or mixed green salad.",
                            u"kind": "item",
                            u"tax_rate": 9.5,
                            u"is_available": True,
                            u"modifier_groups": [
                                {
                                    u"updated": "2020-04-25T18:34:11.586289+00:00",
                                    u"modifiers": [
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.523247+00:00",
                                            u"name": u"soup",
                                            u"created": "2020-04-25T18:33:39.829359+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "f202adf4-2c16-4d43-975e-2116867334f2",
                                        },
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.523450+00:00",
                                            u"name": u"mixed green salad",
                                            u"created": "2020-04-25T18:33:39.829616+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "5202e7da-e9d6-4e68-ae21-211b34e0762e",
                                        },
                                    ],
                                    u"name": u"choice of side",
                                    u"created": "2020-04-25T18:33:45.743905+00:00",
                                    u"kind": "modifier_group",
                                    u"min_allowed": 1,
                                    u"max_allowed": 1,
                                    u"id": "1b25be70-a7f7-4058-8b41-ec8def78bc29",
                                }
                            ],
                            u"id": "ffb691bd-8214-4ddd-a688-f4e486dc668d",
                            u"photo_url": None,
                        },
                        {
                            u"price_currency": u"usd",
                            u"updated": "2020-05-08T05:23:49.745357+00:00",
                            u"name": u"chicken piccata milanese with capellini checca",
                            u"created": "2020-04-25T18:34:08.926329+00:00",
                            u"price": 19.95,
                            u"description": u"sauteed chicken breast in flour, caper, mushrooms, butter, herbs, and tomatoes. served with garlic bread and choice of soup or mixed green salad.",
                            u"kind": "item",
                            u"tax_rate": 9.5,
                            u"is_available": True,
                            u"id": "091b2ace-2d6b-4ed1-bd76-90d145fbc3e6",
                            u"photo_url": None,
                        },
                        {
                            u"price_currency": u"usd",
                            u"updated": "2020-05-08T05:23:49.745203+00:00",
                            u"name": u"chicken parmigiana with penne meat sauce",
                            u"created": "2020-04-25T18:34:08.216899+00:00",
                            u"price": 19.95,
                            u"description": u"breaded chicken breast with mozzarella, parmigiano, and marinara sauce. served with garlic bread and choice of soup or mixed green salad.",
                            u"kind": "item",
                            u"tax_rate": 9.5,
                            u"is_available": True,
                            u"id": "5b2fcd2b-e144-4dc0-b368-da5e48f1022d",
                            u"photo_url": None,
                        },
                        {
                            u"price_currency": u"usd",
                            u"updated": "2020-05-08T05:23:49.744788+00:00",
                            u"name": u"chicken cacciatora with capellini checca",
                            u"created": "2020-04-25T18:34:08.821414+00:00",
                            u"price": 19.95,
                            u"description": u"chicken breast, white wine, mushrooms, and olives in marinara sauce. served with garlic bread and choice of soup or mixed green salad.",
                            u"kind": "item",
                            u"tax_rate": 9.5,
                            u"is_available": True,
                            u"modifier_groups": [
                                {
                                    u"updated": "2020-04-25T18:34:11.586289+00:00",
                                    u"modifiers": [
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.523247+00:00",
                                            u"name": u"soup",
                                            u"created": "2020-04-25T18:33:39.829359+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "f202adf4-2c16-4d43-975e-2116867334f2",
                                        },
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.523450+00:00",
                                            u"name": u"mixed green salad",
                                            u"created": "2020-04-25T18:33:39.829616+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "5202e7da-e9d6-4e68-ae21-211b34e0762e",
                                        },
                                    ],
                                    u"name": u"choice of side",
                                    u"created": "2020-04-25T18:33:45.743905+00:00",
                                    u"kind": "modifier_group",
                                    u"min_allowed": 1,
                                    u"max_allowed": 1,
                                    u"id": "1b25be70-a7f7-4058-8b41-ec8def78bc29",
                                }
                            ],
                            u"id": "2dd521ea-4412-43fb-9896-4a5453f34b54",
                            u"photo_url": None,
                        },
                        {
                            u"price_currency": u"usd",
                            u"updated": "2020-05-08T05:23:49.744967+00:00",
                            u"name": u"chicken marsala with penne alfredo",
                            u"created": "2020-04-25T18:34:09.060666+00:00",
                            u"price": 19.95,
                            u"description": u"sauteed chicken breast with mushrooms, herbs, butter, garlic, and marsala wine. served with garlic bread and choice of soup or mixed green salad.",
                            u"kind": "item",
                            u"tax_rate": 9.5,
                            u"is_available": True,
                            u"modifier_groups": [
                                {
                                    u"updated": "2020-04-25T18:34:11.586289+00:00",
                                    u"modifiers": [
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.523247+00:00",
                                            u"name": u"soup",
                                            u"created": "2020-04-25T18:33:39.829359+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "f202adf4-2c16-4d43-975e-2116867334f2",
                                        },
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.523450+00:00",
                                            u"name": u"mixed green salad",
                                            u"created": "2020-04-25T18:33:39.829616+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "5202e7da-e9d6-4e68-ae21-211b34e0762e",
                                        },
                                    ],
                                    u"name": u"choice of side",
                                    u"created": "2020-04-25T18:33:45.743905+00:00",
                                    u"kind": "modifier_group",
                                    u"min_allowed": 1,
                                    u"max_allowed": 1,
                                    u"id": "1b25be70-a7f7-4058-8b41-ec8def78bc29",
                                }
                            ],
                            u"id": "7de18d64-90ec-4906-b092-1927f52e8509",
                            u"photo_url": None,
                        },
                        {
                            u"price_currency": u"usd",
                            u"updated": "2020-05-08T05:23:49.818723+00:00",
                            u"name": u"veal parmigiana with penne meat sauce",
                            u"created": "2020-04-25T18:34:09.192579+00:00",
                            u"price": 22.95,
                            u"description": u"sauteed breaded veal in egg, herbs, topped with mozzarella, parmigiano, and marinara sauce. served with garlic bread and choice of soup or mixed green salad.",
                            u"kind": "item",
                            u"tax_rate": 9.5,
                            u"is_available": True,
                            u"id": "deb492e7-08f1-4f8b-a396-6a145d9e3f2d",
                            u"photo_url": None,
                        },
                        {
                            u"price_currency": u"usd",
                            u"updated": "2020-05-08T05:23:49.745126+00:00",
                            u"name": u"chicken pancetta with asparagus and angel hair",
                            u"created": "2020-04-25T18:34:08.420889+00:00",
                            u"price": 21.95,
                            u"description": u"chicken breast with asparagus, mushrooms, pancetta, herbs, cream, and parmigiano. served with garlic bread and choice of soup or mixed green salad.",
                            u"kind": "item",
                            u"tax_rate": 9.5,
                            u"is_available": True,
                            u"modifier_groups": [
                                {
                                    u"updated": "2020-04-25T18:34:11.586289+00:00",
                                    u"modifiers": [
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.523247+00:00",
                                            u"name": u"soup",
                                            u"created": "2020-04-25T18:33:39.829359+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "f202adf4-2c16-4d43-975e-2116867334f2",
                                        },
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.523450+00:00",
                                            u"name": u"mixed green salad",
                                            u"created": "2020-04-25T18:33:39.829616+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "5202e7da-e9d6-4e68-ae21-211b34e0762e",
                                        },
                                    ],
                                    u"name": u"choice of side",
                                    u"created": "2020-04-25T18:33:45.743905+00:00",
                                    u"kind": "modifier_group",
                                    u"min_allowed": 1,
                                    u"max_allowed": 1,
                                    u"id": "1b25be70-a7f7-4058-8b41-ec8def78bc29",
                                }
                            ],
                            u"id": "0a0e546f-b662-4c28-9606-893b05209cf4",
                            u"photo_url": None,
                        },
                    ],
                    u"kind": "category",
                    u"id": "aabe670a-e6c8-4e1b-85c7-75242c844217",
                },
                {
                    u"updated": "2020-04-25T18:33:54.548752+00:00",
                    u"name": u"steaks and seafood",
                    u"created": "2020-04-25T18:33:54.421485+00:00",
                    u"items": [
                        {
                            u"price_currency": u"usd",
                            u"updated": "2020-04-25T18:34:11.033541+00:00",
                            u"name": u"shrimp scampi and blackened-with penne alfredo",
                            u"created": "2020-04-25T18:34:10.250194+00:00",
                            u"price": 31.95,
                            u"description": u"double the shrimp, 1/2 scampi, and 1/2 blackened. served with garlic bread and choice of soup or mixed green salad.",
                            u"kind": "item",
                            u"tax_rate": 9.5,
                            u"is_available": True,
                            u"id": "299c0ab1-5d11-451d-9ffc-4aeac06fd409",
                            u"photo_url": None,
                        },
                        {
                            u"price_currency": u"usd",
                            u"updated": "2020-05-08T05:54:01.645962+00:00",
                            u"name": u"linguine ai frutti di mare with blackened shrimp",
                            u"created": "2020-04-25T18:34:10.814854+00:00",
                            u"price": 31.95,
                            u"description": u"linguine, clams, mussels, calamari, tiger shrimp, spicy herbs, wine, and lemon mixed in a red sauce. served with garlic bread and choice of soup or mixed green salad.",
                            u"kind": "item",
                            u"tax_rate": 9.5,
                            u"is_available": True,
                            u"id": "7f1f98db-0d08-4430-80a8-5c9c69c83465",
                            u"photo_url": None,
                        },
                        {
                            u"price_currency": u"usd",
                            u"updated": "2020-04-25T18:34:10.685534+00:00",
                            u"name": u"rib eye steak-with red potatoes and asparagus",
                            u"created": "2020-04-25T18:34:09.646117+00:00",
                            u"price": 32.95,
                            u"description": u"16 oz rib eye choice. served with garlic bread and choice of soup or mixed green salad.",
                            u"kind": "item",
                            u"tax_rate": 9.5,
                            u"is_available": True,
                            u"modifier_groups": [
                                {
                                    u"updated": "2020-04-25T18:34:11.669498+00:00",
                                    u"modifiers": [
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.611827+00:00",
                                            u"name": u"rare",
                                            u"created": "2020-04-25T18:33:55.334814+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "1121f2f6-10f0-4318-825d-bf398ea64fff",
                                        },
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.611970+00:00",
                                            u"name": u"medium rare",
                                            u"created": "2020-04-25T18:33:55.335370+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "118171b1-8f68-4a20-a79c-9e836625ec7d",
                                        },
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.612060+00:00",
                                            u"name": u"medium",
                                            u"created": "2020-04-25T18:33:55.335544+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "8874ed09-e08e-4164-bcd7-b5b0f05b5168",
                                        },
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.612135+00:00",
                                            u"name": u"medium well",
                                            u"created": "2020-04-25T18:33:55.335693+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "41971206-e468-415d-b9a0-db3d7d9e4516",
                                        },
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.612212+00:00",
                                            u"name": u"well done",
                                            u"created": "2020-04-25T18:33:55.335827+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "ba2d130c-e2ee-4879-85a8-eafee0d099e1",
                                        },
                                    ],
                                    u"name": u"choice of steak preparation",
                                    u"created": "2020-04-25T18:33:54.565550+00:00",
                                    u"kind": "modifier_group",
                                    u"min_allowed": 1,
                                    u"max_allowed": 1,
                                    u"id": "d3c8ea7a-87ee-48c4-b832-7aa659f95fbd",
                                }
                            ],
                            u"id": "d7cc567b-e08b-47b3-abb0-b07fd0274f50",
                            u"photo_url": u"https://d1ralsognjng37.cloudfront.net/3804ecfe-fad6-4a4f-bc1d-91d1debe9ddb",
                        },
                        {
                            u"price_currency": u"usd",
                            u"updated": "2020-04-25T18:34:11.762664+00:00",
                            u"name": u"rib eye steak with gorgonzola",
                            u"created": "2020-04-25T18:34:10.033036+00:00",
                            u"price": 32.95,
                            u"description": u"16 oz rib eye choice topped with gorgonzola cheese and with red potatoes. served with garlic bread and choice of soup or mixed green salad.",
                            u"kind": "item",
                            u"tax_rate": 9.5,
                            u"is_available": True,
                            u"modifier_groups": [
                                {
                                    u"updated": "2020-04-25T18:34:11.669498+00:00",
                                    u"modifiers": [
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.611827+00:00",
                                            u"name": u"rare",
                                            u"created": "2020-04-25T18:33:55.334814+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "1121f2f6-10f0-4318-825d-bf398ea64fff",
                                        },
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.611970+00:00",
                                            u"name": u"medium rare",
                                            u"created": "2020-04-25T18:33:55.335370+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "118171b1-8f68-4a20-a79c-9e836625ec7d",
                                        },
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.612060+00:00",
                                            u"name": u"medium",
                                            u"created": "2020-04-25T18:33:55.335544+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "8874ed09-e08e-4164-bcd7-b5b0f05b5168",
                                        },
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.612135+00:00",
                                            u"name": u"medium well",
                                            u"created": "2020-04-25T18:33:55.335693+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "41971206-e468-415d-b9a0-db3d7d9e4516",
                                        },
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.612212+00:00",
                                            u"name": u"well done",
                                            u"created": "2020-04-25T18:33:55.335827+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "ba2d130c-e2ee-4879-85a8-eafee0d099e1",
                                        },
                                    ],
                                    u"name": u"choice of steak preparation",
                                    u"created": "2020-04-25T18:33:54.565550+00:00",
                                    u"kind": "modifier_group",
                                    u"min_allowed": 1,
                                    u"max_allowed": 1,
                                    u"id": "d3c8ea7a-87ee-48c4-b832-7aa659f95fbd",
                                },
                                {
                                    u"updated": "2020-04-25T18:34:11.586289+00:00",
                                    u"modifiers": [
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.523247+00:00",
                                            u"name": u"soup",
                                            u"created": "2020-04-25T18:33:39.829359+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "f202adf4-2c16-4d43-975e-2116867334f2",
                                        },
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.523450+00:00",
                                            u"name": u"mixed green salad",
                                            u"created": "2020-04-25T18:33:39.829616+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "5202e7da-e9d6-4e68-ae21-211b34e0762e",
                                        },
                                    ],
                                    u"name": u"choice of side",
                                    u"created": "2020-04-25T18:33:45.743905+00:00",
                                    u"kind": "modifier_group",
                                    u"min_allowed": 1,
                                    u"max_allowed": 1,
                                    u"id": "1b25be70-a7f7-4058-8b41-ec8def78bc29",
                                },
                            ],
                            u"id": "f39721d9-dcec-47ab-9635-8b0408501eb2",
                            u"photo_url": None,
                        },
                        {
                            u"price_currency": u"usd",
                            u"updated": "2020-05-08T05:33:47.324586+00:00",
                            u"name": u"blackened salmon-with rosemary potatoes",
                            u"created": "2020-04-25T18:34:10.663124+00:00",
                            u"price": 22.95,
                            u"description": u"cayenne pepper, garlic, herbs, butter, and lemon cream sauce. served with garlic bread and choice of soup or mixed green salad.",
                            u"kind": "item",
                            u"tax_rate": 9.5,
                            u"is_available": True,
                            u"id": "441597eb-759f-4b30-924e-1b4cbcc10acc",
                            u"photo_url": None,
                        },
                        {
                            u"price_currency": u"usd",
                            u"updated": "2020-04-25T18:34:10.734368+00:00",
                            u"name": u"shrimp scampi-with penne alfredo",
                            u"created": "2020-04-25T18:34:09.977111+00:00",
                            u"price": 24.95,
                            u"description": u"large tiger shrimp sauteed in lemon scampi sauce. served with garlic bread and choice of soup or mixed green salad.",
                            u"kind": "item",
                            u"tax_rate": 9.5,
                            u"is_available": True,
                            u"id": "051b3930-5735-4c43-a5cc-9210c8809b46",
                            u"photo_url": None,
                        },
                        {
                            u"price_currency": u"usd",
                            u"updated": "2020-04-25T18:34:11.683424+00:00",
                            u"name": u"panko parmesan crusted halibut with capellini checca",
                            u"created": "2020-04-25T18:34:10.421881+00:00",
                            u"price": 26.95,
                            u"description": u"panko parmesan crusted halibut with herbs, butter, and lemon cream sauce. served with garlic bread and choice of soup or mixed green salad.",
                            u"kind": "item",
                            u"tax_rate": 9.5,
                            u"is_available": True,
                            u"modifier_groups": [
                                {
                                    u"updated": "2020-04-25T18:34:11.586289+00:00",
                                    u"modifiers": [
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.523247+00:00",
                                            u"name": u"soup",
                                            u"created": "2020-04-25T18:33:39.829359+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "f202adf4-2c16-4d43-975e-2116867334f2",
                                        },
                                        {
                                            u"price_currency": "USD",
                                            u"updated": "2020-04-25T18:34:11.523450+00:00",
                                            u"name": u"mixed green salad",
                                            u"created": "2020-04-25T18:33:39.829616+00:00",
                                            u"price": 0.0,
                                            u"kind": "modifier",
                                            u"id": "5202e7da-e9d6-4e68-ae21-211b34e0762e",
                                        },
                                    ],
                                    u"name": u"choice of side",
                                    u"created": "2020-04-25T18:33:45.743905+00:00",
                                    u"kind": "modifier_group",
                                    u"min_allowed": 1,
                                    u"max_allowed": 1,
                                    u"id": "1b25be70-a7f7-4058-8b41-ec8def78bc29",
                                }
                            ],
                            u"id": "daeb8dea-3fbc-4a02-8a4d-f3bda1c64652",
                            u"photo_url": u"https://d1ralsognjng37.cloudfront.net/844a5c78-8e1f-4872-bcb2-7ae29410979c",
                        },
                    ],
                    u"kind": "category",
                    u"id": "b1ac9cdd-eddd-4a41-8017-f8203a7adb2a",
                },
            ],
        }

        delivery_service = full_delivery_service_menu
        delivery_service_key = delivery_service.key

        ds = delivery_service_key.get()
        menu_sync_key = ds.menuSync

        schema = CatalogSchema()
        schema.context["menu_sync_key"] = menu_sync_key
        menu_section, errors_load = schema.load(response)
        assert not errors_load
