from freezegun import freeze_time

import pytest
from flask import url_for

from application.apis.deliveryservice.model.DeliveryService import (
    DeliveryServiceType,
    DeliveryService,
)
from application.apis.menu.model.MenuItem import MenuItem
from application.apis.menu.model.MenuSection import MenuSection
from application.apis.menu.model.MenuSync import MenuSync
from application.core.event.model import CoreEvent, CoreEventCategory
from application.core.security.token_handler import get_token
from application.test.api.menu.seed import full_delivery_service_menu
from application.test.utils import remove_keys_from_dict


@pytest.mark.usefixtures("db")
class TestMenuSectionController(object):
    @pytest.fixture
    def catalog_response(self):
        catalog_response = {
            u"external_id": u"da678510-8598-11ea-9423-93d1bd303a8f",
            u"name": u"Brunch",
            u"kind": u"catalog",
            u"categories": [
                {
                    u"name": u"Drinks",
                    u"items": [
                        {
                            u"price_currency": u"USD",
                            u"description": u"Plain coffee",
                            u"price": 12.34,
                            u"kind": u"item",
                            u"tax_rate": 0.24,
                            u"modifier_groups": [
                                {
                                    u"modifiers": [
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Gift package",
                                            u"price": 1.1,
                                            u"kind": u"modifier",
                                            u"id": u"b30f355c-5e20-11ea-80f3-b3789bae7a7e",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Full cutlery",
                                            u"price": 2.2,
                                            u"kind": u"modifier",
                                            u"id": u"c1544cba-5e20-11ea-9a59-bb183ce877b3",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Random stuff",
                                            u"price": 10.12,
                                            u"kind": u"modifier",
                                            u"id": u"c683d7fa-5e20-11ea-ba66-2b3a054f7a67",
                                        },
                                    ],
                                    u"name": u"General Extras",
                                    u"kind": u"modifier_group",
                                    u"min_allowed": 0,
                                    u"max_allowed": 2,
                                    u"id": u"3124f958-5e22-11ea-a209-bfc70e0667d7",
                                },
                                {
                                    u"modifiers": [
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Volcanic Suggar",
                                            u"price": 2.3,
                                            u"kind": u"modifier",
                                            u"id": u"c799638a-5e20-11ea-970c-27db128ea549",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Himalaia Suggar",
                                            u"price": 3.21,
                                            u"kind": u"modifier",
                                            u"id": u"c8106d18-5e20-11ea-bb36-6fbbf42eca74",
                                        },
                                    ],
                                    u"name": u"Coffee extras",
                                    u"kind": u"modifier_group",
                                    u"min_allowed": 0,
                                    u"max_allowed": 2,
                                    u"id": u"c724a6f8-5e20-11ea-b816-7f6a1c0937a5",
                                },
                            ],
                            u"is_available": True,
                            u"photo_url": u"http://example.com/image-url",
                            u"id": u"7ec5cefa-5e20-11ea-8de1-276fc7dce234",
                            u"name": u"Coffee",
                        },
                        {
                            u"price_currency": u"USD",
                            u"description": u"Plain milk",
                            u"price": 12.34,
                            u"kind": u"item",
                            u"tax_rate": 0.24,
                            u"modifier_groups": [
                                {
                                    u"modifiers": [
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Gift package",
                                            u"price": 1.1,
                                            u"kind": u"modifier",
                                            u"id": u"b30f355c-5e20-11ea-80f3-b3789bae7a7e",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Full cutlery",
                                            u"price": 2.2,
                                            u"kind": u"modifier",
                                            u"id": u"c1544cba-5e20-11ea-9a59-bb183ce877b3",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Random stuff",
                                            u"price": 10.12,
                                            u"kind": u"modifier",
                                            u"id": u"c683d7fa-5e20-11ea-ba66-2b3a054f7a67",
                                        },
                                    ],
                                    u"name": u"General Extras",
                                    u"kind": u"modifier_group",
                                    u"min_allowed": 0,
                                    u"max_allowed": 2,
                                    u"id": u"3124f958-5e22-11ea-a209-bfc70e0667d7",
                                },
                                {
                                    u"modifiers": [
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Volcanic Suggar",
                                            u"price": 2.3,
                                            u"kind": u"modifier",
                                            u"id": u"c799638a-5e20-11ea-970c-27db128ea549",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Himalaia Suggar",
                                            u"price": 3.21,
                                            u"kind": u"modifier",
                                            u"id": u"c8106d18-5e20-11ea-bb36-6fbbf42eca74",
                                        },
                                    ],
                                    u"name": u"Coffee extras",
                                    u"kind": u"modifier_group",
                                    u"min_allowed": 0,
                                    u"max_allowed": 2,
                                    u"id": u"c724a6f8-5e20-11ea-b816-7f6a1c0937a5",
                                },
                            ],
                            u"is_available": True,
                            u"photo_url": u"http://example.com/image-url",
                            u"id": u"97e99a6a-5e20-11ea-be41-efead2745647",
                            u"name": u"Milk",
                        },
                    ],
                    u"kind": u"category",
                    u"id": u"8a820696-5e20-11ea-b85c-3bca604d7cf9",
                },
                {
                    u"name": u"Foods",
                    u"items": [
                        {
                            u"price_currency": u"USD",
                            u"description": u"Plain bread",
                            u"price": 12.34,
                            u"kind": u"item",
                            u"tax_rate": 0.24,
                            u"modifier_groups": [
                                {
                                    u"modifiers": [
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Gift package",
                                            u"price": 1.1,
                                            u"kind": u"modifier",
                                            u"id": u"b30f355c-5e20-11ea-80f3-b3789bae7a7e",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Full cutlery",
                                            u"price": 2.2,
                                            u"kind": u"modifier",
                                            u"id": u"c1544cba-5e20-11ea-9a59-bb183ce877b3",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Random stuff",
                                            u"price": 10.12,
                                            u"kind": u"modifier",
                                            u"id": u"c683d7fa-5e20-11ea-ba66-2b3a054f7a67",
                                        },
                                    ],
                                    u"name": u"General Extras",
                                    u"kind": u"modifier_group",
                                    u"min_allowed": 0,
                                    u"max_allowed": 2,
                                    u"id": u"3124f958-5e22-11ea-a209-bfc70e0667d7",
                                }
                            ],
                            u"is_available": True,
                            u"photo_url": u"http://example.com/image-url",
                            u"id": u"9e156fae-5e20-11ea-810e-cbc95b5675b7",
                            u"name": u"Bread",
                        },
                        {
                            u"price_currency": u"USD",
                            u"description": u"Plain cake",
                            u"price": 12.34,
                            u"kind": u"item",
                            u"tax_rate": 0.24,
                            u"modifier_groups": [
                                {
                                    u"modifiers": [
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Gift package",
                                            u"price": 1.1,
                                            u"kind": u"modifier",
                                            u"id": u"b30f355c-5e20-11ea-80f3-b3789bae7a7e",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Full cutlery",
                                            u"price": 2.2,
                                            u"kind": u"modifier",
                                            u"id": u"c1544cba-5e20-11ea-9a59-bb183ce877b3",
                                        },
                                        {
                                            u"price_currency": u"USD",
                                            u"name": u"Random stuff",
                                            u"price": 10.12,
                                            u"kind": u"modifier",
                                            u"id": u"c683d7fa-5e20-11ea-ba66-2b3a054f7a67",
                                        },
                                    ],
                                    u"name": u"General Extras",
                                    u"kind": u"modifier_group",
                                    u"min_allowed": 0,
                                    u"max_allowed": 2,
                                    u"id": u"3124f958-5e22-11ea-a209-bfc70e0667d7",
                                }
                            ],
                            u"is_available": True,
                            u"photo_url": u"http://example.com/image-url",
                            u"id": u"a5daea48-5e20-11ea-b604-5f8c7b7cd3ac",
                            u"name": u"Cake",
                        },
                    ],
                    u"kind": u"category",
                    u"id": u"8fcedff2-5e20-11ea-8b64-abae6d0905f0",
                },
            ],
        }
        for category in catalog_response["categories"]:
            for item in category["items"]:
                item["availability"] = [
                    {
                        u"start_time": u"22:00:00.000",
                        u"kind": u"availability",
                        u"day_of_week": 0,
                        u"end_time": u"23:59:00.000",
                    },
                    {
                        u"start_time": u"07:00:00.000",
                        u"kind": u"availability",
                        u"day_of_week": 0,
                        u"end_time": u"08:00:00.000",
                    },
                    {
                        u"start_time": u"22:00:00.000",
                        u"kind": u"availability",
                        u"day_of_week": 1,
                        u"end_time": u"23:00:00.000",
                    },
                    {
                        u"start_time": u"07:00:00.000",
                        u"kind": u"availability",
                        u"day_of_week": 1,
                        u"end_time": u"08:00:00.000",
                    },
                    {
                        u"start_time": u"00:00:00.000",
                        u"kind": u"availability",
                        u"day_of_week": 1,
                        u"end_time": u"03:00:00.000",
                    },
                ]
        return catalog_response

    @freeze_time("2020-01-30T23:06:00Z")
    def test_get_catalog(
        self, admin_client, full_delivery_service_menu, catalog_response
    ):
        delivery_service = full_delivery_service_menu
        delivery_service.type = DeliveryServiceType.POSTMATES
        delivery_service.put()

        menu_sync_key= delivery_service.menuSync

        query = MenuSection.query()
        query = query.filter(MenuSection.menuSync == menu_sync_key)
        menu_section = query.get()
        menu_section.uuid = catalog_response["external_id"]
        menu_section.availability = [
            {
                "day_of_week": "monday",
                "enabled": True,
                "time_periods": [
                    {"start_time": "22:00", "end_time": "23:59"},
                    {"start_time": "07:00", "end_time": "08:00"},
                ],
            },
            {
                "day_of_week": "tuesday",
                "enabled": False,
                "time_periods": [
                    {"start_time": "22:00", "end_time": "23:00"},
                    {"start_time": "07:00", "end_time": "08:00"},
                ],
            },
            {
                "day_of_week": "tuesday",
                "enabled": True,
                "time_periods": [{"start_time": "00:00", "end_time": "03:00"}, ],
            },
        ]
        menu_section.put()

        restaurant = delivery_service.restaurant.get()

        token = get_token(restaurant.id, expires_in=300)

        response = admin_client.get(
            url_for(
                "api.DS-postmates_delivery_service_postmates_catalog",
                restaurant_id=restaurant.id,
                token=token,
            )
        )
        assert response.status_code == 200
        response = response.json
        response = remove_keys_from_dict(response, ("created", "updated"))
        assert response == catalog_response

    @freeze_time("2020-01-30T23:06:00Z")
    def test_get_catalog_without_token_returns_badrequest(self, admin_client):
        response = admin_client.get(
            url_for(
                "api.DS-postmates_delivery_service_postmates_catalog",
                restaurant_id=1,
                token=None,
            )
        )
        assert response.status_code == 400

    @freeze_time("2020-01-30T23:06:00Z")
    def test_get_catalog_with_expired_token_returns_notfound(
        self, admin_client, full_delivery_service_menu, mocker
    ):
        mocker.patch(
            "application.apis.deliveryservice.controller.postmates.read_token",
            return_value=None,
        )

        delivery_service = full_delivery_service_menu
        delivery_service.type = DeliveryServiceType.POSTMATES
        delivery_service.put()

        restaurant = delivery_service.restaurant.get()

        token = get_token(restaurant.id, expires_in=300)

        response = admin_client.get(
            url_for(
                "api.DS-postmates_delivery_service_postmates_catalog",
                restaurant_id=restaurant.id,
                token=token,
            )
        )
        assert response.status_code == 404

    @freeze_time("2020-01-30T23:06:00Z")
    def test_get_catalog_with_wrong_token_returns_notfound(
        self, admin_client, full_delivery_service_menu
    ):
        delivery_service = full_delivery_service_menu
        delivery_service.type = DeliveryServiceType.POSTMATES
        delivery_service.put()

        restaurant = delivery_service.restaurant.get()

        token = get_token("wrong_id", expires_in=300)

        response = admin_client.get(
            url_for(
                "api.DS-postmates_delivery_service_postmates_catalog",
                restaurant_id=restaurant.id,
                token=token,
            )
        )
        assert response.status_code == 404

    @freeze_time("2020-01-30T23:06:00Z")
    def test_get_catalog_without_restaurant_returns_notfound(self, admin_client):

        token = get_token(1, expires_in=300)

        response = admin_client.get(
            url_for(
                "api.DS-postmates_delivery_service_postmates_catalog",
                restaurant_id=1,
                token=token,
            )
        )
        assert response.status_code == 404


@pytest.mark.usefixtures("db")
class TestDeliveryServicePostmatesConnect(object):

    @pytest.fixture
    def mock_task_to_fetch_menu(self, mocker):
        mocker.patch("application.apis.deliveryservice.controller.doordash.startTaskToFetchMenu")

    def test_post_connect_without_restaurant_returns_not_found(self, api_key_admin_client):
        payload = {"place_id": "123", "account_id": "account_id"}

        response = api_key_admin_client.post(
            url_for(
                "api.DS-postmates_delivery_service_postmates_connect", restaurant_id=1
            ),
            json=payload,
        )
        assert response.status_code == 404

    def test_post_connect_without_admin_return_forbidden(self, client):
        payload = {"location_id": "123"}

        response = client.post(
            url_for(
                "api.DS-postmates_delivery_service_postmates_connect", restaurant_id=1
            ),
            json=payload,
        )
        assert response.status_code != 200


    def test_post_connect_without_payload_returns_badrequest(self, api_key_admin_client):
        response = api_key_admin_client.post(
            url_for(
                "api.DS-postmates_delivery_service_postmates_connect", restaurant_id=1
            ),
            json={},
        )
        assert response.status_code == 400

    def test_post_connect(self, api_key_admin_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        delivery_service.put()

        place_id = "123"
        account_id = "account_id"

        restaurant = delivery_service.restaurant.get()
        payload = {"place_id": place_id, "account_id": account_id}

        response = api_key_admin_client.post(
            url_for(
                "api.DS-postmates_delivery_service_postmates_connect",
                restaurant_id=restaurant.id,
            ),
            json=payload,
        )

        query = DeliveryService.query()
        delivery_service = query.filter(
            DeliveryService.type == DeliveryServiceType.POSTMATES
        ).get()

        assert delivery_service.type == DeliveryServiceType.POSTMATES
        assert delivery_service.restaurant.id() == restaurant.id
        assert delivery_service.serviceLocationId == place_id
        assert delivery_service.service_account_id == account_id

        query = MenuSync.query()
        query = query.filter(MenuSync.service == delivery_service.key)
        query = query.filter(MenuSync.restaurant == restaurant.key)
        menu_sync = query.get()

        query = MenuItem.query()
        menu_itens = query.filter(MenuItem.menuSync == menu_sync.key).fetch()
        assert menu_sync.map_total_menu_items == len(menu_itens)
        assert response.status_code == 200

    @pytest.mark.usefixtures("mock_task_to_fetch_menu")
    def test_connect_core_event(self, api_key_admin_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        delivery_service.put()

        place_id = "123"
        account_id = "account_id"

        restaurant = delivery_service.restaurant.get()
        payload = {"place_id": place_id, "account_id": account_id}

        api_key_admin_client.post(
            url_for(
                "api.DS-postmates_delivery_service_postmates_connect",
                restaurant_id=restaurant.id,
            ),
            json=payload,
        )

        query = CoreEvent.query()
        query = query.filter(CoreEvent.category == CoreEventCategory.DS_CONNECT)
        event = query.get()

        assert event.message == 'Delivery Service CONNECT'
        assert event.name == 'POSTMATES'
        assert event.user_key == None
