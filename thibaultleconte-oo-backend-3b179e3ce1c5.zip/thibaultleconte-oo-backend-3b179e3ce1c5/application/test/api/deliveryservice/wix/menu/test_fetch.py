import json

from mock import Mock, patch

from application.apis.deliveryservice.service.wix.menu.fetch import _parse_section
from application.test.base import BaseTestCase


class TestWixMenuFetch(BaseTestCase):
    @property
    def default_avaialability(self):
        availability = []
        days_of_week = [
            "monday",
            "tuesday",
            "wednesday",
            "thursday",
            "friday",
            "saturday",
            "sunday",
        ]
        for day_of_week in days_of_week:
            time_period = {"start_time": "00:01", "end_time": "23:59"}
            day_availability = {
                "day_of_week": day_of_week.lower(),
                "enabled": True,
                "time_periods": [time_period],
            }
            availability.append(day_availability)
        return availability

    @patch("application.apis.menu.service.crud.section.fetch_section")
    def test_parse_section(self, fetch_section_mock):
        mock_key = Mock()
        mock_section = Mock()
        mock_section.key = mock_key
        mock_key.get.return_value = mock_section

        fetch_section_mock.return_value = mock_section

        menu_sync_key = "key"
        raw_section = {
            "id": "raw_section_id",
            "title": {"en_US": "raw_section_title"},
            "description": {"en_US": "raw_section_description"},
        }

        raw_index = "raw_index"

        _raw_uuid = raw_section.get("id")
        _raw_name = raw_section.get("title").get("en_US")
        _raw_description = raw_section.get("description").get("en_US")

        section = _parse_section(menu_sync_key, raw_section, raw_index)

        assert section.description == "raw_section_description"
        assert section.name == "raw_section_title"
        assert section.availability == self.default_avaialability
