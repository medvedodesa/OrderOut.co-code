# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 12/27/2019
#

import unittest
from application.test.base import BaseTestCase
from application.apis.deliveryservice.service.grubhub.order import (
    build_items_array_from_raw_menu_items,
)


class TestApiDSGrubhubOrderParsing(BaseTestCase):
    def test_build_items_aray_sample_1(self):
        _raw_menu_items = [
            {"quantity": "1", "description": "A1. Four Spring Rolls", "price": "$5.25"},
            {"quantity": "1", "description": "N1. Pad Thai", "price": "$14.95"},
            {
                "quantity": None,
                "description": "* Shrimp\n* * A little bit spicy",
                "price": None,
            },
            {
                "quantity": "1",
                "description": "N6. Spice and Dice Fried Rice",
                "price": "$14.95",
            },
            {"quantity": None, "description": "* Shrimp", "price": None},
        ]
        _items_array = build_items_array_from_raw_menu_items(_raw_menu_items)
        self.assertTrue(len(_items_array) == 3)
        _item_to_check = _items_array[1]
        _modifiers = _item_to_check.get("modifiers")
        self.assertTrue(len(_modifiers) == 2)
        _first_modifier_name = _modifiers[0]
        self.assertTrue(_first_modifier_name == "shrimp")
        _second_modifier_name = _modifiers[1]
        self.assertTrue(_second_modifier_name == "* a little bit spicy")

    def test_build_items_aray_sample_2(self):
        _raw_menu_items = [
            {
                "quantity": "1",
                "description": "Bagel with choice of Cream Cheese and Spreads",
                "price": "$2.68",
            },
            {
                "quantity": None,
                "description": "* Everything Bagel\n* Plain Cream Cheese\n* Toasted",
                "price": None,
            },
            {
                "quantity": "1",
                "description": "Bagel Breakfast Sandwich",
                "price": "$5.04",
            },
            {
                "quantity": None,
                "description": "* Blueberry Bagel\n* No Egg\n* Deli Ham\n* Swiss Cheese\n* Roasted Pepper\n* Grilled Green Peppers\n* Lettuce\n* Ketchup Packets",
                "price": None,
            },
            {
                "quantity": "1",
                "description": "Bagel Breakfast Sandwich",
                "price": "$3.54",
            },
            {
                "quantity": None,
                "description": "* Sundried Tomato Bagel\n* No Egg\n* Toasted\n* Swiss Cheese\n* Grilled Onions\n* Roasted Pepper\n* Grilled Green Peppers\n* Tomato\n* Ketchup Packets",
                "price": None,
            },
        ]
        _items_array = build_items_array_from_raw_menu_items(_raw_menu_items)
        self.assertTrue(len(_items_array) == 3)
        _item_to_check = _items_array[2]
        _modifiers = _item_to_check.get("modifiers")
        self.assertTrue(len(_modifiers) == 9)
        _first_modifier_name = _modifiers[0]
        self.assertTrue(_first_modifier_name == "sundried tomato bagel")
        _second_modifier_name = _modifiers[8]
        self.assertTrue(_second_modifier_name == "ketchup packets")

    def test_build_items_aray_sample_3(self):
        _raw_menu_items = [
            {"quantity": "1", "description": "The Work's", "price": "$13.58"},
            {
                "quantity": None,
                "description": "* Scrambled cheddar\n* Sausage Patty\n* 3 Buttermilk",
                "price": None,
            },
        ]
        _items_array = build_items_array_from_raw_menu_items(_raw_menu_items)
        self.assertTrue(len(_items_array) == 1)
        _item_to_check = _items_array[0]
        _modifiers = _item_to_check.get("modifiers")
        self.assertTrue(len(_modifiers) == 3)
        self.assertTrue(_modifiers[0] == "scrambled cheddar")
        self.assertTrue(_modifiers[1] == "sausage patty")
        self.assertTrue(_modifiers[2] == "3 buttermilk")

    def test_build_items_aray_sample_4_instructions(self):
        _raw_menu_items = [
            {"quantity": "3", "description": "Media Noche", "price": "$20.85"},
            {"quantity": "1", "description": "Media Noche", "price": "$6.95"},
            {
                "quantity": "1",
                "description": "Media Noche Instructions: No mustard",
                "price": "$6.95",
            },
            {"quantity": "2", "description": "Cheese Tequenos", "price": "$4.90"},
            {"quantity": "1", "description": "Soda", "price": "$1.59"},
            {"quantity": None, "description": "* Coca Cola", "price": None},
            {"quantity": "1", "description": "Soda", "price": "$1.59"},
            {"quantity": None, "description": "* Diet Coke", "price": None},
            {"quantity": "1", "description": "Cafe con Leche", "price": "$3.69"},
            {"quantity": None, "description": "* 12 oz.", "price": None},
        ]
        _items_array = build_items_array_from_raw_menu_items(_raw_menu_items)
        self.assertTrue(len(_items_array) == 7)
        _item_to_check = _items_array[0]
        self.assertTrue(_item_to_check.get("name") == "media noche")
        self.assertTrue(_item_to_check.get("price") == 20.85)
        self.assertTrue(_item_to_check.get("unit_price") == 6.95)
        self.assertTrue(_item_to_check.get("quantity") == "3")
        self.assertTrue(len(_item_to_check.get("modifiers")) == 0)
        self.assertTrue(_item_to_check.get("instructions") == None)
        _item_to_check = _items_array[1]
        self.assertTrue(_item_to_check.get("name") == "media noche")
        self.assertTrue(_item_to_check.get("price") == 6.95)
        self.assertTrue(_item_to_check.get("unit_price") == 6.95)
        self.assertTrue(_item_to_check.get("quantity") == "1")
        self.assertTrue(len(_item_to_check.get("modifiers")) == 0)
        self.assertTrue(_item_to_check.get("instructions") == None)
        _item_to_check = _items_array[2]
        self.assertTrue(_item_to_check.get("name") == "media noche")
        self.assertTrue(_item_to_check.get("price") == 6.95)
        self.assertTrue(_item_to_check.get("unit_price") == 6.95)
        self.assertTrue(_item_to_check.get("quantity") == "1")
        self.assertTrue(len(_item_to_check.get("modifiers")) == 0)
        self.assertTrue(_item_to_check.get("instructions") == "no mustard")
        _item_to_check = _items_array[3]
        self.assertTrue(_item_to_check.get("name") == "cheese tequenos")
        self.assertTrue(_item_to_check.get("price") == 4.90)
        self.assertTrue(_item_to_check.get("unit_price") == 2.45)
        self.assertTrue(_item_to_check.get("quantity") == "2")
        self.assertTrue(len(_item_to_check.get("modifiers")) == 0)
        self.assertTrue(_item_to_check.get("instructions") == None)
        _item_to_check = _items_array[4]
        self.assertTrue(_item_to_check.get("name") == "soda")
        self.assertTrue(_item_to_check.get("price") == 1.59)
        self.assertTrue(_item_to_check.get("unit_price") == 1.59)
        self.assertTrue(_item_to_check.get("quantity") == "1")
        self.assertTrue(len(_item_to_check.get("modifiers")) == 1)
        self.assertTrue(_item_to_check.get("modifiers")[0] == "coca cola")
        self.assertTrue(_item_to_check.get("instructions") == None)
        _item_to_check = _items_array[5]
        self.assertTrue(_item_to_check.get("name") == "soda")
        self.assertTrue(_item_to_check.get("price") == 1.59)
        self.assertTrue(_item_to_check.get("unit_price") == 1.59)
        self.assertTrue(_item_to_check.get("quantity") == "1")
        self.assertTrue(len(_item_to_check.get("modifiers")) == 1)
        self.assertTrue(_item_to_check.get("modifiers")[0] == "diet coke")
        self.assertTrue(_item_to_check.get("instructions") == None)
        _item_to_check = _items_array[6]
        self.assertTrue(_item_to_check.get("name") == "cafe con leche")
        self.assertTrue(_item_to_check.get("price") == 3.69)
        self.assertTrue(_item_to_check.get("unit_price") == 3.69)
        self.assertTrue(_item_to_check.get("quantity") == "1")
        self.assertTrue(len(_item_to_check.get("modifiers")) == 1)
        self.assertTrue(_item_to_check.get("modifiers")[0] == "12 oz.")
        self.assertTrue(_item_to_check.get("instructions") == None)


if __name__ == "__main__":
    unittest.main()
