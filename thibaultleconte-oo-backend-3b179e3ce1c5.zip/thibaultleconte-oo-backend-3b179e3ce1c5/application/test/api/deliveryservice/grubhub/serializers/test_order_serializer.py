import pytest

from application.apis.deliveryservice.service.grubhub.serializers.order_serializer import (
    OrderSchema,
)
from application.apis.order.model.Order import OrderStatus, OrderType, Order
from application.core.parser.string import sanitize_str
from application.test.api.menu.factories import (
    MenuItemModifierFactory,
    MenuItemFactory,
    MenuModifierGroupFactory,
)
from application.test.api.menu.seed import menu_sync_key


@pytest.mark.usefixtures("db")
class TestOrderSerializer(object):
    @pytest.fixture
    def payload(self):
        return {
            "store_id": "1",
            "merchant_order_version": "d2fba08b-ab33-47b5-8e81-2ec3ca2cf0d0",
            "status_version_uuid": "cc88b469-469a-3abb-b59d-991492335bb4",
            "uuid": "2e31b090-9542-11ea-a5d6-a51f34ce7d9a",
            "merchant_uuid": "e5c47260-395d-11ea-b3bf-e74097dc91bc",
            "short_merchant_id": "1755674",
            "order_number": "352911557596577",
            "merchant_name": "Padaria Brasil Bakery & Pizzeria",
            "merchant_timezone_id": "America/New_York",
            "is_pickup": False,
            "status_history": [
                {
                    "status": "CONFIRMED",
                    "timestamp": "2020-05-13T17:52:54.185Z",
                    "update_source": "MERCHANT_ORDERS",
                },
                {
                    "status": "RESTAURANT_CONFIRMABLE",
                    "timestamp": "2020-05-13T17:51:52.787Z",
                    "update_source": "TXS",
                },
                {
                    "status": "ANTICIPATED",
                    "timestamp": "2020-05-13T17:51:52.496Z",
                    "update_source": "DINER",
                    "reason": "OrdersAPI Fulfillment Processing Update",
                },
                {
                    "status": "DELIVERY_CONFIRMABLE",
                    "timestamp": "2020-05-13T17:51:52.305Z",
                    "update_source": "DINER",
                    "reason": "GHD",
                },
            ],
            "status": "CONFIRMED",
            "confirmation_code": "3272",
            "time_placed": "2020-05-13T17:51:50.305Z",
            "requested_fulfillment_at": "2020-05-13T18:40:00.000Z",
            "updated_at": "2020-05-13T17:52:54.185Z",
            "recorded_at": "2020-05-13T18:02:08.765Z",
            "estimated_prepared_at": "2020-05-13T18:07:54.174Z",
            "special_instructions": "Keep warm",
            "dining_supplies": "INCLUDE",
            "delivery": {
                "delivery_id": "cf6c5e8e-5982-3fba-9893-230cbfe29cf7",
                "grubhub_delivery": True,
                "delivery_address": {
                    "city": "Miami",
                    "state": "FL",
                    "country": "USA",
                    "zip_code": "12345",
                    "address_line1": "Best St",
                    "address_line2": "101",
                },
                "estimated_delivered": "2020-05-13T18:39:29.358Z",
                "delivery_info": {
                    "pickup": {"geo": {"lat": 42.27948, "lng": -71.4162}},
                    "dropoff": {"geo": {"lat": 42.193047, "lng": -71.32853}},
                    "status": "ASSIGNED",
                    "courier": {
                        "id": "e1bb4777-b9fe-44a2-9824-db4dcfdbaf29",
                        "name": "Monica S",
                        "vehicle": {"type": "Car"},
                        "phone": "7747071121",
                        "photo_url": "https://s3.amazonaws.com/gh-prod-drivers-data/drivers/e1bb4777-b9fe-44a2-9824-db4dcfdbaf29.png",
                        "geo": {"lat": 42.2791, "lng": -71.41663},
                    },
                    "times": {
                        "pickup": {"type": "actual", "timestamp": 1589392928213},
                        "dropoff": {"type": "estimate", "timestamp": 1589395289358},
                    },
                    "preferences": {"pickup_time": "2020-05-13T18:07:54.174Z"},
                    "trip_id": "8ae7dca5-9543-11ea-a0cf-4b553eb04dec",
                    "pickup_feasibility_time": "2020-05-13T18:06:43.387Z",
                },
                "update_time": "dc742c90-9543-11ea-9c27-bbe2d9fc136b",
            },
            "contact_info": {"name": "Justin C", "phone": "(609) 864-4234"},
            "payments": {
                "payments": [{"entitlement_type": "CREDIT_CARD", "amount": 45.00}],
                "adjustments": [],
                "total": 45.00,
                "adjusted_total": 45.00,
                "payment_type": "CREDIT_CARD",
            },
            "charges": {
                "delivery_fee": 6.99,
                "service_fee": 1.20,
                "taxes": {
                    "total": 1.98,
                    "merchant_total": 1.98,
                    "sales": 1.98,
                    "merchant_sales_total": 1.98,
                    "delivery": 0.00,
                    "service": 0.00,
                    "restaurant": 0.00,
                    "restaurant_display": 1.98,
                },
                "tip_amount": 7.44,
                "tip_type": "CREDIT_CARD",
                "sub_total": 28.22,
                "merchant_sub_total": 0.00,
                "total": 45.00,
                "merchant_total": 30.20,
                "restaurant_grand_total": 30.20,
                "restaurant_adjusted_total": 30.20,
                "restaurant_funded_total": 0.00,
                "line_groups": [
                    {
                        "lines": [
                            {
                                "id": "1000827356",
                                "name": "X - Chicken Burger",
                                "quantity": 1,
                                "tags": [],
                                "special_instructions": "",
                                "price": 12.90,
                                "merchant_price": 12.90,
                                "total": 12.90,
                                "merchant_total": 12.90,
                                "line_options": [
                                    {
                                        "id": "1001790033",
                                        "name": "Big",
                                        "price": 10.00,
                                        "merchant_price": 10.00,
                                        "quantity": 1,
                                        "tags": [],
                                        "sub_line_options": [],
                                    },
                                    {
                                        "id": "1001790034",
                                        "name": "Extra Cheese",
                                        "price": 4.00,
                                        "merchant_price": 4.00,
                                        "quantity": 1,
                                        "tags": [],
                                        "sub_line_options": [],
                                    },
                                ],
                                "lead_time_ms": 0,
                            },
                        ]
                    }
                ],
                "coupons": [],
                "lines": [
                    {
                        "id": "1000827356",
                        "name": "X - Chicken Burger",
                        "quantity": 1,
                        "tags": [],
                        "special_instructions": "Without tomato",
                        "price": 12.90,
                        "merchant_price": 12.90,
                        "total": 12.90,
                        "merchant_total": 12.90,
                        "line_options": [
                            {
                                "id": "1001790033",
                                "name": "Big",
                                "price": 10.00,
                                "merchant_price": 10.00,
                                "quantity": 1,
                                "tags": [],
                                "sub_line_options": [],
                            },
                            {
                                "id": "1001790034",
                                "name": "Extra Cheese",
                                "price": 4.00,
                                "merchant_price": 4.00,
                                "quantity": 1,
                                "tags": [],
                                "sub_line_options": [],
                            },
                        ],
                        "lead_time_ms": 0,
                    },
                ],
            },
            "scheduled": True,
            "just_in_time_order": False,
            "just_in_time_scheduled": False,
            "just_in_time_trigger_enabled": False,
            "brand": "GRUBHUB",
            "care_request_in_progress": False,
            "sent_to_logistics": True,
            "location_description": "Concord St",
            "fulfillment_scheduling": "ASAP",
            "order_merchant_uuid": "41abbd27-9c99-34a4-bdd9-78e1361b65ec",
            "before_lead_time_window": False,
            "merchant_is_pos_integrated": False,
            "redacted": False,
            "diners": [
                {
                    "diner_uuid": "ab4dcc60-e501-11e7-b7c9-45292dabe761",
                    "lines": [
                        {
                            "id": "1000827356",
                            "name": "X- Chicken Burger",
                            "quantity": 1,
                            "tags": [],
                            "special_instructions": "",
                            "price": 12.90,
                            "merchant_price": 12.90,
                            "total": 12.90,
                            "merchant_total": 12.90,
                            "line_options": [],
                            "lead_time_ms": 0,
                        },
                        {
                            "id": "1003309665",
                            "name": "Pao Frances / French Roll",
                            "quantity": 1,
                            "tags": [],
                            "special_instructions": "",
                            "price": 1.61,
                            "merchant_price": 1.61,
                            "total": 1.61,
                            "merchant_total": 1.61,
                            "line_options": [],
                            "lead_time_ms": 0,
                        },
                        {
                            "id": "1000827024",
                            "name": "X-Bacon Burger",
                            "quantity": 1,
                            "tags": [],
                            "special_instructions": "",
                            "price": 13.71,
                            "merchant_price": 13.71,
                            "total": 13.71,
                            "merchant_total": 13.71,
                            "line_options": [
                                {
                                    "id": "1001790033",
                                    "name": "Medium",
                                    "price": 0.00,
                                    "merchant_price": 0.00,
                                    "quantity": 1,
                                    "tags": [],
                                    "sub_line_options": [],
                                }
                            ],
                        },
                    ],
                    "charges_container": {
                        "total": 45.00,
                        "subtotal": 28.22,
                        "restaurant_subtotal": 28.22,
                        "restaurant_grand_total": 30.20,
                        "lines": [
                            {
                                "id": "1000827356",
                                "name": "X- Chicken Burger",
                                "quantity": 1,
                                "tags": [],
                                "special_instructions": "",
                                "price": 12.90,
                                "merchant_price": 12.90,
                                "total": 12.90,
                                "merchant_total": 12.90,
                                "line_options": [],
                                "lead_time_ms": 0,
                            },
                            {
                                "id": "1003309665",
                                "name": "Pao Frances / French Roll",
                                "quantity": 1,
                                "tags": [],
                                "special_instructions": "",
                                "price": 1.61,
                                "merchant_price": 1.61,
                                "total": 1.61,
                                "merchant_total": 1.61,
                                "line_options": [],
                                "lead_time_ms": 0,
                            },
                            {
                                "id": "1000827024",
                                "name": "X-Bacon Burger",
                                "quantity": 1,
                                "tags": [],
                                "special_instructions": "",
                                "price": 13.71,
                                "merchant_price": 13.71,
                                "total": 13.71,
                                "merchant_total": 13.71,
                                "line_options": [
                                    {
                                        "id": "1001790033",
                                        "name": "Medium",
                                        "price": 0.00,
                                        "merchant_price": 0.00,
                                        "quantity": 1,
                                        "tags": [],
                                        "sub_line_options": [],
                                    }
                                ],
                            },
                        ],
                        "coupons": [],
                        "fees": {
                            "DELIVERY": {
                                "amount": 6.99,
                                "group": "DELIVERY",
                                "name": "Delivery fee",
                                "taxable": False,
                                "type": "DELIVERY",
                            }
                        },
                        "taxes": {"sales_total": 1.98, "fee_taxes": [], "total": 1.98},
                        "donations": {"amount": 0.37},
                        "tip": {"amount": 7.44, "type": "CREDIT_CARD"},
                    },
                    "payments": [
                        {
                            "payment_uuid": "7d42a12e-3aaf-3a82-a96c-a1e093ea4fdb",
                            "entitlement_id": "1HAt8GSTQ5acfyJUX5slyQ",
                            "entitlement_type": "CREDIT_CARD",
                            "amount_events": [
                                {
                                    "amount_event_id": "dae7fabb-d79b-3506-b5d2-22fac0e00e4b",
                                    "amount": 4500,
                                    "payments_state_id": "204c44a8-420b-3e94-acbe-ab1537a65dd5",
                                    "updated_at": "2020-05-13T17:51:50.283Z",
                                }
                            ],
                            "max_amount": 1004500,
                            "gl_account_name": "BRAINTREE_RECEIVABLE",
                            "payment_status": "COMPLETE",
                        }
                    ],
                    "cart_uuid": "2e31b090-9542-11ea-a5d6-a51f34ce7d9a",
                    "diner_info": {"name": "Justin C", "phone": "(609) 864-4234"},
                    "participation_number": "352911557596577",
                    "participation": "HOST",
                    "order_status": "ACTIVE",
                    "items_count": 3,
                    "special_instructions_count": 0,
                    "pending_adjustments": [],
                    "processed_adjustments": [],
                }
            ],
            "order_type": "STANDARD",
            "received_at": "2020-05-13T17:51:52.787Z",
            "diners_count": 1,
            "items_count": 3,
            "special_instructions_count": 0,
            "gfr_as_pos_companion": False,
            "handoff_options": [
                "CONTACTLESS_CONTACT_METHOD_TEXT",
                "CONTACTLESS",
                "CONTACTLESS_DROPOFF_LOCATION_FRONTDOOR",
            ],
        }

    @pytest.fixture
    def delivery_service_key(self, payload, menu_sync_key):
        store_id = payload["store_id"]
        menu_sync = menu_sync_key.get()
        delivery_service = menu_sync.service.get()
        delivery_service.serviceLocationId = store_id
        return delivery_service.put()

    @pytest.fixture
    def modifier_group_key(self, menu_sync_key, delivery_service_key):
        modifier_group = MenuModifierGroupFactory(menuSync=menu_sync_key, name="Groups")
        return modifier_group.put()

    @pytest.fixture
    def menu_item_key(self, payload, delivery_service_key, modifier_group_key):
        delivery_service = delivery_service_key.get()
        menu_sync_key = delivery_service.menuSync
        menu_item = MenuItemFactory(
            name=payload["charges"]["lines"][0]["name"].lower(),
            menuSync=menu_sync_key,
            modifier_groups=[modifier_group_key],
            uuid=payload["charges"]["lines"][0]["id"],
        )
        return menu_item.put()

    @pytest.fixture
    def menu_item_modifiers(
        self, payload, delivery_service_key, menu_item_key, modifier_group_key
    ):
        delivery_service = delivery_service_key.get()
        menu_sync_key = delivery_service.menuSync
        menu_item_modifier_1 = MenuItemModifierFactory(
            name=payload["charges"]["lines"][0]["line_options"][0]["name"].lower(),
            menuSync=menu_sync_key,
            groups=[modifier_group_key],
            uuid=payload["charges"]["lines"][0]["line_options"][0]["id"],
        )
        menu_item_modifier_1.put()
        menu_item_modifier_2 = MenuItemModifierFactory(
            name=payload["charges"]["lines"][0]["line_options"][1]["name"].lower(),
            menuSync=menu_sync_key,
            groups=[modifier_group_key],
            uuid=payload["charges"]["lines"][0]["line_options"][1]["id"],
        )
        menu_item_modifier_2.put()
        return [menu_item_modifier_1, menu_item_modifier_2]

    def test_create_order(
        self, payload, menu_item_key, menu_item_modifiers, delivery_service_key
    ):
        delivery_service = delivery_service_key.get()
        menu_item = menu_item_key.get()
        schema = OrderSchema(
            context={"delivery_service_key": delivery_service_key}, overwrite=True
        )
        schema.context["raw_data"] = payload
        order, errors = schema.load(payload)
        assert not errors
        assert order.account == delivery_service.account
        assert order.restaurant == delivery_service.restaurant
        assert order.status == OrderStatus.RECEIVED
        assert order.type == OrderType.DELIVERY
        assert order.delivery_service == delivery_service.key
        assert order.delivery_service_uuid == payload["order_number"]
        assert order.customer_name == payload["contact_info"]["name"]
        assert order.customer_phone == payload["contact_info"]["phone"]
        assert order.delivery_service_raw_data == payload
        assert order.delivery_address == sanitize_str(
            "{} {}".format(
                payload["delivery"]["delivery_address"]["address_line1"],
                payload["delivery"]["delivery_address"]["address_line2"],
            )
        )
        assert order.delivery_city == sanitize_str(
            payload["delivery"]["delivery_address"]["city"]
        )
        assert order.delivery_state == sanitize_str(
            payload["delivery"]["delivery_address"]["state"]
        )
        assert order.delivery_zip == sanitize_str(
            payload["delivery"]["delivery_address"]["zip_code"]
        )
        assert order.charge_tax == float(payload["charges"]["taxes"]["total"])
        assert order.charge_subtotal == float(payload["charges"]["sub_total"])
        assert order.charge_tip == float(payload["charges"]["tip_amount"])
        assert order.charge_fee == float(payload["charges"]["service_fee"])
        assert order.charge_customer_delivery_fee == float(
            payload["charges"]["delivery_fee"]
        )
        assert order.store_instructions == "Keep warm - include napkins and utensils"
        assert order.delivery_instructions == (
            "* Text customer\n* Contact-free delivery\n* Leave order at front door of house/apartment unit\nKeep warm"
        )
        assert order.charge_total == order.charge_tax + order.charge_subtotal
        assert len(order.order_items) == len(payload["charges"]["lines"])

        for i, order_item_key in enumerate(order.order_items):
            jorder_item = payload["charges"]["lines"][i]
            order_item = order_item_key.get()
            assert order_item.order == order.key
            assert order_item.unit_price == jorder_item["price"]
            assert order_item.quantity == jorder_item["quantity"]
            assert order_item.price == jorder_item["total"]
            assert order_item.menu_item.get() == menu_item
            if order_item.menu_item.get().name == "X - Chicken Burger".lower():
                assert order_item.store_instructions == "Without tomato"

            jmodifiers = []
            jmodifier_list = jorder_item["line_options"]
            for jmodifier in jmodifier_list:
                jmodifiers.append(jmodifier)

            assert len(order_item.selected_modifier) == len(jmodifiers)
            for j, modifier_key in enumerate(order_item.selected_modifier):
                modifier = modifier_key.get()
                assert modifier.order == order.key
                assert modifier.order_item == order_item_key
                assert modifier.menu_item_modifier.get() == menu_item_modifiers[j]
                assert modifier.price == jmodifiers[j]["price"]

    def test_dont_duplicate_order(
        self, payload, menu_item_key, menu_item_modifiers, delivery_service_key
    ):
        payload["order_number"] = "new_order"

        orders = Order.query().fetch()
        len_orders = len(orders)

        schema = OrderSchema(
            context={"delivery_service_key": delivery_service_key}, overwrite=True
        )
        schema.context["raw_data"] = payload
        schema.load(payload)

        orders = Order.query().fetch()
        assert len(orders) == len_orders + 1

        schema = OrderSchema(
            context={"delivery_service_key": delivery_service_key}, overwrite=True
        )
        schema.context["raw_data"] = payload
        schema.load(payload)

        orders = Order.query().fetch()
        assert len(orders) == len_orders + 1
