import pytest
from flask import url_for
from freezegun import freeze_time
from google.appengine.ext import ndb
from mock.mock import Mock

from application.apis.deliveryservice.model.DeliveryService import (
    DeliveryService,
    DeliveryServiceType,
)
from application.apis.deliveryservice.service.grubhub.order import (
    processTaskToProcessOrderFromGrubhub,
)
from application.apis.order.model.Order import Order
from application.apis.order.service.creator import get_create_order
from application.core.event.model import CoreEvent, CoreEventCategory
from application.core.security.cryptography import AESCipher
from application.core.settings.app import get_config_for_key
from application.test.api.menu.factories import (
    MenuItemModifierFactory,
    MenuItemFactory,
    MenuModifierGroupFactory,
)
from application.test.api.menu.seed import menu_sync_key
from application.test.api.point_of_sale.factories import PointOfSaleFactory
from application.apis.pointofsale.model.PointOfSale import PointOfSaleType
from application.test.api.menu.seed import full_delivery_service_menu


@pytest.mark.usefixtures("db")
class TestDeliveryServiceGrubHubCredential(object):
    def test_post_credential(self, api_key_admin_client, menu_sync_key):
        ds = menu_sync_key.get().service.get()

        payload = {"username": "johndoe", "password": "$tr0ng_P@ssw0rd"}

        ds = DeliveryService.get_by_id(ds.id)
        ds.type = DeliveryServiceType.GRUBHUB
        ds.put()

        response = api_key_admin_client.post(
            url_for(
                "api.DS-grubhub_delivery_service_grubhub_credential",
                restaurant_id=ds.restaurant.id(),
            ),
            json=payload,
        )

        assert response.status_code == 200
        assert ds.service_username == payload["username"]
        assert ds.service_password != payload["password"]
        assert ds.service_secret == payload["password"]

        decrypted_password = AESCipher(key=get_config_for_key("SECRET_KEY")).decrypt(
            ds.service_password
        )
        assert decrypted_password == payload["password"]


@pytest.mark.usefixtures("db")
class TestDeliveryServiceGrubHubParseurWebhook(object):
    @pytest.fixture
    def parseur_payload(self):
        return {
            "grandTotal": "$30.20",
            "reference": "35291155 - 7596577",
            "dropoffPhone": "(609) 864-4234",
            "tax": "$1.98",
            "To": "oogh+1755854@in.parseur.com",
            "Template": "Grubhub v11 no address instructions",
            "dropoffName": "Justin C",
            "itemCount": "3",
            "orderType": "DELIVERY",
            "confirmationLink": "https://orderemails.grubhub.com/554597ff-96ae-4bb7-8e25-5a99627cb1aa/4e8c6f9f-9113-392f-8013-f114fae8fa64",
            "source": "grubhub",
            "Recipient": "oogh+1755854@in.parseur.com",
            "pickupPhone": "(508) 872-8698",
            "Sender": "orders@eat.grubhub.com",
            "getSwiftTemplate": "Padaria Brasil Bakery & Pizzeria",
            "CC": None,
            "deliveryInstructions": "Contact-free delivery* * Leave order at front door of house/apartment unit* Text customer",
            "confirmationCode": "3272",
            "dropoffDescription": "Include napkins and utensils? YES",
            "items": [
                {
                    "price": "$12.90",
                    "description": "X - Chicken Burger",
                    "quantity": "1",
                },
                {
                    "price": "$1.61",
                    "description": "Pao Frances / French Roll",
                    "quantity": "1",
                },
                {"price": "$13.71", "description": "X-Bacon Burger", "quantity": "1"},
                {"price": None, "description": "* Medium", "quantity": None},
            ],
            "paymentMode": "PREPAID DO NOT CHARGE",
            "dateTime": "May 13, 2020, 2:18 PM",
            "subTotal": "$28.22",
            "Subject": "Order 35291155-7596577 Confirmation",
        }

    @pytest.fixture
    def grubhub_api_payload(self):
        return {
            "merchant_order_version": "d2fba08b-ab33-47b5-8e81-2ec3ca2cf0d0",
            "status_version_uuid": "cc88b469-469a-3abb-b59d-991492335bb4",
            "uuid": "2e31b090-9542-11ea-a5d6-a51f34ce7d9a",
            "merchant_uuid": "e5c47260-395d-11ea-b3bf-e74097dc91bc",
            "short_merchant_id": "1755674",
            "order_number": "352911557596577",
            "merchant_name": "Padaria Brasil Bakery & Pizzeria",
            "merchant_timezone_id": "America/New_York",
            "is_pickup": False,
            "status_history": [
                {
                    "status": "CONFIRMED",
                    "timestamp": "2020-05-13T17:52:54.185Z",
                    "update_source": "MERCHANT_ORDERS",
                },
                {
                    "status": "RESTAURANT_CONFIRMABLE",
                    "timestamp": "2020-05-13T17:51:52.787Z",
                    "update_source": "TXS",
                },
                {
                    "status": "ANTICIPATED",
                    "timestamp": "2020-05-13T17:51:52.496Z",
                    "update_source": "DINER",
                    "reason": "OrdersAPI Fulfillment Processing Update",
                },
                {
                    "status": "DELIVERY_CONFIRMABLE",
                    "timestamp": "2020-05-13T17:51:52.305Z",
                    "update_source": "DINER",
                    "reason": "GHD",
                },
            ],
            "status": "CONFIRMED",
            "confirmation_code": "3272",
            "time_placed": "2020-05-13T17:51:50.305Z",
            "requested_fulfillment_at": "2020-05-13T18:40:00.000Z",
            "updated_at": "2020-05-13T17:52:54.185Z",
            "recorded_at": "2020-05-13T18:02:08.765Z",
            "estimated_prepared_at": "2020-05-13T18:07:54.174Z",
            "special_instructions": "Keep warm",
            "dining_supplies": "INCLUDE",
            "delivery": {
                "delivery_id": "cf6c5e8e-5982-3fba-9893-230cbfe29cf7",
                "grubhub_delivery": True,
                "delivery_address": {
                    "city": "Miami",
                    "state": "FL",
                    "country": "USA",
                    "zip_code": "12345",
                    "address_line1": "Best st",
                    "address_line2": "123",
                },
                "estimated_delivered": "2020-05-13T18:39:29.358Z",
                "delivery_info": {
                    "pickup": {"geo": {"lat": 42.27948, "lng": -71.4162}},
                    "dropoff": {"geo": {"lat": 42.193047, "lng": -71.32853}},
                    "status": "ASSIGNED",
                    "courier": {
                        "id": "e1bb4777-b9fe-44a2-9824-db4dcfdbaf29",
                        "name": "Monica S",
                        "vehicle": {"type": "Car"},
                        "phone": "7747071121",
                        "photo_url": "https://s3.amazonaws.com/gh-prod-drivers-data/drivers/e1bb4777-b9fe-44a2-9824-db4dcfdbaf29.png",
                        "geo": {"lat": 42.2791, "lng": -71.41663},
                    },
                    "times": {
                        "pickup": {"type": "actual", "timestamp": 1589392928213},
                        "dropoff": {"type": "estimate", "timestamp": 1589395289358},
                    },
                    "preferences": {"pickup_time": "2020-05-13T18:07:54.174Z"},
                    "trip_id": "8ae7dca5-9543-11ea-a0cf-4b553eb04dec",
                    "pickup_feasibility_time": "2020-05-13T18:06:43.387Z",
                },
                "update_time": "dc742c90-9543-11ea-9c27-bbe2d9fc136b",
            },
            "contact_info": {"name": "Justin C", "phone": "(609) 864-4234"},
            "payments": {
                "payments": [{"entitlement_type": "CREDIT_CARD", "amount": 45.00}],
                "adjustments": [],
                "total": 45.00,
                "adjusted_total": 45.00,
                "payment_type": "CREDIT_CARD",
            },
            "charges": {
                "delivery_fee": 6.99,
                "service_fee": 0.00,
                "taxes": {
                    "total": 1.98,
                    "merchant_total": 1.98,
                    "sales": 1.98,
                    "merchant_sales_total": 1.98,
                    "delivery": 0.00,
                    "service": 0.00,
                    "restaurant": 0.00,
                    "restaurant_display": 1.98,
                },
                "tip_amount": 7.44,
                "tip_type": "CREDIT_CARD",
                "sub_total": 28.22,
                "merchant_sub_total": 0.00,
                "total": 45.00,
                "merchant_total": 30.20,
                "restaurant_grand_total": 30.20,
                "restaurant_adjusted_total": 30.20,
                "restaurant_funded_total": 0.00,
                "line_groups": [
                    {
                        "lines": [
                            {
                                "id": "1000827356",
                                "name": "X- Chicken Burger",
                                "quantity": 1,
                                "tags": [],
                                "special_instructions": "",
                                "price": 12.90,
                                "merchant_price": 12.90,
                                "total": 12.90,
                                "merchant_total": 12.90,
                                "line_options": [],
                                "lead_time_ms": 0,
                            },
                            {
                                "id": "1003309665",
                                "name": "Pao Frances / French Roll",
                                "quantity": 1,
                                "tags": [],
                                "special_instructions": "",
                                "price": 1.61,
                                "merchant_price": 1.61,
                                "total": 1.61,
                                "merchant_total": 1.61,
                                "line_options": [],
                                "lead_time_ms": 0,
                            },
                            {
                                "id": "1000827024",
                                "name": "X-Bacon Burger",
                                "quantity": 1,
                                "tags": [],
                                "special_instructions": "",
                                "price": 13.71,
                                "merchant_price": 13.71,
                                "total": 13.71,
                                "merchant_total": 13.71,
                                "line_options": [
                                    {
                                        "name": "Medium",
                                        "price": 0.00,
                                        "id": "123",
                                        "merchant_price": 0.00,
                                        "quantity": 1,
                                        "tags": [],
                                        "sub_line_options": [],
                                    }
                                ],
                            },
                        ]
                    }
                ],
                "coupons": [],
                "lines": [
                    {
                        "id": "1000827356",
                        "name": "X - Chicken Burger",
                        "quantity": 1,
                        "tags": [],
                        "special_instructions": "",
                        "price": 12.90,
                        "merchant_price": 12.90,
                        "total": 12.90,
                        "merchant_total": 12.90,
                        "line_options": [],
                        "lead_time_ms": 0,
                    },
                    {
                        "id": "1003309665",
                        "name": "Pao Frances / French Roll",
                        "quantity": 1,
                        "tags": [],
                        "special_instructions": "",
                        "price": 1.61,
                        "merchant_price": 1.61,
                        "total": 1.61,
                        "merchant_total": 1.61,
                        "line_options": [],
                        "lead_time_ms": 0,
                    },
                    {
                        "id": "1000827024",
                        "name": "X-Bacon Burger",
                        "quantity": 1,
                        "tags": [],
                        "special_instructions": "",
                        "price": 13.71,
                        "merchant_price": 13.71,
                        "total": 13.71,
                        "merchant_total": 13.71,
                        "line_options": [
                            {
                                "id": "1001790033",
                                "name": "Medium",
                                "price": 0.00,
                                "merchant_price": 0.00,
                                "quantity": 1,
                                "tags": [],
                                "sub_line_options": [],
                            }
                        ],
                    },
                ],
            },
            "scheduled": True,
            "just_in_time_order": False,
            "just_in_time_scheduled": False,
            "just_in_time_trigger_enabled": False,
            "brand": "GRUBHUB",
            "care_request_in_progress": False,
            "sent_to_logistics": True,
            "location_description": "Concord St",
            "fulfillment_scheduling": "ASAP",
            "order_merchant_uuid": "41abbd27-9c99-34a4-bdd9-78e1361b65ec",
            "before_lead_time_window": False,
            "merchant_is_pos_integrated": False,
            "redacted": False,
            "diners": [
                {
                    "diner_uuid": "ab4dcc60-e501-11e7-b7c9-45292dabe761",
                    "lines": [
                        {
                            "id": "1000827356",
                            "name": "X- Chicken Burger",
                            "quantity": 1,
                            "tags": [],
                            "special_instructions": "",
                            "price": 12.90,
                            "merchant_price": 12.90,
                            "total": 12.90,
                            "merchant_total": 12.90,
                            "line_options": [],
                            "lead_time_ms": 0,
                        },
                        {
                            "id": "1003309665",
                            "name": "Pao Frances / French Roll",
                            "quantity": 1,
                            "tags": [],
                            "special_instructions": "",
                            "price": 1.61,
                            "merchant_price": 1.61,
                            "total": 1.61,
                            "merchant_total": 1.61,
                            "line_options": [],
                            "lead_time_ms": 0,
                        },
                        {
                            "id": "1000827024",
                            "name": "X-Bacon Burger",
                            "quantity": 1,
                            "tags": [],
                            "special_instructions": "",
                            "price": 13.71,
                            "merchant_price": 13.71,
                            "total": 13.71,
                            "merchant_total": 13.71,
                            "line_options": [
                                {
                                    "id": "1001790033",
                                    "name": "Medium",
                                    "price": 0.00,
                                    "merchant_price": 0.00,
                                    "quantity": 1,
                                    "tags": [],
                                    "sub_line_options": [],
                                }
                            ],
                        },
                    ],
                    "charges_container": {
                        "total": 45.00,
                        "subtotal": 28.22,
                        "restaurant_subtotal": 28.22,
                        "restaurant_grand_total": 30.20,
                        "lines": [
                            {
                                "id": "1000827356",
                                "name": "X- Chicken Burger",
                                "quantity": 1,
                                "tags": [],
                                "special_instructions": "",
                                "price": 12.90,
                                "merchant_price": 12.90,
                                "total": 12.90,
                                "merchant_total": 12.90,
                                "line_options": [],
                                "lead_time_ms": 0,
                            },
                            {
                                "id": "1003309665",
                                "name": "Pao Frances / French Roll",
                                "quantity": 1,
                                "tags": [],
                                "special_instructions": "",
                                "price": 1.61,
                                "merchant_price": 1.61,
                                "total": 1.61,
                                "merchant_total": 1.61,
                                "line_options": [],
                                "lead_time_ms": 0,
                            },
                            {
                                "id": "1000827024",
                                "name": "X-Bacon Burger",
                                "quantity": 1,
                                "tags": [],
                                "special_instructions": "",
                                "price": 13.71,
                                "merchant_price": 13.71,
                                "total": 13.71,
                                "merchant_total": 13.71,
                                "line_options": [
                                    {
                                        "id": "1001790033",
                                        "name": "Medium",
                                        "price": 0.00,
                                        "merchant_price": 0.00,
                                        "quantity": 1,
                                        "tags": [],
                                        "sub_line_options": [],
                                    }
                                ],
                            },
                        ],
                        "coupons": [],
                        "fees": {
                            "DELIVERY": {
                                "amount": 6.99,
                                "group": "DELIVERY",
                                "name": "Delivery fee",
                                "taxable": False,
                                "type": "DELIVERY",
                            }
                        },
                        "taxes": {"sales_total": 1.98, "fee_taxes": [], "total": 1.98},
                        "donations": {"amount": 0.37},
                        "tip": {"amount": 7.44, "type": "CREDIT_CARD"},
                    },
                    "payments": [
                        {
                            "payment_uuid": "7d42a12e-3aaf-3a82-a96c-a1e093ea4fdb",
                            "entitlement_id": "1HAt8GSTQ5acfyJUX5slyQ",
                            "entitlement_type": "CREDIT_CARD",
                            "amount_events": [
                                {
                                    "amount_event_id": "dae7fabb-d79b-3506-b5d2-22fac0e00e4b",
                                    "amount": 4500,
                                    "payments_state_id": "204c44a8-420b-3e94-acbe-ab1537a65dd5",
                                    "updated_at": "2020-05-13T17:51:50.283Z",
                                }
                            ],
                            "max_amount": 1004500,
                            "gl_account_name": "BRAINTREE_RECEIVABLE",
                            "payment_status": "COMPLETE",
                        }
                    ],
                    "cart_uuid": "2e31b090-9542-11ea-a5d6-a51f34ce7d9a",
                    "diner_info": {"name": "Justin C", "phone": "(609) 864-4234"},
                    "participation_number": "352911557596577",
                    "participation": "HOST",
                    "order_status": "ACTIVE",
                    "items_count": 3,
                    "special_instructions_count": 0,
                    "pending_adjustments": [],
                    "processed_adjustments": [],
                }
            ],
            "order_type": "STANDARD",
            "received_at": "2020-05-13T17:51:52.787Z",
            "diners_count": 1,
            "items_count": 3,
            "special_instructions_count": 0,
            "gfr_as_pos_companion": False,
            "handoff_options": [
                "CONTACTLESS_CONTACT_METHOD_TEXT",
                "CONTACTLESS",
                "CONTACTLESS_DROPOFF_LOCATION_FRONTDOOR",
            ],
        }

    @pytest.fixture
    def delivery_service_key(self, menu_sync_key):
        store_id = "1755854"
        menu_sync = menu_sync_key.get()
        delivery_service = menu_sync.service.get()
        delivery_service.serviceLocationId = store_id
        return delivery_service.put()

    @pytest.fixture
    def modifier_group_key(self, menu_sync_key, delivery_service_key):
        modifier_group = MenuModifierGroupFactory(menuSync=menu_sync_key, name="Groups")
        return modifier_group.put()

    @pytest.fixture
    def menu_item_modifiers(
        self, parseur_payload, delivery_service_key, modifier_group_key
    ):
        delivery_service = delivery_service_key.get()
        menu_sync_key = delivery_service.menuSync
        menu_item_modifier_1 = MenuItemModifierFactory(
            name="medium",
            menuSync=menu_sync_key,
            groups=[modifier_group_key],
            uuid="123",
        )
        return [menu_item_modifier_1.put()]

    @pytest.fixture
    def menu_items(
        self,
        parseur_payload,
        delivery_service_key,
        menu_item_modifiers,
        modifier_group_key,
    ):
        delivery_service = delivery_service_key.get()
        menu_sync_key = delivery_service.menuSync
        menu_item_1 = MenuItemFactory(
            name="x - chicken burger", menuSync=menu_sync_key, uuid="1000827356",
        )
        menu_item_1.put()

        menu_item_2 = MenuItemFactory(
            name="pao frances / french roll", menuSync=menu_sync_key, uuid="1003309665",
        )
        menu_item_2.put()

        menu_item_3 = MenuItemFactory(
            name="x-bacon burger",
            menuSync=menu_sync_key,
            modifier_groups=[modifier_group_key],
            uuid="1000827024",
        )
        menu_item_3.put()

        return [menu_item_1, menu_item_2, menu_item_3]

    @pytest.fixture
    def mock_google_stuff(self, mocker):
        mocker.patch(
            "application.apis.order.service.creator.save_order_to_bigquery",
            return_value=None,
        )
        mocker.patch(
            "application.apis.deliveryservice.service.grubhub.order.confirm_order"
        )
        mocker.patch(
            "application.apis.deliveryservice.service.grubhub.order.push_fail_safe_order_to_printers"
        )
        mocker.patch(
            "application.apis.deliveryservice.service.grubhub.order.push_order_to_point_of_sale"
        )

    @pytest.fixture
    def mock_working_grubhub_api(self, mocker, grubhub_api_payload):
        mock_grubhub_api = mocker.Mock()
        mock_grubhub_api.get_active_order.return_value = grubhub_api_payload

        mock_grubhub_api_factory = mocker.Mock()
        mock_grubhub_api_factory.instantiate_google_urlfetch_api_client.return_value = (
            mock_grubhub_api
        )

        mocker.patch(
            "application.apis.deliveryservice.service.grubhub.order.GrubHubApiClientFactory",
            mock_grubhub_api_factory,
        )

    @pytest.fixture
    def mock_no_working_grubhub_api(self, mocker, grubhub_api_payload):
        mock_grubhub_api = mocker.Mock()
        mock_grubhub_api.get_active_order.return_value = None

        mock_grubhub_api_factory = mocker.Mock()
        mock_grubhub_api_factory.instantiate_google_urlfetch_api_client.return_value = (
            mock_grubhub_api
        )

        mocker.patch(
            "application.apis.deliveryservice.service.grubhub.order.GrubHubApiClientFactory",
            mock_grubhub_api_factory,
        )

    @pytest.mark.usefixtures("mock_google_stuff", "mock_no_working_grubhub_api")
    def test_parseur_webhook_with_parseur(
        self, parseur_payload, menu_items, menu_item_modifiers, delivery_service_key
    ):
        order_id = parseur_payload["reference"]
        order = get_create_order(
            order_id=order_id, delivery_service_key=delivery_service_key
        )

        response = processTaskToProcessOrderFromGrubhub(order.id, parseur_payload)
        assert response["fail_safe_printing"] == "False"

    @pytest.mark.usefixtures("mock_google_stuff", "mock_working_grubhub_api")
    def test_parseur_webhook_with_api(
        self, parseur_payload, menu_items, menu_item_modifiers, delivery_service_key
    ):
        order_id = parseur_payload["reference"]
        order = get_create_order(
            order_id=order_id, delivery_service_key=delivery_service_key
        )

        response = processTaskToProcessOrderFromGrubhub(order.id, parseur_payload)
        assert response["fail_safe_printing"] == "False"

    @pytest.mark.usefixtures("mock_google_stuff", "mock_no_working_grubhub_api")
    def test_e2e_parseur_webhook_with_parseur(
        self,
        mocker,
        parseur_payload,
        menu_items,
        menu_item_modifiers,
        delivery_service_key,
        api_key_admin_client,
    ):
        def mock_deferred(process_parseur_webhook, request_url, json_dict):
            return process_parseur_webhook(request_url, json_dict)

        def mock_add_task(category, entity, data_dict):
            return processTaskToProcessOrderFromGrubhub(entity.id, data_dict)

        mocker.patch(
            "application.apis.deliveryservice.controller.grubhub.startDeferredTask",
            mock_deferred,
        )

        mocker.patch(
            "application.apis.deliveryservice.service.grubhub.order.addTask",
            mock_add_task,
        )

        mock_finish_processing_order = mocker.Mock()
        mocker.patch(
            "application.apis.deliveryservice.service.grubhub.order.finish_processing_order",
            mock_finish_processing_order,
        )

        response = api_key_admin_client.post(
            url_for("api.DS-grubhub_delivery_service_grubhub_parseur_process"),
            json=parseur_payload,
        )

        finish_processing_order_call_args = mock_finish_processing_order.call_args
        json_dict = finish_processing_order_call_args[0][1]
        fail_safe_printing = finish_processing_order_call_args[0][2]

        payload_reference = parseur_payload.pop("reference")
        json_dict_reference = json_dict.pop("reference")

        json_dict_reference = json_dict_reference.replace("-", "").replace(" ", "")
        payload_reference = payload_reference.replace("-", "").replace(" ", "")

        order = (
            Order.query().filter(Order.delivery_service_uuid == payload_reference).get()
        )

        assert len(order.order_items) == 3
        assert json_dict_reference == payload_reference
        assert json_dict == parseur_payload
        assert not fail_safe_printing
        assert response.status_code == 200

    @pytest.mark.usefixtures("mock_google_stuff", "mock_working_grubhub_api")
    def test_e2e_parseur_webhook_with_api(
        self,
        mocker,
        parseur_payload,
        menu_items,
        menu_item_modifiers,
        delivery_service_key,
        api_key_admin_client,
    ):
        def mock_deferred(process_parseur_webhook, request_url, json_dict):
            return process_parseur_webhook(request_url, json_dict)

        def mock_add_task(category, entity, data_dict):
            return processTaskToProcessOrderFromGrubhub(entity.id, data_dict)

        mocker.patch(
            "application.apis.deliveryservice.controller.grubhub.startDeferredTask",
            mock_deferred,
        )

        mocker.patch(
            "application.apis.deliveryservice.service.grubhub.order.addTask",
            mock_add_task,
        )

        mock_finish_processing_order = mocker.Mock()
        mocker.patch(
            "application.apis.deliveryservice.service.grubhub.order.finish_processing_order",
            mock_finish_processing_order,
        )

        response = api_key_admin_client.post(
            url_for("api.DS-grubhub_delivery_service_grubhub_parseur_process"),
            json=parseur_payload,
        )

        finish_processing_order_call_args = mock_finish_processing_order.call_args
        json_dict = finish_processing_order_call_args[0][1]

        payload_reference = parseur_payload.pop("reference")
        json_dict_reference = json_dict.pop("reference")

        json_dict_reference = json_dict_reference.replace("-", "").replace(" ", "")
        payload_reference = payload_reference.replace("-", "").replace(" ", "")

        order = (
            Order.query().filter(Order.delivery_service_uuid == payload_reference).get()
        )

        assert order.charge_mode.lower() == parseur_payload.get("paymentMode").lower()

        assert len(order.order_items) == 3
        assert json_dict_reference == payload_reference
        assert json_dict == parseur_payload
        assert response.status_code == 200


@pytest.mark.usefixtures("db")
class TestGruhubToPosE2E(object):
    @pytest.fixture
    def grubhub_api_order(self):
        return {
            "scheduled": True,
            "short_merchant_id": "312640",
            "contact_info": {"phone": "(617) 653-1302", "name": "Thibault LE C"},
            "merchant_is_pos_integrated": False,
            "redacted": False,
            "updated_at": "2020-06-15T19:53:03.611Z",
            "received_at": "2020-06-15T19:53:03.611Z",
            "before_lead_time_window": False,
            "diners_count": 1,
            "care_request_in_progress": False,
            "uuid": "cdafb184-af41-11ea-9bc3-fbb69b56a595",
            "confirmation_code": "7749",
            "merchant_uuid": "959eb930-dcfe-11e6-a053-57fb2d4aad6d",
            "gfr_as_pos_companion": False,
            "order_merchant_uuid": "529c4fa1-87a3-37eb-ad81-b754d8a3ad10",
            "merchant_name": "Joy Burger Bar",
            "status": "RESTAURANT_CONFIRMABLE",
            "just_in_time_scheduled": False,
            "brand": "GRUBHUB",
            "sent_to_logistics": True,
            "time_placed": "2020-06-15T19:53:00.097Z",
            "items_count": 3,
            "fulfillment_scheduling": "ASAP",
            "recorded_at": "2020-06-15T19:53:03.999Z",
            "merchant_timezone_id": "America/New_York",
            "status_version_uuid": "05ab2dd4-b084-35db-9126-08a4b3647c58",
            "order_type": "STANDARD",
            "just_in_time_order": False,
            "special_instructions": "Keep warm",
            "special_instructions_count": 1,
            "charges": {
                "coupons": [],
                "tip_amount": 0,
                "restaurant_grand_total": 31.52,
                "lines": [
                    {
                        "merchant_price": 8.95,
                        "name": "5 oz. Midi Burger",
                        "tags": [],
                        "price": 8.95,
                        "lead_time_ms": 0,
                        "merchant_total": 13.15,
                        "line_options": [
                            {
                                "merchant_price": 0,
                                "name": "Well Done",
                                "tags": [],
                                "price": 0,
                                "sub_line_options": [],
                                "id": "19629961",
                                "quantity": 1,
                            },
                            {
                                "merchant_price": 0,
                                "name": "Plain Wrap",
                                "tags": [],
                                "price": 0,
                                "sub_line_options": [],
                                "id": "21077290",
                                "quantity": 1,
                            },
                            {
                                "merchant_price": 2.25,
                                "name": "Bacon",
                                "tags": [],
                                "price": 2.25,
                                "sub_line_options": [],
                                "id": "96928675",
                                "quantity": 1,
                            },
                            {
                                "merchant_price": 1.95,
                                "name": "Fried Egg",
                                "tags": [],
                                "price": 1.95,
                                "sub_line_options": [],
                                "id": "19629983",
                                "quantity": 1,
                            },
                            {
                                "merchant_price": 0,
                                "name": "Ketchup",
                                "tags": [],
                                "price": 0,
                                "sub_line_options": [],
                                "id": "45420228",
                                "quantity": 1,
                            },
                            {
                                "merchant_price": 0,
                                "name": "Lettuce",
                                "tags": [],
                                "price": 0,
                                "sub_line_options": [],
                                "id": "126081342",
                                "quantity": 1,
                            },
                            {
                                "merchant_price": 0,
                                "name": "Bacon aioli",
                                "tags": [],
                                "price": 0,
                                "sub_line_options": [],
                                "id": "35686118",
                                "quantity": 1,
                            },
                            {
                                "merchant_price": 0,
                                "name": "Pickle",
                                "tags": [],
                                "price": 0,
                                "sub_line_options": [],
                                "id": "1503220362",
                                "quantity": 1,
                            },
                        ],
                        "total": 13.15,
                        "line_item_id": "cdafb181-af41-11ea-9bc3-fbb69b56a595",
                        "id": "15776054",
                        "quantity": 1,
                    },
                    {
                        "merchant_price": 3.85,
                        "name": "Homemade Fries",
                        "tags": [],
                        "price": 3.85,
                        "lead_time_ms": 0,
                        "merchant_total": 3.85,
                        "line_options": [],
                        "total": 3.85,
                        "line_item_id": "cdafb182-af41-11ea-9bc3-fbb69b56a595",
                        "id": "15776064",
                        "quantity": 1,
                    },
                    {
                        "merchant_price": 0,
                        "name": "The Texican",
                        "tags": [],
                        "price": 0,
                        "merchant_total": 11.95,
                        "special_instructions": "Allergic to jalapenos ",
                        "line_options": [
                            {
                                "merchant_price": 11.95,
                                "name": "Midi (5oz)",
                                "tags": [],
                                "price": 11.95,
                                "sub_line_options": [],
                                "id": "121521015",
                                "quantity": 1,
                            },
                            {
                                "merchant_price": 0,
                                "name": "Medium Well",
                                "tags": [],
                                "price": 0,
                                "sub_line_options": [],
                                "id": "19629960",
                                "quantity": 1,
                            },
                            {
                                "merchant_price": 0,
                                "name": "Plain Wrap",
                                "tags": [],
                                "price": 0,
                                "sub_line_options": [],
                                "id": "21077290",
                                "quantity": 1,
                            },
                        ],
                        "total": 11.95,
                        "line_item_id": "cdafb183-af41-11ea-9bc3-fbb69b56a595",
                        "id": "43608250",
                        "quantity": 1,
                    },
                ],
                "tip_type": "CREDIT_CARD",
                "sub_total": 28.95,
                "delivery_fee": 0,
                "taxes": {
                    "restaurant_display": 2.57,
                    "merchant_sales_total": 2.57,
                    "service": 0,
                    "restaurant": 0,
                    "sales": 2.57,
                    "delivery": 0,
                    "merchant_total": 2.57,
                    "total": 2.57,
                },
                "restaurant_adjusted_total": 31.52,
                "merchant_total": 31.52,
                "merchant_sub_total": 0,
                "line_groups": [
                    {
                        "lines": [
                            {
                                "merchant_price": 8.95,
                                "name": "5 oz. Midi Burger",
                                "tags": [],
                                "price": 8.95,
                                "lead_time_ms": 0,
                                "merchant_total": 13.15,
                                "line_options": [
                                    {
                                        "merchant_price": 0,
                                        "name": "Well Done",
                                        "tags": [],
                                        "price": 0,
                                        "sub_line_options": [],
                                        "quantity": 1,
                                    },
                                    {
                                        "merchant_price": 0,
                                        "name": "Plain Wrap",
                                        "tags": [],
                                        "price": 0,
                                        "sub_line_options": [],
                                        "quantity": 1,
                                    },
                                    {
                                        "merchant_price": 2.25,
                                        "name": "Bacon",
                                        "tags": [],
                                        "price": 2.25,
                                        "sub_line_options": [],
                                        "quantity": 1,
                                    },
                                    {
                                        "merchant_price": 1.95,
                                        "name": "Fried Egg",
                                        "tags": [],
                                        "price": 1.95,
                                        "sub_line_options": [],
                                        "quantity": 1,
                                    },
                                    {
                                        "merchant_price": 0,
                                        "name": "Ketchup",
                                        "tags": [],
                                        "price": 0,
                                        "sub_line_options": [],
                                        "quantity": 1,
                                    },
                                    {
                                        "merchant_price": 0,
                                        "name": "Lettuce",
                                        "tags": [],
                                        "price": 0,
                                        "sub_line_options": [],
                                        "quantity": 1,
                                    },
                                    {
                                        "merchant_price": 0,
                                        "name": "Bacon aioli",
                                        "tags": [],
                                        "price": 0,
                                        "sub_line_options": [],
                                        "quantity": 1,
                                    },
                                    {
                                        "merchant_price": 0,
                                        "name": "Pickle",
                                        "tags": [],
                                        "price": 0,
                                        "sub_line_options": [],
                                        "quantity": 1,
                                    },
                                ],
                                "total": 13.15,
                                "id": "15776054",
                                "quantity": 1,
                            },
                            {
                                "merchant_price": 3.85,
                                "name": "Homemade Fries",
                                "tags": [],
                                "price": 3.85,
                                "lead_time_ms": 0,
                                "merchant_total": 3.85,
                                "line_options": [],
                                "total": 3.85,
                                "id": "15776064",
                                "quantity": 1,
                            },
                            {
                                "merchant_price": 0,
                                "name": "The Texican",
                                "tags": [],
                                "price": 0,
                                "merchant_total": 11.95,
                                "special_instructions": "Allergic to jalapenos ",
                                "line_options": [
                                    {
                                        "merchant_price": 11.95,
                                        "name": "Midi (5oz)",
                                        "tags": [],
                                        "price": 11.95,
                                        "sub_line_options": [],
                                        "quantity": 1,
                                    },
                                    {
                                        "merchant_price": 0,
                                        "name": "Medium Well",
                                        "tags": [],
                                        "price": 0,
                                        "sub_line_options": [],
                                        "quantity": 1,
                                    },
                                    {
                                        "merchant_price": 0,
                                        "name": "Plain Wrap",
                                        "tags": [],
                                        "price": 0,
                                        "sub_line_options": [],
                                        "quantity": 1,
                                    },
                                ],
                                "total": 11.95,
                                "id": "43608250",
                                "quantity": 1,
                            },
                        ]
                    }
                ],
                "service_fee": 0,
                "total": 31.52,
                "restaurant_funded_total": 0,
            },
            "handoff_options": ["CONTACTLESS_CONTACT_METHOD_TEXT"],
            "delivery": {
                "delivery_id": "cf6c5e8e-5982-3fba-9893-230cbfe29cf7",
                "grubhub_delivery": True,
                "delivery_address": {
                    "city": "Miami",
                    "state": "FL",
                    "country": "USA",
                    "zip_code": "12345",
                    "address_line1": "Best St",
                    "address_line2": "101",
                },
                "estimated_delivered": "2020-05-13T18:39:29.358Z",
                "delivery_info": {
                    "pickup": {"geo": {"lat": 42.27948, "lng": -71.4162}},
                    "dropoff": {"geo": {"lat": 42.193047, "lng": -71.32853}},
                    "status": "ASSIGNED",
                    "courier": {
                        "id": "e1bb4777-b9fe-44a2-9824-db4dcfdbaf29",
                        "name": "Monica S",
                        "vehicle": {"type": "Car"},
                        "phone": "7747071121",
                        "photo_url": "https://s3.amazonaws.com/gh-prod-drivers-data/drivers/e1bb4777-b9fe-44a2-9824-db4dcfdbaf29.png",
                        "geo": {"lat": 42.2791, "lng": -71.41663},
                    },
                    "times": {
                        "pickup": {"type": "actual", "timestamp": 1589392928213},
                        "dropoff": {"type": "estimate", "timestamp": 1589395289358},
                    },
                    "preferences": {"pickup_time": "2020-05-13T18:07:54.174Z"},
                    "trip_id": "8ae7dca5-9543-11ea-a0cf-4b553eb04dec",
                    "pickup_feasibility_time": "2020-05-13T18:06:43.387Z",
                },
                "update_time": "dc742c90-9543-11ea-9c27-bbe2d9fc136b",
            },
            "dining_supplies": "INCLUDE",
            "requested_fulfillment_at": "2020-06-15T19:58:00.102Z",
            "is_pickup": True,
            "location_description": "Lexington Ave",
            "payments": {
                "total": 31.52,
                "adjustments": [],
                "payment_type": "CREDIT_CARD",
                "payments": [{"entitlement_type": "CREDIT_CARD", "amount": 31.52}],
                "adjusted_total": 31.52,
            },
            "merchant_order_version": "ce8a362e-dab6-4222-9fba-3f64e0b6a02e",
            "just_in_time_trigger_enabled": False,
            "order_number": "077011885117955",
            "status_history": [
                {
                    "status": "RESTAURANT_CONFIRMABLE",
                    "timestamp": "2020-06-15T19:53:03.611Z",
                    "update_source": "TXS",
                },
                {
                    "status": "ANTICIPATED",
                    "timestamp": "2020-06-15T19:53:03.255Z",
                    "reason": "non-GHD",
                    "update_source": "DINER",
                },
            ],
        }

    @pytest.fixture
    def parseur_payload(self):
        return {
            "grandTotal": "$31.52",
            "reference": "077011885117955",
            "dropoffPhone": "(617) 653-1302",
            "tax": "$2.57",
            "To": "joyburgerbar3@gmail.com, oogh+312640@in.parseur.com",
            "Template": "Grubhub v11 pickup",
            "dropoffName": "Thibault LE C",
            "itemCount": "3",
            "orderType": "PICKUP",
            "confirmationLink": "https://orderemails.grubhub.com/07d4eda0-f9f6-43f0-b82e-942f271a1409/b03226dd-7259-351c-967e-363455172d2d",
            "tip": "$0.00",
            "source": "grubhub",
            "Recipient": "oogh+312640@in.parseur.com",
            "pickupPhone": "(212) 289-6222",
            "Sender": "orders@eat.grubhub.com",
            "getSwiftTemplate": "Joy Burger Bar",
            "CC": None,
            "confirmationCode": "7749",
            "dropoffDescription": "Include napkins and utensils? YES",
            "items": [
                {
                    "price": "$13.15",
                    "description": "5 oz. Midi Burger",
                    "quantity": "1",
                },
                {
                    "price": None,
                    "description": """* Well Done
                    * Plain Wrap
                    * Bacon
                    * Fried Egg
                    * Ketchup
                    * Lettuce
                    * Bacon aioli
                    * Pickle""",
                    "quantity": None,
                },
                {"price": "$3.85", "description": "Homemade Fries", "quantity": "1"},
                {
                    "price": "$11.95",
                    "description": "The Texican Instructions: Allergic to jalapenos",
                    "quantity": "1",
                },
                {
                    "price": None,
                    "description": """* Midi (5oz)
                    * Medium Well
                    * Plain Wrap""",
                    "quantity": None,
                },
            ],
            "paymentMode": "PREPAID DO NOT CHARGE",
            "dateTime": "Jun 15, 2020, 3:58 PM",
            "subTotal": "$28.95",
            "Subject": "Order 07701188-5117955 Confirmation",
        }

    @pytest.fixture
    def delivery_service_key(self, menu_sync_key):
        store_id = "312640"
        menu_sync = menu_sync_key.get()
        delivery_service = menu_sync.service.get()
        delivery_service.type = DeliveryServiceType.GRUBHUB
        delivery_service.integration_enabled = True
        delivery_service.serviceLocationId = store_id
        return delivery_service.put()

    @pytest.fixture
    def point_of_sale_key(self, menu_sync_key):
        menu_sync = menu_sync_key.get()
        restaurant_key = menu_sync.restaurant
        restaurant = restaurant_key.get()
        account_key = restaurant.account
        point_of_sale_key = PointOfSaleFactory(
            restaurant=restaurant_key, account=account_key, type=PointOfSaleType.NEWTEK
        ).put()
        restaurant.point_of_sale = point_of_sale_key
        restaurant.put()
        return point_of_sale_key

    @pytest.fixture
    def menu_item_1_modifier_group_key(self, menu_sync_key, delivery_service_key):
        modifier_group = MenuModifierGroupFactory(menuSync=menu_sync_key, name="Groups")
        return modifier_group.put()

    @pytest.fixture
    def menu_item_3_modifier_group_key(self, menu_sync_key, delivery_service_key):
        modifier_group = MenuModifierGroupFactory(
            menuSync=menu_sync_key, name="Groups 2"
        )
        return modifier_group.put()

    @pytest.fixture
    def menu_item_1_modifiers(
        self, delivery_service_key, menu_item_1_modifier_group_key
    ):
        delivery_service = delivery_service_key.get()
        menu_sync_key = delivery_service.menuSync
        menu_item_modifier_1 = MenuItemModifierFactory(
            name="well done",
            menuSync=menu_sync_key,
            groups=[menu_item_1_modifier_group_key],
            uuid="19629961",
            mappedToMenuItemModifier=MenuItemModifierFactory(
                name="mapped well done", menuSync=menu_sync_key,
            ).put(),
        )
        menu_item_modifier_2 = MenuItemModifierFactory(
            name="plain wrap",
            menuSync=menu_sync_key,
            groups=[menu_item_1_modifier_group_key],
            uuid="21077290",
            mappedToMenuItemModifier=MenuItemModifierFactory(
                name="mapped plain wrap", menuSync=menu_sync_key,
            ).put(),
        )
        menu_item_modifier_3 = MenuItemModifierFactory(
            name="bacon",
            menuSync=menu_sync_key,
            groups=[menu_item_1_modifier_group_key],
            uuid="96928675",
            mappedToMenuItemModifier=MenuItemModifierFactory(
                name="mapped bacon", menuSync=menu_sync_key,
            ).put(),
        )
        menu_item_modifier_4 = MenuItemModifierFactory(
            name="fried egg",
            menuSync=menu_sync_key,
            groups=[menu_item_1_modifier_group_key],
            uuid="19629983",
            mappedToMenuItemModifier=MenuItemModifierFactory(
                name="mapped fried egg", menuSync=menu_sync_key,
            ).put(),
        )
        menu_item_modifier_5 = MenuItemModifierFactory(
            name="ketchup",
            menuSync=menu_sync_key,
            groups=[menu_item_1_modifier_group_key],
            uuid="45420228",
            mappedToMenuItemModifier=MenuItemModifierFactory(
                name="mapped ketchup", menuSync=menu_sync_key,
            ).put(),
        )
        menu_item_modifier_6 = MenuItemModifierFactory(
            name="lettuce",
            menuSync=menu_sync_key,
            groups=[menu_item_1_modifier_group_key],
            uuid="126081342",
            mappedToMenuItemModifier=MenuItemModifierFactory(
                name="mapped lettuce", menuSync=menu_sync_key,
            ).put(),
        )
        menu_item_modifier_7 = MenuItemModifierFactory(
            name="bacon aioli",
            menuSync=menu_sync_key,
            groups=[menu_item_1_modifier_group_key],
            uuid="35686118",
            mappedToMenuItemModifier=MenuItemModifierFactory(
                name="mapped bacon aioli", menuSync=menu_sync_key,
            ).put(),
        )
        menu_item_modifier_8 = MenuItemModifierFactory(
            name="pickle",
            menuSync=menu_sync_key,
            groups=[menu_item_1_modifier_group_key],
            uuid="1503220362",
            mappedToMenuItemModifier=MenuItemModifierFactory(
                name="mapped pickle", menuSync=menu_sync_key,
            ).put(),
        )
        return [
            menu_item_modifier_1.put(),
            menu_item_modifier_2.put(),
            menu_item_modifier_3.put(),
            menu_item_modifier_4.put(),
            menu_item_modifier_5.put(),
            menu_item_modifier_6.put(),
            menu_item_modifier_7.put(),
            menu_item_modifier_8.put(),
        ]

    @pytest.fixture
    def menu_item_3_modifiers(
        self, delivery_service_key, menu_item_3_modifier_group_key
    ):
        delivery_service = delivery_service_key.get()
        menu_sync_key = delivery_service.menuSync
        menu_item_modifier_1 = MenuItemModifierFactory(
            name="midi (5oz)",
            menuSync=menu_sync_key,
            groups=[menu_item_3_modifier_group_key],
            uuid="121521015",
            mappedToMenuItemModifier=MenuItemModifierFactory(
                name="mapped midi (5oz)", menuSync=menu_sync_key,
            ).put(),
        )
        menu_item_modifier_2 = MenuItemModifierFactory(
            name="medium well",
            menuSync=menu_sync_key,
            groups=[menu_item_3_modifier_group_key],
            uuid="19629960",
            mappedToMenuItemModifier=MenuItemModifierFactory(
                name="mapped medium well", menuSync=menu_sync_key,
            ).put(),
        )
        menu_item_modifier_3 = MenuItemModifierFactory(
            name="plain wrap",
            menuSync=menu_sync_key,
            groups=[menu_item_3_modifier_group_key],
            uuid="21077290",
            mappedToMenuItemModifier=MenuItemModifierFactory(
                name="mapped plain wrap", menuSync=menu_sync_key,
            ).put(),
        )
        return [
            menu_item_modifier_1.put(),
            menu_item_modifier_2.put(),
            menu_item_modifier_3.put(),
        ]

    @pytest.fixture
    def menu_items(
        self,
        delivery_service_key,
        menu_item_1_modifier_group_key,
        menu_item_1_modifiers,
        menu_item_3_modifier_group_key,
        menu_item_3_modifiers,
    ):
        delivery_service = delivery_service_key.get()
        menu_sync_key = delivery_service.menuSync
        menu_item_1 = MenuItemFactory(
            name="5 oz. midi burger",
            menuSync=menu_sync_key,
            modifier_groups=[menu_item_1_modifier_group_key],
            uuid="15776054",
            mappedToMenuItem=MenuItemFactory(
                name="mapped 5 oz. midi burger", menuSync=menu_sync_key,
            ).put(),
        )
        menu_item_1.put()

        menu_item_2 = MenuItemFactory(
            name="homemade fries",
            menuSync=menu_sync_key,
            uuid="15776064",
            mappedToMenuItem=MenuItemFactory(
                name="mapped homemade fries", menuSync=menu_sync_key,
            ).put(),
        )
        menu_item_2.put()

        menu_item_3 = MenuItemFactory(
            name="the texican",
            menuSync=menu_sync_key,
            modifier_groups=[menu_item_3_modifier_group_key],
            uuid="43608250",
            mappedToMenuItem=MenuItemFactory(
                name="mapped the texican", menuSync=menu_sync_key,
            ).put(),
        )
        menu_item_3.put()

        return [menu_item_1, menu_item_2, menu_item_3]

    @pytest.fixture
    def mock_google_stuff(self, mocker):
        from application.apis.order.service.push import (
            _process_push_order_to_point_of_sale,
        )

        def wrap_process_push_order_to_point_of_sale(
                order_key, forced=False, unmapped_order_itens=None
        ):
            unmapped_order_itens = []
            return _process_push_order_to_point_of_sale(order_key, forced, unmapped_order_itens)

        mocker.patch(
            "application.apis.deliveryservice.service.grubhub.order.push_order_to_point_of_sale",
            wrap_process_push_order_to_point_of_sale,
        )

        mocker.patch(
            "application.apis.order.service.creator.save_order_to_bigquery",
            return_value=None,
        )
        mocker.patch(
            "application.apis.deliveryservice.service.grubhub.order.confirm_order"
        )
        mocker.patch(
            "application.apis.deliveryservice.service.grubhub.order.push_fail_safe_order_to_printers"
        )
        mocker.patch("application.apis.order.service.push.push_order_to_printers",)

    @pytest.fixture
    def mock_working_grubhub_api(self, mocker, grubhub_api_order):
        mock_grubhub_api = mocker.Mock()
        mock_grubhub_api.get_active_order.return_value = grubhub_api_order

        mock_grubhub_api_factory = mocker.Mock()
        mock_grubhub_api_factory.instantiate_google_urlfetch_api_client.return_value = (
            mock_grubhub_api
        )

        mocker.patch(
            "application.apis.deliveryservice.service.grubhub.order.GrubHubApiClientFactory",
            mock_grubhub_api_factory,
        )

    @pytest.mark.usefixtures(
        "mock_google_stuff", "mock_working_grubhub_api", "point_of_sale_key"
    )
    @freeze_time("2020-06-16T19:59:44Z")
    def test_e2e_grubhub_api_to_newtek(
        self,
        mocker,
        parseur_payload,
        menu_items,
        menu_item_1_modifiers,
        delivery_service_key,
        api_key_admin_client,
    ):
        def mock_deferred(process_parseur_webhook, request_url, json_dict):
            return process_parseur_webhook(request_url, json_dict)

        def mock_add_task(category, entity, data_dict):
            return processTaskToProcessOrderFromGrubhub(entity.id, data_dict)

        create_order_on_newtek_mock = mocker.patch(
            "application.apis.pointofsale.service.newtek.order.__create_order_on_newtek",
        )
        save_newtek_order_uuid = mocker.patch(
            "application.apis.pointofsale.service.newtek.order.__save_newtek_order_uuid",
        )

        mocker.patch(
            "application.apis.deliveryservice.controller.grubhub.startDeferredTask",
            mock_deferred,
        )

        mocker.patch(
            "application.apis.deliveryservice.service.grubhub.order.addTask",
            mock_add_task,
        )

        mocker.patch(
            "application.apis.deliveryservice.service.grubhub.order.confirm_order",
        )

        api_key_admin_client.post(
            url_for("api.DS-grubhub_delivery_service_grubhub_parseur_process"),
            json=parseur_payload,
        )
        response = create_order_on_newtek_mock.call_args[0][1]

        orders = Order.query().filter().fetch()
        assert len(orders) == 1
        order = orders[0]
        assert order.ready_by is None

        assert response == {
            "delivery": {
                "fees": 0.0,
                "delivery_instructions": "* Text customer\nKeep warm",
                "address": "best st 101, miami, fl, 12345",
                "service_fee": 0.0,
                "time": "Now",
            },
            "items": [
                {
                    "modifiers": [
                        {
                            "description": "mapped well done",
                            "notes": "",
                            "amount": 0.0,
                            "price": 0.0,
                            "modifier_id": "eee9d5f6-616c-4af3-b7d5-abc28feb0356",
                            "quantity": 1,
                        },
                        {
                            "description": "mapped plain wrap",
                            "notes": "",
                            "amount": 0.0,
                            "price": 0.0,
                            "modifier_id": "eee9d5f6-616c-4af3-b7d5-abc28feb0356",
                            "quantity": 1,
                        },
                        {
                            "description": "mapped bacon",
                            "notes": "",
                            "amount": 2.25,
                            "price": 2.25,
                            "modifier_id": "eee9d5f6-616c-4af3-b7d5-abc28feb0356",
                            "quantity": 1,
                        },
                        {
                            "description": "mapped fried egg",
                            "notes": "",
                            "amount": 1.95,
                            "price": 1.95,
                            "modifier_id": "eee9d5f6-616c-4af3-b7d5-abc28feb0356",
                            "quantity": 1,
                        },
                        {
                            "description": "mapped ketchup",
                            "notes": "",
                            "amount": 0.0,
                            "price": 0.0,
                            "modifier_id": "eee9d5f6-616c-4af3-b7d5-abc28feb0356",
                            "quantity": 1,
                        },
                        {
                            "description": "mapped lettuce",
                            "notes": "",
                            "amount": 0.0,
                            "price": 0.0,
                            "modifier_id": "eee9d5f6-616c-4af3-b7d5-abc28feb0356",
                            "quantity": 1,
                        },
                        {
                            "description": "mapped bacon aioli",
                            "notes": "",
                            "amount": 0.0,
                            "price": 0.0,
                            "modifier_id": "eee9d5f6-616c-4af3-b7d5-abc28feb0356",
                            "quantity": 1,
                        },
                        {
                            "description": "mapped pickle",
                            "notes": "",
                            "amount": 0.0,
                            "price": 0.0,
                            "modifier_id": "eee9d5f6-616c-4af3-b7d5-abc28feb0356",
                            "quantity": 1,
                        },
                    ],
                    "description": "mapped 5 oz. midi burger",
                    "price": 8.95,
                    "tip": 0,
                    "amount": 13.15,
                    "quantity": 1,
                    "id": "fae28a9d-3e78-48da-8d9d-2519e6aedb01",
                    "item_notes": "",
                },
                {
                    "modifiers": [],
                    "description": "mapped homemade fries",
                    "price": 3.85,
                    "tip": 0,
                    "amount": 3.85,
                    "quantity": 1,
                    "id": "fae28a9d-3e78-48da-8d9d-2519e6aedb01",
                    "item_notes": "",
                },
                {
                    "modifiers": [
                        {
                            "description": "mapped midi (5oz)",
                            "notes": "",
                            "amount": 11.95,
                            "price": 11.95,
                            "modifier_id": "eee9d5f6-616c-4af3-b7d5-abc28feb0356",
                            "quantity": 1,
                        },
                        {
                            "description": "mapped medium well",
                            "notes": "",
                            "amount": 0.0,
                            "price": 0.0,
                            "modifier_id": "eee9d5f6-616c-4af3-b7d5-abc28feb0356",
                            "quantity": 1,
                        },
                        {
                            "description": "mapped plain wrap",
                            "notes": "",
                            "amount": 0.0,
                            "price": 0.0,
                            "modifier_id": "eee9d5f6-616c-4af3-b7d5-abc28feb0356",
                            "quantity": 1,
                        },
                    ],
                    "description": "mapped the texican",
                    "price": 0.0,
                    "tip": 0,
                    "amount": 11.95,
                    "quantity": 1,
                    "id": "fae28a9d-3e78-48da-8d9d-2519e6aedb01",
                    "item_notes": "Allergic to jalapenos ",
                },
            ],
            "customer_info": {
                "phone": "(617) 653-1302",
                "name": "Thibault LE C",
                "email": "",
            },
            "order": {
                "store_id": None,
                "discount": 0.0,
                "tip": 0.0,
                "notes": "Keep warm - include napkins and utensils",
                "tax": 2.57,
                "order_reference": "077011885117955",
                "coupon_code": "",
                "order_status": "RECEIVED",
                "order_date": "2020-06-16 19:59:44",
                "total": 31.52,
                "subtotal": 28.95,
                "order_type": "PICKUP",
            },
            "payment": {
                "pay_type": "GRUBHUB",
                "payment_method": "PREPAID DO NOT CHARGE",
                "tip": 0.0,
                "tax": 2.57,
                "pay_date": "2020-06-16 19:59:44",
                "payment_reference_number": "077011885117955",
                "total": 31.52,
            },
        }

@pytest.mark.usefixtures("db")
class TestDeliveryServiceGrubHubConnect(object):

    @pytest.fixture(autouse=True)
    def mock_task_to_fetch_menu(self, mocker):
        mocker.patch("application.apis.deliveryservice.controller.grubhub.startTaskToFetchMenu")

    @pytest.fixture(autouse=True)
    def mock_user(self, mocker):
        user_key = Mock()
        user_key.key = ndb.Key('user', 1)
        mocker.patch(
            "application.apis.deliveryservice.service.common.events.get_current_user",
            return_value=user_key
        )

    def test_connect_core_event(self, api_key_admin_client, full_delivery_service_menu):
        delivery_service = full_delivery_service_menu
        delivery_service.put()

        restaurant = delivery_service.restaurant.get()
        payload = {
            "restaurantUrl": 'restaurantUrl',
            "service_username": 'service_username',
            "service_password": 'service_password',
        }

        api_key_admin_client.post(
            url_for(
                "api.DS-grubhub_delivery_service_grubhub_connect",
                restaurant_id=restaurant.id,
            ),
            json=payload,
        )

        query = CoreEvent.query()
        query = query.filter(CoreEvent.category == CoreEventCategory.DS_CONNECT)
        event = query.get()

        assert event.message == 'Delivery Service CONNECT'
        assert event.name == 'GRUBHUB'
        assert event.user_key.id() == 1

