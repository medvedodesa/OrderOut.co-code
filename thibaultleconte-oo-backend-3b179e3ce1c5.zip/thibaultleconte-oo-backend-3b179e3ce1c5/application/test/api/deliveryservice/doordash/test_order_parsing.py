# -*- coding: utf-8 -*-
#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# thibault@orderout.co
#
# 03/13/2019
#

import unittest
from application.test.base import BaseTestCase
from application.apis.deliveryservice.service.doordash.order import parse_order_menu_item_price, parse_order_menu_item_unit_price
from application.apis.deliveryservice.service.doordash.order import parse_order_menu_item_to_split_name_and_category_and_extra
from application.apis.deliveryservice.service.doordash.order import parse_order_item_modifier_names_and_instructions
from application.apis.deliveryservice.service.doordash.order import build_items_array_from_raw_menu_items


class TestApiDSDoorDashOrderParsing(BaseTestCase):

    # PRICE
    def test_normal_price(self):
        raw_menu_item = {'unitPrice': '$9.45', 'price': '$9.45'}
        expected_unit_price = 9.45
        expected_price = 9.45
        result_unit_price = parse_order_menu_item_unit_price(raw_menu_item)
        result_price = parse_order_menu_item_price(raw_menu_item)
        self.assertTrue(result_unit_price == expected_unit_price)
        self.assertTrue(result_price == expected_price)

    def test_unitprice_only(self):
        raw_menu_item = {'unitPrice': '$9.45 $9.45', 'price': None}
        expected_unit_price = 9.45
        expected_price = 9.45
        result_unit_price = parse_order_menu_item_unit_price(raw_menu_item)
        result_price = parse_order_menu_item_price(raw_menu_item)
        self.assertTrue(result_unit_price == expected_unit_price)
        self.assertTrue(result_price == expected_price)

    def test_unitprice_subtotal(self):
        raw_menu_item = {'unitPrice': '$9.45 $18.90', 'price': None}
        expected_unit_price = 9.45
        expected_price = 18.90
        result_unit_price = parse_order_menu_item_unit_price(raw_menu_item)
        result_price = parse_order_menu_item_price(raw_menu_item)
        self.assertTrue(result_unit_price == expected_unit_price)
        self.assertTrue(result_price == expected_price)

    def test_no_price(self):
        raw_menu_item = {'unitPrice': '', 'price': None}
        expected_unit_price = None
        expected_price = None
        result_unit_price = parse_order_menu_item_unit_price(raw_menu_item)
        result_price = parse_order_menu_item_price(raw_menu_item)
        self.assertTrue(result_unit_price == expected_unit_price)
        self.assertTrue(result_price == expected_price)

    # NAME, CATEGORY, EXTRA
    def test_parentheses_in_name(self):
        raw_menu_item = {"description": "Cafe con Leche (8 Oz.) (in Coffee & Cafe con Leche) blah blah blah",
                         "extra": ""}
        expected_name = "cafe con leche (8 oz.)"
        expected_category = "(in coffee & cafe con leche)"
        expected_extra = "blah blah blah"
        raw_name, result_name, result_category, result_extra = parse_order_menu_item_to_split_name_and_category_and_extra(raw_menu_item)
        self.assertTrue(result_name == expected_name)
        self.assertTrue(result_category == expected_category)
        self.assertTrue(result_extra == expected_extra)

    def test_name_category_modifiers(self):
        raw_menu_item = {"description": "create your own sundae (in create ",
                         "extra": "your own sundaes)\xe2\x80\xa2choose sundae size regular\xe2\x80\xa2choose sundae toppings pineapple"}
        expected_name = "create your own sundae"
        expected_category = "(in create your own sundaes)"
        expected_extra = "\xe2\x80\xa2choose sundae size regular\xe2\x80\xa2choose sundae toppings pineapple"
        raw_name, result_name, result_category, result_extra = parse_order_menu_item_to_split_name_and_category_and_extra(raw_menu_item)
        self.assertTrue(result_name == expected_name)
        self.assertTrue(result_category == expected_category)
        self.assertTrue(result_extra == expected_extra)

    def test_parentheses_in_extra(self):
        raw_menu_item = {"description": "Cafe con Leche (8 Oz.) (in Coffee & Cafe con ",
                         "extra": "Leche)\xe2\x80\xa2blah blah    (large)\xe2\x80\xa2blah blah\xe2\x80\xa2blah (small)"}
        expected_name = "cafe con leche (8 oz.)"
        expected_category = "(in coffee & cafe con leche)"
        expected_extra = "\xe2\x80\xa2blah blah (large)\xe2\x80\xa2blah blah\xe2\x80\xa2blah (small)"
        raw_name, result_name, result_category, result_extra = parse_order_menu_item_to_split_name_and_category_and_extra(raw_menu_item)
        self.assertTrue(result_name == expected_name)
        self.assertTrue(result_category == expected_category)
        self.assertTrue(result_extra == expected_extra)

    def test_ice_cream_cake(self):
        raw_menu_item = {"description": "chocolate mint fudge ganache cake (in",
                         "extra": "handmade ice cream cakes)"}
        expected_name = "chocolate mint fudge ganache cake"
        expected_category = "(in handmade ice cream cakes)"
        expected_extra = None
        raw_name, result_name, result_category, result_extra = parse_order_menu_item_to_split_name_and_category_and_extra(raw_menu_item)
        self.assertTrue(result_name == expected_name)
        self.assertTrue(result_category == expected_category)
        self.assertTrue(result_extra == expected_extra)

    def test_curly_que_fries(self):
        raw_menu_item = {"description": "Curly Que Fries (in Fries, Rings & Things)",
                         "extra": "\xe2\x80\xa2Extra Cheese Sauce Cheddar Cheese Sauce (+ $0.94)"}
        expected_name = "curly que fries"
        expected_category = "(in fries, rings & things)"
        expected_extra = "\xe2\x80\xa2extra cheese sauce cheddar cheese sauce (+ $0.94)"
        raw_name, result_name, result_category, result_extra = parse_order_menu_item_to_split_name_and_category_and_extra(raw_menu_item)
        self.assertTrue(result_name == expected_name)
        self.assertTrue(result_category == expected_category)
        self.assertTrue(result_extra == expected_extra)

    def test_bowl_with_extra(self):
        raw_menu_item = {"description": "Bowl (in Bowls, Salads and Pitas)",
                         "extra": "• Start with A Base - Bowl Basmati Rice\n• Choose Your Proteins Mediterranean Grilled Chicken\n• Choose Your Toppings Arugula\n• Choose Your Toppings Crumbled Feta\n• Choose Your Toppings Quinoa\n• Choose Your Dressing Parmesan Herb"}
        expected_name = "bowl"
        expected_category = "(in bowls, salads and pitas)"
        expected_extra = "• start with a base - bowl basmati rice • choose your proteins mediterranean grilled chicken • choose your toppings arugula • choose your toppings crumbled feta • choose your toppings quinoa • choose your dressing parmesan herb"
        raw_name, result_name, result_category, result_extra = parse_order_menu_item_to_split_name_and_category_and_extra(raw_menu_item)
        self.assertTrue(result_name == expected_name)
        self.assertTrue(result_category == expected_category)
        self.assertTrue(result_extra == expected_extra)

    def test_with_newlines_modifiers(self):
        raw_menu_item = {"description": "Pita (in Bowls, Salads and Pitas)",
                         "extra": "• Choose Your Dips and Spreads Roasted Red Pepper and\nWalnut Hummus\n• Choose Your Proteins Mediterranean Grilled Chicken\n• Choose Your Toppings Arugula\n• Choose Your Toppings Kalamata Olives\n• Choose Your Toppings Pickled Red Onions\n• Choose Your Toppings Radishes\n• Choose Your Toppings Tomato & Cucumber\n• Choose Your Dressing Creamy Feta"}
        expected_name = "pita"
        expected_category = "(in bowls, salads and pitas)"
        expected_extra = "• choose your dips and spreads roasted red pepper and walnut hummus • choose your proteins mediterranean grilled chicken • choose your toppings arugula • choose your toppings kalamata olives • choose your toppings pickled red onions • choose your toppings radishes • choose your toppings tomato & cucumber • choose your dressing creamy feta"
        raw_name, result_name, result_category, result_extra = parse_order_menu_item_to_split_name_and_category_and_extra(raw_menu_item)
        self.assertTrue(result_name == expected_name)
        self.assertTrue(result_category == expected_category)
        self.assertTrue(result_extra == expected_extra)

    # MODIFIERS

    def test_bowl_with_extra_modifiers(self):
        raw_menu_item = {"description": "Bowl (in Bowls, Salads and Pitas)",
                         "extra": "• Start with A Base - Bowl Basmati Rice\n• Choose Your Proteins Mediterranean Grilled Chicken\n• Choose Your Toppings Arugula\n• Choose Your Toppings Crumbled Feta\n• Choose Your Toppings Quinoa\n• Choose Your Dressing Parmesan Herb"}
        expected_name = "bowl"
        expected_category = "(in bowls, salads and pitas)"
        expected_extra = "• start with a base - bowl basmati rice • choose your proteins mediterranean grilled chicken • choose your toppings arugula • choose your toppings crumbled feta • choose your toppings quinoa • choose your dressing parmesan herb"
        raw_name, result_name, result_category, result_extra = parse_order_menu_item_to_split_name_and_category_and_extra(raw_menu_item)
        raw_order_item_modifiers_names, order_item_instructions = parse_order_item_modifier_names_and_instructions(raw_extra=result_extra)
        self.assertTrue(len(raw_order_item_modifiers_names) == 6)
        _modifier_to_check = raw_order_item_modifiers_names[-1]
        self.assertTrue(_modifier_to_check == 'choose your dressing parmesan herb')

    # BUILT ITEMS

    def test_build_items_aray_sample_1(self):
        _raw_menu_items = [{'quantity': '1', 'description': 'Bowl (in Bowls, Salads and Pitas)', 'unitPrice': '$9.45', 'price': '$9.45', 'extra': '• Start with A Base - Bowl Basmati Rice\n• Choose Your Proteins Mediterranean Grilled Chicken\n• Choose Your Toppings Arugula\n• Choose Your Toppings Crumbled Feta\n• Choose Your Toppings Quinoa\n• Choose Your Dressing Parmesan Herb'},
                           {'quantity': '1', 'description': 'Pita (in Bowls, Salads and Pitas)', 'unitPrice': '$8.65', 'price': '$8.65', 'extra': '• Choose Your Dips and Spreads Roasted Red Pepper and\nWalnut Hummus\n• Choose Your Proteins Mediterranean Grilled Chicken\n• Choose Your Toppings Arugula\n• Choose Your Toppings Kalamata Olives\n• Choose Your Toppings Pickled Red Onions\n• Choose Your Toppings Radishes\n• Choose Your Toppings Tomato & Cucumber\n• Choose Your Dressing Creamy Feta'},
                           {'quantity': '1', 'description': 'Grilled Lamb and Beef Meatballs (in Extras)', 'unitPrice': '$3.95 $3.95', 'price': None, 'extra': None},
                           {'quantity': '1', 'description': 'Hummus and Fire-Baked Pita Chips (in Extras)', 'unitPrice': '$4.25', 'price': '$4.25', 'extra': None}]
        _items_array = build_items_array_from_raw_menu_items(_raw_menu_items)
        self.assertTrue(len(_items_array) == 4)
        _item_to_check = _items_array[1]
        _item_name = _item_to_check.get('name')
        self.assertTrue(_item_name == 'pita')
        _modifiers = _item_to_check.get('modifiers')
        self.assertTrue(len(_modifiers) == 8)
        _first_modifier_name = _modifiers[0]
        self.assertTrue(_first_modifier_name == 'choose your dips and spreads roasted red pepper and walnut hummus')
        _last_modifier_name = _modifiers[-1]
        self.assertTrue(_last_modifier_name == 'choose your dressing creamy feta')

if __name__ == '__main__':
    unittest.main()
