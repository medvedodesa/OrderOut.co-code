# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/14/2019
#

import unittest
from application.test.base import BaseTestCase
from application.apis.group.model import Group
from application.apis.account.model import Account
from application.apis.group.service import check_name_and_create, exists_with_name_for_account, get_by_id_and_populate


class TestApiGroupCrud(BaseTestCase):

    def test_group_list(self):
        _account = Account.create("Tibo Industries")
        _groups, _previous_cursor, _next_cursor, _more, _count = Group.list_with_pagination(account_key=_account.key, keys_only=False)
        self.assertTrue(len(_groups) == 0)
        _group = check_name_and_create(name="Tibo Franchises", account_key=_account.key)
        _groups, _previous_cursor, _next_cursor, _more, _count = Group.list_with_pagination(account_key=_account.key, keys_only=False)
        self.assertTrue(len(_groups) == 1)

    def test_group_create(self):
        _tibo_account = Account.create("Tibo Industries")
        name = "Tibo Franchises"
        self.assertFalse(exists_with_name_for_account(name=name, account_key=_tibo_account.key))
        _group = Group.create(name="Tibo Franchises", account_key=_tibo_account.key)
        self.assertTrue(exists_with_name_for_account(name=name, account_key=_tibo_account.key))
        _bob_account = Account.create("Bob Industries")
        self.assertFalse(exists_with_name_for_account(name=name, account_key=_bob_account.key))

    def test_group_rename(self):
        _account_name = "Tibo Industries"
        _group_name_origin = "Tibo Franchises"
        _group_name_new = "Tibo Franchises New World"
        _tibo_account = Account.create(_account_name)
        _group = check_name_and_create(name=_group_name_origin, account_key=_tibo_account.key)
        self.assertTrue(_group.name == _group_name_origin)
        _json_dict = {'name': _group_name_new}
        _group = get_by_id_and_populate(_group.key.id(), _json_dict)
        self.assertTrue(_group.name == _group_name_new)

    def test_group_delete(self):
        _account_name = "Tibo Industries"
        _group_name_origin = "Tibo Franchises"
        _tibo_account = Account.create(_account_name)
        _group = check_name_and_create(name=_group_name_origin, account_key=_tibo_account.key)
        try:
            _group.delete()
        except Exception as e:
            print(e)
        self.assertFalse(exists_with_name_for_account(name=_group_name_origin, account_key=_tibo_account.key))
        _groups, _previous_cursor, _next_cursor, _more, _count = Group.list_with_pagination(account_key=_tibo_account.key, keys_only=False)
        self.assertTrue(len(_groups) == 0)

if __name__ == '__main__':
    unittest.main()
