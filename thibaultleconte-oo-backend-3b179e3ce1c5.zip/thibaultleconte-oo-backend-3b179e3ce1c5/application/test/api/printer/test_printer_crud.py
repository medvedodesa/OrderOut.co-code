# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/14/2019
#

import unittest
from application.test.base import BaseTestCase
from application.apis.printer.service.common.crud import get_or_create_printer
from application.apis.printer.service.common.fetcher import fetch_printer_key_from_mac



class TestApiPrinterCrud(BaseTestCase):

    def test_printer_mac_create_mac(self):
        _mac_address = '00:aa:22:BB:44:cC'
        _p, _created = get_or_create_printer(_mac_address)
        _fetched_printer_key = fetch_printer_key_from_mac(_mac_address)
        self.assertTrue(_p.key == _fetched_printer_key)

    def test_printer_mac_fetch_uppercase(self):
        _mac_address_original = '00:aa:22:BB:44:cC'
        _p, _created = get_or_create_printer(_mac_address_original)
        _mac_address_upper = '00:AA:22:BB:44:CC'
        _fetched_printer_key = fetch_printer_key_from_mac(_mac_address_upper)
        self.assertTrue(_fetched_printer_key)

if __name__ == '__main__':
    unittest.main()
