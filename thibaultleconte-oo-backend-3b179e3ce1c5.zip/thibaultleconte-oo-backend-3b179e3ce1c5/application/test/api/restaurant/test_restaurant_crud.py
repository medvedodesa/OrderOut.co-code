# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/14/2019
#

import unittest
from application.test.base import BaseTestCase
from application.apis.restaurant.model import Restaurant
from application.apis.account.model import Account
from application.apis.group.model import Group
from application.apis.restaurant.service import add_to_group, remove_from_group, exists_with_name, check_and_create_with_name, get_by_id_and_populate

class TestApiRestaurantCrud(BaseTestCase):

    def test_restaurant_list_with_account(self):
        _tibo_account = Account.create("Tibo Industries")
        _objects, _previous_cursor, _next_cursor, _more = Restaurant.list_with_pagination_with_account(account_key=_tibo_account.key)
        self.assertTrue(len(_objects) == 0)
        _restaurant = Restaurant.create(name="Tibo Restaurant", account_key=_tibo_account.key)
        _objects, _previous_cursor, _next_cursor, _more = Restaurant.list_with_pagination_with_account(account_key=_tibo_account.key)
        self.assertTrue(len(_objects) == 1)

    def test_restaurant_list_with_group(self):
        _tibo_account = Account.create("Tibo Industries")
        _group = Group.create("Tibo Fleet 1", _tibo_account.key)
        _objects, _previous_cursor, _next_cursor, _more = Restaurant.list_with_pagination_with_group(group_key=_group.key)
        self.assertTrue(len(_objects) == 0)
        _restaurant = Restaurant.create(name="Tibo Restaurant", account_key=_tibo_account.key)
        _objects, _previous_cursor, _next_cursor, _more = Restaurant.list_with_pagination_with_group(group_key=_group.key)
        self.assertTrue(len(_objects) == 0)
        add_to_group(_restaurant.key, _group.key)
        _objects, _previous_cursor, _next_cursor, _more = Restaurant.list_with_pagination_with_group(group_key=_group.key)
        self.assertTrue(len(_objects) == 1)

    def test_restaurant_create(self):
        _tibo_account = Account.create("Tibo Industries")
        _restaurant_name = "Tibo Restaurant"
        self.assertFalse(exists_with_name(name=_restaurant_name, account_key=_tibo_account.key))
        _restaurant = Restaurant.create(name=_restaurant_name, account_key=_tibo_account.key)
        self.assertTrue(exists_with_name(name=_restaurant_name, account_key=_tibo_account.key))
        _bob_account = Account.create("Bob Industries")
        self.assertFalse(exists_with_name(name=_restaurant_name, account_key=_bob_account.key))

    def test_restaurant_rename(self):
        _account_name = "Tibo Industries"
        _restaurant_name_origin = "Tibo Restaurant"
        _restaurant_name_new = "Tibo Restaurant New World"
        _tibo_account = Account.create(_account_name)
        _restaurant = check_and_create_with_name(name=_restaurant_name_origin, account_key=_tibo_account.key)
        self.assertTrue(_restaurant.name == _restaurant_name_origin)
        _json_dict = {'name': _restaurant_name_new}
        _restaurant = get_by_id_and_populate(_restaurant.key.id(), _json_dict)
        self.assertTrue(_restaurant.name == _restaurant_name_new)

    def test_restaurant_delete(self):
        _account_name = "Tibo Industries"
        _restaurant_name_origin = "Tibo Franchises"
        _tibo_account = Account.create(_account_name)
        _restaurant = check_and_create_with_name(name=_restaurant_name_origin, account_key=_tibo_account.key)
        _restaurant.delete()
        self.assertFalse(exists_with_name(name=_restaurant_name_origin, account_key=_tibo_account.key))
        _objects, _previous_cursor, _next_cursor, _more = Restaurant.list_with_pagination_with_account(account_key=_tibo_account.key)
        self.assertTrue(len(_objects) == 0)

    def test_restaurant_add_group(self):
        _tibo_account = Account.create("Tibo Industries")
        _group = Group.create("Tibo Fleet 1", _tibo_account.key)
        _restaurant = Restaurant.create("Tibo Restaurant", _tibo_account.key)
        _objects, _previous_cursor, _next_cursor, _more = Restaurant.list_with_pagination_with_group(group_key=_group.key)
        self.assertTrue(len(_objects) == 0)
        add_to_group(_restaurant.key, _group.key)
        _objects, _previous_cursor, _next_cursor, _more = Restaurant.list_with_pagination_with_group(group_key=_group.key)
        self.assertTrue(len(_objects) == 1)

    def test_restaurant_remove_group(self):
        _tibo_account = Account.create("Tibo Industries")
        _group = Group.create("Tibo Fleet 1", _tibo_account.key)
        _restaurant = Restaurant.create("Tibo Restaurant", _tibo_account.key)
        add_to_group(_restaurant.key, _group.key)
        _objects, _previous_cursor, _next_cursor, _more = Restaurant.list_with_pagination_with_group(group_key=_group.key)
        self.assertTrue(len(_objects) == 1)
        remove_from_group(_restaurant.key)
        _objects, _previous_cursor, _next_cursor, _more = Restaurant.list_with_pagination_with_group(group_key=_group.key)
        self.assertTrue(len(_objects) == 0)

if __name__ == '__main__':
    unittest.main()
