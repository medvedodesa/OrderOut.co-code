# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/03/2020
#

import unittest
from application.test.base import BaseTestCase
from application.apis.restaurant.model import Restaurant
from application.apis.account.model import Account
from application.apis.group.model import Group
from application.apis.restaurant.service import add_to_group, remove_from_group, exists_with_name, check_and_create_with_name, get_by_id_and_populate
from application.core.datetime.timezone import convert_utc_datetime_to_zipcode_timezone
from datetime import datetime
import pytest

class TestApiRestaurantTimezone(BaseTestCase):

    def test_restaurant_timezone_miami(self):
        _tibo_account = Account.create("Tibo Industries")
        _restaurant = Restaurant.create(name="Tibo Restaurant", account_key=_tibo_account.key)
        _restaurant.street_address_1 = "400 NE 26th st"
        _restaurant.street_address_2 = ""
        _restaurant.street_address_3 = ""
        _restaurant.city = "Miami"
        _restaurant.zipcode = "33127"
        _restaurant.state = "FL"
        _restaurant.country = "USA"
        _restaurant.phone_number = "1234567890"
        _restaurant.put()

        now_utc = datetime(2020, 6, 6, 15, 55, 30)
        result = convert_utc_datetime_to_zipcode_timezone(now_utc, _restaurant.zipcode, '6077764721442816')

        self.assertTrue(result == datetime(2020, 6, 6, 11, 55, 30))

    def test_restaurant_timezone_chicago(self):
        _tibo_account = Account.create("Tibo Industries")
        _restaurant = Restaurant.create(name="Tibo Restaurant", account_key=_tibo_account.key)
        _restaurant.street_address_1 = "3201 W Leland Ave"
        _restaurant.street_address_2 = ""
        _restaurant.street_address_3 = ""
        _restaurant.city = "Chicago"
        _restaurant.zipcode = "60625"
        _restaurant.state = "IL"
        _restaurant.country = "USA"
        _restaurant.phone_number = "1234567890"
        _restaurant.put()

        now_utc = datetime(2020, 6, 6, 15, 55, 30)
        result = convert_utc_datetime_to_zipcode_timezone(now_utc, _restaurant.zipcode, '123')

        self.assertTrue(result == datetime(2020, 6, 6, 10, 55, 30))

    def test_restaurant_timezone_los_angeles(self):
        _tibo_account = Account.create("Tibo Industries")
        _restaurant = Restaurant.create(name="Tibo Restaurant", account_key=_tibo_account.key)
        _restaurant.street_address_1 = "3479 W 67th St"
        _restaurant.street_address_2 = ""
        _restaurant.street_address_3 = ""
        _restaurant.city = "Los Angeles"
        _restaurant.zipcode = "90043"
        _restaurant.state = "CA"
        _restaurant.country = "USA"
        _restaurant.phone_number = "1234567890"
        _restaurant.put()

        now_utc = datetime(2020, 6, 6, 15, 55, 30)
        result = convert_utc_datetime_to_zipcode_timezone(now_utc, _restaurant.zipcode, '123')

        self.assertTrue(result == datetime(2020, 6, 6, 8, 55, 30))

    def test_restaurant_timezone_honolulu(self):
        _tibo_account = Account.create("Tibo Industries")
        _restaurant = Restaurant.create(name="Tibo Restaurant", account_key=_tibo_account.key)
        _restaurant.street_address_1 = "7007 Hawaii Kai Dr"
        _restaurant.street_address_2 = ""
        _restaurant.street_address_3 = ""
        _restaurant.city = "Honolulu"
        _restaurant.zipcode = "96826"
        _restaurant.state = "HI"
        _restaurant.country = "USA"
        _restaurant.phone_number = "1234567890"
        _restaurant.put()

        now_utc = datetime(2020, 6, 6, 15, 55, 30)
        result = convert_utc_datetime_to_zipcode_timezone(now_utc, _restaurant.zipcode, '123')

        self.assertTrue(result == datetime(2020, 6, 6, 5, 55, 30))


if __name__ == '__main__':
    unittest.main()
