# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/03/2020
#

import unittest
from application.test.base import BaseTestCase
from application.apis.restaurant.model import Restaurant
from application.apis.account.model import Account
from application.apis.group.model import Group
from application.apis.restaurant.service import add_to_group, remove_from_group, exists_with_name, check_and_create_with_name, get_by_id_and_populate
from application.core.datetime.timezone import convert_utc_datetime_to_zipcode_timezone
from datetime import datetime
from application.apis.restaurant.service import get_preparation_time_utc_timestamp
import pytest

class TestApiRestaurantPreparationTime(BaseTestCase):

    def test_update(self):
        _tibo_account = Account.create("Tibo Industries")
        _restaurant = Restaurant.create(name="Tibo Restaurant", account_key=_tibo_account.key)
        self.assertTrue(_restaurant.preparation_time == 900)
        _json_dict = {'preparation_time': 25*60}
        _restaurant = get_by_id_and_populate(_restaurant.key.id(), _json_dict)
        self.assertTrue(_restaurant.preparation_time == 1500)

        current_utc = int(datetime.now().strftime("%s"))
        preparation_time_utc = current_utc + _restaurant.preparation_time
        _value = get_preparation_time_utc_timestamp(_restaurant.key)
        self.assertTrue(preparation_time_utc == _value)

if __name__ == '__main__':
    unittest.main()
