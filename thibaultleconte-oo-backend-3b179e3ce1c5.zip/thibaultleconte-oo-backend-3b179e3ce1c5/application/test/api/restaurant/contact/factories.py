import factory


from application.apis.restaurant.contact.model import Contact


class ContactFactory(factory.Factory):
    class Meta:
        model = Contact

    name = "John Doe"
    restaurant = None
