import factory


from application.apis.restaurant.model import Restaurant


class RestaurantFactory(factory.Factory):
    class Meta:
        model = Restaurant

    name = "Restaurant Name"
    account = None
