# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/14/2019
#

import unittest
from application.test.base import BaseTestCase

# class TestApiAuthentication(BaseTestCase):

    # def test_authentication_password_match(self):
    #     raise NotImplementedError
    #
    # def test_authentication_user(self):
    #     raise NotImplementedError

if __name__ == '__main__':
    unittest.main()
