# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

import os
import unittest
from application import app
from application.test.base import BaseTestCase
from application.core.settings.app import get_config_for_key


class TestConfig(BaseTestCase):

    def test_app_is_testing(self):
        self.assertTrue(get_config_for_key('TESTING'))
        self.assertTrue(get_config_for_key('DEBUG'))

if __name__ == '__main__':
    unittest.main()
