# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

import os
import unittest
from google.appengine.ext import ndb
from google.appengine.ext import testbed


class BaseTestCase(unittest.TestCase):

    def create_app(self):
        return app

    def setUp(self):
        self.testbed = testbed.Testbed()
        self.testbed.activate()
        self.testbed.init_datastore_v3_stub()
        self.testbed.init_memcache_stub()
        root_path_queue_file = os.path.join(os.path.dirname(__file__), '..', '..')
        self.testbed.init_taskqueue_stub(root_path=root_path_queue_file)
        self.testbed.init_urlfetch_stub()
        self.testbed.setup_env(dm_unittest=str(True), overwrite=True)
        ndb.get_context().clear_cache()
        self.taskqueue_stub = self.testbed.get_stub(testbed.TASKQUEUE_SERVICE_NAME)

    def tearDown(self):
        self.testbed.deactivate()

    #############################
    # get test email and password
    #############################

    def generate_fake_user_properties(self):
        provider_uuid = "007"
        provider_payload = {'key': 'value'}
        email="tibo@gmail.com"
        firstname="Tibo"
        lastname="LC"
        return provider_uuid, provider_payload, email, firstname, lastname
