from flask import Blueprint
from flask_restplus import Api

from application.cron.deliveryservice.doordash.controller import nsApi as nsDoorDash


blueprint = Blueprint("cron", __name__)

api_description = "OrderOut Cron API."

api = Api(
    blueprint, title="OrderOut Cron API", version="1.0", description=api_description, doc="/doc"
)

api.add_namespace(nsDoorDash, path="/ds/doordash")
