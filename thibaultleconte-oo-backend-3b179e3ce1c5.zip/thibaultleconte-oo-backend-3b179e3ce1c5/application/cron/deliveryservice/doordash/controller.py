import logging

from flask import Response
from flask_restplus import Resource, Namespace

from application.apis.deliveryservice.model.DeliveryService import DeliveryService, DeliveryServiceType
from application.cron.deliveryservice.doordash.service import poll_orders

nsApi = Namespace('cron-ds-doordash', description='Cron DoorDash related operations.')


@nsApi.route('/poll-orders')
class DeliveryServiceDoorDashPollOrders(Resource):

    def get(self):
        logging.info("Poll DoorDash Orders")
        delivery_services = _get_delivery_services_by_api_switch_active()

        for delivery_service in delivery_services:
            poll_orders(delivery_service)

        return Response("OK", 200)

def _get_delivery_services_by_api_switch_active():
    query = DeliveryService.query()
    query = query.filter(DeliveryService.type == DeliveryServiceType.DOORDASH)
    query = query.filter(DeliveryService.service_api_active == True)
    return query.fetch()
