from application.apis.deliveryservice.model.DeliveryService import DeliveryServiceType
from application.core.event.model import CoreEventCategory
from application.core.event.service import create_event
from application.core.notification_hub.notifications.invalid_credentials import InvalidCredentialsNotification
from application.core.notification_hub.sender.factory import NotificationSlackSenderFactory


def notify_invalid_credentials(delivery_service):
    notification = InvalidCredentialsNotification(
        restaurant_id=delivery_service.restaurant.id(),
        ds_id=delivery_service.key.id(),
        ds_type=DeliveryServiceType.DOORDASH
    )
    notification_sender_group = NotificationSlackSenderFactory().create(
        monitored_channel="alerts-doordash-credentials"
    )
    notification_sender_group.dispatch(notification)


def create_core_event_credentials(delivery_service):
    create_event(
        category=CoreEventCategory.DS_CREDENTIALS,
        name="DOORDASH Invalid credentials",
        success=False,
        message="Failed to authenticate with DoorDash (Polling orders)",
        parent_entities_keys=[key for key in [
            delivery_service.account,
            delivery_service.restaurant,
            delivery_service.key,
        ] if key],
    )
