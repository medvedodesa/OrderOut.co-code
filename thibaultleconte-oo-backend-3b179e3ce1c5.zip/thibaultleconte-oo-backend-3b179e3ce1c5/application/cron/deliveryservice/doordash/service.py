import logging

from application.apis.deliveryservice.model.DeliveryService import DeliveryService, DeliveryServiceType
from application.core.delivery_services.doordash.doordash_api import DoorDashUnauthorized, INVALID_CREDENTIALS_CODE
from application.core.delivery_services.doordash.factories import DoorDashApiClientFactory
from application.cron.deliveryservice.doordash.monitoring import notify_invalid_credentials, create_core_event_credentials


def poll_orders(delivery_service):
    delivery_service_id = delivery_service.key.id()

    if not delivery_service:
        logging.info("Poll DoorDash Orders - Invalid DS:{}".format(delivery_service_id))
        return

    logging.info("Poll DoorDash Orders - DS:{}".format(delivery_service_id))

    try:
        username = delivery_service.service_username
        password = delivery_service.service_secret
        if delivery_service.type == DeliveryServiceType.DOORDASH and username and password:
            doordash_api = DoorDashApiClientFactory.instantiate_google_urlfetch_api_client(username, password)
            active_orders_response = doordash_api.get_active_orders(delivery_service.serviceLocationId)

            logging.info("Poll DoorDash Orders - Active orders:{}".format(active_orders_response))
            if isinstance(active_orders_response, str):
                exception_message = "Poll DoorDash Orders - Invalid active orders response"
                logging.warning(exception_message)
                return

            for order_status in active_orders_response.keys():
                for order in active_orders_response.get(order_status):
                    process_order(order_status, order)

    except DoorDashUnauthorized as e:
        exception_message = "Poll DoorDash Orders - Unauthorized DoorDash login DS:{}".format(delivery_service_id)
        logging.warning(exception_message)
        if e.doordash_code == INVALID_CREDENTIALS_CODE:
            notify_invalid_credentials(delivery_service)
            create_core_event_credentials(delivery_service)

    except Exception as e:
        exception_message = "Poll DoorDash Orders - Poll orders failed DS:{} Exception:{}".format(delivery_service_id, e)
        logging.exception(exception_message)


def process_order(order_status, order):
    doordash_order_uuid = order.get("order").get("delivery_uuid")

    logging.info("Poll DoorDash Orders - Process order '{}' in '{}' list".format(doordash_order_uuid, order_status))
