from base64 import b64encode

import mock
import pytest
from flask import testing

from google.appengine.ext import ndb, testbed
from google.appengine.ext import deferred

from . import app as oo_app
from .apis.user.model.User import UserRole
from .test.api.user.factories import UserFactory


@pytest.fixture(scope='session')
def app():
    from _pytest.monkeypatch import MonkeyPatch
    m = MonkeyPatch()
    m.setattr(deferred, "defer", value=mock.Mock())
    return oo_app


@pytest.fixture(scope="class")
def db():
    _testbed = testbed.Testbed()
    _testbed.activate()
    _testbed.init_datastore_v3_stub()
    _testbed.init_memcache_stub()
    _testbed.init_search_stub()

    ndb.get_context().clear_cache()


@pytest.fixture(scope='session')
def admin_client(app):
    app.test_client_class = TestClient
    app.testing = True
    with app.test_client() as c:
        return c


class TestClient(testing.FlaskClient):
    def open(self, *args, **kwargs):
        api_key_headers = {
            "Authorization": "Basic {user}".format(user=b64encode(b"1234:pass"))
        }
        headers = kwargs.pop('headers', {})
        headers.update(api_key_headers)
        kwargs['headers'] = headers
        return super(testing.FlaskClient, self).open(*args, **kwargs)


@pytest.fixture(scope='session')
def api_key_admin_client(app):
    app.test_client_class = ApiKeyTestClient
    return app.test_client()


class ApiKeyTestClient(testing.FlaskClient):
    def open(self, *args, **kwargs):
        api_key_headers = {
            "api-key": "007",
        }
        headers = kwargs.pop('headers', {})
        headers.update(api_key_headers)
        kwargs['headers'] = headers
        return super(testing.FlaskClient, self).open(*args, **kwargs)


@pytest.fixture
def user():
    user = UserFactory(email="user@example.org")
    user.put()
    return user


@pytest.fixture
def front_api_client(app, user):
    def _mocked_get_auth_token(func):
        rsa = True
        return rsa, user

    from application.core.authentication import service

    from _pytest.monkeypatch import MonkeyPatch
    m = MonkeyPatch()

    m.setattr(service, "_get_auth_token", value=_mocked_get_auth_token)
    return app.test_client()


@pytest.fixture
def manager_user():
    user = UserFactory(email="usermanager@example.org")
    user.role = UserRole.MANAGER
    user.put()
    return user


@pytest.fixture
def front_api_manager_client(app, manager_user):
    def _mocked_get_auth_token(func):
        rsa = True
        return rsa, manager_user

    from application.core.authentication import service

    from _pytest.monkeypatch import MonkeyPatch
    m = MonkeyPatch()

    m.setattr(service, "_get_auth_token", value=_mocked_get_auth_token)
    return app.test_client()
