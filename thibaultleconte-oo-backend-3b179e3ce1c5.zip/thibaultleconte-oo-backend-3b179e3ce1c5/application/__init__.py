# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

import os
from flask import Flask, request, g, send_from_directory
from application.website import blueprint as website_blueprint
from application.core import blueprint as core_blueprint
from application.apis import blueprint as apis_blueprint
from application.front_api import blueprint as front_apis_blueprint
from application.cron import blueprint as crons_blueprint
from application.integration import blueprint as integrations_blueprint
from application.admin import (
    admin_blueprint,
    admin_common_blueprint,
    admin_event_blueprint,
    admin_request_blueprint,
    admin_task_blueprint,
    admin_webhook_blueprint,
    admin_objviewer_blueprint
)
from application.admin.filters import filters
from flask_cors import CORS

import sys
reload(sys)
sys.setdefaultencoding('utf8')

app = Flask(__name__)
CORS(app)
server_software = os.getenv('SERVER_SOFTWARE', '')
if server_software.startswith('Google App Engine/') or "remote_api_shell" in server_software:
    # To not have an error with urllib3 (Twilio)
    from requests_toolbelt.adapters import appengine
    appengine.monkeypatch()
    # Config
    # app.logger.info("USING CONFIG PRODUCTION")
    app.config.from_object('application.config.Production')
elif os.getenv('FLASK_ENV', '') == "TEST":
    # Config
    # app.logger.info("USING CONFIG TEST")
    app.config.from_object('application.config.Testing')
else:
    # To not have an error with urllib3 (Twilio)
    from requests_toolbelt.adapters import appengine
    appengine.monkeypatch()
    # Config
    # app.logger.info("USING CONFIG DEVELOPMENT")
    app.config.from_object('application.config.Development')

app.register_blueprint(website_blueprint)
app.register_blueprint(core_blueprint, url_prefix='/core')
app.register_blueprint(apis_blueprint, url_prefix='/api')
app.register_blueprint(front_apis_blueprint, url_prefix='/front-api')
app.register_blueprint(crons_blueprint, url_prefix='/cron')
app.register_blueprint(integrations_blueprint, url_prefix='/integration')
app.register_blueprint(admin_blueprint, url_prefix='/infrastructure/admin')
app.register_blueprint(admin_common_blueprint, url_prefix='/infrastructure/admin')
app.register_blueprint(admin_event_blueprint, url_prefix='/infrastructure/admin/event')
app.register_blueprint(admin_request_blueprint, url_prefix='/infrastructure/admin/urlfetch')
app.register_blueprint(admin_task_blueprint, url_prefix='/infrastructure/admin/task')
app.register_blueprint(admin_webhook_blueprint, url_prefix='/infrastructure/admin/webhook')
app.register_blueprint(admin_objviewer_blueprint, url_prefix='/infrastructure/admin/viewer')

@app.route('/_ah/warmup', methods=['GET'])
def gae_warmup_request():
    return "Ok"

@app.before_request
def before_request():
    g.current_user = None


# ADMIN WEBSITE
###############

@app.route('/infrastructure/admin/<path:filename>')
def admin_static(filename):
    return send_from_directory(app.root_path + '/admin/static/', filename)

for filter in filters:
    app.jinja_env.filters[filter] = filters[filter]
