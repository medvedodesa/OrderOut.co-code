from datetime import datetime, timedelta

from application.apis.account.model import Account
from application.apis.deliveryservice.model.DeliveryService import DeliveryServiceType, DeliveryService
from application.apis.deliveryservice.service.common.fetch import generate_list_delivery_services_available

from application.apis.order.service.fetch import fetch_orders_offset_pagination
from application.apis.restaurant.model import Restaurant
from application.core.marshal import oo_marshal_list


def list_orders(
        account_id,
        restaurant_id,
        from_timestamp,
        to_timestamp,
        delivery_service_type,
        page,
        item_per_page,
        sort,
):
    from application.apis.order.controller import order_marshal

    _account_key = Account.get_key(account_id)
    _restaurant_key = Restaurant.get_key(restaurant_id)
    _from_timestamp = None
    _to_timestamp = None

    if from_timestamp:
        if type(from_timestamp) == int:
            datetime.fromtimestamp(from_timestamp)
        else:
            _from_timestamp = datetime.strptime(from_timestamp, '%Y-%m-%d')

    if to_timestamp:
        if type(to_timestamp) == int:
            datetime.fromtimestamp(to_timestamp)
        else:
            _to_timestamp = datetime.strptime(to_timestamp, '%Y-%m-%d')
            _to_timestamp = _to_timestamp + timedelta(days=1)

    _delivery_service = []
    if delivery_service_type:
        delivery_service_type_list = delivery_service_type.split(',')
        delivery_service_type = [
            DeliveryServiceType._EnumClass__by_number.get(int(delivery_service_type)) for
            delivery_service_type in delivery_service_type_list]
        _delivery_service = DeliveryService.query().filter(
            DeliveryService.type.IN(delivery_service_type)).fetch(keys_only=True)

    _objects, _prev, _next, _count = fetch_orders_offset_pagination(account_key=_account_key,
                                                                    restaurant_key=_restaurant_key,
                                                                    from_timestamp=_from_timestamp,
                                                                    to_timestamp=_to_timestamp,
                                                                    delivery_service=_delivery_service,
                                                                    _page=page,
                                                                    _item_per_page=item_per_page,
                                                                    sort=sort)

    _ds_available_list = generate_list_delivery_services_available()

    __marshalled_result = {'data': oo_marshal_list(_objects, order_marshal),
                           'prev': _prev,
                           'next': _next,
                           'page': page,
                           'count': _count,
                           'item_per_page': item_per_page,
                           'delivery_services_available': _ds_available_list}

    return __marshalled_result