# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/13/2019
#
import logging
from flask import request
from flask_restplus import Resource, Namespace, reqparse
from werkzeug.exceptions import NotFound

from .functions import list_orders
from .model.Order import Order
from application.core.marshal import pagination_schema
from application.core.authentication.service import requires_auth_token
from application.core.exception import errorHandler
from application.apis.order.service.cancel import order_is_canceled
from application.apis.order.service.push import push_order_to_point_of_sale, push_canceled_order_to_printers, push_order_to_printers
from .model.order_issue import OrderIssue

nsApi = Namespace('order', description='Order related operations.')

order_marshal = nsApi.model('Order', Order.schema())
orders_pagination_marshal_response = nsApi.model('OrdersPaginationResponse', pagination_schema(order_marshal))


@nsApi.route('/list')
class OrderList(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('List Orders')
    @nsApi.response(200, 'OK', orders_pagination_marshal_response)
    @errorHandler
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('page', default=1, type=int)
        parser.add_argument('item_per_page', default=25, type=int)
        parser.add_argument('sort_order', default='desc', type=str)
        parser.add_argument('delivery_service_type', default='', type=str)
        parser.add_argument('account_id', default=None, type=int)
        parser.add_argument('restaurant_id', default=None, type=int)
        parser.add_argument('from_timestamp', default=None, type=int)
        parser.add_argument('to_timestamp', default=None, type=int)
        args = parser.parse_args()

        # _limit = args.get('pageSize')
        _sort = args.get('sort_order')
        _page = args.get('page', 1)
        _item_per_page = min(args.get('item_per_page'), 100)
        _account_id = args.get('account_id')
        _restaurant_id = args.get('restaurant_id')
        _from_timestamp = args.get('from_timestamp')
        _to_timestamp = args.get('to_timestamp')
        _delivery_service_type = args.get('delivery_service_type')

        __marshalled_result = list_orders(
            account_id=_account_id,
            restaurant_id=_restaurant_id,
            from_timestamp=_from_timestamp,
            to_timestamp=_to_timestamp,
            delivery_service_type=_delivery_service_type,
            page=_page,
            item_per_page=_item_per_page,
            sort=_sort,
        )
        return __marshalled_result

@nsApi.route('/<int:order_id>')
@nsApi.param('order_id', 'Order identifier')
class OrderGet(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get an Order')
    @nsApi.response(200, 'OK', order_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(404, 'Not found')
    @nsApi.marshal_with(order_marshal)
    @errorHandler
    def get(self, order_id):
        return Order.get_by_id(order_id)

@nsApi.route('/<int:order_id>/save_to_pos')
@nsApi.param('order_id', 'Order identifier')
class OrderPutSaveToPOS(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Post an Order to the Restaurant\'s Point Of Sale')
    @nsApi.response(200, 'OK')
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(404, 'Not found')
    @errorHandler
    def put(self, order_id):
        _order = Order.get_by_id(order_id)
        success = push_order_to_point_of_sale(_order.key, forced=True)
        if success: return {'status': 'success'}
        return {'status': 'error'}

@nsApi.route('/<int:order_id>/print')
@nsApi.param('order_id', 'Order identifier')
class OrderPutPrint(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Print an Order to the Restaurant\'s Printer')
    @nsApi.response(200, 'OK')
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(404, 'Not found')
    @errorHandler
    def put(self, order_id):
        _order = Order.get_by_id(order_id)
        success = push_order_to_printers(_order.key)
        if success:
            return {'status': 'success'}
        return {'status': 'error'}

@nsApi.route('/<int:order_id>/cancel')
@nsApi.param('order_id', 'Order identifier')
class OrderPutCancel(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Cancel an Order')
    @nsApi.response(200, 'OK')
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(404, 'Not found')
    @errorHandler
    def put(self, order_id):
        success = True
        try:
            _order = Order.get_by_id(order_id)
            _order = order_is_canceled(_order.key)
            _order = push_canceled_order_to_printers(_order.key)
        except Exception as e:
            logging.exception("Exception on canceling order: {}".format(e))
            success = False

        if success:
            return {'status': 'success'}
        return {'status': 'error'}


@nsApi.route('/<int:order_id>/report_issue')
class ReportOrderIssue(Resource):
    method_decorators = [requires_auth_token]

    def post(self, order_id):
        order = Order.get_by_id(order_id)
        if not order:
            raise NotFound

        order_key = order.key

        message = request.args.get("message", "")

        order_issue = OrderIssue(order=order_key, message=message).put()

        return {"status": "success"}
