# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/27/2019
#

from google.appengine.ext import ndb
from application.core.model.Base import Base
from flask_restplus import fields, marshal
from application.core.marshal import SchemaFieldKeyFormatter, SchemaFieldListOfKeysFormatter
from application.apis.menu.model.MenuItemModifier import MenuItemModifierSchemaFieldFromKeyFormatter


class OrderItemModifier(Base):
    order = ndb.KeyProperty(required=True)
    order_item = ndb.KeyProperty(required=True)
    menu_item_modifier = ndb.KeyProperty(required=True)
    price = ndb.FloatProperty(default=0)
    point_of_sale_uuid = ndb.StringProperty(indexed=False)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema['modifier'] = MenuItemModifierSchemaFieldFromKeyFormatter(attribute='menu_item_modifier', description='Menu Item Modifier')
        schema['price'] = fields.Float(description="Price")
        return schema

class OrderItemModifierSchemaFieldListOfKeysFormatter(fields.Raw):
    def format(self, value):
        result = []
        for v in value:
            result.append(marshal(v.get(), OrderItemModifier.schema()))
        return result
