from google.appengine.ext import ndb
from application.core.model.Base import Base


class OrderIssue(Base):
    order = ndb.KeyProperty(required=True)
    message = ndb.StringProperty(indexed=False)