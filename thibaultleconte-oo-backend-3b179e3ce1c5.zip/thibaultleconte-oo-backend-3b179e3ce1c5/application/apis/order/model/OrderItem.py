# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/11/2019
#

from google.appengine.ext import ndb
from application.core.model.Base import Base
from flask_restplus import fields, marshal
from application.core.marshal import SchemaFieldKeyFormatter, SchemaFieldListOfKeysFormatter
from application.apis.menu.model.MenuItem import MenuItemSchemaFieldFromKeyFormatter
from .OrderItemModifier import OrderItemModifierSchemaFieldListOfKeysFormatter


class OrderItem(Base):
    order = ndb.KeyProperty(required=True)
    menu_item = ndb.KeyProperty(required=True)
    unit_price = ndb.FloatProperty(default=0)
    quantity = ndb.IntegerProperty(default=0)
    price = ndb.FloatProperty(default=0)
    selected_modifier = ndb.KeyProperty(repeated=True)
    store_instructions = ndb.TextProperty(indexed=False)
    point_of_sale_uuid = ndb.StringProperty(indexed=False)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema['menu_item'] = MenuItemSchemaFieldFromKeyFormatter(attribute='menu_item', description='Menu Item')
        schema['quantity'] = fields.Integer(description="Quantity")
        schema['unit_price'] = fields.Float(description="Unit Price")
        schema['price'] = fields.Float(description="Price")
        schema['modifiers'] = OrderItemModifierSchemaFieldListOfKeysFormatter(attribute='selected_modifier', description='Selected Modifier')
        schema['store_instructions'] = fields.String(description="Store Instructions")
        return schema

    @classmethod
    def create(cls, order_key, menu_item_key):
        _obj = cls()
        _obj.order = order_key
        _obj.menu_item = menu_item_key
        _obj.put()
        return _obj


class OrderItemSchemaFieldListOfKeysFormatter(fields.Raw):
    def format(self, value):
        result = []
        for v in value:
            obj = v.get()
            if obj:
                result.append(marshal(obj, OrderItem.schema()))
        return result
