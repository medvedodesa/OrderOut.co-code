# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/11/2019
#

from google.appengine.ext import ndb
from application.core.model.Base import Base
from google.appengine.ext.ndb import msgprop
from protorpc import messages
from flask_restplus import fields
from .OrderItem import OrderItemSchemaFieldListOfKeysFormatter
from application.apis.deliveryservice.model.DeliveryService import DeliveryServiceSchemaFieldFromKeyFormatter
from application.apis.account.model import AccountSchemaFieldFromKeyFormatter
from application.apis.restaurant.model import RestaurantSchemaFieldFromKeyFormatter
from application.apis.pointofsale.model.PointOfSale import PointOfSaleSchemaFieldFromKeyFormatter


class OrderStatus(messages.Enum):
    UNKNOWN = 0
    RECEIVED = 1
    CONFIRMED = 2
    CANCELLED = 3

class OrderType(messages.Enum):
    UNKNOWN = 0
    DELIVERY = 1
    PICKUP = 2

class Order(Base):
    account = ndb.KeyProperty(required=True)
    restaurant = ndb.KeyProperty(required=True)
    status = msgprop.EnumProperty(OrderStatus, default=OrderStatus.UNKNOWN, required=True)
    type = msgprop.EnumProperty(OrderType, default=OrderType.UNKNOWN, required=True)
    delivery_service = ndb.KeyProperty(required=True, indexed=True)
    delivery_service_uuid = ndb.StringProperty(required=True)
    order_items = ndb.KeyProperty(repeated=True)
    oo_test = ndb.BooleanProperty(default=False)
    customer_name = ndb.StringProperty(indexed=False)
    customer_phone = ndb.StringProperty(indexed=False)
    customer_email = ndb.StringProperty(indexed=False)
    point_of_sale = ndb.KeyProperty()
    point_of_sale_uuid = ndb.StringProperty(indexed=False)
    point_of_sale_customer_uuid = ndb.StringProperty(indexed=False)
    point_of_sale_payment_uuid = ndb.StringProperty(indexed=False)
    delivery_service_short_uuid = ndb.StringProperty()
    delivery_service_raw_data = ndb.JsonProperty(indexed=False, compressed=True)
    charge_tax = ndb.FloatProperty(default=0, indexed=False)
    charge_subtotal = ndb.FloatProperty(default=0, indexed=False)
    charge_fee = ndb.FloatProperty(default=0, indexed=False)
    charge_tip = ndb.FloatProperty(default=0, indexed=False)
    charge_customer_delivery_fee = ndb.FloatProperty(default=0, indexed=False)
    charge_total = ndb.FloatProperty(default=0, indexed=True)
    charge_mode = ndb.StringProperty(indexed=False)
    store_instructions = ndb.TextProperty(indexed=False)
    delivery_address = ndb.TextProperty(default=None, indexed=False)
    delivery_city = ndb.TextProperty(default=None, indexed=False)
    delivery_state = ndb.TextProperty(default=None, indexed=False)
    delivery_zip = ndb.TextProperty(default=None, indexed=False)
    delivery_instructions = ndb.TextProperty(indexed=False)
    ready_by = ndb.StringProperty(indexed=False)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema['account'] = AccountSchemaFieldFromKeyFormatter(attribute='account', description='Account')
        schema['restaurant'] = RestaurantSchemaFieldFromKeyFormatter(attribute='restaurant', description='Restaurant')
        schema['status'] = fields.String()
        schema['type'] = fields.String()
        schema['order_items'] = OrderItemSchemaFieldListOfKeysFormatter(attribute='order_items', description='Order Items')
        schema['customer_name'] = fields.String(description="Customer Name")
        schema['customer_phone'] = fields.String(description="Customer Phone Number")
        schema['customer_email'] = fields.String(description="Customer Email")
        schema['point_of_sale'] = PointOfSaleSchemaFieldFromKeyFormatter(attribute='point_of_sale', description='Point Of Sale')
        schema['point_of_sale_uuid'] = fields.String(description="Point Of Sale Order uuid")
        schema['delivery_service'] = DeliveryServiceSchemaFieldFromKeyFormatter(attribute='delivery_service', description='Delivery Service')
        schema['delivery_service_uuid'] = fields.String(required=True, description="uuid")
        schema['delivery_service_short_uuid'] = fields.String(description="Delivery Service Order Number")
        schema['charge_tax'] = fields.Float(description="Tax Charges")
        schema['charge_subtotal'] = fields.Float(description="Subtotal Charges")
        schema['charge_fee'] = fields.Float(description="Delivery Fee")
        schema['charge_tip'] = fields.Float(description="Order Tip")
        schema['charge_customer_delivery_fee'] = fields.Float(description="Order Tip")
        schema['charge_total'] = fields.Float(description="Total Charges")
        schema['charge_mode'] = fields.String(description="Charges Payment Mode")
        schema['store_instructions'] = fields.String(description="store_instructions")
        schema['delivery_address'] = fields.String(description="delivery_address")
        schema['delivery_city'] = fields.String(description="delivery_city")
        schema['delivery_state'] = fields.String(description="delivery_state")
        schema['delivery_zip'] = fields.String(description="delivery_zip")
        schema['delivery_instructions'] = fields.String(description="delivery_instructions")
        schema['ready_by'] = fields.String(description="Order must be ready by")
        schema['test'] = fields.Boolean(attribute='oo_test', description="Test from OrderOut")
        schema['api_updated_at'] = fields.DateTime(readOnly=True, description="Last Update date and time")
        return schema

    ######
    # CRUD
    ######

    @classmethod
    def create(cls, account_key, restaurant_key, status, type, delivery_service_key, delivery_service_uuid):
        _obj = cls()
        _obj.account = account_key
        _obj.restaurant = restaurant_key
        _obj.status = status
        _obj.type = type
        _obj.delivery_service = delivery_service_key
        _obj.delivery_service_uuid = delivery_service_uuid
        _obj.put()
        return _obj

    def put(self, **kwargs):
        key = super(Order, self).put(**kwargs)

        import logging
        logging.info("SAVE ORDER - Id: {}".format(key.id()))
        logging.info("SAVE ORDER - Obj: {}".format(key.get()))

        return key

    #######
    # LOGIC
    #######

    @property
    def total_number_of_items(self):
        _result = 0
        for _oi_key in self.order_items:
            _oi = _oi_key.get()
            _result += _oi.quantity
        return _result

    @property
    def total_charge_without_tip(self):
        return sum([self.charge_subtotal, self.charge_tax, self.charge_fee, self.charge_customer_delivery_fee])

    @property
    def charge_tip_to_send_to_the_pos(self):
        if self.type == OrderType.DELIVERY:
            return 0
        return self.charge_tip
