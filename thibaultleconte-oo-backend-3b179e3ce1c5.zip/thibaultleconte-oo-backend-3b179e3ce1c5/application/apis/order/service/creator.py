# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/28/2019
#
import base64

from ..model.Order import Order, OrderStatus, OrderType
from application.apis.deliveryservice.service.common.fetch import get_delivery_service_keys_for_restaurant
from .fetch import fetch_order_by_restaurant_and_delivery_service
from flask import current_app
from application.core.email.service import send_raw_email_to_admin, send_email_to_onboarding_team
from .bigquery import save as save_order_to_bigquery
from application.apis.order.service.count import count_total_orders_for_restaurant, count_total_orders_for_delivery_service
from application.core.settings.app import get_config_for_key
from application.core.slack.onboarding_first_order import post_to_onboarding_first_order_for_new_delivery_service
from application.core.slack.onboarding_followup import post_to_onboarding_followup_for_restaurant
import logging
import json


def get_create_order(order_id, delivery_service_key):
    ds = delivery_service_key.get()
    restaurant = ds.restaurant.get()

    order = fetch_order_by_restaurant_and_delivery_service(restaurant_key=ds.restaurant,
                                                           deliveryservice_keys=[delivery_service_key],
                                                           delivery_service_uuid=order_id)

    if order:
        return order

    order = Order(
        account=restaurant.account,
        restaurant=restaurant.key,
        delivery_service=delivery_service_key,
        delivery_service_uuid=order_id,
        point_of_sale=restaurant.point_of_sale,
    )

    return order.put().get()


def create_update_order(delivery_service_key,
                        delivery_service_uuid,
                        type_delivery,
                        raw_data,
                        customer_name='',
                        customer_phone='',
                        customer_email='',
                        delivery_service_short_uuid='',
                        charge_tax=0,
                        charge_subtotal=0,
                        charge_fee=0,
                        charge_tip=0,
                        charge_customer_delivery_fee=0,
                        charge_total=0,
                        charge_payment_mode='',
                        store_instructions='',
                        delivery_address='',
                        delivery_city='',
                        delivery_state='',
                        delivery_zip='',
                        delivery_instructions='',
                        ready_by='Now',
                        forTesting=False):

    _is_new_order = False
    _ds = delivery_service_key.get()
    _restaurant = _ds.restaurant.get()

    delivery_service_uuid = delivery_service_uuid.encode('utf-8').strip()

    _deliveryservice_keys = get_delivery_service_keys_for_restaurant(_ds.restaurant, _ds.type, include_deleted=True)
    _order = fetch_order_by_restaurant_and_delivery_service(_ds.restaurant, _deliveryservice_keys, delivery_service_uuid)
    if not _order:
        _order = Order()
        _order.delivery_service = delivery_service_key
        _order.delivery_service_uuid = delivery_service_uuid
        _order.account = _restaurant.account
        _order.restaurant = _restaurant.key
        _order.point_of_sale = _restaurant.point_of_sale

        _is_new_order = True # Alert for new order
        _order.put()
    _order = update_order(order_key=_order.key,
                          type_delivery=type_delivery,
                          raw_data=raw_data,
                          customer_name=customer_name,
                          customer_phone=customer_phone,
                          customer_email=customer_email,
                          delivery_service_short_uuid=delivery_service_short_uuid,
                          charge_tax=charge_tax,
                          charge_subtotal=charge_subtotal,
                          charge_fee=charge_fee,
                          charge_tip=charge_tip,
                          charge_customer_delivery_fee=charge_customer_delivery_fee,
                          charge_total=charge_total,
                          charge_payment_mode=charge_payment_mode,
                          store_instructions=store_instructions,
                          delivery_address=delivery_address,
                          delivery_city=delivery_city,
                          delivery_state=delivery_state,
                          delivery_zip=delivery_zip,
                          delivery_instructions=delivery_instructions,
                          ready_by=ready_by,
                          forTesting=forTesting)
    if _is_new_order: _process_new_order(delivery_service_key, _order.key)
    return _order

def update_order(order_key,
                 type_delivery,
                 raw_data,
                 customer_name='',
                 customer_phone='',
                 customer_email='',
                 delivery_service_short_uuid='',
                 charge_tax=0,
                 charge_subtotal=0,
                 charge_fee=0,
                 charge_tip=0,
                 charge_customer_delivery_fee=0,
                 charge_total=0,
                 charge_payment_mode='',
                 store_instructions='',
                 delivery_address='',
                 delivery_city='',
                 delivery_state='',
                 delivery_zip='',
                 delivery_instructions='',
                 ready_by='Now',
                 forTesting=False):
    _order = order_key.get()
    if _order.status == OrderStatus.UNKNOWN: _order.status = OrderStatus.RECEIVED
    _order.type = OrderType.DELIVERY if type_delivery else OrderType.PICKUP
    _order.customer_name = customer_name
    _order.customer_phone = customer_phone
    _order.customer_email = customer_email

    datastore_max_length = get_config_for_key("DATASTORE_MAX_LENGTH")
    dumped_raw_data = json.dumps(raw_data)

    if len(dumped_raw_data) > datastore_max_length:
        _order.delivery_service_raw_data = base64.b64encode(raw_data)
    else:
        _order.delivery_service_raw_data = dumped_raw_data

    _order.delivery_service_short_uuid = delivery_service_short_uuid
    _order.charge_tax = float(charge_tax)
    _order.charge_subtotal = float(charge_subtotal)
    _order.charge_fee = float(charge_fee)
    _order.charge_tip = float(charge_tip)
    _order.charge_customer_delivery_fee = float(charge_customer_delivery_fee)
    _order.charge_total = float(charge_total) if float(charge_total) > 0 else _order.charge_tax + _order.charge_subtotal + _order.charge_fee + _order.charge_tip + _order.charge_customer_delivery_fee
    _order.charge_mode = charge_payment_mode
    _order.store_instructions = store_instructions if store_instructions else ""
    _order.delivery_address = delivery_address
    _order.delivery_city = delivery_city
    _order.delivery_state = delivery_state
    _order.delivery_zip = delivery_zip
    _order.delivery_instructions = delivery_instructions if delivery_instructions else ""
    _order.ready_by = ready_by if ready_by else 'Now'
    _order.oo_test = forTesting
    _order.put()
    return _order

##################
# HANDLE NEW ORDER
##################

def _process_new_order(delivery_service_key, order_key):
    # Order & Restaurant
    _order = order_key.get()
    _account_key = _order.account
    _restaurant_key = _order.restaurant
    _delivery_service_key = _order.delivery_service
    # Email
    success_notify = __check_number_of_orders_and_notify(order_key, _account_key, _restaurant_key, _delivery_service_key)
    # Big Query
    success_bq = save_order_to_bigquery(order_key)
    return success_notify

def __check_number_of_orders_and_notify(order_key, account_key, restaurant_key, delivery_service_key):
    _notification_sent = False

    # Count orders for restaurant
    _nb_orders_for_restaurant = count_total_orders_for_restaurant(restaurant_key)
    _nb_orders_for_delivery_service = count_total_orders_for_delivery_service(delivery_service_key)

    # get config thresholds
    _nb_orders_threshold_onboarding_followup = get_config_for_key('EMAIL_THRESHOLD_ONBOARDING_FOLLOWUP')

    if _nb_orders_for_delivery_service == 1:
        _notification_sent = __notify_slack_first_order_for_delivery_service(order_key, account_key, restaurant_key, delivery_service_key)

    if _nb_orders_for_restaurant in _nb_orders_threshold_onboarding_followup:
        _notification_sent = __notify_followup_for_onboarding_team(order_key, account_key, restaurant_key, _nb_orders_for_restaurant)

    # if _nb_orders_for_restaurant < _nb_orders_threshold_onboarding_followup:
    #     _notification_sent = _notify_new_order_by_email_for_admin(delivery_service_key, order_key)

    return _notification_sent

def __notify_slack_first_order_for_delivery_service(order_key, account_key, restaurant_key, delivery_service_key):
    _account_name = account_key.get().name
    _restaurant_name = restaurant_key.get().name
    _delivery_service_name = delivery_service_key.get().type
    _restaurant_admin_url = "{}/restaurant/{}".format(get_config_for_key("ADMIN_BASE_URL"), str(restaurant_key.id()))
    _order_admin_url = "{}/order/{}".format(get_config_for_key("ADMIN_BASE_URL"), str(order_key.id()))
    post_to_onboarding_first_order_for_new_delivery_service(account_name=_account_name,
                                                            restaurant_name=_restaurant_name,
                                                            delivery_service_name=_delivery_service_name,
                                                            restaurant_admin_url=_restaurant_admin_url,
                                                            order_admin_url=_order_admin_url)
    return True

def __notify_followup_for_onboarding_team(order_key, account_key, restaurant_key, nb_orders):
    _account_name = account_key.get().name
    _restaurant_name = restaurant_key.get().name
    _restaurant_admin_url = "{}/restaurant/{}".format(get_config_for_key("ADMIN_BASE_URL"), str(restaurant_key.id()))
    _order_admin_url = "{}/order/{}".format(get_config_for_key("ADMIN_BASE_URL"), str(order_key.id()))
    # SLACK
    post_to_onboarding_followup_for_restaurant(account_name=_account_name,
                                               restaurant_name=_restaurant_name,
                                               number_of_orders=nb_orders,
                                               restaurant_admin_url=_restaurant_admin_url,
                                               order_admin_url=_order_admin_url)
    # EMAIL
    # _restaurant = restaurant_key.get()
    # _account = _restaurant.account.get()
    # _subject = "First %s orders received" % (str(nb_orders))
    # _body = "%s %s just received its order #%s.\n" % (str(_account.name), str(_restaurant.name), str(nb_orders))
    # _body += "Time to reach out to the manager to ask if everything is rolling fine...\n"
    # _body += "Account id: %s\n" % (str(_account.key.id()))
    # _body += "Restaurant id: %s\n" % (str(_restaurant.key.id()))
    # result = send_email_to_onboarding_team(subject=_subject, body=_body)
    return True

# def _notify_new_order_by_email_for_admin(delivery_service_key, order_key):
#     _ds = delivery_service_key.get()
#     _restaurant = _ds.restaurant.get()
#     _account = _restaurant.account.get()
#     _name = str(_account.name) + " - " + str(_restaurant.name)
#     _delivery_service_name = _ds.type
#     data_dict = {'type': str(_ds.type), 'id': int(_ds.key.id())}
#     body = json.dumps(data_dict)
#     result = send_raw_email_to_admin(subject="NEW ORDER for %s with %s" % (_name, _delivery_service_name), body=body)
#     return result
