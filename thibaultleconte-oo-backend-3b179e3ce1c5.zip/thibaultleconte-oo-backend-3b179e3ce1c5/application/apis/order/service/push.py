# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/15/2019
#
import json
import zlib

from application.apis.pointofsale.model.PointOfSale import PointOfSaleType
from application.apis.printer.service.common.printjob import publish_order_print_job_for_restaurant, publish_fail_safe_order_print_job_for_restaurant
from application.apis.printer.service.common.printjob import publish_canceled_order_print_job_for_restaurant
from application.core.task.service import startDeferredTask
from application.apis.pointofsale.service.clover.order import push_order as push_order_to_clover
from application.apis.pointofsale.service.newtek.order import push_order as push_order_to_newtek
from application.apis.pointofsale.service.tabit.order import push_order as push_order_to_tabit
from application.apis.pointofsale.service.aldelo.order import push_order as push_order_to_aldelo
import logging


###############
# POINT OF SALE
###############

def push_order_to_point_of_sale(order_key, forced=False, unmapped_order_itens=None):
    if not unmapped_order_itens:
        unmapped_order_itens = []

    startDeferredTask(_process_push_order_to_point_of_sale, order_key, forced, unmapped_order_itens)
    return

def _process_push_order_to_point_of_sale(order_key, forced, unmapped_order_itens=None):
    if not unmapped_order_itens:
        unmapped_order_itens = []

    _order_ready_to_print = False
    from application import app
    with app.app_context():
        _order = order_key.get()

        _delivery_service = _order.delivery_service.get() if _order.delivery_service else None
        if not _delivery_service: return False
        _restaurant = _order.restaurant.get() if _order.restaurant else None
        if not _restaurant: return False
        _point_of_sale = _restaurant.point_of_sale.get() if _restaurant.point_of_sale else None

        if _delivery_service.integration_enabled == True or forced == True:
            if _point_of_sale:
                if _point_of_sale.type == PointOfSaleType.CLOVER:
                    _order_ready_to_print = push_order_to_clover(_order.key, _point_of_sale.key)
                elif _point_of_sale.type == PointOfSaleType.NEWTEK:
                    _order_ready_to_print = push_order_to_newtek(_order.key, _point_of_sale.key)
                elif _point_of_sale.type == PointOfSaleType.TABIT:
                    _order_ready_to_print = push_order_to_tabit(_order.key, _point_of_sale.key, unmapped_order_itens)
                elif _point_of_sale.type == PointOfSaleType.ALDELO:
                    _order_ready_to_print = push_order_to_aldelo(_order.key)
                else:
                    logging.error('Point of sale %s %s not supported for pushing order' % (str(_point_of_sale.key.id()), str(_point_of_sale.type)))
            else:
                _order_ready_to_print = True # NO Point Of sale so no reason to have an issue with the order withen pushing it to POS -> Print

            if _order_ready_to_print == True:
                push_order_to_printers(order_key)

        return _order_ready_to_print

#########
# PRINTER
#########

# Order Received / Confirmed

def push_order_to_printers(order_key):
    startDeferredTask(__process_push_order_to_printers, order_key)

def __process_push_order_to_printers(order_key):
    from application import app
    with app.app_context():
        _order = order_key.get()
        _restaurant = _order.restaurant.get()
        _jobs = publish_order_print_job_for_restaurant(restaurant_key=_order.restaurant,
                                                       order_key=_order.key,
                                                       doublePrinting=_restaurant.printDoubleOrder)

# Order Received / Confirmed Fail Safe Mode

def push_fail_safe_order_to_printers(order_key, raw_json_dict):
    logging.info("push_fail_safe_order_to_printers")
    raw_json_dict = zlib.compress(json.dumps(raw_json_dict))
    logging.info("len message: {}".format(len(raw_json_dict)))
    startDeferredTask(__process_push_fail_safe_order_to_printers, order_key, raw_json_dict)

def __process_push_fail_safe_order_to_printers(order_key, raw_json_dict):
    logging.info("__process_push_fail_safe_order_to_printers")
    raw_json_dict = json.loads(zlib.decompress(raw_json_dict))

    from application import app
    with app.app_context():
        _order = order_key.get()
        _restaurant = _order.restaurant.get()
        _jobs = publish_fail_safe_order_print_job_for_restaurant(restaurant_key=_order.restaurant,
                                                                 order_key=_order.key,
                                                                 raw_json_dict=raw_json_dict,
                                                                 doublePrinting=_restaurant.printDoubleOrder)

# Order Received / Confirmed Fail Safe Mode

def push_canceled_order_to_printers(order_key):
    startDeferredTask(__process_push_canceled_order_to_printers, order_key)

def __process_push_canceled_order_to_printers(order_key):
    from application import app
    with app.app_context():
        _order = order_key.get()
        _jobs = publish_canceled_order_print_job_for_restaurant(restaurant_key=_order.restaurant, order_key=_order.key)
