# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 07/11/2019
#

from flask import current_app
from application.core.task.service import startDeferredTask
from application.core.gcloud.bigquery.creator import store_one_row
from application.core.settings.app import get_config_for_key


def save(order_key):
    startDeferredTask(__save_async, order_key)

def __save_async(order_key):
    from application import app
    with app.app_context():
        _table_name = get_config_for_key('GCLOUD_BIGQUERY_TABLE_ORDER')
    _data_dict = generate_order_dict_for_bigquery(order_key)
    result = store_one_row(_table_name, _data_dict)
    return result

def generate_order_dict_for_bigquery(order_key):
    _order = order_key.get()
    _account = _order.account.get()
    _restaurant = _order.restaurant.get()
    _delivery_service = _order.delivery_service.get()
    _data_dict = {'order_id': int(_order.key.id()),
                  'account_id': int(_order.account.id()),
                  'account_name': str(_account.name),
                  'restaurant_id': int(_order.restaurant.id()),
                  'restaurant_name': str(_restaurant.name),
                  'delivery_service_id': int(_order.delivery_service.id()),
                  'delivery_service_type': str(_delivery_service.type),
                  'type': str(_order.type),
                  'charge_tax': float(_order.charge_tax),
                  'charge_subtotal': float(_order.charge_subtotal),
                  'charge_fee': float(_order.charge_fee),
                  'charge_tip': float(_order.charge_tip),
                  'charge_customer_delivery_fee': float(_order.charge_customer_delivery_fee),
                  'charge_total': float(_order.charge_total),
                  'api_created_at': str(_order.api_created_at)}
    import logging
    logging.info(_data_dict)
    return _data_dict
