# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/11/2019
#

from ..model.OrderItem import OrderItem


def clear_order_item_for_order(order_key):
    _order = order_key.get()
    _order.order_items = []
    _order.put()
    return True

def add_order_item_to_order(order_key, menu_item_key, unit_price, quantity, price, store_instructions=''):
    # makes no sense we dont have the order item cart id (Maybe with UberEats, But Grubhub no way)
    # _order_item = __fetch_order_item(order_key=order_key, menu_item_key=menu_item_key)
    # if not _order_item:
    try:
        quantity = int(quantity)
    except:
        quantity = 0
    _order_item = OrderItem(order=order_key, menu_item=menu_item_key)
    _order_item.unit_price = unit_price
    _order_item.quantity = quantity
    _order_item.price = price
    _order_item.store_instructions = store_instructions if store_instructions else ''
    _order_item.put()
    return _order_item

def __fetch_order_item(order_key, menu_item_key):
    _query = OrderItem.query()
    _query = _query.filter(OrderItem.order == order_key)
    _query = _query.filter(OrderItem.menu_item == menu_item_key)
    _order_item = _query.get()
    return _order_item
