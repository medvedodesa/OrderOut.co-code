# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 07/16/2019
#

from application.apis.menu.service.fetch.item import fetch_all_items
from application.apis.menu.service.modifier import fetch_all_menu_item_modifiers_for_menu_sync
import random
from application.apis.order.service.orderItem import add_order_item_to_order
from application.apis.order.service.orderItemModifier import create_order_item_modifier
from application.apis.order.model.Order import Order, OrderStatus, OrderType

def create_order(account_key, restaurant_key, delivery_service_key):

    _random_int = str(random.randint(1,1000))
    _order = Order()
    _order.status = OrderStatus.RECEIVED
    _order.type = OrderType.DELIVERY
    _order.restaurant = restaurant_key
    _order.point_of_sale = restaurant_key.get().point_of_sale
    _order.account = account_key
    _order.delivery_service = delivery_service_key
    _order.delivery_service_uuid = "testOrder_" + _random_int
    _order.oo_test = True
    _order.customer_name = 'Cleopatra'
    _order.customer_phone = '+1 (765) 333-9876'
    _order.ready_by = 'Now'
    _order.delivery_service_uuid = 'order_number_' + _random_int
    _order.delivery_address = '1 delivery addr street, awesome city, 44321, fl'
    _order.delivery_city = 'awesome city'
    _order.delivery_state = 'fl'
    _order.delivery_zip = '44321'
    _order.delivery_instructions = 'The entrance code is 1234'
    _order.store_instructions = 'Please add extra ketchup'
    _order.charge_mode = 'Pre-Paid'
    _order.put()
    _order_items_keys = generate_order_items_from_delivery_service(account_key, restaurant_key, delivery_service_key, _order.key)
    _order.order_items = _order_items_keys
    _order.charge_subtotal = 0
    for _order_item_key in _order_items_keys:
        _order_item = _order_item_key.get()
        _charge = _order_item.quantity * _order_item.unit_price
        # for _selected_modifier_key in _order_item.selected_modifier:
        #     _selected_modifier = _selected_modifier_key.get()
        #     _charge += _selected_modifier.price
        _order.charge_subtotal += _charge
    _order.charge_tax = round(_order.charge_subtotal * 0.07, 2) # random $7 sales tax
    _order.charge_fee = 1.37 # randowmly chosen
    _order.charge_tip = 3.49 # randowmly chosen
    _order.charge_customer_delivery_fee = 4.99 # randowmly chosen
    _order.charge_total = _order.charge_subtotal + _order.charge_tax + _order.charge_fee + _order.charge_tip + _order.charge_customer_delivery_fee
    _order.put()

    return _order



def generate_order_items_from_delivery_service(account_key, restaurant_key, delivery_service_key, order_key, nb_order_items=3):
    result = []
    _menu_sync = delivery_service_key.get().menuSync
    _menu_items = fetch_all_items(menu_sync_key=_menu_sync, keys_only=False)
    _menu_item_modifiers = fetch_all_menu_item_modifiers_for_menu_sync(_menu_sync)
    if not _menu_items: return result
    secure_random = random.SystemRandom()
    # Default is 3 order menu items
    for i in range(nb_order_items):
        _menu_item = secure_random.choice(_menu_items)
        _quantity = 1
        _store_instructions = 'Thx for cooking it with Love.'
        _order_item = add_order_item_to_order(
            order_key, _menu_item.key, _menu_item.price, _quantity, _menu_item.price * _quantity, _store_instructions
        )
        _selected_modifier = []
        _nb_item_modifiers = random.randint(0,2)
        for j in range(_nb_item_modifiers):
            _menu_item_modifier = secure_random.choice(_menu_item_modifiers)
            _order_item_modifier = create_order_item_modifier(order_key, _order_item.key, _menu_item_modifier.key, price=_menu_item_modifier.price)
            _order_item.unit_price += _order_item_modifier.price
            _selected_modifier.append(_order_item_modifier.key)
        _order_item.price = _order_item.unit_price * _order_item.quantity
        _order_item.selected_modifier = _selected_modifier
        _order_item.put()
        # Randomly select between 0, 1 and 2 modifiers for every order item.
        # create order modifier
        # link / attach the order modifier to order item
        result.append(_order_item.key)
    return result

def generate_order_items_from_delivery_service_fake(account_key, restaurant_key, delivery_service_key, order_key, nb_order_items=2):
    result = []
    _menu_sync = delivery_service_key.get().menuSync
    _menu_items = fetch_all_items(menu_sync_key=_menu_sync, keys_only=False)
    import logging
    logging.info(len(_menu_items))
    _menu_items_selected = []
    for _m in _menu_items:
        if _m.mappedToMenuItem:
            _menu_items_selected.append(_m)
            _pos_m = _m.mappedToMenuItem.get()
            logging.info("ds %s -> pos %s -> uuid %s" % (str(_m.name), str(_pos_m.name), str(_pos_m.uuid)))
    logging.info(len(_menu_items_selected))

    if not _menu_items_selected: return result
    secure_random = random.SystemRandom()
    for i in range(nb_order_items):
        _menu_item = secure_random.choice(_menu_items_selected)
        _quantity = 1
        _store_instructions = 'Thx for cooking it with Love.'
        _order_item = add_order_item_to_order(order_key, _menu_item.key, _menu_item.price, _quantity, _menu_item.price, _store_instructions)
        result.append(_order_item.key)
    return result
