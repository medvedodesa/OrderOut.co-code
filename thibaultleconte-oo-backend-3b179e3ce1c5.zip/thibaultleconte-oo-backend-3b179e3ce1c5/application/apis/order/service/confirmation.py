# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/03/2019
#

from ..model.Order import OrderStatus

def check_order_is_confirmed(order_key):
    _order = order_key.get()
    if _order.status == OrderStatus.CONFIRMED:
        return True
    return False

def set_order_as_confirmed(order_key):
    _order = order_key.get()
    _order.status = OrderStatus.CONFIRMED
    _order.put()
    return True
