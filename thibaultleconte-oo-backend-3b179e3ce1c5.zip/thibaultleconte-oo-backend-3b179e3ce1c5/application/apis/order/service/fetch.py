# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/21/2019
#

from application.apis.order.model.Order import Order

def fetch_order_from_delivery_service_uuid(delivery_service_uuid):
    _order = Order.query().filter(Order.delivery_service_uuid == delivery_service_uuid).get()
    return _order

def fetch_order_by_restaurant_and_delivery_service(restaurant_key, deliveryservice_keys, delivery_service_uuid):
    _query = Order.query()
    _query = _query.filter(Order.restaurant == restaurant_key)
    _query = _query.filter(Order.delivery_service.IN(deliveryservice_keys))
    _query = _query.filter(Order.delivery_service_uuid == delivery_service_uuid)
    _last_order = _query.get()
    return _last_order

def get_last_order_key_for_restaurant(restaurant_key):
    _query = Order.query()
    _query = _query.filter(Order.restaurant == restaurant_key)
    _query = _query.order(-Order.api_created_at)
    _last_order_keys = _query.fetch(1, keys_only=True)
    if len(_last_order_keys) > 0:
        return _last_order_keys[0]
    return None

def get_last_order_key_for_point_of_sale(point_of_sale_key):
    _query = Order.query()
    _query = _query.filter(Order.point_of_sale == point_of_sale_key)
    _query = _query.order(-Order.api_created_at)
    _last_order_keys = _query.fetch(1, keys_only=True)
    if len(_last_order_keys) > 0:
        return _last_order_keys[0]
    return None

# Orders list

def fetch_orders(account_key, restaurant_key, from_timestamp, to_timestamp, prev_cursor, next_cursor, limit, sort):
    _query = Order.query()
    if account_key: _query = _query.filter(Order.account == account_key)
    if restaurant_key: _query = _query.filter(Order.restaurant == restaurant_key)
    if from_timestamp: _query = _query.filter(Order.api_created_at >= from_timestamp)
    if to_timestamp: _query = _query.filter(Order.api_created_at <= to_timestamp)
    _objects, _prev_cursor, _next_cursor, _more, _count = Order.list_with_pagination(query=_query, _prev_cursor=prev_cursor, _next_cursor=next_cursor, limit=limit, sort=sort)
    return _objects, _prev_cursor, _next_cursor, _more, _count


def fetch_orders_offset_pagination(account_key, restaurant_key, from_timestamp, to_timestamp, delivery_service, _page=1, _item_per_page=2, sort='desc'):
    _query = Order.query()
    if account_key: _query = _query.filter(Order.account == account_key)
    if restaurant_key: _query = _query.filter(Order.restaurant == restaurant_key)
    if from_timestamp: _query = _query.filter(Order.api_created_at >= from_timestamp)
    if to_timestamp: _query = _query.filter(Order.api_created_at <= to_timestamp)
    order_by_key = False
    if delivery_service:
        _query = _query.filter(Order.delivery_service.IN(delivery_service))
        order_by_key = True
    _objects, prev, _next, _count = Order.list_with_offset_pagination(query=_query, page=_page, item_per_page=_item_per_page, keys_only=True, sort=sort, order_by_key=order_by_key)
    return _objects, prev, _next, _count
