# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/27/2019
#

from ..model.OrderItemModifier import OrderItemModifier

def create_order_item_modifier(order_key, order_item_key, menu_item_modifier_key, price=0):
    # _order_item_modifier = __fetch_order_item_modifier(order_key=order_key,
    #                                                    order_item_key=order_item_key,
    #                                                    menu_item_modifier_key=menu_item_modifier_key)
    # if not _order_item_modifier:
    _order_item_modifier = OrderItemModifier(order=order_key, order_item=order_item_key, menu_item_modifier=menu_item_modifier_key)
    _order_item_modifier.price = float(price)
    _order_item_modifier.put()
    return _order_item_modifier

# def __fetch_order_item_modifier(order_key, order_item_key, menu_item_modifier_key):
#     _query = OrderItemModifier.query()
#     _query = _query.filter(OrderItemModifier.order == order_key)
#     _query = _query.filter(OrderItemModifier.order_item == order_item_key)
#     _query = _query.filter(OrderItemModifier.menu_item_modifier == menu_item_modifier_key)
#     _order_item_modifier = _query.get()
#     return _order_item_modifier
