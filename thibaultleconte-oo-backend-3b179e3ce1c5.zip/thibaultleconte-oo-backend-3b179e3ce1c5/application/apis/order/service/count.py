# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 07/22/2019
#

from ..model.Order import Order

def count_total_orders_for_restaurant(restaurant_key):
    _query = Order.query()
    _query = _query.filter(Order.restaurant == restaurant_key)
    _count = _query.count()
    return _count

def count_total_orders_for_delivery_service(delivery_service_key):
    _query = Order.query()
    _query = _query.filter(Order.delivery_service == delivery_service_key)
    _count = _query.count()
    return _count
