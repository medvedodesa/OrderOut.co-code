# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/03/2019
#

from ..model.Order import OrderStatus

def order_is_canceled(order_key):
    _order = order_key.get()
    _order.status = OrderStatus.CANCELLED
    _order.put()
    return _order
