# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/13/2019
#

from application.core.model.Base import Base
from google.appengine.ext import ndb
from flask_restplus import fields
from application.apis import ooexceptions
from google.appengine.datastore.datastore_query import Cursor


class Customer(Base):
    email = ndb.StringProperty(required=True)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(Customer, cls).schema()
        schema['email'] = fields.String(required=True, description="Email")
        return schema

    #################
    # Check if exists
    #################

    @classmethod
    def exists_with_email(cls, email):
        _query = super(cls, cls).query()
        _query = _query.filter(cls.email == email)
        result = _query.count()
        return True if result > 0 else False

    ######
    # CRUD
    ######

    @classmethod
    def get_by_email(cls, email):
        _query = super(cls, cls).query()
        _query = _query.filter(cls.email == email)
        _obj = _query.get()
        if _obj: return _obj
        return None
