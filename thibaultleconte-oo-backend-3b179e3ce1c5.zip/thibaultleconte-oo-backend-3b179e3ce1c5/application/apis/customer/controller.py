# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/13/2019
#

from flask import request
from flask_restplus import Resource, Namespace
from .model import Customer
from application.apis import ooexceptions

nsApi = Namespace('customer', description='Customer related operations. These are people ordering food from restaurant. They are not considered as Users for OrderOut')

customer_marshal = nsApi.model('Customer', Customer.schema())

@nsApi.route('/<int:id>')
@nsApi.param('id', 'Customer identifier')
class UserCustomerGet(Resource):

    @nsApi.doc('Get a Customer')
    @nsApi.response(200, 'OK', customer_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(404, 'Not found')
    @nsApi.marshal_with(customer_marshal)
    def get(self, id):
        try:
            return Customer.get_by_id(id)
        except ooexceptions.ResourceDoesNotExist:
            nsApi.abort(404, 'Not found')
        except ooexceptions.NotFound:
            nsApi.abort(404, 'Not found')
        except Exception as e:
            import logging
            logging.error(e)
            nsApi.abort(400, 'Bad request')
        # TODO: Move to something like these to HANDLE ERRORS https://opensource.com/article/17/3/python-flask-exceptions
