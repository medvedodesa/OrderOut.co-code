# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/06/2019
#

from flask import request
from flask_restplus import Resource, Namespace
from application.core.authentication.service import requires_auth_token
from application.core.webhook.service import save_webhook
from application.core.webhook.model import CoreWebhookService
from application.core.task.service import startDeferredTask
from ..service.task import start_deferred_task_after_new_subscription, start_sync_task_after_new_subscription


nsApi = Namespace('Automation-Zapier', description='Zapier Automation related operations.')


@nsApi.route('/subscription/new')
class AutomationZapierNewSubscriptionWebhook(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Webhook used by Zapier to send New Subscription information')
    def post(self):
        json_dict = request.get_json()
        _wh = save_webhook(url=request.url, service=CoreWebhookService.ZAPIER, payload=json_dict)

        _account_name = json_dict.get('account_name', '')
        _restaurant_name = json_dict.get('restaurant_name', '')
        _restaurant_address_1 = json_dict.get('restaurant_address_1', '')
        _restaurant_address_2 = json_dict.get('restaurant_address_2', '')
        _restaurant_address_3 = json_dict.get('restaurant_address_3', '')
        _restaurant_city = json_dict.get('restaurant_city', '')
        _restaurant_zipcode = json_dict.get('restaurant_zipcode', '')
        _restaurant_state = json_dict.get('restaurant_state', '')
        _restaurant_country = json_dict.get('restaurant_country', '')
        _owner_name = json_dict.get('owner_name', '')
        _owner_email = json_dict.get('owner_email', '')
        _owner_phone = json_dict.get('owner_phone', '')
        _amount = json_dict.get('subscription_amount', '')
        _subscription_plan_name = json_dict.get('subscription_plan_name', '')

        # ASYNC
        # success = startDeferredTask(start_deferred_task_after_new_subscription, _account_name, _restaurant_name, _restaurant_address_1, _restaurant_address_2, _restaurant_address_3, _restaurant_city, _restaurant_zipcode, _restaurant_state, _restaurant_country, _amount, _subscription_plan_name, _owner_email, _owner_name, _owner_phone)
        # SYNC
        _account_key, _restaurant_key, _dashboard_url, _onboarding_url = start_sync_task_after_new_subscription(_account_name, _restaurant_name, _restaurant_address_1, _restaurant_address_2, _restaurant_address_3, _restaurant_city, _restaurant_zipcode, _restaurant_state, _restaurant_country, _amount, _subscription_plan_name, _owner_email, _owner_name, _owner_phone)
        success = True if _account_key else False 

        _wh.is_successful() if success else _wh.failed()
        return {"status": str(success),
                "account_id": str(_account_key.id()),
                "restaurant_id": str(_restaurant_key.id()),
                "dashboard_url": _dashboard_url,
                "onboarding_url": _onboarding_url}
