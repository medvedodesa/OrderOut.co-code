# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/06/2019
#

from flask import request
from flask_restplus import Resource, Namespace
from application.core.authentication.service import requires_auth_token
from application.core.webhook.service import save_webhook
from application.core.webhook.model import CoreWebhookService
from application.core.task.service import startDeferredTask
from ..service.task import auto_create_account_and_restaurant
from ..service.task import push_subscription_to_databox


nsApi = Namespace('Automation-Typeform', description='Typeform Automation related operations.')

TYPEFORM_FIELD_ID_OWNER_NAME = 'gWnR2Jdutq1Q'
TYPEFORM_FIELD_ID_RESTAURANT_NAME = 'Phx4JkN3fycu'
TYPEFORM_FIELD_ID_OWNER_EMAIL = 'l4pSoJxuavCW'
TYPEFORM_FIELD_ID_OWNER_PHONE = 'f0VtxycvWwrC'
TYPEFORM_FIELD_ID_ADDRESS_STREET = 'j61AwaZCfllY'
TYPEFORM_FIELD_ID_ADDRESS_CITY_STATE = 'aBVAsgzdb4Wy'
TYPEFORM_FIELD_ID_ADDRESS_ZIP = 'sm95unnMwJgb'


@nsApi.route('/gravity/new')
class AutomationTypeformNewGravitySubscriptionWebhook(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Webhook used by Typeform to send New Subscription information')
    def post(self):
        json_dict = request.get_json()
        _wh = save_webhook(url=request.url, service=CoreWebhookService.TYPEFORM, payload=json_dict)

        _account_name = None
        _address_street = None
        _address_city_state = None
        _address_zip = None
        _restaurant_name = None
        _owner_email = None
        _subscription_plan_name = 'gravity'
        _amount = 0
        for _raw_answer in json_dict.get('form_response', {}).get('answers', []):
            if _raw_answer.get('field', {}).get('id') == TYPEFORM_FIELD_ID_RESTAURANT_NAME:
                _account_name = _raw_answer.get('text')
            if _raw_answer.get('field', {}).get('id') == TYPEFORM_FIELD_ID_ADDRESS_STREET:
                _address_street = _raw_answer.get('text')
            if _raw_answer.get('field', {}).get('id') == TYPEFORM_FIELD_ID_ADDRESS_CITY_STATE:
                _address_city_state = _raw_answer.get('text')
            if _raw_answer.get('field', {}).get('id') == TYPEFORM_FIELD_ID_ADDRESS_ZIP:
                _address_zip = _raw_answer.get('text')
            if _raw_answer.get('field', {}).get('id') == TYPEFORM_FIELD_ID_OWNER_EMAIL:
                _owner_email = _raw_answer.get('text')
        _restaurant_name = _address_street + ', ' + _address_city_state + ', ' + _address_zip


        success = startDeferredTask(auto_create_account_and_restaurant, _account_name, _restaurant_name)
        success = startDeferredTask(push_subscription_to_databox, _amount, _subscription_plan_name)

        _wh.is_successful() if success else _wh.failed()
        return {"status": str(success)}

    @nsApi.route('/newtek/new')
    class AutomationTypeformNewNewtekSubscriptionWebhook(Resource):
        # method_decorators = [requires_auth_token]

        @nsApi.doc('Webhook used by Typeform to send New Subscription information')
        def post(self):
            json_dict = request.get_json()
            _wh = save_webhook(url=request.url, service=CoreWebhookService.TYPEFORM, payload=json_dict)

            _account_name = None
            _address_street = None
            _address_city_state = None
            _address_zip = None
            _restaurant_name = None
            _owner_email = None
            _subscription_plan_name = 'gravity'
            _amount = 0
            for _raw_answer in json_dict.get('form_response', {}).get('answers', []):
                if _raw_answer.get('field', {}).get('id') == TYPEFORM_FIELD_ID_RESTAURANT_NAME:
                    _account_name = _raw_answer.get('text')
                if _raw_answer.get('field', {}).get('id') == TYPEFORM_FIELD_ID_ADDRESS_STREET:
                    _address_street = _raw_answer.get('text')
                if _raw_answer.get('field', {}).get('id') == TYPEFORM_FIELD_ID_ADDRESS_CITY_STATE:
                    _address_city_state = _raw_answer.get('text')
                if _raw_answer.get('field', {}).get('id') == TYPEFORM_FIELD_ID_ADDRESS_ZIP:
                    _address_zip = _raw_answer.get('text')
                if _raw_answer.get('field', {}).get('id') == TYPEFORM_FIELD_ID_OWNER_EMAIL:
                    _owner_email = _raw_answer.get('text')
            _restaurant_name = _address_street + ', ' + _address_city_state + ', ' + _address_zip


            success = startDeferredTask(auto_create_account_and_restaurant, _account_name, _restaurant_name)
            success = startDeferredTask(push_subscription_to_databox, _amount, _subscription_plan_name)

            _wh.is_successful() if success else _wh.failed()
            return {"status": str(success)}
