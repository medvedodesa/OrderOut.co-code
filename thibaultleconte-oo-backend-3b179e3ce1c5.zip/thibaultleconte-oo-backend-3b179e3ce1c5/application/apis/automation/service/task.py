# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/06/2019
#
from application.apis.account.service import get_by_name as get_account_by_name, check_name_and_create
from application.apis.restaurant.service import get_by_name as get_restaurant_by_name, check_and_create_with_name
from application.apis.user.model.User import User, UserRole
from application.core.email.service import send_email_new_subscription_for_clover_with_printer, send_email_new_subscription_for_clover_no_printer
from application.core.email.service import send_email_from_dashboard_with_instructions_to_setup_doordash_grubhub
from application.core.databox.push import push_chargebee_subscription
from application.core.happyfox.push import create_ticket_for_onboarding as create_onboarding_ticket_on_happyfox
from application.core.settings.app import get_config_for_key


def start_deferred_task_after_new_subscription(account_name, restaurant_name, restaurant_address_1, restaurant_address_2, restaurant_address_3, restaurant_city, restaurant_zipcode, restaurant_state, restaurant_country, amount, subscription_plan_name, owner_email, owner_name, owner_phone):
    data = {
        "firstname": owner_name,
        "phone": owner_phone,
    }

    user = User.get_by_email(owner_email)
    if not user:
        user = User.create_and_populate(email=owner_email, json_dict=data, role=UserRole.MANAGER)

    _account_key, _restaurant_key = auto_create_account_and_restaurant(account_name, restaurant_name, restaurant_address_1, restaurant_address_2, restaurant_address_3, restaurant_city, restaurant_zipcode, restaurant_state, restaurant_country, user_key=user.key)
    # _admin_url = "{}/restaurant/{}".format(get_config_for_key("ADMIN_BASE_URL"), str(_restaurant_key.id()))
    # _onboarding_url = "{}/restaurant/{}/onboarding".format(get_config_for_key("DASHBOARD_BASE_URL"), str(_restaurant_key.id()))
    return

def start_sync_task_after_new_subscription(account_name, restaurant_name, restaurant_address_1, restaurant_address_2, restaurant_address_3, restaurant_city, restaurant_zipcode, restaurant_state, restaurant_country, amount, subscription_plan_name, owner_email, owner_name, owner_phone):
    data = {
        "firstname": owner_name,
        "phone": owner_phone,
    }

    user = User.get_by_email(owner_email)
    if not user:
        user = User.create_and_populate(email=owner_email, json_dict=data, role=UserRole.OWNER)

    if user.is_admin:
        return

    _account_key, _restaurant_key = auto_create_account_and_restaurant(account_name, restaurant_name, restaurant_address_1, restaurant_address_2, restaurant_address_3, restaurant_city, restaurant_zipcode, restaurant_state, restaurant_country, user_key=user.key)

    _admin_url = "{}/restaurant/{}".format(get_config_for_key("ADMIN_BASE_URL"), str(_restaurant_key.id()))
    _onboarding_url = "{}/restaurant/{}/onboarding".format(get_config_for_key("DASHBOARD_BASE_URL"), str(_restaurant_key.id()))
    return _account_key, _restaurant_key, _admin_url, _onboarding_url

def auto_create_account_and_restaurant(account_name, restaurant_name, restaurant_address_1, restaurant_address_2, restaurant_address_3, restaurant_city, restaurant_zipcode, restaurant_state, restaurant_country, user_key=None):
    if not account_name or not restaurant_name: return
    _account = get_account_by_name(name=account_name)
    if not _account: _account = check_name_and_create(name=account_name)
    _restaurant = get_restaurant_by_name(name=restaurant_name, account_key=_account.key)
    if not _restaurant: _restaurant = check_and_create_with_name(name=restaurant_name, account_key=_account.key)
    _restaurant.street_address_1 = restaurant_address_1
    _restaurant.street_address_2 = restaurant_address_2
    _restaurant.street_address_3 = restaurant_address_3
    _restaurant.city = restaurant_city
    _restaurant.zipcode = restaurant_zipcode
    _restaurant.state = restaurant_state
    _restaurant.country = restaurant_country
    _restaurant.add_user(user_key=user_key)
    _restaurant.put()

    return _account.key, _restaurant.key

def push_subscription_to_databox(amount, subscription_plan_name):
    push_chargebee_subscription(amount=amount, subscription_name=subscription_plan_name)
    return True

def push_subscription_to_happyfox(owner_email, owner_name, owner_phone, account_name, restaurant_name, subscription_plan_name, dashboard_url):
    create_onboarding_ticket_on_happyfox(owner_email, owner_name, owner_phone, account_name, restaurant_name, subscription_plan_name, dashboard_url)
    return True


# NOT USED anymore
def start_deferred_task_email_sendgrid_template_onboarding_clover_no_printer(account_name, owner_email, subscription_plan_name):
    if not owner_email: return
    send_email_new_subscription_for_clover_no_printer(owner_email, account_name)
    return

# NOT USED anymore
def start_deferred_task_email_sendgrid_template_onboarding_clover_with_printer(account_name, owner_email, subscription_plan_name):
    if not owner_email: return
    send_email_new_subscription_for_clover_with_printer(owner_email, account_name)
    return
