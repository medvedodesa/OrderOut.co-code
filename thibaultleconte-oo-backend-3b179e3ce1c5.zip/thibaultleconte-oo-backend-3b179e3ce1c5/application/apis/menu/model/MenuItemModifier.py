# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/23/2019
#

from google.appengine.ext import ndb
from application.core.model.Base import Base
from flask_restplus import fields, marshal
from application.core.marshal import SchemaFieldKeyFormatter


class MenuItemModifier(Base):
    menuSync = ndb.KeyProperty(required=True)
    name = ndb.StringProperty(required=True)
    uuid = ndb.StringProperty()
    is_available = ndb.BooleanProperty(default=True)
    price = ndb.FloatProperty(default=0)
    mappedToMenuItemModifier = ndb.KeyProperty(default=None)

    # item = ndb.KeyProperty()
    # group = ndb.KeyProperty()
    groups = ndb.KeyProperty(repeated=True)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema['name'] = fields.String(required=True, description="name")
        schema['uuid'] = fields.String(description="uuid")
        schema['is_available'] = fields.Boolean(attribute="is_available")
        schema['price'] = fields.Float(description="price")
        schema['mappedToMenuItemModifier'] = SchemaFieldKeyFormatter(attribute='mappedToMenuItemModifier', description='Menu Item Modifier mapped to')
        return schema

    ######
    # CRUD
    ######

    @classmethod
    def create(cls, menu_sync_key, modifier_group_key, name, uuid=None):
        _obj = cls()
        _obj.menuSync = menu_sync_key
        # _obj.group = modifier_group_key
        if modifier_group_key not in _obj.groups: _obj.groups.append(modifier_group_key)
        _obj.name = name
        _obj.uuid = uuid
        _obj.put()
        return _obj

    #####
    # Get
    #####

    @classmethod
    def fetch_by_uuid_or_name(cls, menu_sync_key, uuid, name=None):
        if not uuid and not name: return None
        _query = MenuItemModifier.query()
        _query = _query.filter(MenuItemModifier.menuSync == menu_sync_key)
        if uuid: _query = _query.filter(MenuItemModifier.uuid == uuid)
        if name: _query = _query.filter(MenuItemModifier.name == name)
        return _query.get()

class MenuItemModifiersListSchemaFieldFromKeyFormatter(fields.Raw):
    def format(self, value):
        result = []
        menu_item_modifiers = ndb.get_multi(value)
        for menu_item_modifier in menu_item_modifiers:
            result.append(marshal(menu_item_modifier, MenuItemModifier.schema()))
        return result

class MenuItemModifierSchemaFieldFromKeyFormatter(fields.Raw):
    def format(self, value):
        if value:
            return marshal(value.get(), MenuItemModifier.schema())
        return None
