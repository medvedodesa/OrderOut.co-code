# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/14/2019
#
import json

from google.appengine.ext import ndb

from application.core.model.Base import Base
from flask_restplus import fields, marshal
from .MenuCategory import MenuCategory


class MenuSection(Base):
    menuSync = ndb.KeyProperty(required=True)
    name = ndb.StringProperty(required=True)
    availability = ndb.JsonProperty(default=None)
    position = ndb.IntegerProperty(default=0)
    uuid = ndb.StringProperty()
    description = ndb.StringProperty()
    enabled = ndb.BooleanProperty(default=True)

    categories = ndb.KeyProperty(repeated=True)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls, expanded=False):
        schema = super(cls, cls).schema()
        schema["name"] = fields.String(required=True)
        schema["uuid"] = fields.String()
        schema["availability"] = ManySectionSchemaFieldAvailabilityFormatter(
            attribute="availability", description="Availability"
        )
        schema["description"] = fields.String()
        schema['position'] = fields.Integer()
        schema["enabled"] = fields.Boolean()
        if expanded:
            schema["categories"] = ManySectionSchemaFieldCategoriesExpanded(
                attribute="categories"
            )
        return schema

    ######
    # CRUD
    ######

    @classmethod
    def create(cls, menu_sync_key, name, uuid=None):
        _obj = cls()
        _obj.menuSync = menu_sync_key
        _obj.name = name
        _obj.uuid = uuid
        _obj.put()
        return _obj


########
# SCHEMA
########


class ManySectionSchemaFieldAvailabilityFormatter(fields.Raw):
    def format(self, value):
        if value:
            if isinstance(value, (unicode, str)):
                json_formatted = json.loads(value)
                return json_formatted
            else:
                return value
        return None


class ManySectionSchemaFieldCategoriesExpanded(fields.Raw):
    def format(self, value):
        result = []
        for v in value:
            result.append(marshal(v.get(), MenuCategory.schema(expanded=True)))
        return result
