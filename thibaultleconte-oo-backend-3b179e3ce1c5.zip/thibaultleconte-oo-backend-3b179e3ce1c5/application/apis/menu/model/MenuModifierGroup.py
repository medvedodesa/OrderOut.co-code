# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/18/2019
#

from google.appengine.ext import ndb
from application.core.model.Base import Base
from flask_restplus import fields, marshal
from .MenuItemModifier import MenuItemModifiersListSchemaFieldFromKeyFormatter


class MenuModifierGroup(Base):
    menuSync = ndb.KeyProperty(required=True)
    name = ndb.StringProperty(required=True)
    uuid = ndb.StringProperty()
    min_permitted = ndb.IntegerProperty()
    max_permitted = ndb.IntegerProperty()
    is_available = ndb.BooleanProperty(default=True)

    items = ndb.KeyProperty(repeated=True)
    modifiers = ndb.KeyProperty(repeated=True)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema['name'] = fields.String(required=True, description="name")
        schema['uuid'] = fields.String(description="uuid")
        schema['is_available'] = fields.Boolean(attribute="is_available")
        schema['min_permitted'] = fields.Integer(description="min_permitted")
        schema['max_permitted'] = fields.Integer(description="max_permitted")
        schema['modifiers'] = MenuItemModifiersListSchemaFieldFromKeyFormatter(attribute='modifiers', description='Menu Item Modifiers')
        return schema

    ######
    # CRUD
    ######

    @classmethod
    def create(cls, menu_sync_key, item_key, name, uuid=None):
        _obj = cls()
        _obj.menuSync = menu_sync_key
        if item_key not in _obj.items: _obj.items.append(item_key)
        _obj.name = name
        _obj.uuid = uuid
        _obj.put()
        return _obj

    #####
    # Get
    #####

    @classmethod
    def fetch_by_uuid_or_name(cls, menu_sync_key, uuid, name=None):
        if not uuid and not name: return None
        _query = MenuModifierGroup.query()
        _query = _query.filter(MenuModifierGroup.menuSync == menu_sync_key)
        if uuid: _query = _query.filter(MenuModifierGroup.uuid == uuid)
        if name: _query = _query.filter(MenuModifierGroup.name == name)
        return _query.get()

class MenuModifierGroupSchemaFieldFromKeyFormatter(fields.Raw):
    def format(self, value):
        result = []
        menu_modifier_groups = ndb.get_multi(value)
        for menu_modifier_group in menu_modifier_groups:
            result.append(marshal(menu_modifier_group, MenuModifierGroup.schema()))
        return result
