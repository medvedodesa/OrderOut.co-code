# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/23/2019
#

from google.appengine.ext import ndb
from application.core.model.Base import Base
from flask_restplus import fields, marshal
from application.core.marshal import SchemaFieldKeyFormatter
from .MenuModifierGroup import MenuModifierGroupSchemaFieldFromKeyFormatter
from ..service.fetch.modifierGroup import fetch_all_modifier_groups_keys_for_menu_item


class MenuItem(Base):
    menuSync = ndb.KeyProperty(required=True)
    name = ndb.StringProperty(required=True)
    uuid = ndb.StringProperty()
    price = ndb.FloatProperty(default=0)
    is_available = ndb.BooleanProperty(default=True)
    mappedToMenuItem = ndb.KeyProperty(default=None)
    description = ndb.StringProperty()
    currency = ndb.StringProperty(default='USD')
    is_alcohol = ndb.BooleanProperty(default=False)
    tax_rate = ndb.FloatProperty()
    vat_rate_percentage = ndb.FloatProperty()
    disable_instructions = ndb.BooleanProperty(default=False)
    image_url = ndb.StringProperty()

    categories = ndb.KeyProperty(repeated=True)
    modifier_groups = ndb.KeyProperty(repeated=True) #USED

    @property
    def modifiergroups(self):
        _modifier_groups_keys = fetch_all_modifier_groups_keys_for_menu_item(menu_item_key=self.key)
        # if self.modifier_groups != _modifier_groups_keys:
        #     import logging
        #     logging.info(self.modifier_groups)
        #     logging.info(_modifier_groups_keys)
        return _modifier_groups_keys

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls, expanded=False):
        schema = super(cls, cls).schema()
        schema['name'] = fields.String(required=True, description="name")
        schema['uuid'] = fields.String(description="uuid")
        schema['price'] = fields.Float(description="price")
        schema['modifier_groups'] = MenuModifierGroupSchemaFieldFromKeyFormatter(attribute='modifiergroups', description='List of Modifiers Menu Item Groups')
        schema['is_available'] = fields.Boolean(attribute="is_available", description="is_available")
        schema['price'] = fields.Float(description="price")
        schema['mappedToMenuItem'] = SchemaFieldKeyFormatter(attribute='mappedToMenuItem', description='Menu Item mapped to')
        schema['category_name'] = fields.String(required=False, description="category name")
        return schema

    ######
    # CRUD
    ######

    @classmethod
    def create(cls, menu_sync_key, category_key, name, uuid=None):
        _obj = cls()
        _obj.menuSync = menu_sync_key
        if category_key not in _obj.categories:
            _obj.categories.append(category_key)
        _obj.name = name
        _obj.uuid = uuid
        _obj.put()
        return _obj

class MenuItemSchemaFieldFromKeyFormatter(fields.Raw):
    def format(self, value):
        if value:
            obj = value.get()
            if obj:
                return marshal(obj, MenuItem.schema())
        return None
