# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/14/2019
#

from google.appengine.ext import ndb
from application.core.model.Base import Base
from flask_restplus import fields, marshal
from .MenuItem import MenuItem
from ..service.menuItem import fetch_all_menu_items_keys_for_category


class MenuCategory(Base):
    menuSync = ndb.KeyProperty(required=True)
    section = ndb.KeyProperty()
    name = ndb.StringProperty(required=True)
    uuid = ndb.StringProperty()
    enabled = ndb.BooleanProperty(default=True)
    position = ndb.IntegerProperty(default=0)

    @property
    def menuitems(self):
        _menu_items_keys = fetch_all_menu_items_keys_for_category(category_key=self.key)
        return _menu_items_keys

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls, expanded=False):
        schema = super(cls, cls).schema()
        schema['name'] = fields.String(required=True)
        schema['uuid'] = fields.String()
        schema['enabled'] = fields.Boolean()
        schema['position'] = fields.Integer()
        if expanded: schema['menuitems'] = MenyCategorySchemaFieldMenuItems(attribute='menuitems')
        return schema

    ######
    # CRUD
    ######

    @classmethod
    def create(cls, menu_sync_key, section_key, name, uuid=None):
        _obj = cls()
        _obj.menuSync = menu_sync_key
        _obj.section = section_key
        _obj.name = name
        _obj.uuid = uuid
        _obj.put()
        return _obj

########
# SCHEMA
########

class MenyCategorySchemaFieldMenuItems(fields.Raw):
    def format(self, value):
        result = []
        for v in value:
            result.append(marshal(v.get(), MenuItem.schema()))
        return result
