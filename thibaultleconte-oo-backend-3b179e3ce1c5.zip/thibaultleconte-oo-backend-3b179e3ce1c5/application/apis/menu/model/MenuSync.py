# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/09/2019
#

from google.appengine.ext import ndb
from google.appengine.ext.ndb import msgprop
from protorpc import messages

from application.apis.user.model.User import UserSchemaFieldFromKeyFormatter
from application.core.model.Base import Base
from flask_restplus import fields, marshal
from application.core.marshal import SchemaFieldKeyFormatter, SchemaFieldListOfKeysFormatter

class MenuSyncStatus(messages.Enum):
    UNKNOWN = 0
    RUNNING = 1
    ERROR = 2
    SUCCESS = 3

class MenuSync(Base):
    restaurant = ndb.KeyProperty(required=True)
    service = ndb.KeyProperty()
    fetch_menu_status = msgprop.EnumProperty(MenuSyncStatus, default=MenuSyncStatus.UNKNOWN)
    fetch_external_id = ndb.StringProperty(default='')
    process_menu_status = msgprop.EnumProperty(MenuSyncStatus, default=MenuSyncStatus.UNKNOWN)
    process_external_id = ndb.StringProperty(default='')
    map_total_menu_items = ndb.IntegerProperty(default=0)
    map_mapped_menu_items = ndb.IntegerProperty(default=0)
    map_unmapped_menu_items = ndb.IntegerProperty(default=0)
    map_total_menu_modifiers = ndb.IntegerProperty(default=0)
    map_mapped_menu_modifiers = ndb.IntegerProperty(default=0)
    map_unmapped_menu_modifiers = ndb.IntegerProperty(default=0)
    task_processing_done = ndb.KeyProperty(default=None)
    author = ndb.KeyProperty()
    published_on = ndb.DateTimeProperty()
    name = ndb.StringProperty(default='')
    description = ndb.StringProperty(default='')

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema['restaurant'] = SchemaFieldKeyFormatter(attribute='restaurant', description='Restaurant')
        schema['service'] = MenySyncServiceFieldFromKeyFormatter(attribute='service', description='Service')
        schema['fetch_menu_status'] = fields.String()
        schema['process_menu_status'] = fields.String()
        schema['map_total_menu_items'] = fields.Integer(readonly=True, description="Number of Menu Items")
        schema['map_mapped_menu_items'] = fields.Integer(readonly=True, description="Number of Mapped Menu Items")
        schema['map_unmapped_menu_items'] = fields.Integer(readonly=True, description="Number of Unmapped Menu Items")
        schema['map_total_menu_modifiers'] = fields.Integer(readonly=True, description="Number of Menu Modifiers")
        schema['map_mapped_menu_modifiers'] = fields.Integer(readonly=True, description="Number of Mapped Menu Modifiers")
        schema['map_unmapped_menu_modifiers'] = fields.Integer(readonly=True, description="Number of Unmapped Menu Modifiers")
        schema['api_updated_at'] = fields.DateTime(readOnly=True, description="Last Update date and time")
        schema['author'] = UserSchemaFieldFromKeyFormatter(attribute='author', description='Author')
        schema['published_on'] = fields.DateTime(description="Menu publish date and time")
        schema['name'] = fields.String()
        schema['description'] = fields.String()
        return schema

    ######
    # CRUD
    ######

    @classmethod
    def create(cls, restaurant_key, service_key=None):
        _obj = cls()
        _obj.restaurant = restaurant_key
        _obj.service = service_key
        _obj.put()
        return _obj

    #######
    # Query
    #######

    @classmethod
    def list_with_pagination_with_restaurant(cls, restaurant_key, cursor=None, limit=25):
        _cursor =ndb.Cursor(urlsafe=cursor) if cursor else None
        _query = MenuSync.query()
        _query = _query.filter(MenuSync.restaurant == restaurant_key)
        _query = _query.order(-MenuSync.api_created_at)
        _objects, _next_cursor, _more = _query.fetch_page(limit, start_cursor=_cursor)
        _previous_cursor = _next_cursor.reversed() if _next_cursor else None
        return _objects, _previous_cursor, _next_cursor, _more

class MenySyncSchemaFieldFromKeyFormatter(fields.Raw):
    def format(self, value):
        if value:
            return marshal(value.get(), MenuSync.schema())
        return None

class MenySyncServiceFieldFromKeyFormatter(fields.Raw):
    def format(self, value):
        if value:
            _entity = value.get()
            _schema = None
            from application.apis.deliveryservice.model.DeliveryService import DeliveryService
            from application.apis.pointofsale.model.PointOfSale import PointOfSale
            if isinstance(_entity, DeliveryService):
                _schema = DeliveryService.schema(with_menu_sync=False, with_email_verification=False)
            elif isinstance(_entity, PointOfSale):
                _schema = PointOfSale.schema(with_menu_sync=False)
            return marshal(_entity, _schema)
        return None
