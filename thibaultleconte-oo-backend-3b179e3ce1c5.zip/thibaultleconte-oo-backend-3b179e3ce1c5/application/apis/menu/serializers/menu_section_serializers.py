from datetime import datetime

from marshmallow import Schema, fields, post_load

from application.core.util.date_utils import validate_hour_minute_format, DAYS_OF_WEEK


class MenuSectionAvailabilityTimePeriodSchema(Schema):
    start_time = fields.Str(validate=validate_hour_minute_format, required=True)
    end_time = fields.Str(validate=validate_hour_minute_format, required=True)


class MenuSectionAvailabilitySchema(Schema):
    day_of_week = fields.Str(
        required=True,
        validate=lambda dow: dow
        in [
            "monday",
            "tuesday",
            "wednesday",
            "thursday",
            "friday",
            "saturday",
            "sunday",
        ],
    )
    enabled = fields.Bool(default=True)
    time_periods = fields.Nested(
        MenuSectionAvailabilityTimePeriodSchema, many=True, required=True
    )


class MenuSectionSchema(Schema):
    name = fields.Str(required=True)
    availability = fields.Nested(
        MenuSectionAvailabilitySchema, many=True, required=False
    )
    position = fields.Int(required=False)
    uuid = fields.UUID(required=False)
    description = fields.Str(required=False)
    enabled = fields.Bool(required=False)

    @post_load
    def post_load_handler(self, data, **kwargs):
        time_format = "%H:%M"
        new_availabilities = []
        data["availability"] = data.get("availability", [])
        for availability in data["availability"]:

            for time_period in availability["time_periods"]:
                start_value = time_period["start_time"]
                end_value = time_period["end_time"]

                start_date = datetime.strptime(start_value, time_format)
                end_date = datetime.strptime(end_value, time_format)

                delta = end_date - start_date

                # Split overlapping days.
                if delta.days < 0:
                    end_time = time_period["end_time"]

                    time_period["end_time"] = "23:59"

                    # Add time period to the next day.
                    next_weekday = DAYS_OF_WEEK.index(availability["day_of_week"]) + 1
                    weekday_name = DAYS_OF_WEEK[next_weekday % 7]

                    if end_time != "00:00":
                        new_time_period = {"start_time": "00:00", "end_time": end_time}
                        new_availabilities.append(
                            {
                                "enabled": availability["enabled"],
                                "time_periods": [new_time_period],
                                "day_of_week": weekday_name,
                            }
                        )

        data["availability"].extend(new_availabilities)
        if "uuid" in data:
            data["uuid"] = str(data["uuid"])
        return data
