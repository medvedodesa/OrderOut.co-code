# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 10/18/2019
#

from ..model.MenuItemModifier import MenuItemModifier
from application.apis.menu.service.fetch.menuSync import fetch_all_for_account


def fetch_all_menu_item_modifiers_keys_for_ids(ids):
    _result = []
    for k in ids:
        _key = __fetch_menu_item_modifier_key_for_id(k)
        if _key: _result.append(_key)
    return _result

def fetch_all_modifiers_for_menu_item(menu_item_key):
    _menu_item = menu_item_key.get()
    if len(_menu_item.modifier_groups) == 0: return []
    _query = MenuItemModifier.query()
    _query = _query.filter(MenuItemModifier.groups.IN(_menu_item.modifier_groups))
    _query = _query.order(MenuItemModifier.name)
    _modifiers = _query.fetch()
    return _modifiers

def fetch_menu_item_modifiers_keys_with_uuids(menu_sync_key, uuids):
    _query = MenuItemModifier.query()
    _query = _query.filter(MenuItemModifier.menuSync == menu_sync_key)
    _query = _query.filter(MenuItemModifier.uuid.IN(uuids))
    menu_item_modifiers_keys = _query.fetch(keys_only=True)
    return menu_item_modifiers_keys

def fetch_all_menu_item_modifiers_for_menu_sync(menu_sync_key):
    _query = MenuItemModifier.query()
    _query = _query.filter(MenuItemModifier.menuSync == menu_sync_key)
    _menu_item_modifiers = _query.fetch()
    return _menu_item_modifiers

def fetch_menu_item_modifier_for_menu_sync(item_modifier_id, menu_sync_key):
    query = MenuItemModifier.query()
    query = query.filter(MenuItemModifier.menuSync == menu_sync_key)
    query = query.filter(MenuItemModifier.uuid == item_modifier_id)
    menu_item_modifier = query.get()
    return menu_item_modifier

def fetch_all_delivery_service_menu_item_modifiers_for_account(account_key):
    _menuSync_keys = fetch_all_for_account(account_key)
    _menu_item_modifiers = []
    for _ms_key in _menuSync_keys:
        _modifiers = fetch_all_menu_item_modifiers_for_menu_sync(_ms_key)
        for _mod in _modifiers:
            if _mod.mappedToMenuItemModifier:
                _menu_item_modifiers.append(_mod)
    return _menu_item_modifiers

########
# HELPER
########

def __fetch_menu_item_modifier_key_for_id(id):
    return MenuItemModifier.get_key(id)



#####
# POS
#####

def fetch_all_modifiers_for_point_of_sale(point_of_sale_key):
    _pos = point_of_sale_key.get()
    _menu_items = fetch_all_menu_item_modifiers_for_menu_sync(_pos.menuSync)
    return _menu_items

##################
# DELIVERY SERVICE
##################

def fetch_all_modifiers_for_delivery_service(delivery_service_key):
    _ds = delivery_service_key.get()
    _menu_items = fetch_all_menu_item_modifiers_for_menu_sync(_ds.menuSync)
    return _menu_items

####################
# Unmapped Modifiers
####################

def filter_all_unmapped_modifiers(menu_item_modifiers):
    _unmapped_modifiers = []
    for _mod in menu_item_modifiers:
        if not _mod.mappedToMenuItemModifier:
            _unmapped_modifiers.append(_mod)
    return _unmapped_modifiers
