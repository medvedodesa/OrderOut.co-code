# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 10/07/2020
#

from application.apis.menu.service.fetch.section import fetch_section
from application.apis.menu.service.crud.section import create_update_menu_section
from application.apis.menu.service.fetch.category import fetch_category
from application.apis.menu.service.crud.category import create_update_menu_category
from application.apis.menu.service.fetch.modifierGroup import fetch_all_modifier_groups_keys_for_menusync
from application.apis.pointofsale.service.clover.menu import add_item_to_clover, add_modifier_to_clover, add_modifier_group_to_clover
from application.apis.menu.service.crud.item import create_update_item
from application.apis.menu.service.crud.modifierGroup import create_update_modifier_group
from application.apis.menu.service.crud.modifier import create_update_modifier
from application.apis.menu.service.modifier import fetch_all_modifiers_for_menu_item, filter_all_unmapped_modifiers
from application.apis.menu.service.modifier import fetch_all_menu_item_modifiers_for_menu_sync


OO_MAGIC_MAPPING_SECTION_NAME = 'OrderOut Magic Mapping'
OO_MAGIC_MAPPING_CATEGORY_NAME = 'OrderOut Magic Mapping'
OO_MAGIC_MAPPING_MODIFIER_GROUP_NAME = 'OrderOut Magic Mapping'



def create_item_in_clover_and_map(pos_key, pos_menu_sync_key, pos_category_key, ds_unmapped_item):
    # menu item
    _name, _uuid, _price = add_item_to_clover(pointofsale_key=pos_key, menu_item_name=ds_unmapped_item.name, menu_item_price=ds_unmapped_item.price)
    if not _name and not _uuid and not _price: return ds_unmapped_item, None
    _new_pos_menu_item = create_update_item(menu_sync_key=pos_menu_sync_key,
                                        category_key=pos_category_key,
                                        name=_name,
                                        uuid=_uuid,
                                        price=_price)
    ds_unmapped_item.mappedToMenuItem = _new_pos_menu_item.key

    # modifiers
    _menu_item_modifiers = fetch_all_modifiers_for_menu_item(menu_item_key=ds_unmapped_item.key)
    _unmapped_menu_item_modifiers = filter_all_unmapped_modifiers(_menu_item_modifiers)
    if len(_unmapped_menu_item_modifiers) > 0:
        _pos_existing_modifiers = fetch_all_menu_item_modifiers_for_menu_sync(menu_sync_key=pos_menu_sync_key)
        _pos_modifier_group_key = get_magic_mapping_modifier_group(pointofsale_key=pos_key, pos_menu_sync_key=pos_menu_sync_key, pos_menu_item_key=_new_pos_menu_item.key)
        _pos_modifier_group = _pos_modifier_group_key.get()
        _menu_modifiers = []
        for _ds_unmapped_modifier in _unmapped_menu_item_modifiers:
            _ds_mod, _pos_mod = create_modifier_in_clover_and_map(pos_key=pos_key, menu_sync_key=pos_menu_sync_key, pos_existing_modifiers=_pos_existing_modifiers, modifier_group_key=_pos_modifier_group_key, modifier_group_uuid=_pos_modifier_group.uuid, ds_unmapped_modifier=_ds_unmapped_modifier)
            _menu_modifiers.append(_ds_mod)
            if _ds_mod not in _pos_existing_modifiers: _pos_existing_modifiers.append(_ds_mod)
        # To replace with a Put_multi that save to cache, the ndb one does NOT
        for _e in _menu_modifiers: _e.put()
        # MenuItemModifier.put_multi(_menu_modifiers)

    return ds_unmapped_item, _new_pos_menu_item

def create_modifier_in_clover_and_map(pos_key, menu_sync_key, pos_existing_modifiers, modifier_group_key, modifier_group_uuid, ds_unmapped_modifier):
    _pos_mapped_modifier = __find_modifier_with_name(name_to_search=ds_unmapped_modifier.name, list_of_modifiers=pos_existing_modifiers)
    if not _pos_mapped_modifier:
        _name, _uuid, _price = add_modifier_to_clover(pointofsale_key=pos_key, modifier_group_uuid=modifier_group_uuid, name=ds_unmapped_modifier.name, price=ds_unmapped_modifier.price)
        if _name and _uuid and _price is not None:
            _pos_mapped_modifer = create_update_modifier(menu_sync_key=menu_sync_key,
                                                      modifier_group_key=modifier_group_key,
                                                      name=_name,
                                                      uuid=_uuid,
                                                      price=_price)
        else:
            _pos_mapped_modifier = None

    if _pos_mapped_modifier:
        ds_unmapped_modifier.mappedToMenuItemModifier = _pos_mapped_modifier.key
    return ds_unmapped_modifier, _pos_mapped_modifier

###############

def get_magic_mapping_section(pos_menu_sync_key):
    _section_key = fetch_section(menu_sync_key=pos_menu_sync_key, name=OO_MAGIC_MAPPING_SECTION_NAME, keys_only=True)
    if _section_key: return _section_key
    _section = create_update_menu_section(menu_sync_key=pos_menu_sync_key, name=OO_MAGIC_MAPPING_SECTION_NAME)
    return _section.key

def get_magic_mapping_category(pos_menu_sync_key, pos_section_key):
    _category_key = fetch_category(menu_sync_key=pos_menu_sync_key, section_key=pos_section_key, name=OO_MAGIC_MAPPING_CATEGORY_NAME, keys_only=True)
    if _category_key: return _category_key
    _category = create_update_menu_category(menu_sync_key=pos_menu_sync_key, section_key=pos_section_key, name=OO_MAGIC_MAPPING_CATEGORY_NAME)
    return _category.key

def get_magic_mapping_modifier_group(pointofsale_key, pos_menu_sync_key, pos_menu_item_key):
    _modifier_group_keys = fetch_all_modifier_groups_keys_for_menusync(menu_sync_key=pos_menu_sync_key, name=OO_MAGIC_MAPPING_MODIFIER_GROUP_NAME)
    if len(_modifier_group_keys) > 0: return _modifier_group_keys[0]
    _clover_modifier_group_uuid = add_modifier_group_to_clover(pointofsale_key=pointofsale_key, modifier_group_name=OO_MAGIC_MAPPING_MODIFIER_GROUP_NAME)
    _modifier_group = create_update_modifier_group(menu_sync_key=pos_menu_sync_key, item_key=pos_menu_item_key, name=OO_MAGIC_MAPPING_MODIFIER_GROUP_NAME, uuid=_clover_modifier_group_uuid)
    return _modifier_group.key

###############

def __find_modifier_with_name(name_to_search, list_of_modifiers):
    for _mod in list_of_modifiers:
        if _mod.name.lower() == name_to_search.lower():
            return _mod
    return None
