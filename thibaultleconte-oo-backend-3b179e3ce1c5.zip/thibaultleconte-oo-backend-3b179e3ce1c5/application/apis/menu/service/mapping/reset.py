# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/01/2019
#


def reset_mapping_for_menu_item(menu_item):
    menu_item.mappedToMenuItem = None
    menu_item.put()
    return menu_item

def reset_mapping_for_menu_item_modifier(menu_item_modifier):
    menu_item_modifier.mappedToMenuItemModifier = None
    menu_item_modifier.put()
    return menu_item_modifier
