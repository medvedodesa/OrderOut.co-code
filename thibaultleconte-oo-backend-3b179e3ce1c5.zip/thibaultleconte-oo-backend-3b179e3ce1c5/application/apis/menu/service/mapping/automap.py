# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/01/2019
#
import logging
from collections import defaultdict

from google.appengine.ext import ndb
from application.core.task.service import startDeferredTask

from application.apis.menu.service.menuItem import (
    fetch_all_delivery_service_menu_items_for_account,
)
from application.apis.menu.service.modifier import (
    fetch_all_modifiers_for_menu_item,
    fetch_all_delivery_service_menu_item_modifiers_for_account,
)
from application.apis.menu.service.stats import refresh_stats
from application.apis.menu.service.fetch.item import fetch_all_items


def map_item_and_modifiers(
    pos_menu_item, ds_menu_item, map_pos_menu_item_modifiers, map_historical_modifier_name, use_old_mapping_uuid,
):
    ds_elements_mapped = []

    ds_menu_item.mappedToMenuItem = pos_menu_item.key
    ds_elements_mapped.append(ds_menu_item)

    logging.info("Mapping item: {} to {}".format(ds_menu_item.key, pos_menu_item.key))

    count_modifiers = 0

    for modifier_group_key in ds_menu_item.modifiergroups:
        modifier_group = modifier_group_key.get()
        modifiers = modifier_group.modifiers if modifier_group else []

        logging.info("Len of modifiers: {}".format(len(modifiers)))

        for modifier_key in modifiers:
            ds_modifier = modifier_key.get()
            if ds_modifier:
                count_modifiers += 1
                found_pos_modifier = None
                ds_modifier_old_map_uuid = None

                modifier_name = ds_modifier.name.lower()

                logging.info("Trying to map modifier: {}".format(modifier_name))

                old_mapped_modifier = (
                    ds_modifier.mappedToMenuItemModifier.get() if ds_modifier.mappedToMenuItemModifier else None
                )
                if old_mapped_modifier:
                    ds_modifier_old_map_uuid = old_mapped_modifier.uuid

                # If we have a modifier with the same name on the just mapped pos item, map each other.

                # Else look for others modifiers with the same name,
                # check if we have a pos modifier with the same name as the mapped modifier.
                if modifier_name in map_pos_menu_item_modifiers[pos_menu_item.id]:
                    found_pos_modifier = map_pos_menu_item_modifiers[pos_menu_item.id][modifier_name]
                    logging.info("Found pos modifier with same name: {}".format(found_pos_modifier.key))

                elif (
                    use_old_mapping_uuid
                    and ds_modifier_old_map_uuid
                    and ds_modifier_old_map_uuid in map_pos_menu_item_modifiers[pos_menu_item.id]
                ):
                    found_pos_modifier = map_pos_menu_item_modifiers[pos_menu_item.id][ds_modifier_old_map_uuid]
                    logging.info("Found pos modifier with same old mapping uuid: {}".format(found_pos_modifier.key))

                if found_pos_modifier:
                    ds_modifier.mappedToMenuItemModifier = found_pos_modifier.key
                    ds_elements_mapped.append(ds_modifier)
                else:
                    historical_ds_modifiers_with_same_name = map_historical_modifier_name.get(modifier_name, [])
                    logging.info(
                        "Len of historical ds modifiers with same name {}".format(
                            len(historical_ds_modifiers_with_same_name)
                        )
                    )
                    for historical_modifier in historical_ds_modifiers_with_same_name:
                        mapped_modifier = historical_modifier.mappedToMenuItemModifier
                        mapped_modifier_name = mapped_modifier.get().name.lower()

                        logging.info("Modifier historical mapped to {}".format(mapped_modifier_name))

                        pos_modifier = map_pos_menu_item_modifiers[pos_menu_item.id].get(mapped_modifier_name)

                        if not pos_modifier and use_old_mapping_uuid:
                            mapped_modifier_uuid = mapped_modifier.get().uuid
                            pos_modifier = map_pos_menu_item_modifiers[pos_menu_item.id].get(mapped_modifier_uuid)

                        if pos_modifier:
                            logging.info("Modifier found: {}".format(pos_modifier.key))
                            ds_modifier.mappedToMenuItemModifier = pos_modifier.key
                            ds_elements_mapped.append(ds_modifier)
                            break

    logging.info("len of all modifiers for item: {} is: {}".format(pos_menu_item.name, count_modifiers))
    logging.info("len of ds_elements_mapped: {}".format(len(ds_elements_mapped)))
    return ds_elements_mapped


def auto_map_delivery_service_menu_to_point_of_sale_menu_v2(pos_key, ds, use_old_mapping_uuid=False):
    logging.info("Starting the mapping of the DS: {} with the POS: {}".format(ds.key, pos_key))

    _pos = pos_key.get()
    pos_menu_items = fetch_all_items(menu_sync_key=_pos.menuSync, keys_only=False)
    ds_menu_items = fetch_all_items(menu_sync_key=ds.menuSync, keys_only=False)
    historical_ds_mis = fetch_all_delivery_service_menu_items_for_account(ds.account)
    historical_ds_mods = fetch_all_delivery_service_menu_item_modifiers_for_account(ds.account)

    logging.info("POS menu items length: {}".format(len(pos_menu_items)))
    logging.info("DS menu items length: {}".format(len(ds_menu_items)))
    logging.info("Historial DS menu items length: {}".format(len(historical_ds_mis)))
    logging.info("Historial DS modifiers length: {}".format(len(historical_ds_mods)))

    if not pos_menu_items or not ds_menu_items:
        return []

    ds_elements_mapped = []
    ds_elements_not_mapped = []

    # Create index to quick access the entities.
    map_pos_menu_item_name = dict()
    map_pos_menu_item_uuid = dict()
    map_pos_menu_item_modifiers = defaultdict(dict)

    map_historical_item_name = defaultdict(list)
    map_historical_modifier_name = defaultdict(list)

    count_historical_items_mapped = 0
    count_historical_modifiers_mapped = 0

    for historical_ds_menu_item in historical_ds_mis:
        if historical_ds_menu_item.mappedToMenuItem:
            count_historical_items_mapped += 1
            map_historical_item_name[historical_ds_menu_item.name.lower()].append(historical_ds_menu_item)

    for historical_ds_modifier in historical_ds_mods:
        if historical_ds_modifier.mappedToMenuItemModifier:
            count_historical_modifiers_mapped += 1
            map_historical_modifier_name[historical_ds_modifier.name.lower()].append(historical_ds_modifier)

    logging.info("Historical items mapped: {}".format(count_historical_items_mapped))
    logging.info("Historical modifiers mapped: {}".format(count_historical_modifiers_mapped))

    for pos_menu_item in pos_menu_items:
        map_pos_menu_item_name[pos_menu_item.name.lower()] = pos_menu_item
        if pos_menu_item.uuid:
            map_pos_menu_item_uuid[pos_menu_item.uuid] = pos_menu_item

        for modifier in fetch_all_modifiers_for_menu_item(menu_item_key=pos_menu_item.key):
            map_pos_menu_item_modifiers[pos_menu_item.id][modifier.name.lower()] = modifier
            if modifier.uuid:
                map_pos_menu_item_modifiers[pos_menu_item.id][modifier.uuid] = modifier

    # Try to map each delivery service item
    for ds_menu_item in ds_menu_items:
        pos_menu_item_found = None
        ds_menu_item_old_map_uuid = None

        ds_menu_item_name = ds_menu_item.name.lower()

        logging.info("Trying to map item: {} STEP 1".format(ds_menu_item_name))

        old_mapped_item = ds_menu_item.mappedToMenuItem.get() if ds_menu_item.mappedToMenuItem else None
        if old_mapped_item:
            ds_menu_item_old_map_uuid = old_mapped_item.uuid

        # If we have a pos item with the same name, map each other.
        # Else add to a list to try to map later on the code.
        if ds_menu_item_name in map_pos_menu_item_name:
            pos_menu_item_found = map_pos_menu_item_name[ds_menu_item_name]
            logging.info("Found pos item with same name")

        elif use_old_mapping_uuid and ds_menu_item_old_map_uuid and ds_menu_item_old_map_uuid in map_pos_menu_item_uuid:
            pos_menu_item_found = map_pos_menu_item_uuid[ds_menu_item_old_map_uuid]
            logging.info("Found pos item based on an old mapped pos item uuid")

        if pos_menu_item_found:
            ds_elements_mapped.extend(
                map_item_and_modifiers(
                    pos_menu_item_found,
                    ds_menu_item,
                    map_pos_menu_item_modifiers,
                    map_historical_modifier_name,
                    use_old_mapping_uuid,
                )
            )

        else:
            logging.info("Couldn't find pos item on step 1")
            ds_elements_not_mapped.append(ds_menu_item)

    # Try to map the unmapped delivery service items.
    for ds_menu_item in ds_elements_not_mapped:

        # Look for others delivery service items with the same name,
        # check if we have a pos item with the same name as the mapped item.
        pos_menu_item_found = None

        ds_menu_item_name = ds_menu_item.name.lower()

        logging.info("Trying to map item: {} STEP 2".format(ds_menu_item_name))

        historical_ds_menu_items_with_same_name = map_historical_item_name.get(ds_menu_item_name, [])
        logging.info(
            "Len of historial ds menu items with same name: {}".format(len(historical_ds_menu_items_with_same_name))
        )
        for historical_ds_menu_item in historical_ds_menu_items_with_same_name:
            mapped_ds_menu_item = historical_ds_menu_item.mappedToMenuItem
            mapped_ds_menu_item_name = mapped_ds_menu_item.get().name.lower()

            logging.info("Item historical mapped to {}".format(mapped_ds_menu_item_name))

            pos_menu_item_found = map_pos_menu_item_name.get(mapped_ds_menu_item_name)

            if not pos_menu_item_found and use_old_mapping_uuid:
                mapped_ds_menu_item_uuid = mapped_ds_menu_item.get().uuid
                pos_menu_item_found = map_pos_menu_item_uuid.get(mapped_ds_menu_item_uuid)

            if pos_menu_item_found:
                break

        if pos_menu_item_found:
            logging.info("Found pos item on step 2")
            ds_elements_mapped.extend(
                map_item_and_modifiers(
                    pos_menu_item_found,
                    ds_menu_item,
                    map_pos_menu_item_modifiers,
                    map_historical_modifier_name,
                    use_old_mapping_uuid,
                )
            )

    logging.info("Saving {} elements".format(len(ds_elements_mapped)))
    # To replace with a Put_multi that save to cache, the ndb one does NOT
    for _e in ds_elements_mapped: _e.put()
    # ndb.put_multi(ds_elements_mapped)

    startDeferredTask(
        refresh_stats, ds.menuSync, _transactional=ndb.in_transaction(), _countdown=10, _queue="autoMapQueue",
    )

    return ds_menu_items
