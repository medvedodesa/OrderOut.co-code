# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/19/2019
#

from ...model.MenuSection import MenuSection


def fetch_all_sections(menu_sync_key):
    _query = MenuSection.query()
    _query = _query.filter(MenuSection.menuSync == menu_sync_key)
    _query = _query.filter(MenuSection.enabled == True)
    _query = _query.order(MenuSection.position)
    _result = _query.fetch()
    return _result

def fetch_section(menu_sync_key, name, uuid=None, keys_only=False):
    _query = MenuSection.query()
    _query = _query.filter(MenuSection.menuSync == menu_sync_key)
    _query = _query.filter(MenuSection.name == name)
    if uuid: _query = _query.filter(MenuSection.uuid == uuid)
    _result = _query.get(keys_only=keys_only)
    return _result
