# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/25/2019
#

from ...model.MenuCategory import MenuCategory


def fetch_category(menu_sync_key, section_key, name, uuid=None, keys_only=False):
    _query = MenuCategory.query()
    _query = _query.filter(MenuCategory.menuSync == menu_sync_key)
    # _query = _query.filter(MenuCategory.section == section_key)
    _query = _query.filter(MenuCategory.name == name)
    if uuid: _query = _query.filter(MenuCategory.uuid == uuid)
    _result = _query.get(keys_only=keys_only)
    return _result
