# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 12/05/2019
#

from ...model.MenuItem import MenuItem

def fetch_first_by_uuid(menu_sync_key, uuid, category_key=None):
    if not uuid: return None
    _query = MenuItem.query()
    _query = _query.filter(MenuItem.menuSync == menu_sync_key)
    _query = _query.filter(MenuItem.uuid == uuid)
    if category_key: _query = _query.filter(MenuItem.categories == category_key)
    return _query.get()

def fetch_all_items(menu_sync_key, keys_only):
    _query = MenuItem.query()
    _query = _query.filter(MenuItem.menuSync == menu_sync_key)
    return _query.fetch(keys_only=keys_only)
