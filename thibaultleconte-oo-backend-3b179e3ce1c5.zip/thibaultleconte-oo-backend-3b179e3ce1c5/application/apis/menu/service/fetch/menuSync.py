# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/09/2020
#

from ...model.MenuSync import MenuSync
from application.apis.deliveryservice.service.common.fetch import get_delivery_service_for_account

def fetch_all_for_account(account_key, keys_only=True):
    if not account_key: return []
    _service_keys = get_delivery_service_for_account(account_key, keys_only=True)
    _query = MenuSync.query()
    _query = _query.filter(MenuSync.service.IN(_service_keys))
    _query = _query.order(-MenuSync.api_created_at)
    return _query.fetch(10, keys_only=keys_only)
