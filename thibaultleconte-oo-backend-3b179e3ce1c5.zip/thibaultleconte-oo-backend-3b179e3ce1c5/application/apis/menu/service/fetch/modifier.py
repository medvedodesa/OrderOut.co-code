# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 12/16/2019
#

from ...model.MenuItemModifier import MenuItemModifier


def fetch_first_by_uuid(menu_sync_key, uuid):
    if not uuid: return None
    _query = MenuItemModifier.query()
    _query = _query.filter(MenuItemModifier.menuSync == menu_sync_key)
    _query = _query.filter(MenuItemModifier.uuid == uuid)
    return _query.get()

# def fetch_all_modifier_groups_keys_for_menu_item(menu_item_key):
#     _query = MenuItemModifier.query()
#     _query = _query.filter(MenuModifierGroup.items == menu_item_key)
#     _result = _query.fetch(keys_only=True)
#     return _result
