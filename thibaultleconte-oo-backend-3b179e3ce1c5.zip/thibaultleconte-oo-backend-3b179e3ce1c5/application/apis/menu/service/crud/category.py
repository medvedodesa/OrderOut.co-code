# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/01/2019
#

from ...model.MenuCategory import MenuCategory
from application.core.exception import NotFound
from ..fetch.category import fetch_category
from .section import add_category, remove_category


def create_update_menu_category(menu_sync_key, section_key, name, uuid=None, enabled=True):
    _category = fetch_category(menu_sync_key, section_key, name, uuid)
    if not _category:
        _category = MenuCategory.create(menu_sync_key, section_key, name, uuid)

    _section = add_category(section_key=section_key, category_key=_category.key)
    _category = update_category(category_key=_category.key,
                                name=name,
                                uuid=uuid,
                                enabled=enabled)
    return _category

def update_category(category_key, name, uuid=None, enabled=True):
    _category = category_key.get()
    if not _category: return NotFound
    _category.name = name
    _category.enabled = enabled
    _category.put()
    return _category

def delete_category(category_key):
    _category = category_key.get()
    if not _category: return NotFound
    _section = remove_category(section_key=_category.section, category_key=category_key)
    _category.delete()
    return True

def add_category(section_key, category_key):
    _section = section_key.get()
    if category_key not in _section.categories: _section.categories.append(category_key)
    _section.put()
    return _section

def remove_category(section_key, category_key):
    _section = section_key.get()
    if category_key in _section.categories: _section.categories.remove(category_key)
    _section.put()
    return _section
