# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/01/2019
#

from ...model.MenuSection import MenuSection
from application.core.exception import NotFound
from ..availability import fetch_availability
from ..fetch.section import fetch_section
import json


def create_update_menu_section(
    menu_sync_key,
    name,
    availability=(),
    position=0,
    uuid=None,
    description=None,
    enabled=True,
):
    _section = fetch_section(menu_sync_key, name, uuid)
    # if not availability: _final_availability = fetch_availability(_section.name, availability)
    # _section.availability = json.dumps(_final_availability)
    if not _section:
        _section = MenuSection.create(menu_sync_key, name, uuid)
    _section = update_section(
        section_key=_section.key,
        name=name,
        availability=availability,
        position=position,
        uuid=uuid,
        description=description,
        enabled=enabled,
    )
    return _section


def update_section(
    section_key,
    name,
    availability=(),
    position=0,
    uuid=None,
    description=None,
    enabled=True,
):
    _section = section_key.get()
    if not _section:
        return NotFound
    _section.name = name
    _section.description = description
    _section.enabled = enabled
    _section.position = position
    if availability:
        _section.availability = availability
    else:
        _final_availability = fetch_availability(_section.name, availability)
        _section.availability = _final_availability
    _section.put()
    return _section


def add_category(section_key, category_key):
    _section = section_key.get()
    _section.categories.append(category_key)
    _section.put()
    return _section


def remove_category(section_key, category_key):
    _section = section_key.get()
    if category_key in _section.categories:
        _section.categories.remove(category_key)
    _section.put()
    return _section
