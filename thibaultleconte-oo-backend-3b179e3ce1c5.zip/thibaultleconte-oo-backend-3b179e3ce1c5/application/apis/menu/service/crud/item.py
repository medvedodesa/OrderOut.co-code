# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/01/2019
#

from ...model.MenuItem import MenuItem
from ..fetch.item import fetch_first_by_uuid
from application.core.exception import NotFound


def create_update_item(menu_sync_key,
                       category_key,
                       name,
                       uuid=None,
                       is_available=True,
                       price=0.0,
                       description=None,
                       currency=None,
                       is_alcohol=False,
                       disable_instructions=False,
                       image_url=None,
                       tax_rate=0.0,
                       vat_rate_percentage=0.0):
    _item = fetch_first_by_uuid(menu_sync_key=menu_sync_key, uuid=uuid, category_key=category_key)
    if not _item:
        _item = MenuItem.create(menu_sync_key=menu_sync_key, category_key=category_key, name=name, uuid=uuid)

    _item = update_item(item_key=_item.key,
                        name=name,
                        uuid=uuid,
                        is_available=is_available,
                        price=price,
                        description=description,
                        currency=currency,
                        is_alcohol=is_alcohol,
                        disable_instructions=disable_instructions,
                        image_url=image_url,
                        tax_rate=tax_rate,
                        vat_rate_percentage=vat_rate_percentage)
    return _item

def update_item(item_key,
                name,
                uuid=None,
                is_available=True,
                price=0.0,
                description=None,
                currency=None,
                is_alcohol=False,
                disable_instructions=False,
                image_url=None,
                tax_rate=0.0,
                vat_rate_percentage=0.0):
    _item = item_key.get()
    if not _item: return NotFound
    _item.name = name
    _item.is_available = is_available
    _item.price = price
    _item.description = description
    _item.currency = currency if currency else 'USD'
    _item.is_alcohol = is_alcohol
    _item.disable_instructions = disable_instructions
    _item.image_url = image_url
    _item.tax_rate = tax_rate
    _item.vat_rate_percentage = vat_rate_percentage
    _item.put()
    return _item

def delete_item(item_key):
    _item = item_key.get()
    if not _item: return NotFound
    _item.delete()
    return True
