# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 12/16/2019
#

from application.apis.menu.model.MenuItemModifier import MenuItemModifier
from ..fetch.modifier import fetch_first_by_uuid
from application.core.exception import NotFound


def create_update_modifier(menu_sync_key,
                           modifier_group_key,
                           name,
                           uuid=None,
                           is_available=True,
                           price=0.0):

    _modifier = fetch_first_by_uuid(menu_sync_key=menu_sync_key, uuid=uuid)
    if not _modifier:
        _modifier = MenuItemModifier.create(menu_sync_key=menu_sync_key, modifier_group_key=modifier_group_key, name=name, uuid=uuid)

    _modifier = add_modifier_to_group(modifier_group_key=modifier_group_key, modifier_key=_modifier.key)
    _modifier = update_modifier(modifier_key=_modifier.key,
                                name=name,
                                uuid=uuid,
                                is_available=is_available,
                                price=price)
    return _modifier

def update_modifier(modifier_key,
                    name,
                    uuid=None,
                    is_available=True,
                    price=0.0):
    _modifier = modifier_key.get()
    if not _modifier: return NotFound
    _modifier.name = name
    _modifier.is_available = is_available
    _modifier.price = price
    _modifier.put()
    return _modifier

def delete_modifier(modifier_key):
    _modifier = modifier_key.get()
    if not _modifier: return NotFound
    remove_modifier_from_group(modifier_key)
    _modifier.delete()
    return True

def add_modifier_to_group(modifier_group_key, modifier_key):
    _group = modifier_group_key.get()
    if modifier_key not in _group.modifiers:
        _group.modifiers.append(modifier_key)
        _group.put()
    _modifier = modifier_key.get()
    # _modifier.group = _group.key
    if modifier_group_key not in _modifier.groups: _modifier.groups.append(modifier_group_key)
    _modifier.put()
    return _modifier

def remove_modifier_from_group(modifier_key):
    _modifier = modifier_key.get()

    # _group = _modifier.group.get()
    # if modifier_key in _group.modifiers:
    #     _group.modifiers.remove(modifier_key)
    #     _group.put()

    for _group_key in _modifier.groups:
        _group = _group_key.get()
        if modifier_key in _group.modifiers:
            _group.modifiers.remove(modifier_key)
            _group.put()

        if _group_key in _modifier.groups:
            _modifier.groups.remove(_group_key)
            _modifier.put()

    return _modifier
