# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/01/2019
#

from application.apis.menu.model.MenuModifierGroup import MenuModifierGroup
from ..fetch.modifierGroup import fetch_first_by_uuid
from application.core.exception import NotFound


def create_update_modifier_group(menu_sync_key,
                                 item_key,
                                 name,
                                 uuid=None,
                                 is_available=True,
                                 min_permitted=0,
                                 max_permitted=1):

    _modifier_group = fetch_first_by_uuid(menu_sync_key=menu_sync_key, uuid=uuid)
    if not _modifier_group:
        _modifier_group = MenuModifierGroup.create(menu_sync_key=menu_sync_key, item_key=item_key, name=name, uuid=uuid)

    _item = add_modifier_group(item_key=item_key, modifier_group_key=_modifier_group.key)
    _item = update_modifier_group(modifier_group_key=_modifier_group.key,
                                  name=name,
                                  uuid=uuid,
                                  is_available=is_available,
                                  min_permitted=min_permitted,
                                  max_permitted=max_permitted)
    return _item

def update_modifier_group(modifier_group_key,
                          name,
                          uuid=None,
                          is_available=True,
                          min_permitted=0,
                          max_permitted=1):
    _modifier_group = modifier_group_key.get()
    if not _modifier_group: return NotFound
    _modifier_group.name = name
    _modifier_group.is_available = is_available
    _modifier_group.min_permitted = min_permitted
    _modifier_group.max_permitted = max_permitted
    _modifier_group.put()
    return _modifier_group

def delete_modifier_group(modifier_group_key):
    _modifier_group = modifier_group_key.get()
    if not _modifier_group: return NotFound
    remove_modifier_group(modifier_group_key)
    _modifier_group.delete()
    return True

def add_modifier_group(item_key, modifier_group_key):
    _item = item_key.get()
    if modifier_group_key not in _item.modifier_groups: _item.modifier_groups.append(modifier_group_key)
    _item.put()
    _modifier_group = modifier_group_key.get()
    if item_key not in _modifier_group.items: _modifier_group.items.append(item_key)
    _modifier_group.put()
    return _item

def remove_modifier_group(modifier_group_key):
    _modifier_group = modifier_group_key.get()

    for item_key in _modifier_group.items:
        _item = item_key.get()
        if modifier_group_key in _item.modifier_groups:
            _item.modifier_groups.remove(modifier_group_key)
            _item.put()

        if item_key in _modifier_group.items:
            _modifier_group.items.remove(item_key)
            _modifier_group.put()

    return _item
