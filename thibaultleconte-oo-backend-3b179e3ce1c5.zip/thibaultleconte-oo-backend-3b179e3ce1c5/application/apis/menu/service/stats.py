# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/09/2019
#

from ..model.MenuItem import MenuItem
from ..model.MenuItemModifier import MenuItemModifier
from application.apis.deliveryservice.service.common.menuitemstats import update_menu_sync_menu_stats

def refresh_stats(menu_sync_key, all_menu_items=None, all_menu_modifiers=None):
    _unmapped_menu_items = []
    _mapped_menu_items = []
    _mapped_menu_modifiers = []
    _unmapped_menu_modifiers = []

    if not all_menu_items:
        _query_item = MenuItem.query()
        _query_item = _query_item.filter(MenuItem.menuSync == menu_sync_key)
        all_menu_items = _query_item.fetch()
    for _mi in all_menu_items:
        if _mi.mappedToMenuItem:
            _mapped_menu_items.append(_mi)
        else:
            _unmapped_menu_items.append(_mi)

    if not all_menu_modifiers:
        _query_modifier = MenuItemModifier.query()
        _query_modifier = _query_modifier.filter(MenuItemModifier.menuSync == menu_sync_key)
        all_menu_modifiers = _query_modifier.fetch()
    for _mod in all_menu_modifiers:
        if _mod.mappedToMenuItemModifier:
            _mapped_menu_modifiers.append(_mod)
        else:
            _unmapped_menu_modifiers.append(_mod)

    status = update_menu_sync_menu_stats(menu_sync_key=menu_sync_key,
                                         total_items=len(all_menu_items),
                                         mapped_items=len(_mapped_menu_items),
                                         unmapped_items=len(_unmapped_menu_items),
                                         total_modifiers=len(all_menu_modifiers),
                                         mapped_modifiers=len(_mapped_menu_modifiers),
                                         unmapped_modifiers=len(_unmapped_menu_modifiers))

    return status
