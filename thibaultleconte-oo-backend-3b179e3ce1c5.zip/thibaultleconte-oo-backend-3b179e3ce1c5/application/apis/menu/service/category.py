# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# chirag@orderout.co
#
# 04/16/2020
#

from application.apis.menu.model.MenuCategory import MenuCategory


###############
# Menu Category
###############

def fetch_all_menu_categories_for_menu_sync(menu_sync_key):
    _query = MenuCategory.query()
    _query = _query.filter(MenuCategory.menuSync == menu_sync_key)
    _menu_categories = _query.fetch()
    return _menu_categories