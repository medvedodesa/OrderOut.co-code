# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/01/2019
#

def fetch_availability(section_name, raw_availability):
    availability = []
    _days_of_week = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
    for day_of_week in _days_of_week:
        _day_availability = __find_day_availability(raw_availability, day_of_week)

        if not _day_availability: _day_availability = __create_default_availability_for_day(section_name, day_of_week)
        # _day_availability = __create_default_availability_for_day(section_name, day_of_week)

        availability.append(_day_availability)
    return availability

def __find_day_availability(availability_array, day_of_week):
    for day_availability in availability_array:
        _day_of_week = day_availability.get('day_of_week')
        if _day_of_week:
            if _day_of_week.lower() == day_of_week:
                return day_availability
    return None

def __create_default_availability_for_day(section_name, day_of_week):
    _time_period = {'start_time': '00:01', 'end_time': '23:59'}

    # _time_period = {'start_time': '11:30'}
    # if 'alcohol' in section_name.lower():
    #     _time_period['end_time'] = '21:30'
    # else:
    #     _time_period['end_time'] = '22:00'
    # if day_of_week in ['friday', 'saturday']:
    #     _time_period = {'start_time': '11:30'}
    #     if 'alcohol' in section_name.lower():
    #         _time_period['end_time'] = '22:30'
    #     else:
    #         _time_period['end_time'] = '23:00'

    _day_availability = {'day_of_week': day_of_week.lower(),
                         'enabled': True,
                         'time_periods': [_time_period]}
    return _day_availability
