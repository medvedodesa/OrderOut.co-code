# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/23/2019
#

from ..model.MenuItem import MenuItem
from ..model.MenuCategory import MenuCategory
from ..model.MenuModifierGroup import MenuModifierGroup
from ..model.MenuItemModifier import MenuItemModifier
from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from .stats import refresh_stats
from application.apis.menu.service.menusync.process import manage_menu_task
from application.core.parser.string import sanitize_str
from application.core.parser.price import sanitize_price
from google.appengine.ext import ndb
from application.core.task.service import startDeferredTask
from .crud.item import create_update_item
from .crud.modifierGroup import create_update_modifier_group


##############################################
# Create or update Menu Item and its Modifiers
##############################################

def startTaskToCreateOrUpdateMenuItemsAndModifiers(menu_sync, menu_item_dict):
    _raw_name = menu_item_dict.get('name')
    if not _raw_name or len(_raw_name) == 0: return None
    _task = addTask(category=CoreTaskCategory.CORE_MENU_ITEM, entity=menu_sync, data_dict=menu_item_dict)
    return _task

def processTaskToCreateOrUpdateMenuItemsAndModifiers(menu_sync_key, menu_item_dict, task_key):
    _task_result_json = {}

    _ms = menu_sync_key.get()
    _task_result_json['menu_sync'] = _ms.key.id()

    # Menu Item
    _mi = __saveMenuItem(menu_sync_key=_ms.key, menu_item_dict=menu_item_dict)
    _task_result_json['menu_item'] = _mi.key.id()

    # Modifier Groups
    # _mi = __saveModifierGroups(menu_item=_mi, menu_item_dict=menu_item_dict)
    # Transaction Sync to not have duplicate element with uuid
    startDeferredTask(__saveModifierGroups_transaction, _mi, menu_item_dict, _transactional=ndb.in_transaction())

    # Refresh stats
    refresh_stats(menu_sync_key=_ms.key)

    # Manage Menu Sync tasks
    manage_menu_task(menu_sync_key=_ms.key)

    return _task_result_json

def __saveModifierGroups_transaction(menu_item, menu_item_dict):
    _mi = __saveModifierGroups(menu_item=menu_item, menu_item_dict=menu_item_dict)
    return

def __saveMenuItem(menu_sync_key, menu_item_dict):

    _id = menu_item_dict.get('id')
    _uuid = sanitize_str(menu_item_dict.get('uuid'))
    _name = sanitize_str(menu_item_dict.get('name'))
    _is_available = bool(menu_item_dict.get('is_available'))
    _price = sanitize_price(menu_item_dict.get('price'))
    _description = sanitize_str(menu_item_dict.get('description'))
    _currency = sanitize_str(menu_item_dict.get('currency'))
    _is_alcohol = bool(menu_item_dict.get('is_alcohol'))
    _position = int(menu_item_dict.get('position', 0))
    _disable_instructions = bool(menu_item_dict.get('disable_instructions'))
    _image_url = sanitize_str(menu_item_dict.get('image_url'))
    _tax_rate = sanitize_price(menu_item_dict.get('tax_rate'))
    _vat_rate_percentage = sanitize_price(menu_item_dict.get('vat_rate_percentage'))

    _category_id = menu_item_dict.get('category_id')
    _category_key = MenuCategory.get_key(_category_id)

    _mi = create_update_item(menu_sync_key=menu_sync_key,
                             category_key=_category_key,
                             name=_name,
                             uuid=_uuid,
                             is_available=_is_available,
                             price=_price,
                             description=_description,
                             currency=_currency,
                             is_alcohol=_is_alcohol,
                             disable_instructions=_disable_instructions,
                             image_url=_image_url,
                             tax_rate=_tax_rate,
                             vat_rate_percentage=_vat_rate_percentage)

    return _mi

def __saveModifierGroups(menu_item, menu_item_dict):
    _modifier_groups = []

    # Prepare Menu Item and clear its modifiers references
    menu_item.modifier_groups = _modifier_groups

    for _raw_mod_group in menu_item_dict['modifier_groups']:
        _name = sanitize_str(_raw_mod_group.get('name'))
        if _name or len(_name) > 0:

            _uuid = sanitize_str(_raw_mod_group.get('uuid'))
            _raw_min_permitted = _raw_mod_group.get('min_permitted') if _raw_mod_group.get('min_permitted') else 0
            _min_permitted = int(_raw_min_permitted)
            _raw_max_permitted = _raw_mod_group.get('max_permitted') if _raw_mod_group.get('max_permitted') else 1
            _max_permitted = int(_raw_max_permitted)

            _mod_group = create_update_modifier_group(menu_sync_key=menu_item.menuSync,
                                                      item_key=menu_item.key,
                                                      name=_name,
                                                      uuid=_uuid,
                                                      min_permitted=_min_permitted,
                                                      max_permitted=_max_permitted)

            _modifier_groups.append(_mod_group)
            __saveModifiers(menu_item=menu_item, menu_modifier_group=_mod_group, menu_modifier_group_dict=_raw_mod_group)

    # Save modifier groups in Menu Item
    for _mg in _modifier_groups:
        if _mg.key not in menu_item.modifier_groups:
            menu_item.modifier_groups.append(_mg.key)
    menu_item.put()

    return menu_item

def __saveModifiers(menu_item, menu_modifier_group, menu_modifier_group_dict):
    _modifiers = []

    # Prepare Menu Item and clear its modifiers references
    menu_modifier_group.modifiers = _modifiers

    for _raw_mod in menu_modifier_group_dict['modifiers']:

        _raw_name = sanitize_str(_raw_mod.get('name'))
        if _raw_name or len(_name) > 0:
            _id = _raw_mod.get('id')
            _uuid = sanitize_str(_raw_mod.get('uuid'))
            _name = sanitize_str(_raw_name)
            _is_available = bool(_raw_mod.get('is_available'))
            _price = sanitize_price(_raw_mod.get('price'))
            _group_name = sanitize_str(_raw_mod.get('group_name'))
            _raw_min_permitted = _raw_mod.get('min_permitted') if _raw_mod.get('min_permitted') else 0
            _min_permitted = int(_raw_min_permitted)
            _raw_max_permitted = _raw_mod.get('max_permitted') if _raw_mod.get('max_permitted') else 1
            _max_permitted = int(_raw_max_permitted)
            # _position = int(_raw_mod.get('position', 0))

            _mod = MenuItemModifier.fetch_by_uuid_or_name(menu_sync_key=menu_item.menuSync, uuid=_uuid)
            if not _mod: _mod = MenuItemModifier(menuSync=menu_item.menuSync, uuid=_uuid)
            _mod.item = menu_item.key
            _mod.group = menu_modifier_group.key
            if menu_modifier_group.key not in _mod.groups: _mod.groups.append(menu_modifier_group.key)
            _mod.name = _name
            _mod.is_available = _is_available
            _mod.price = _price
            _modifiers.append(_mod)

    ndb.put_multi(_modifiers)

    # Save modifiers in Menu Item
    for _mod in _modifiers:
        if _mod.key not in menu_modifier_group.modifiers:
            menu_modifier_group.modifiers.append(_mod.key)
    menu_modifier_group.put()

    return menu_modifier_group

###################
# DICTIONARY HELPER
###################

def generate_modifier_dict(name, price, id=None, uuid=None, is_available=True, position=0):
    _mod = {'id': id,
            'uuid': sanitize_str(uuid, lower_case=False),
            'name': sanitize_str(name),
            'price': sanitize_price(price),
            'position': position,
            'is_available': is_available}
    return _mod

def generate_modifier_group_dict(name, modifiers, uuid=None, min_permitted=0, max_permitted=0, position=0):
    _group = {'name': sanitize_str(name),
              'modifiers': modifiers,
              'uuid': sanitize_str(uuid, lower_case=False),
              'min_permitted': min_permitted,
              'max_permitted': max_permitted,
              'position': position}
    return _group

def generate_item_dict(name, price, modifier_groups, id=None, uuid=None, is_available=True, category_id=None,
                       description=None, currency=None, is_alcohol=False, position=0, tax_rate=0, vat_rate_percentage=0,
                       disable_instructions=False, image_url=None):
    _mi = {'id': id,
           'uuid': sanitize_str(uuid, lower_case=False),
           'name': sanitize_str(name),
           'price': sanitize_price(price),
           'modifier_groups': modifier_groups,
           'is_available': is_available,
           'category_id': category_id,
           'description': sanitize_str(description),
           'currency': sanitize_str(currency),
           'is_alcohol': is_alcohol,
           'position': position,
           'tax_rate': tax_rate,
           'vat_rate_percentage': vat_rate_percentage,
           'disable_instructions': disable_instructions,
           'image_url': sanitize_str(image_url)}
    return _mi
