# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/09/2019
#

from ..model.MenuItem import MenuItem
from ..model.MenuItemModifier import MenuItemModifier
from google.appengine.ext import ndb
from application.core.error import report_error
from application.apis.menu.service.fetch.menuSync import fetch_all_for_account
from application.apis.menu.service.fetch.item import fetch_all_items


##################
# DELIVERY SERVICE
##################

def fetch_all_delivery_service_menu_items_for_account(account_key):
    _menuSync_keys = fetch_all_for_account(account_key)
    _menu_items = []
    for _ms_key in _menuSync_keys:
        _items = fetch_all_items(menu_sync_key=_ms_key, keys_only=False)
        for _mi in _items:
            if _mi.mappedToMenuItem:
                _menu_items.append(_mi)
    return _menu_items

###############
# Menu Category
###############

def fetch_all_menu_items_keys_for_category(category_key):
    _query = MenuItem.query()
    _query = _query.filter(MenuItem.categories == category_key)
    _result = _query.fetch(keys_only=True)
    return _result
