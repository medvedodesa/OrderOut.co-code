# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/09/2019
#

from flask import current_app
from ...model.MenuSync import MenuSync, MenuSyncStatus
from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from application.apis.deliveryservice.model.DeliveryService import DeliveryService, DeliveryServiceType
from application.core.email.service import send_admin_email
from application.core.settings.app import get_config_for_key


def process_menu_task_started(menuSync_key, tasks_keys):
    _ms = menuSync_key.get()
    _ms.process_menu_status = MenuSyncStatus.RUNNING
    _ms.put()
    return _ms

def manage_menu_task(menu_sync_key):
    _ms = menu_sync_key.get()
    if not _ms.task_processing_done:
        process_menu_task_finished(menuSync_key=_ms.key, success=True)
    return

def process_menu_task_finished(menuSync_key, success):
    _ms = menuSync_key.get()
    if success:
        _ms.process_menu_status = MenuSyncStatus.SUCCESS
        _task = addTask(category=CoreTaskCategory.CORE_MENU_PROCESS_DONE, entity=_ms)
        _ms.task_processing_done = _task.key
    else:
        _ms.process_menu_status = MenuSyncStatus.ERROR
    _ms.put()
    return _ms

def processTaskAfterMenuHasBeenProcessed(menuSync_id):
    _ms = MenuSync.get_by_id(menuSync_id)
    if _ms.service:
        _ds = _ms.service.get()
        # if isinstance(_ds, DeliveryService):
        #     notify_with_email_menu_processed_successfully(_ms.key)
    return

def notify_with_email_menu_processed_successfully(menuSync_key):
    _ms = menuSync_key.get()
    if _ms.service:
        _ds = _ms.service.get()
        _account = _ds.account.get()
        _restaurant = _ds.restaurant.get()
        _recipients = get_config_for_key('EMAIL_TO_ADMINS')
        _subject = 'Menu Synced for {account} {restaurant} on {deliveryservice}'.format(account=_account.name.upper(),
                                                                                        restaurant=_restaurant.name.upper(),
                                                                                        deliveryservice=_ds.type)
        _message = '''Menu has been synced with {nb_menu_items} menu items'''.format(nb_menu_items=str(object=_ms.map_total_menu_items))
        send_admin_email(_recipients, _subject, _message)
    return
