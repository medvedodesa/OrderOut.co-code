# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/09/2019
#

from ...model.MenuSync import MenuSync

def create_menu_sync(restaurant_key, service_key, name=None, description=None, author=None):
    _menu_sync = MenuSync(restaurant=restaurant_key, service=service_key)
    _menu_sync.name = name
    _menu_sync.description = description
    _menu_sync.author = author
    _menu_sync.put()
    return _menu_sync

def get_menu_sync_key_by_fetch_external_id(fetch_external_id):
    _query = MenuSync.query()
    _query = _query.filter(MenuSync.fetch_external_id == fetch_external_id)
    _result = _query.fetch(1, keys_only=True)
    if len(_result) > 0:
        return _result[0]
    return None
