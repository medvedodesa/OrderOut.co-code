# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/10/2019
#

from application.core.task.model import CoreTask

def get_all_tasks(menuSync_key):
    _query = CoreTask.query()
    _query = _query.filter(CoreTask.entity == menuSync_key)
    _query = _query.order(CoreTask.api_created_at)
    _objects = _query.fetch()
    return _objects
