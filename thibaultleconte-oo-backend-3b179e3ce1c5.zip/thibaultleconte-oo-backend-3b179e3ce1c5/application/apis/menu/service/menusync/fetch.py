# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/09/2019
#

from ...model.MenuSync import MenuSyncStatus

def fetch_menu_task_started(menuSync_key, task_key):
    _menuSync = menuSync_key.get()
    _menuSync.fetch_menu_status = MenuSyncStatus.RUNNING
    _menuSync.put()
    return _menuSync

def fetch_menu_task_finished(menuSync_key, success):
    _menuSync = menuSync_key.get()
    _menuSync.fetch_menu_status = MenuSyncStatus.SUCCESS if success else MenuSyncStatus.ERROR
    _menuSync.put()
    return _menuSync
