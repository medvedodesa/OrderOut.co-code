# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/09/2019
#
import logging

from flask import request
from flask_restplus import Resource, Namespace
from google.appengine.ext import deferred, ndb

from application.apis.pointofsale.model.PointOfSale import PointOfSale
from application.apis.deliveryservice.model.DeliveryService import DeliveryService
from application.apis.menu.model.MenuSync import MenuSync
from application.apis.menu.model.MenuCategory import MenuCategory
from application.apis.menu.model.MenuItem import MenuItem
from application.apis.menu.model.MenuItemModifier import MenuItemModifier
from application.apis.ooexceptions import NotFound
from application.core.authentication.service import requires_auth_token
from ..service.modifier import fetch_all_modifiers_for_menu_item, fetch_all_delivery_service_menu_item_modifiers_for_account
from ..service.mapping.automap import auto_map_delivery_service_menu_to_point_of_sale_menu_v2
from ..service.mapping.reset import (
    reset_mapping_for_menu_item,
    reset_mapping_for_menu_item_modifier,
)
from ..service.stats import refresh_stats
from ..service.crud.item import create_update_item, update_item, delete_item
from application.core.exception import errorHandler
from flask_restplus import marshal
from application.core.parser.string import sanitize_str
from application.core.parser.price import sanitize_price
from application.core.task.service import startDeferredTask


nsApi = Namespace("menuitem", description="Menu Item related operations.")

item_marshal = nsApi.model("MenuItem", MenuItem.schema())
mi_mod_marshal = nsApi.model("MenuItemModifier", MenuItemModifier.schema())


######
# CRUD
######

@nsApi.route("menu/item/")
class MenuItemPost(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc("Create an Item")
    @nsApi.response(200, "OK", item_marshal)
    @nsApi.response(409, "Conflict with other ressource")
    @nsApi.response(400, "Bad Request")
    @nsApi.expect(item_marshal, validate=True)
    @nsApi.marshal_with(item_marshal)
    @errorHandler
    def post(self):
        _json_dict = request.get_json()
        _category_id = _json_dict.get("category_id")
        _category_key = MenuCategory.get_key(_category_id)
        _name = _json_dict.get("name")
        _menu_sync_id = _json_dict.get("menu_sync_id")
        _menu_sync_key = MenuSync.get_key(_menu_sync_id)
        _item = create_update_item(
            menu_sync_key=_menu_sync_key, category_key=_category_key, name=_name
        )
        return _item


@nsApi.route("menu/item/<int:item_id>")
@nsApi.param("item_id", "Item identifier")
class MenuItemGetPutDelete(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc("Get Item")
    @nsApi.response(200, "OK", item_marshal)
    @nsApi.response(409, "Conflict with other ressource")
    @nsApi.response(404, "Not found")
    @errorHandler
    def get(self, item_id):
        _expanded = request.args.get("expanded")
        _item = MenuItem.get_by_id(item_id)
        if not _item: raise NotFound
        return marshal(_item, MenuItem.schema(expanded=_expanded))

    @nsApi.doc("Put Item")
    @nsApi.response(200, "OK", item_marshal)
    @nsApi.response(404, "Not found")
    @nsApi.response(400, "Bad Request")
    @nsApi.expect(item_marshal, validate=True)
    def put(self, item_id):
        json_dict = request.get_json()
        _expanded = json_dict.get("expanded")
        _item = MenuItem.get_by_id(item_id)
        if not _item:
            raise NotFound
        _name = sanitize_str(json_dict.get("name"))
        _uuid = sanitize_str(json_dict.get("uuid"))
        _is_available = bool(json_dict.get("is_available"))
        _price = sanitize_price(json_dict.get("price"))
        _description = sanitize_str(json_dict.get("description"))
        _currency = sanitize_str(json_dict.get("currency"))
        _is_alcohol = bool(json_dict.get("is_alcohol"))
        _disable_instructions = bool(json_dict.get("disable_instructions"))
        _image_url = sanitize_str(json_dict.get("image_url"))
        _tax_rate = sanitize_price(json_dict.get("tax_rate"))
        _vat_rate_percentage = sanitize_price(json_dict.get("vat_rate_percentage"))
        _item = update_item(
            item_key=_item.key,
            name=_name,
            uuid=_uuid,
            is_available=_is_available,
            price=_price,
            description=_description,
            currency=_currency,
            is_alcohol=_is_alcohol,
            disable_instructions=_disable_instructions,
            image_url=_image_url,
            tax_rate=_tax_rate,
            vat_rate_percentage=_vat_rate_percentage,
        )
        return marshal(_item, MenuItem.schema(expanded=_expanded))

    @nsApi.doc("Delete Item")
    @nsApi.response(200, "OK")
    @nsApi.response(404, "Not found")
    @nsApi.response(400, "Bad Request")
    # @errorHandler
    def delete(self, item_id):
        _item = MenuItem.get_by_id(item_id)
        if not _item:
            raise NotFound
        success = delete_item(item_key=_item.key)
        return {}


#######
# LOGIC
#######


@nsApi.route("menu/item/<int:menu_item_id>/modifiers")
@nsApi.param("menu_item_id", "Menu Item identifier")
class MenuGetMenuItemModifiers(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc("List the Modifiers for a Menu Item")
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    @nsApi.marshal_list_with(mi_mod_marshal)
    def get(self, menu_item_id):
        _mi_key = MenuItem.get_key(menu_item_id)
        if not _mi_key:
            raise NotFound
        _data = fetch_all_modifiers_for_menu_item(menu_item_key=_mi_key)
        return _data


@nsApi.route("menu/automap/ds/<int:delivery_service_id>/pos/<int:point_of_sale_id>")
@nsApi.param("delivery_service_id", "Delivery Service identifier")
@nsApi.param("point_of_sale_id", "Point Of Sale identifier")
class MenuAutoMapGetByDeliveryServicev2(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc(
        "Automatically map Delivery Service Menu Items to Point Of Sale Menu Items"
    )
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    # @errorHandler
    @nsApi.marshal_list_with(item_marshal)
    def get(self, delivery_service_id, point_of_sale_id):
        _pos_key = PointOfSale.get_key(point_of_sale_id)
        if not _pos_key: raise NotFound
        _ds = DeliveryService.get_by_id(delivery_service_id)
        if not _ds: raise NotFound

        # use_old_mapping_uuid = str(request.args.get("use_old_mapping_uuid")) == "1"
        use_old_mapping_uuid = True

        logging.info("Starting menu automaping: use old mapping uuid? {}".format(use_old_mapping_uuid))

        startDeferredTask(
            auto_map_delivery_service_menu_to_point_of_sale_menu_v2, _pos_key, _ds, use_old_mapping_uuid,
            _queue="autoMapQueue",
        )
        return []


@nsApi.route("menu/map/item/ds/<int:ds_menu_item_id>/pos/<int:pos_menu_item_id>")
@nsApi.param("ds_menu_item_id", "Point Of Sale Menu Item identifier")
@nsApi.param("pos_menu_item_id", "Delivery Service Menu Item identifier")
class MenuPutMapDeliveryServiceMenuItemToPointOsSaleMenuItem(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc(
        "Map a specific Delivery Service Menu Item to a specific Point Of Sale Menu Items"
    )
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    @nsApi.marshal_with(item_marshal)
    def put(self, ds_menu_item_id, pos_menu_item_id):
        _ds_menu_item = MenuItem.get_by_id(ds_menu_item_id)
        if not _ds_menu_item:
            raise NotFound
        _pos_menu_item = MenuItem.get_by_id(pos_menu_item_id)
        if not _pos_menu_item:
            raise NotFound
        _ds_menu_item.mappedToMenuItem = _pos_menu_item.key
        _ds_menu_item.put()
        refresh_stats(_ds_menu_item.menuSync)
        return _ds_menu_item


@nsApi.route("menu/map/modifier/ds/<int:ds_modifier_id>/pos/<int:pos_modifier_id>")
@nsApi.param("ds_menu_item_id", "Point Of Sale Menu Item identifier")
@nsApi.param("pos_menu_item_id", "Delivery Service Menu Item identifier")
class MenuPutMapDeliveryServiceMenuItemToPointOsSaleMenuItem(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc(
        "Map a specific Delivery Service Menu Item Modifier to a specific Point Of Sale Menu Item Modifier"
    )
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    @nsApi.marshal_with(mi_mod_marshal)
    def put(self, ds_modifier_id, pos_modifier_id):
        _ds_mod = MenuItemModifier.get_by_id(ds_modifier_id)
        if not _ds_mod:
            raise NotFound
        _pos_mod = MenuItemModifier.get_by_id(pos_modifier_id)
        if not _pos_mod:
            raise NotFound
        _ds_mod.mappedToMenuItemModifier = _pos_mod.key
        _ds_mod.put()
        refresh_stats(_ds_mod.menuSync)
        return _ds_mod


@nsApi.route("menu/item/<int:ds_menu_item_id>/reset")
@nsApi.param("ds_menu_item_id", "Delivery Service Menu Item identifier")
class MenuPutResetDeliveryServiceMenuItem(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc("Reset a specific Delivery Service Menu Item")
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    @nsApi.marshal_with(item_marshal)
    def put(self, ds_menu_item_id):
        _mi = MenuItem.get_by_id(ds_menu_item_id)
        if not _mi:
            raise NotFound
        _mi = reset_mapping_for_menu_item(_mi)
        refresh_stats(_mi.menuSync)
        return _mi


@nsApi.route("menu/modifier/<int:ds_menu_item_modifier_id>/reset")
@nsApi.param(
    "ds_menu_item_modifier_id", "Delivery Service Menu Item Modifier identifier"
)
class MenuPutResetDeliveryServiceMenuItemModifier(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc("Reset a specific Delivery Service Menu Item Modifier")
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    @nsApi.marshal_with(mi_mod_marshal)
    def put(self, ds_menu_item_modifier_id):
        _mod = MenuItemModifier.get_by_id(ds_menu_item_modifier_id)
        if not _mod:
            raise NotFound
        _mod = reset_mapping_for_menu_item_modifier(_mod)
        refresh_stats(_mod.menuSync)
        return _mod
