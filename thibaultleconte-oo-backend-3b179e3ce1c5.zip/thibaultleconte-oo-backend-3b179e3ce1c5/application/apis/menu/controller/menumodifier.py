# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 12/16/2019
#

from flask import request
from flask_restplus import Resource, Namespace
from application.apis.menu.model.MenuSync import MenuSync
from application.apis.menu.model.MenuModifierGroup import MenuModifierGroup
from application.apis.menu.model.MenuItemModifier import MenuItemModifier
from application.apis.ooexceptions import NotFound
from application.core.authentication.service import requires_auth_token
from ..service.crud.modifier import create_update_modifier, update_modifier, delete_modifier
from application.core.exception import errorHandler
from flask_restplus import marshal
from application.core.parser.string import sanitize_str


nsApi = Namespace('menumodifier', description='Menu Medifier related operations.')

modifier_marshal = nsApi.model('MenuItemModifier', MenuItemModifier.schema())


######
# CRUD
######

@nsApi.route('/')
class MenuModifierPost(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Create a Modifier')
    @nsApi.response(200, 'OK', modifier_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(400, 'Bad Request')
    @nsApi.expect(modifier_marshal, validate=True)
    @nsApi.marshal_with(modifier_marshal)
    @errorHandler
    def post(self):
        _json_dict = request.get_json()
        _menu_sync_id = _json_dict.get('menu_sync_id')
        _menu_sync_key = MenuSync.get_key(_menu_sync_id)
        _modifier_group_id = _json_dict.get('modifier_group_id')
        _modifier_group_key = MenuModifierGroup.get_key(_modifier_group_id)
        _name = _json_dict.get('name')
        _uuid = _json_dict.get('uuid')
        _item = create_update_modifier(menu_sync_key=_menu_sync_key, modifier_group_key=_modifier_group_key, name=_name, uuid=_uuid)
        return _item

@nsApi.route('/<int:modifier_id>')
@nsApi.param('modifier_id', 'Modifier identifier')
class MenuModifierGetPutDelete(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get Modifier')
    @nsApi.response(200, 'OK', modifier_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(404, 'Not found')
    @errorHandler
    def get(self, modifier_id):
        _modifier = MenuItemModifier.get_by_id(modifier_id)
        if not _modifier: raise NotFound
        return marshal(_modifier, MenuItemModifier.schema())

    @nsApi.doc('Put Modifier Group')
    @nsApi.response(200, 'OK', modifier_marshal)
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    @nsApi.expect(modifier_marshal, validate=True)
    @errorHandler
    def put(self, modifier_id):
        json_dict = request.get_json()
        _modifier = MenuItemModifier.get_by_id(modifier_id)
        if not _modifier: raise NotFound
        _name = sanitize_str(json_dict.get('name'))
        _uuid = sanitize_str(json_dict.get('uuid'))
        _is_available = bool(json_dict.get('is_available'))
        _price = float(json_dict.get('price'))
        _modifier = update_modifier(modifier_key=_modifier.key,
                                    name=_name,
                                    uuid=_uuid,
                                    is_available=_is_available,
                                    price=_price)
        return marshal(_modifier, MenuItemModifier.schema())

    @nsApi.doc('Delete Modifier')
    @nsApi.response(200, 'OK')
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    @errorHandler
    def delete(self, modifier_id):
        _modifier = MenuItemModifier.get_by_id(modifier_id)
        if not _modifier: raise NotFound
        success = delete_modifier(_modifier.key)
        return {}
