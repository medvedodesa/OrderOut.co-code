# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 10/09/2019
#

from flask import request
from flask_restplus import Resource, Namespace
from application.apis.menu.model.MenuSync import MenuSync
from application.apis.menu.model.MenuSection import MenuSection
from application.apis.menu.serializers.menu_section_serializers import MenuSectionSchema
from application.apis.ooexceptions import NotFound
from application.core.authentication.service import requires_auth_token
from ..service.fetch.section import fetch_all_sections
from ..service.crud.section import create_update_menu_section, update_section
from flask_restplus import marshal
from application.core.exception import errorHandler, BadRequest

nsApi = Namespace('menusync', description='MenuSync related operations.')

section_marshal = nsApi.model('Section', MenuSection.schema())

##########
# Sections
##########

@nsApi.route('menu/ms/<int:menu_sync_id>/sections')
@nsApi.param('menu_sync_id', 'Menu Sync identifier')
class MenuSyncGetSections(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('List Sections for a Menu Sync')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    def get(self, menu_sync_id):
        _expanded = request.args.get('expanded', default=False, type=bool)
        _menu_sync_key = MenuSync.get_key(menu_sync_id)
        _sections = fetch_all_sections(menu_sync_key=_menu_sync_key)
        return marshal(_sections, MenuSection.schema(expanded=_expanded))

######
# CRUD
######

@nsApi.route('menu/section/')
class MenuSectionPost(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Create a Section')
    @nsApi.response(200, 'OK', section_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(400, 'Bad Request')
    @nsApi.expect(section_marshal, validate=True)
    @nsApi.marshal_with(section_marshal)
    @errorHandler
    def post(self):
        _json_dict = request.get_json()
        _menu_sync_id = _json_dict.get('menu_sync_id')
        _name = _json_dict.get('name')
        _menu_sync_key = MenuSync.get_key(_menu_sync_id)
        _section = create_update_menu_section(menu_sync_key=_menu_sync_key, name=_name)
        return _section

@nsApi.route('menu/section/<int:section_id>')
@nsApi.param('section_id', 'Section identifier')
class MenuSectionGetPutDelete(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get Section')
    @nsApi.response(200, 'OK', section_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(404, 'Not found')
    @errorHandler
    def get(self, section_id):
        _expanded = request.args.get('expanded', default=False, type=bool)
        _section = MenuSection.get_by_id(section_id)
        if not _section: raise NotFound
        return marshal(_section, MenuSection.schema(expanded=_expanded))

    @nsApi.doc('Put Section')
    @nsApi.response(200, 'OK', section_marshal)
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    def put(self, section_id):
        json_dict = request.get_json()

        schema = MenuSectionSchema()
        json_dict, errors = schema.load(json_dict)

        if errors:
            raise BadRequest

        _expanded = False
        _name = json_dict.get('name')
        _position = json_dict.get('position')
        _uuid = json_dict.get('uuid')
        _description = json_dict.get('description')
        _enabled = json_dict.get('enabled')
        _availability = json_dict.get('availability')

        _section = MenuSection.get_by_id(section_id)
        if not _section: raise NotFound
        _section = update_section(section_key=_section.key,
                                  name=_name,
                                  availability=_availability,
                                  position=_position,
                                  uuid=_uuid,
                                  description=_description,
                                  enabled=_enabled)
        return marshal(_section, MenuSection.schema(expanded=_expanded))

    @nsApi.doc('Delete Section')
    @nsApi.response(200, 'OK')
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    @errorHandler
    def delete(self, section_id):
        _section = MenuSection.get_by_id(section_id)
        if not _section: raise NotFound
        _section.delete()
        return {}
