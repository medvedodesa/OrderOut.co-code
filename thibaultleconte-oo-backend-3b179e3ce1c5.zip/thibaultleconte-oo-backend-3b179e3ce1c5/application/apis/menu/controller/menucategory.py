# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/25/2019
#

from flask import request
from flask_restplus import Resource, Namespace
from application.apis.menu.model.MenuSync import MenuSync
from application.apis.menu.model.MenuSection import MenuSection
from application.apis.menu.model.MenuCategory import MenuCategory
from application.apis.ooexceptions import NotFound
from application.core.authentication.service import requires_auth_token
from flask_restplus import marshal
from application.core.exception import errorHandler
from application.apis.menu.service.crud.category import create_update_menu_category, update_category, delete_category


nsApi = Namespace('menucategory', description='Menu Category related operations.')

category_marshal = nsApi.model('Category', MenuCategory.schema())

######
# CRUD
######

@nsApi.route('/')
class MenuCategoryPost(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Create a Category')
    @nsApi.response(200, 'OK', category_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(400, 'Bad Request')
    @nsApi.expect(category_marshal, validate=True)
    @nsApi.marshal_with(category_marshal)
    # @errorHandler
    def post(self):
        _json_dict = request.get_json()
        _menu_sync_id = _json_dict.get('menu_sync_id')
        _section_id = _json_dict.get('section_id')
        _name = _json_dict.get('name')
        _menu_sync_key = MenuSync.get_key(_menu_sync_id)
        _menu_section_key = MenuSection.get_key(_section_id)
        _category = create_update_menu_category(menu_sync_key=_menu_sync_key, section_key=_menu_section_key, name=_name)
        return _category

@nsApi.route('/<int:category_id>')
@nsApi.param('category_id', 'Category identifier')
class MenuCategoryGetPutDelete(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get Category')
    @nsApi.response(200, 'OK', category_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(404, 'Not found')
    @errorHandler
    def get(self, category_id):
        _expanded = request.args.get('expanded', default=False, type=bool)
        _category = MenuCategory.get_by_id(category_id)
        if not _category: raise NotFound
        return marshal(_category, MenuCategory.schema(expanded=_expanded))

    @nsApi.doc('Put Category')
    @nsApi.response(200, 'OK', category_marshal)
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    @nsApi.expect(category_marshal, validate=True)
    def put(self, category_id):
        json_dict = request.get_json()
        _expanded = json_dict.get('expanded')
        _name = json_dict.get('name')
        _uuid = json_dict.get('uuid')
        _enabled = json_dict.get('enabled')
        _category = MenuCategory.get_by_id(category_id)
        if not _category: raise NotFound
        _category = update_category(category_key=_category.key,
                                    name=_name,
                                    uuid=_uuid,
                                    enabled=_enabled)
        return marshal(_category, MenuCategory.schema(expanded=_expanded))

    @nsApi.doc('Delete Category')
    @nsApi.response(200, 'OK')
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    @errorHandler
    def delete(self, category_id):
        _category = MenuCategory.get_by_id(category_id)
        if not _category: raise NotFound
        success = delete_category(category_key=_category.key)
        return {}
