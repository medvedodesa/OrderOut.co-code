# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 12/13/2019
#

from flask import request
from flask_restplus import Resource, Namespace
from application.apis.menu.model.MenuSync import MenuSync
from application.apis.menu.model.MenuItem import MenuItem
from application.apis.menu.model.MenuModifierGroup import MenuModifierGroup
from application.apis.menu.model.MenuItemModifier import MenuItemModifier
from application.apis.ooexceptions import NotFound
from application.core.authentication.service import requires_auth_token
from ..service.crud.modifierGroup import create_update_modifier_group, update_modifier_group, delete_modifier_group
from application.core.exception import errorHandler
from flask_restplus import marshal
from application.core.parser.string import sanitize_str


nsApi = Namespace('menumodifiergroup', description='Menu Medifier Group related operations.')

mod_group_marshal = nsApi.model('MenuMedifierGroup', MenuModifierGroup.schema())


######
# CRUD
######

@nsApi.route('/')
class MenuModifierGroupPost(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Create a Modifier Group')
    @nsApi.response(200, 'OK', mod_group_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(400, 'Bad Request')
    @nsApi.expect(mod_group_marshal, validate=True)
    @nsApi.marshal_with(mod_group_marshal)
    @errorHandler
    def post(self):
        _json_dict = request.get_json()
        _menu_sync_id = _json_dict.get('menu_sync_id')
        _menu_sync_key = MenuSync.get_key(_menu_sync_id)
        _item_id = _json_dict.get('item_id')
        _item_key = MenuItem.get_key(_item_id)
        _name = _json_dict.get('name')
        _uuid = _json_dict.get('uuid')
        _item = create_update_modifier_group(menu_sync_key=_menu_sync_key, item_key=_item_key, name=_name, uuid=_uuid)
        return _item

@nsApi.route('/<int:modifier_group_id>')
@nsApi.param('modifier_group_id', 'Modifier Group identifier')
class MenuModifierGroupGetPutDelete(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get Modifier Group')
    @nsApi.response(200, 'OK', mod_group_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(404, 'Not found')
    @errorHandler
    def get(self, modifier_group_id):
        _modifier_group = MenuModifierGroup.get_by_id(modifier_group_id)
        if not _modifier_group: raise NotFound
        return marshal(_modifier_group, MenuModifierGroup.schema())

    @nsApi.doc('Put Modifier Group')
    @nsApi.response(200, 'OK', mod_group_marshal)
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    @nsApi.expect(mod_group_marshal, validate=True)
    def put(self, modifier_group_id):
        json_dict = request.get_json()
        _modifier_group = MenuModifierGroup.get_by_id(modifier_group_id)
        if not _modifier_group: raise NotFound
        _name = sanitize_str(json_dict.get('name'))
        _uuid = sanitize_str(json_dict.get('uuid'))
        _is_available = bool(json_dict.get('is_available'))
        _min_permitted = int(json_dict.get('min_permitted'))
        _max_permitted = int(json_dict.get('max_permitted'))
        _modifier_group = update_modifier_group(modifier_group_key=_modifier_group.key,
                                                name=_name,
                                                uuid=_uuid,
                                                is_available=_is_available,
                                                min_permitted=_min_permitted,
                                                max_permitted=_max_permitted)
        return marshal(_modifier_group, MenuModifierGroup.schema())

    @nsApi.doc('Delete Modifier Group')
    @nsApi.response(200, 'OK')
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    @errorHandler
    def delete(self, modifier_group_id):
        _modifier_group = MenuModifierGroup.get_by_id(modifier_group_id)
        if not _modifier_group: raise NotFound
        success = delete_modifier_group(_modifier_group.key)
        return {}
