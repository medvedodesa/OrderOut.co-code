# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/10/2019
#

from flask import request
from flask_restplus import Resource, Namespace
from application.apis.menu.model.MenuSync import MenuSync
from application.apis.menu.model.MenuSection import MenuSection
from application.core.task.model import CoreTask
from ..service.menusync.task import get_all_tasks
from application.apis.ooexceptions import NotFound
from application.core.authentication.service import requires_auth_token
from application.core.marshal import pagination_schema
from application.apis.restaurant.model import Restaurant
from application.core.exception import errorHandler


nsApi = Namespace('menusync', description='MenuSync related operations.')

menusync_marshal = nsApi.model('MenuSync', MenuSync.schema())
menusyncs_pagination_marshal = nsApi.model('MenuSyncsPagination', pagination_schema(menusync_marshal))
task_marshal = nsApi.model('CoreTask', CoreTask.schema())


################
# Menu Sync List
################

@nsApi.route('restaurant/<int:restaurant_id>/menusync')
@nsApi.param('restaurant_id', 'Restaurant identifier')
class MenuSyncList(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('List Menu Sync for a restaurant')
    @nsApi.response(200, 'OK', menusyncs_pagination_marshal)
    @nsApi.marshal_with(menusyncs_pagination_marshal)
    @errorHandler
    def get(self, restaurant_id):
        _restaurant_key = Restaurant.get_key(restaurant_id)
        _cursor = request.args.get('cursor', default=None, type=str)
        _elements, _previous_cursor, _next_cursor, _more = MenuSync.list_with_pagination_with_restaurant(restaurant_key=_restaurant_key, cursor=_cursor)
        return {'data': _elements,
                'previous_cursor': _previous_cursor.urlsafe() if _previous_cursor else None,
                'next_cursor': _next_cursor.urlsafe() if _next_cursor else None,
                'more': _more}

###################
# Menu Sync Details
###################

@nsApi.route('menu/ms/<int:menu_sync_id>')
@nsApi.param('menu_sync_id', 'Menu Sync identifier')
class MenuSyncGet(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get Menu Sync')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    @nsApi.marshal_with(menusync_marshal)
    @errorHandler
    def get(self, menu_sync_id):
        _ms = MenuSync.get_by_id(menu_sync_id)
        if not _ms: raise NotFound
        return _ms

    @nsApi.doc('Delete Menu')
    @nsApi.response(200, 'OK')
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    @errorHandler
    def delete(self, menu_sync_id):
        _ms = MenuSync.get_by_id(menu_sync_id)
        if not _ms: raise NotFound
        _ms.delete()
        return {}

@nsApi.route('menusync/<int:menu_sync_id>/tasks')
@nsApi.param('menu_sync_id', 'MenuSync identifier')
class MenuSyncTasksGet(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('List the Menu Sync Tasks')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    @nsApi.marshal_list_with(task_marshal)
    @errorHandler
    def get(self, menu_sync_id):
        _ms_key = MenuSync.get_key(menu_sync_id)
        if not _ms_key: raise NotFound
        _data = get_all_tasks(menuSync_key=_ms_key)
        return _data

# CLOVER MAGIC BUTTON
#####################

@nsApi.route('menusync/<int:menu_sync_id>/magic')
@nsApi.param('menu_sync_id', 'MenuSync identifier')
class MenuSyncMagicPost(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Create unmapped menu items and modifiers in POS')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    # @nsApi.marshal_list_with(task_marshal)
    # @errorHandler
    def post(self, menu_sync_id):
        _ms_key = MenuSync.get_key(menu_sync_id)
        if not _ms_key: raise NotFound
        return {'success': True}
