# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 09/10/2020
#

from flask_restplus import Resource, Namespace
from application.core.authentication.service import requires_auth_token
from application.apis.ooexceptions import NotFound, BadRequest
from flask_restplus import marshal
from application.core.exception import errorHandler

from application.apis.menu.model.MenuItem import MenuItem
from application.apis.menu.model.MenuItemModifier import MenuItemModifier
from application.apis.pointofsale.model.PointOfSale import PointOfSale
from application.apis.deliveryservice.model.DeliveryService import DeliveryService


from application.apis.menu.service.fetch.item import fetch_all_items
from application.apis.menu.service.modifier import fetch_all_modifiers_for_menu_item, fetch_all_menu_item_modifiers_for_menu_sync

from application.apis.menu.service.mapping.clover.magicmapping import create_item_in_clover_and_map, create_modifier_in_clover_and_map
from application.apis.menu.service.mapping.clover.magicmapping import get_magic_mapping_section, get_magic_mapping_category, get_magic_mapping_modifier_group

from google.appengine.ext import ndb
from application.core.task.service import startDeferredTask
from application.apis.menu.service.stats import refresh_stats

nsApi = Namespace('magicmapping', description='Menu Magic Mapping related operations.')

mi_marshal = nsApi.model('MenuItem', MenuItem.schema())
mi_marshal_expanded = nsApi.model('MenuItem', MenuItem.schema(expanded=True))

modifier_marshal = nsApi.model('MenuItemModifier', MenuItemModifier.schema())

@nsApi.route("/ds/<int:delivery_service_id>/pos/<int:pos_id>")
@nsApi.param('delivery_service_id', 'Delivery Service identifier')
@nsApi.param('pos_id', 'Point Of Sale ID')
class MenuMagicMappingForDeliveryService(Resource):
    method_decorators = [requires_auth_token]
    @nsApi.doc('create and map deliver service items to point of sale')
    # @errorHandler
    def put(self, delivery_service_id, pos_id):
        _ds = DeliveryService.get_by_id(delivery_service_id)
        if not _ds: raise NotFound
        _pos = PointOfSale.get_by_id(pos_id)
        if not _pos: raise NotFound
        if not _pos.menuSync: raise BadRequest

        _ds_menu_items = fetch_all_items(menu_sync_key=_ds.menuSync, keys_only=False)

        _pos_section_key = get_magic_mapping_section(pos_menu_sync_key=_pos.menuSync)
        _pos_category_key = get_magic_mapping_category(pos_menu_sync_key=_pos.menuSync, pos_section_key=_pos_section_key)

        _pos_existing_modifiers = fetch_all_menu_item_modifiers_for_menu_sync(menu_sync_key=_pos.menuSync)

        # create unmapped items
        _ds_newly_mapped_items = []
        _pos_items = []
        _ds_newly_mapped_modifiers = []
        _pos_modifiers = []

        for _ds_mi in _ds_menu_items:
            # PROCESS UNMAPPED ITEMS
            if not _ds_mi.mappedToMenuItem and len(_ds_newly_mapped_items) < 25:
                _ds_mi, _pos_mi = create_item_in_clover_and_map(pos_key=_pos.key,
                                                                pos_menu_sync_key=_pos.menuSync,
                                                                pos_category_key=_pos_category_key,
                                                                ds_unmapped_item=_ds_mi)
                if _ds_mi and _pos_mi:
                    _pos_items.append(_pos_mi)
                    if _ds_mi.mappedToMenuItem:
                        _ds_newly_mapped_items.append(_ds_mi)

            # PROCESS UNMAPPED MODIFIERS
            _ds_modifiers_for_item = []
            _pos_modifier_group = None
            _pos_modifier_group_key = None
            if _ds_mi:
                _ds_modifiers_for_item = fetch_all_modifiers_for_menu_item(_ds_mi.key)

                _pos_mi_key = _ds_mi.mappedToMenuItem
                _pos_modifier_group_key = get_magic_mapping_modifier_group(pointofsale_key=_pos.key, pos_menu_sync_key=_pos.menuSync, pos_menu_item_key=_pos_mi_key)
                _pos_modifier_group = _pos_modifier_group_key.get()

            if _pos_modifier_group and _pos_modifier_group_key:
                for _ds_mod in _ds_modifiers_for_item:
                    if not _ds_mod.mappedToMenuItemModifier and len(_ds_newly_mapped_modifiers) < 25:
                        _ds_mod, _pos_mod = create_modifier_in_clover_and_map(pos_key=_pos.key,
                                                                              menu_sync_key=_pos.menuSync,
                                                                              pos_existing_modifiers=_pos_existing_modifiers,
                                                                              modifier_group_key=_pos_modifier_group_key,
                                                                              modifier_group_uuid=_pos_modifier_group.uuid,
                                                                              ds_unmapped_modifier=_ds_mod)
                        if _pos_mod:
                            _pos_modifiers.append(_pos_mod)
                        if _ds_mod.mappedToMenuItemModifier: _ds_newly_mapped_modifiers.append(_ds_mod)

        # To replace with a Put_multi that save to cach, the ndb one does NOT
        for _e in _ds_newly_mapped_items: _e.put()
        for _e in _ds_newly_mapped_modifiers: _e.put()
        # MenuItem.put_multi(_unmapped_items)

        startDeferredTask(refresh_stats, _ds.menuSync, _transactional=ndb.in_transaction(), _countdown=1, _queue="autoMapQueue")
        # refresh_stats(_ds.menuSync)

        # _success = True if len(_unmapped_items) == _mapped_items_success else False
        # _message = "%s Menu Items mapped successfully. %s unsuccessful" % (str(_mapped_items_success), str(len(_unmapped_items) - _mapped_items_success))
        _success = True
        _message = "Done"
        return format_response(_success, _message, _ds_newly_mapped_items, _pos_items, mi_marshal_expanded)

@nsApi.route("/mi/<int:item_id>/pos/<int:pos_id>")
@nsApi.param('item_id', 'Menu Item ID')
@nsApi.param('pos_id', 'Point Of Sale ID')
class MenuMagicMappingForMenuItem(Resource):
    method_decorators = [requires_auth_token]
    @nsApi.doc('create and map deliver service item to point of sale')
    # @errorHandler
    def put(self, item_id, pos_id):
        _ds_mi = MenuItem.get_by_id(item_id)
        if not _ds_mi: raise NotFound
        _pos = PointOfSale.get_by_id(pos_id)
        if not _pos: raise NotFound
        if not _pos.menuSync: raise BadRequest

        _pos_section_key = get_magic_mapping_section(pos_menu_sync_key=_pos.menuSync)
        _pos_category_key = get_magic_mapping_category(pos_menu_sync_key=_pos.menuSync, pos_section_key=_pos_section_key)

        _message = 'Unknown'
        _pos_items = list()
        _ds_menu_items = [_ds_mi]
        if not _ds_mi.mappedToMenuItem:
            _ds_mi, _pos_mi = create_item_in_clover_and_map(pos_key=_pos.key,
                                                pos_menu_sync_key=_pos.menuSync,
                                                pos_category_key=_pos_category_key,
                                                ds_unmapped_item=_ds_mi)
            if not _pos_mi:
                return format_response(False, "Error when creating mapping in Clover", _ds_menu_items, _pos_items, mi_marshal_expanded)
            else:
                _pos_items.append(_pos_mi)
            _message = 'Menu Item mapping Successful'

        _success = True if _ds_mi.mappedToMenuItem else False

        # To replace with a Put_multi that save to cach, the ndb one does NOT
        for _e in _ds_menu_items: _e.put()
        # MenuItem.put_multi(_ds_menu_items)

        startDeferredTask(refresh_stats, _ds_mi.menuSync, _transactional=ndb.in_transaction(), _countdown=1, _queue="autoMapQueue")

        return format_response(_success, _message, _ds_menu_items, _pos_items, mi_marshal_expanded)


@nsApi.route("/mi/<int:item_id>/mod/<int:modifier_id>/pos/<int:pos_id>")
@nsApi.param('item_id', 'Menu Item ID')
@nsApi.param('modifier_id', 'Menu Item Modifier identifier')
@nsApi.param('pos_id', 'Point Of Sale ID')
class MenuMagicMappingForModifier(Resource):
    method_decorators = [requires_auth_token]
    @nsApi.doc('create and map deliver service modifier to point of sale')
    # @errorHandler
    def put(self, item_id, modifier_id, pos_id):
        _ds_mi = MenuItem.get_by_id(item_id)
        if not _ds_mi: raise NotFound
        _ds_mod = MenuItemModifier.get_by_id(modifier_id)
        if not _ds_mod: raise NotFound
        _pos = PointOfSale.get_by_id(pos_id)
        if not _pos: raise NotFound
        if not _pos.menuSync: raise BadRequest

        if not _ds_mi.mappedToMenuItem: raise BadRequest
        _pos_mi_key =  _ds_mi.mappedToMenuItem

        _pos_modifier_group_key = get_magic_mapping_modifier_group(pointofsale_key=_pos.key, pos_menu_sync_key=_pos.menuSync, pos_menu_item_key=_pos_mi_key)
        _pos_modifier_group = _pos_modifier_group_key.get()

        _message = 'Unknown'
        _pos_modifiers = []
        if not _ds_mod.mappedToMenuItemModifier:
            _pos_existing_modifiers = fetch_all_menu_item_modifiers_for_menu_sync(menu_sync_key=_pos.menuSync)
            _ds_mod, _pos_mod = create_modifier_in_clover_and_map(pos_key=_pos.key, menu_sync_key=_pos.menuSync, pos_existing_modifiers=_pos_existing_modifiers, modifier_group_key=_pos_modifier_group_key, modifier_group_uuid=_pos_modifier_group.uuid, ds_unmapped_modifier=_ds_mod)
            if _pos_mod:
                _pos_modifiers.append(_pos_mod)
                _message = 'Menu Modifier mapping Successful'

        _success = True if _ds_mod.mappedToMenuItemModifier else False
        _ds_menu_modifiers = [_ds_mod]
        # To replace with a Put_multi that save to cach, the ndb one does NOT
        for _e in _ds_menu_modifiers: _e.put()
        # MenuItemModifier.put_multi(_ds_menu_modifiers)

        startDeferredTask(refresh_stats, _ds_mod.menuSync, _transactional=ndb.in_transaction(), _countdown=1, _queue="autoMapQueue")

        return format_response(_success, _message, _ds_menu_modifiers, _pos_modifiers, modifier_marshal)

def format_response(success, message, ds_items, pos_items, marshal_type):
    _marshalled_ds_items = []
    _marshalled_pos_items = []

    for _ds_item in ds_items: _marshalled_ds_items.append(marshal(_ds_item, marshal_type))
    for _pos_item in pos_items: _marshalled_pos_items.append(marshal(_pos_item, marshal_type))

    return {'success': success, 'message': message, 'ds_items': _marshalled_ds_items, 'pos_items': _marshalled_pos_items}
