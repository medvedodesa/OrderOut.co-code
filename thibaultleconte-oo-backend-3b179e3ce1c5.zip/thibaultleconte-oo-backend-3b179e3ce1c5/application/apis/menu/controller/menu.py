# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/07/2019
#

from flask_restplus import Resource, Namespace
from application.core.authentication.service import requires_auth_token
from application.apis.ooexceptions import NotFound, BadRequest
from application.apis.pointofsale.model.PointOfSale import PointOfSale
from application.apis.deliveryservice.model.DeliveryService import DeliveryService
from application.apis.menu.model.MenuItem import MenuItem
from application.apis.menu.service.fetch.item import fetch_all_items
from application.apis.menu.service.category import fetch_all_menu_categories_for_menu_sync

from application.apis.pointofsale.service.clover.menu import add_item_to_clover, get_modifier_groups, add_modifier_to_clover
from application.apis.menu.model.MenuItem import MenuItem
from application.apis.menu.service.modifier import fetch_all_modifiers_for_delivery_service, fetch_all_modifiers_for_point_of_sale, filter_all_unmapped_modifiers
from application.apis.menu.service.crud.item import create_update_item
from application.apis.menu.service.crud.modifier import create_update_modifier
from application.apis.restaurant.model import Restaurant
from google.appengine.ext import ndb
from application.core.task.service import startDeferredTask
from application.apis.menu.service.stats import refresh_stats


nsApi = Namespace('menu', description='Menu related operations.')

mi_marshal = nsApi.model('MenuItem', MenuItem.schema())


###############
# Point Of Sale
###############

@nsApi.route('menu/pos/<int:point_of_sale_id>')
@nsApi.param('point_of_sale_id', 'Point Of Sale identifier')
class MenuGetByPointOfSale(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('List the Menu Items for a Point Of Sale')
    @nsApi.response(200, 'OK', mi_marshal)
    @nsApi.marshal_list_with(mi_marshal)
    def get(self, point_of_sale_id):
        _pos = PointOfSale.get_by_id(point_of_sale_id)
        if not _pos: raise NotFound
        if not _pos.menuSync: raise BadRequest
        _data = fetch_all_items(menu_sync_key=_pos.menuSync, keys_only=False)
        return _data

##################
# Delivery Service
##################

@nsApi.route('menu/ds/<int:delivery_service_id>')
@nsApi.param('delivery_service_id', 'Delivery Service identifier')
class MenuGetByDeliveryService(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('List the Menu Items for a Delivery Service')
    @nsApi.response(200, 'OK', mi_marshal)
    @nsApi.marshal_list_with(mi_marshal)
    def get(self, delivery_service_id):
        _ds = DeliveryService.get_by_id(delivery_service_id)
        if not _ds: raise NotFound
        if not _ds.menuSync: raise BadRequest


        _menu_items = fetch_all_items(menu_sync_key=_ds.menuSync, keys_only=False)
        _menu_categories = fetch_all_menu_categories_for_menu_sync(menu_sync_key=_ds.menuSync)

        if(len(_menu_items) > 0):
            for _menu_item in _menu_items:
                if(len(_menu_item.categories) > 0):
                    _menu_categories_name = []
                    for _menu_category_uuid in _menu_item.categories:
                        _category_dict = filter(lambda category: category.key.id() == _menu_category_uuid.id(), _menu_categories)[0]
                        if _category_dict:
                            _menu_categories_name.append(_category_dict.name)
                    if(len(_menu_categories_name) > 0):
                        _menu_item.category_name = ",".join(_menu_categories_name)

        # refresh stats
        refresh_stats(menu_sync_key=_ds.menuSync, all_menu_items=_menu_items)

        return _menu_items
