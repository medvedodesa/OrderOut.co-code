# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/03/2019
#

from google.appengine.ext import ndb
from application.core.model.Base import Base
from flask_restplus import fields
from application.apis.ooexceptions import BadRequest
from application.core.marshal import SchemaFieldKeyFormatter
from application.apis.printer.model.Printer import PrinterSchemaFieldFromKeyFormatter


class Job(Base):
    printer = ndb.KeyProperty(required=True)
    body = ndb.BlobProperty(indexed=False)
    mediaType = ndb.StringProperty(default='application/vnd.star.starprnt')
    printed = ndb.BooleanProperty(default=False)
    oo_test = ndb.BooleanProperty(default=False)
    failsafe = ndb.BooleanProperty(default=False)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls, include_body=True):
        schema = super(cls, cls).schema()
        schema['printerId'] = SchemaFieldKeyFormatter(attribute='printer', description='Printer id')
        schema['printer'] = PrinterSchemaFieldFromKeyFormatter(attribute='printer', description='Printer')
        if include_body: schema['body'] = fields.String(description="Text to print")
        schema['mediaType'] = fields.String(description="Media Type to print")
        schema['printed'] = fields.Boolean(description="Printed Success")
        schema['test'] = fields.Boolean(attribute='oo_test', description="Test from OrderOut")
        schema['failsafe'] = fields.Boolean(attribute='failsafe', description="Fail Safe Printing")
        return schema
