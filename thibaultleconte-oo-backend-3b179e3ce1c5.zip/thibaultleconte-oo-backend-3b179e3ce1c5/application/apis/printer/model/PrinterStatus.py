# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/03/2019
#

from google.appengine.ext import ndb
from application.core.model.Base import Base
from flask_restplus import fields
from application.apis.ooexceptions import BadRequest
from application.core.marshal import SchemaFieldKeyFormatter


class PrinterStatus(Base):
    printer = ndb.KeyProperty(required=True)
    status = ndb.StringProperty(required=True)
    status_code = ndb.StringProperty(required=True)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema['printerId'] = SchemaFieldKeyFormatter(attribute='printer', description='Printer id')
        schema['status'] = fields.String(required=True, description="Status")
        schema['status_code'] = fields.String(required=True, description="Status Code")
        return schema
