# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/03/2019
#

from google.appengine.ext import ndb
from application.core.model.Base import Base
from flask_restplus import fields
from application.apis.ooexceptions import BadRequest
from application.core.marshal import SchemaFieldKeyFormatter


class JobStatus(Base):
    printer = ndb.KeyProperty(required=True)
    code = ndb.StringProperty(required=True)
    message = ndb.StringProperty(default='')
    job = ndb.KeyProperty()

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema['printerId'] = SchemaFieldKeyFormatter(attribute='printer', description='Printer id')
        schema['jobId'] = SchemaFieldKeyFormatter(attribute='job', description='Job id')
        schema['code'] = fields.String(required=True, description="Status Code")
        schema['message'] = fields.String(required=True, description="Status Mesage")
        return schema
