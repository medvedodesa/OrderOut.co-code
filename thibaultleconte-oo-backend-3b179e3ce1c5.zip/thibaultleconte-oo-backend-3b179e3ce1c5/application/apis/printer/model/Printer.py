# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/03/2019
#

from google.appengine.ext import ndb
from application.core.model.Base import Base
from flask_restplus import fields
from application.apis.ooexceptions import BadRequest
from application.core.marshal import SchemaFieldKeyFormatter
from flask_restplus import fields, marshal


class Printer(Base):
    mac = ndb.StringProperty(required=True)
    restaurant = ndb.KeyProperty(default=None)
    status = ndb.KeyProperty(default=None)
    jobStatus = ndb.KeyProperty(default=None)
    uuid = ndb.StringProperty(default='')
    manufacturerName = ndb.StringProperty(default='')
    pairingSuccess = ndb.BooleanProperty(default=False)
    pairingSuccessCreatedAt = ndb.DateTimeProperty()
    pairingCode = ndb.StringProperty(default='')
    pairingCodeCreatedAt = ndb.DateTimeProperty()


    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema['mac'] = fields.String(required=True, description="Printer MAC Address")
        schema['restaurant'] = SchemaFieldKeyFormatter(attribute='restaurant', description='Restaurant Id')
        schema['status'] = SchemaFieldKeyFormatter(attribute='status', description='Printer Status')
        schema['jobStatusId'] = SchemaFieldKeyFormatter(attribute='jobStatus', description='Job Status Id')
        schema['uuid'] = fields.String(description="Printer Manufacturer Unique Id")
        schema['manufacturerName'] = fields.String(description="Printer Manufacturer Name")
        schema['pairingSuccess'] = fields.Boolean(description="Printer Pairing")
        schema['pairingSuccessCreatedAt'] = fields.DateTime(description="Printer Pairing")
        return schema

    ###################
    # List & Pagination
    ###################

    @classmethod
    def list_with_pagination_with_restaurant(cls, restaurant_key, cursor=None, limit=25):
        _cursor =ndb.Cursor(urlsafe=cursor) if cursor else None
        _query = Printer.query()
        _query = _query.filter(Printer.restaurant == restaurant_key)
        _query = _query.order(-Printer.api_created_at)
        _objects, _next_cursor, _more = _query.fetch_page(limit, start_cursor=_cursor)
        _previous_cursor = _next_cursor.reversed() if _next_cursor else None
        return _objects, _previous_cursor, _next_cursor, _more

    ######
    # CRUD
    ######

    @classmethod
    def create(cls, mac, restaurant_key, manufacturer_name):
        _obj = cls()
        _obj.mac = mac.lower()
        _obj.restaurant = restaurant_key
        _obj.manufacturerName = manufacturer_name
        _obj.put()
        return _obj

class PrinterSchemaFieldFromKeyFormatter(fields.Raw):
    def format(self, value):
        if value:
            return marshal(value.get(), Printer.schema())
        return None
