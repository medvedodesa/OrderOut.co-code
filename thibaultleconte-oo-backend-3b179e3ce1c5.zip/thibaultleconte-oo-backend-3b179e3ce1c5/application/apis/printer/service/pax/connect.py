# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/08/2020
#

from datetime import datetime
from application.apis.printer.service.common.crud import get_or_create_printer
from ..common.manufacturer import PAX_MANUFACTURER_NAME

def create_pax_printer(point_of_sale_key):
    _pos = point_of_sale_key.get()
    _printer, _created = get_or_create_printer(mac=_pos.service_merchant_id, restaurant_key=_pos.restaurant, manufacturer_name=PAX_MANUFACTURER_NAME)
    _printer.pairingSuccess = True
    _printer.pairingSuccessCreatedAt = datetime.utcnow()
    _printer.put()
    return _printer
