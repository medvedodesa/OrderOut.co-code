# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/22/2020
#

# Ceviche PRODUCTION 4hh72e8jwyqkr
# ceviche order 6T3BBTP2Y92T2

# Cookiedoe SANDBOX P7EWCVM316RDY
# Cookiedoe order FQKKEDQ2M1RYE

import logging

def convert_merchant_id_to_sandbox(merchant_id):
    # logging.info('Got %s' % (str(merchant_id)))
    if merchant_id == 'P7EWCVM316RDY': # Cookiedoe
    # if merchant_id == '7VQQ0HH29XTQA': # Jolly
        # logging.info('returned 4hh72e8jwyqkr')
        return '4hh72e8jwyqkr'
    # logging.info('returned %s' % (str(merchant_id)))
    return merchant_id

def convert_order_id_to_sandbox(order_id):
    # logging.info('Got %s' % (str(order_id)))
    if order_id == 'JZVJZT4A3Y56T':
        #     logging.info('returned FQKKEDQ2M1RYE')
        return 'FQKKEDQ2M1RYE' #COOKIEDOE
    # return 'NXRHFDBHA5GFW' # Jolly
    # logging.info('returned %s' % (str(order_id)))
    return order_id
