# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/16/2019
#
import base64

from .crud import get_or_create_printer
from ...model.Job import Job
from .fetcher import fetch_paired_printers_for_restaurant
from .formatter import format_for_testing, format_order_with_full_info, format_fail_safe_order_with_full_info
from .formatter import format_code_for_pairing, format_code_for_pairing_is_successful
from .formatter import format_canceled_order
from flask import current_app
from application.core.email.service import send_admin_email
from application.core.settings.app import get_config_for_key
from application.apis.printer.service.common.manufacturer import check_manufacturer_is_starmicronics, check_manufacturer_is_clover
import logging


#########
# PAIRING
#########

def publish_pairing_print_job(printer_key, code):
    _media_type, _message = format_code_for_pairing(code)
    _printers_keys = [printer_key]
    _jobs = __publish_print_job(printer_key=printer_key, media_type=_media_type, message=_message)
    notify_admin_new_pairing_code_creation(printer_key, code)
    return _jobs

def notify_admin_new_pairing_code_creation(printer_key, code):
    _recipients = get_config_for_key('EMAIL_TO_ADMINS')
    _environment_name = get_config_for_key('ENV_NAME')
    _subject = 'New Pairing Code Printed'
    _message = '''
    Printer id: {printer_id}
    Pairing Code: {pairing_code}
    '''.format(printer_id=str(printer_key.id()), pairing_code=str(code))
    send_admin_email(_recipients, _subject, _message)

def publish_pairing_is_successful_print_job(printer_key, account_key, restaurant_key):
    _restaurant = restaurant_key.get()
    _account = account_key.get()
    _media_type, _message = format_code_for_pairing_is_successful(account_name=_account.name, restaurant_name=_restaurant.name)
    _jobs = __publish_print_job(printer_key=printer_key, media_type=_media_type, message=_message)
    return _jobs

#######
# ORDER
#######

def publish_order_print_job_for_restaurant(restaurant_key, order_key, testing=False, doublePrinting=False):
    _printers_keys = fetch_paired_printers_for_restaurant(restaurant_key)
    _jobs = __publish_order_print_job_for_printers(_printers_keys, order_key, testing=testing, doublePrinting=doublePrinting)
    return _jobs

def __publish_order_print_job_for_printers(printers_keys, order_key, testing=False, doublePrinting=False):
    _jobs = []
    for _printer_key in printers_keys:
        _media_type = None
        _message = None
        if check_manufacturer_is_starmicronics(_printer_key):
            _media_type, _message = format_order_with_full_info(order_key) if order_key else format_for_testing()
            logging.info('secret search text from tibo for starmicronics for printer %s order %s' % (str(_printer_key.id()), str(order_key.id())))
        elif check_manufacturer_is_clover(_printer_key):
            if order_key:
                _order = order_key.get()
                if _order:
                    if not _order.point_of_sale_uuid:
                        logging.error("Cannot print on Clover Printer because Order %s does NOT have a Clover Order UUID" % (str(order_key.id())))
                        continue
                    _media_type = 'text/plain'
                    _message = str(_order.point_of_sale_uuid)
                    logging.info('Publishing a new print job with clover uuid -%s-' % (str(_message)))
                    # logging.info('secret search text from tibo for clover for printer %s order %s' % (str(_printer_key.id()), str(order_key.id())))
        else:
            logging.error('Printer %s type not recognized' % str(_printer_key.id()))
        if _media_type and _message:
            _jobs = __publish_print_job(printer_key=_printer_key, media_type=_media_type, message=_message, testing=testing, doublePrinting=doublePrinting)
            _jobs.extend(_jobs)
    return _jobs

###################
# ORDER - FAIL SAFE
###################

def publish_fail_safe_order_print_job_for_restaurant(restaurant_key, order_key, raw_json_dict, testing=False, doublePrinting=False):
    logging.info("publish_fail_safe_order_print_job_for_restaurant")
    _printers_keys = fetch_paired_printers_for_restaurant(restaurant_key)
    _jobs = __publish_fail_safe_order_print_job_for_printers(_printers_keys, order_key, raw_json_dict, testing=testing, doublePrinting=doublePrinting)
    return _jobs

def __publish_fail_safe_order_print_job_for_printers(printers_keys, order_key, raw_json_dict, testing=False, doublePrinting=False):
    logging.info("__publish_fail_safe_order_print_job_for_printers")
    _jobs = []
    for _printer_key in printers_keys:
        _media_type = None
        _message = None
        if check_manufacturer_is_starmicronics(_printer_key):
            _media_type, _message = format_fail_safe_order_with_full_info(order_key=order_key, raw_json_dict=raw_json_dict)
        elif check_manufacturer_is_clover(_printer_key):
            # Add oo-event
            logging.warning('Cannot fail safe print on Clover-Printer for printer %s and order %s' % (str(_printer_key.id()), str(order_key.id())))
            continue
        else:
            logging.error('Printer %s type not recognized' % str(_printer_key.id()))
        if _media_type and _message:
            _jobs = __publish_print_job(printer_key=_printer_key, media_type=_media_type, message=_message, testing=testing, failsafe=True, doublePrinting=doublePrinting)
            _jobs.extend(_jobs)
    return _jobs

################
# ORDER - CANCEL
################

def publish_canceled_order_print_job_for_restaurant(restaurant_key, order_key, testing=False):
    _printers_keys = fetch_paired_printers_for_restaurant(restaurant_key)
    _jobs = publish_canceled_order_print_job_for_printers(_printers_keys, order_key, testing=testing)
    return _jobs

def publish_canceled_order_print_job_for_printers(printers_keys, order_key, testing=False):
    _jobs = []
    for _printer_key in printers_keys:
        _media_type = None
        _message = None
        if check_manufacturer_is_starmicronics(_printer_key):
            _media_type, _message = format_canceled_order(order_key) if order_key else format_for_testing()
        elif check_manufacturer_is_clover(_printer_key):
            # Add oo-event
            logging.warning('Cannot cancel on Clover-Printer for printer %s and order %s' % (str(_printer_key.id()), str(order_key.id())))
            continue
        else:
            logging.error('Printer %s type not recognized' % str(_printer_key.id()))
        if _media_type and _message:
            _jobs = __publish_print_job(printer_key=_printer_key, media_type=_media_type, message=_message, testing=testing)
            _jobs.extend(_jobs)
    return _jobs

########
# HELPER
########

def __publish_print_job(printer_key, media_type, message, testing=False, failsafe=False, doublePrinting=False):
    logging.info("__publish_print_job")
    _jobs = []
    _job = __create_print_job(printer_key, media_type, message, testing, failsafe)
    _jobs.append(_job)
    if doublePrinting:
        _job = __create_print_job(printer_key, media_type, message, testing, failsafe)
        _jobs.append(_job)
    return _jobs

def __create_print_job(printer_key, media_type, message, testing, failsafe):
    _job = Job()
    _job.printer = printer_key
    _job.mediaType = media_type

    datastore_max_length = get_config_for_key("DATASTORE_MAX_LENGTH")
    if len(message) > datastore_max_length:
        _job.body = base64.b64encode(message)
    else:
        _job.body = message

    _job.oo_test = testing
    _job.failsafe = failsafe
    _job.put()
    return _job

###################
# List & Pagination
###################

def fetch_printjob_offset_pagination_for_printer(printer_key, _page=1, _item_per_page=2):
    _query = Job.query()
    _query = _query.filter(Job.printer == printer_key)
    _objects, prev, _next, _count = Job.list_with_offset_pagination(query=_query, page=_page, item_per_page=_item_per_page, keys_only=True, sort='desc')
    return _objects, prev, _next, _count

def fetch_printjob_offset_pagination(show_only_not_printed=False, _page=1, _item_per_page=2):
    _query = Job.query()
    if show_only_not_printed:
        _filter_bool = not show_only_not_printed
        _query = _query.filter(Job.printed == _filter_bool)
    _objects, prev, _next, _count = Job.list_with_offset_pagination(query=_query, page=_page, item_per_page=_item_per_page, keys_only=True, sort='desc')
    return _objects, prev, _next, _count
