# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/16/2019
#

from flask import current_app
from .crud import get_or_create_printer
from datetime import datetime
from random import randint
from application.apis.ooexceptions import PrinterAlreadyPairedError, BadRequest
from .printjob import publish_pairing_print_job
from .fetcher import get_printer_from_pairing_code, check_pairing_code_is_available, count_printer_status_event
from application.core.error import report_and_abort
from application.core.settings.app import get_config_for_key
import logging


def setup_printer_for_pairing(printer_key):
    _printer = printer_key.get()
    if _printer.restaurant: raise BadRequest
    if _printer.pairingSuccess: raise BadRequest
    if __check_printer_was_turned_off(printer_key) == False: return False
    _pairing_code = __generate_pairing_code()
    if not _pairing_code: return False
    _printer.pairingCode = _pairing_code
    _printer.pairingCodeCreatedAt = datetime.utcnow()
    _printer.pairingSuccess = False
    _printer.pairingSuccessCreatedAt = None
    _printer.put()
    _print_jobs = publish_pairing_print_job(_printer.key, _printer.pairingCode)
    return True

def __check_printer_was_turned_off(printer_key):
    _last_seconds = get_config_for_key('PRINTER_TURNED_OFF_TRIGGER_SECONDS')
    _nb = count_printer_status_event(printer_key, _last_seconds)
    logging.info('Nb printer status even %s in last %s seconds' % (str(_nb), str(_last_seconds)))
    if _nb == 0: return True
    return False

def __generate_pairing_code():
    for i in range(1, 25):
        _pairing_code = str(randint(10000, 99999))
        _is_available = check_pairing_code_is_available(_pairing_code)
        if _is_available: return _pairing_code
    _message = '__generate_pairing_code loop run out'
    report_and_abort(_message)
    return None

def pair_printer_with_restaurant_and_pairing_code(restaurant_key, pairing_code):
    _printer = get_printer_from_pairing_code(pairing_code)
    if _printer.restaurant:
        logging.error('Printer %s(%s) is paired to restaurant %s' % (str(_printer.mac), str(_printer.key.id()), str(restaurant_key.id())))
        raise BadRequest
    if _printer.pairingCode != str(pairing_code):
        logging.error('Printer %s(%s) pairing code %s not matching %s' % (str(_printer.mac), str(_printer.key.id()), str(_printer.pairingCode), str(pairing_code)))
        raise BadRequest
    _printer.restaurant = restaurant_key
    _printer.pairingSuccess = True
    _printer.pairingSuccessCreatedAt = datetime.utcnow()
    _printer.put()
    return _printer

def clear_pairing(mac):
    _printer, _created = get_or_create_printer(mac)
    _printer.pairingCode = str('')
    _printer.pairingCodeCreatedAt = None
    _printer.pairingSuccess = False
    _printer.pairingSuccessCreatedAt = None
    _printer.put()
    return _printer
