# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/08/2019
#

from ...model.Printer import Printer
from application.apis.ooexceptions import ResourceDoesNotExist, ConflictResourceAlreadyExistsError, PrinterAlreadyPairedError
from flask import current_app
from application.core.email.service import send_admin_email
from application.core.settings.app import get_config_for_key
from google.appengine.api import memcache
from .manufacturer import STARMICRONICS_MANUFACTURER_NAME, CLOVER_MANUFACTURER_NAME

#####
# GET
#####

def get_or_create_printer(mac, restaurant_key=None, manufacturer_name=STARMICRONICS_MANUFACTURER_NAME):
    created = False
    _printer = __fetch_by_mac(mac)
    if not _printer:
        _printer = Printer.create(mac=mac, restaurant_key=restaurant_key, manufacturer_name=manufacturer_name)
        created = True
    if _printer.manufacturerName != manufacturer_name and manufacturer_name != STARMICRONICS_MANUFACTURER_NAME:
        _printer.manufacturerName = manufacturer_name
        _printer.put()
    if _printer.restaurant != restaurant_key and restaurant_key:
        _printer.restaurant = restaurant_key
        _printer.put()
    return _printer, created

def __fetch_by_mac(mac):
    _query = Printer.query()
    _query = _query.filter(Printer.mac == mac.lower())
    _printer = _query.get()
    return _printer

def notify_admin_new_printer_creation(manufacturerName, mac):
    _recipients = get_config_for_key('EMAIL_TO_ADMINS')
    _environment_name = get_config_for_key('ENV_NAME')
    _subject = 'New Printer Created'
    _message = '''
    Printer Manufacturer: {manufacturer}
    Printer MAC address: {mac_address}
    '''.format(manufacturer=str(manufacturerName), mac_address=str(mac))
    send_admin_email(_recipients, _subject, _message)
