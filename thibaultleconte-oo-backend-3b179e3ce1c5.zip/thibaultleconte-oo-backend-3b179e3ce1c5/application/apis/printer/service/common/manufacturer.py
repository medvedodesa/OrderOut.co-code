# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/18/2020
#

import logging

STARMICRONICS_MANUFACTURER_NAME = 'starmicronics'
CLOVER_MANUFACTURER_NAME = 'clover'
PAX_MANUFACTURER_NAME = 'pax'


def check_manufacturer_is_starmicronics(printer_key):
    _printer = printer_key.get()
    if _printer.manufacturerName == STARMICRONICS_MANUFACTURER_NAME:
        logging.info('Printer %s manufacturer is %s' % (str(printer_key.id()), str(_printer.manufacturerName)))
        return True
    return False

def check_manufacturer_is_clover(printer_key):
    _printer = printer_key.get()
    if _printer.manufacturerName == CLOVER_MANUFACTURER_NAME:
        logging.info('Printer %s manufacturer is %s' % (str(printer_key.id()), str(_printer.manufacturerName)))
        return True
    return False

def check_manufacturer_is_pax(printer_key):
    _printer = printer_key.get()
    if _printer.manufacturerName == PAX_MANUFACTURER_NAME:
        logging.info('Printer %s manufacturer is %s' % (str(printer_key.id()), str(_printer.manufacturerName)))
        return True
    return False
