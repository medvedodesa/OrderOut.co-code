# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/17/2019
#
import logging

from flask import current_app
from ..starcloudprint.cputil import convert
from application.core.settings.app import get_config_for_key
from application.core.error import report_error
from application.apis.deliveryservice.model.DeliveryService import DeliveryServiceType

__MEDIATYPE_TEXT_PLAIN = 'text/plain'
__MEDIATYPE_START_PRNT_MODE = 'application/vnd.star.starprnt'

######
# TEST
######

def format_for_testing():
    _media_type = __MEDIATYPE_START_PRNT_MODE
    _message = '[align: centre][feed: length 10mm][image: url {logo_url};width 60%;min-width 48mm][feed: length 10mm]This is a test.[cut: feed; partial]'
    _message = _message.format(logo_url=__format_orderout_logo_url_for_printing())
    _url, _status_code, _result = convert(mediaType=_media_type, body=_message)
    return _media_type, _result

#########
# PAIRING
#########

def format_code_for_pairing(code):
    _media_type = __MEDIATYPE_START_PRNT_MODE
    _message = '''\
    [align: centre]
    [image: url {logo_url};width 60%;min-width 48mm]
    [feed: length 3mm]
    [align: centre][magnify: width 2; height 2]Pairing Code[magnify]
    [magnify: width 4; height 4][bold: on] {code} [bold: off][magnify]
    [align: left]
    Congratulations, you have successfully connected the OrderOut Kitchen Printer to the network!
    OrderOut is currently connecting to your delivery services.

    You MUST TEXT the PAIRING CODE above, along with the NAME of your restaurant & ADDRESS to [bold: on]{oo_support_phonenumber}[bold: off] in order to complete the setup.
    [cut: feed; partial]'''
    _message = _message.format(logo_url=__format_orderout_logo_url_for_printing(), code=str(code), oo_support_phonenumber=str(get_config_for_key('ORDEROUT_SUPPORT_PHONENUMBER')))
    _url, _status_code, _result = convert(mediaType=_media_type, body=_message)
    return _media_type, _result

def format_code_for_pairing_is_successful(account_name, restaurant_name):
    _media_type = __MEDIATYPE_START_PRNT_MODE
    _message = '''\
    [align: centre]
    [image: url {logo_url};width 60%;min-width 48mm]
    [feed: length 3mm]
    [align: centre][magnify: width 2; height 2][bold: on]SUCCESS[bold: off][magnify]

    This printer is now connected to

    [magnify: width 2; height 2]{account}[magnify]
    [magnify: width 2; height 2]{restaurant}[magnify]
    [cut: feed; partial]'''
    _message = _message.format(logo_url=__format_orderout_logo_url_for_printing(),
                               account=str(account_name),
                               restaurant=str(restaurant_name))
    _url, _status_code, _result = convert(mediaType=_media_type, body=_message)
    return _media_type, _result

#################
# ORDER FAIL SAFE
#################

def format_fail_safe_order_with_full_info(order_key, raw_json_dict):
    _media_type = __MEDIATYPE_START_PRNT_MODE

    _order = order_key.get()
    _ds = _order.delivery_service.get()
    _pos = _order.point_of_sale.get() if _order.point_of_sale else None


    _message = __generate_order_header(_order, _ds, failsafe=True)
    if _ds.type == DeliveryServiceType.WIX:
        menu_items = raw_json_dict.get('menu',{}).get('items',[])
        #creating menu items map as title is not given in orderitems
        menu_item_map = {}
        for menu_item in menu_items:
            uuid = menu_item.get("id")
            title = menu_item.get("title").get("en_US")
            menu_item_map[uuid] = title

        order_items = raw_json_dict.get('order',{}).get('orderItems',[])
        for item in order_items:
            item_uuid = item.get("itemId")
            item_title = menu_item_map.get(item_uuid,"")
            item_quantity = str(item.get("count"))
            _message += __format_fail_safe_menu_item(name=item_title, quantity=item_quantity)
            if 'comment' in item: # some item can contain comments also
                _raw_item_modifier = item.get('comment')
                _message += __format_fail_safe_menu_item_modifier(name=_raw_item_modifier)
        # PROCESS FROM JSON

    else: # PARSEUR for Doordash and Grubhub
        import logging
        logging.info(_ds.type)
        logging.info(raw_json_dict)
        for _raw_item in raw_json_dict.get('items'): #.get('menu')
            _raw_item_quantity = _raw_item.get('quantity')
            _raw_item_name = _raw_item.get('description')
            _message += __format_fail_safe_menu_item(name=_raw_item_name, quantity=_raw_item_quantity)
            # modifiers
            if 'extra' in _raw_item:
                _raw_item_modifiers = _raw_item.get('extra')
                if _raw_item_modifiers:
                    for _raw_item_modifier in _raw_item_modifiers.split('\n'):
                        _message += __format_fail_safe_menu_item_modifier(name=_raw_item_modifier)

    _message += __generate_order_footer(_order, _ds, _pos)

    _url, _status_code, _result = convert(mediaType=_media_type, body=_message)
    return _media_type, _result

def __format_fail_safe_menu_item(name, quantity):
    _message = "[magnify: width 2; height 2]%s[magnify]\n" % (str(name))
    if quantity:
        _message = "[magnify: width 2; height 2]%s %s[magnify]\n" % (str(quantity), str(name))
    return _message

def __format_fail_safe_menu_item_modifier(name):
    _message = "[magnify: width 1; height 2][sp]- %s[magnify]\n" % (str(name))
    return _message


#######
# ORDER
#######

def format_order_with_full_info(order_key):
    _media_type = __MEDIATYPE_START_PRNT_MODE

    _order = order_key.get()
    _ds = _order.delivery_service.get()
    _pos = _order.point_of_sale.get() if _order.point_of_sale else None

    _message = __generate_order_header(_order, _ds)

    for _order_item_key in _order.order_items:

        _order_item = _order_item_key.get()
        if not _order_item.menu_item:
            _message = 'Order %s - Menu Item not found for order_item %s' % (str(order_key.id()), str(_order_item_key.id()))
            data_dict = {'order': order_key.id(), 'order_item': _order_item_key.id()}
            report_error(500, subject='Printer Formatting Issue', message=_message, data_dict=data_dict)
        _menu_item = _order_item.menu_item.get()

        _message += "[magnify: width 2; height 2]%s %s[magnify]\n" % (str(_order_item.quantity), str(_menu_item.name))

        for _selected_modifier_key in _order_item.selected_modifier:
            _selected_modifier = _selected_modifier_key.get()
            if _selected_modifier.menu_item_modifier:
                _menu_item_modifier = _selected_modifier.menu_item_modifier.get()
                if not _menu_item_modifier.name: logging.error(_order)
                _message += "[magnify: width 1; height 2][sp]- %s[magnify]\n" % (str(_menu_item_modifier.name))

        if _order_item.store_instructions:
            if len(_order_item.store_instructions):
                _message += "[magnify: width 1; height 2][underline: on]Instructions:[underline: off]%s[magnify]\n" % (str(_order_item.store_instructions))

        _message += '\n'

    _message += __generate_order_footer(_order, _ds, _pos)

    _url, _status_code, _result = convert(mediaType=_media_type, body=_message)
    return _media_type, _result

##############
# ORDER CANCEL
##############

def format_canceled_order(order_key):
    _media_type = __MEDIATYPE_START_PRNT_MODE

    _order = order_key.get()
    _ds = _order.delivery_service.get()

    _message = '''
    [feed: length 10mm][align: centre]
    [magnify: width 2; height 2]{delivery_service_name}[magnify]

    [align: centre]
    [magnify: width 2; height 1]Order #[magnify]
    [magnify: width 2; height 2]{order_ds_uuid}[magnify]

    [magnify: width 3; height 3]{order_status}[magnify]

    [magnify: width 2; height 1]{customer_name}[magnify]
    [magnify: width 2; height 1]{customer_phone}[magnify]
    [align]
    '''
    _message = _message.format(delivery_service_name=str(_ds.type),
                               order_ds_uuid=__format_order_uuid_for_delivery_service(_order),
                               order_status=str(_order.status),
                               customer_name=str(_order.customer_name).upper(),
                               customer_phone=str(_order.customer_phone))
    _message += '[cut: feed; partial]'

    _url, _status_code, _result = convert(mediaType=_media_type, body=_message)
    return _media_type, _result

##########################
# ORDER FORMATTING HELPERS
##########################

def __generate_order_header(order, delivery_service, failsafe=False):
    _message = '[feed: length 10mm][align: centre]'
    if order.oo_test:
        _message += '[magnify: width 2; height 1]THIS IS A TEST ORDER FROM ORDEROUT[magnify]\n'

    _message += '''
    [magnify: width 2; height 2]{delivery_service_name}[magnify]
    [magnify: width 2; height 2]{order_type}[magnify]

    [magnify: width 2; height 1]Order #[magnify]
    [magnify: width 2; height 2]{order_ds_uuid}[magnify]
    [magnify: width 2; height 2]{order_status}[magnify]

    [magnify: width 2; height 2]{customer_name}[magnify]
    [magnify: width 2; height 1]{customer_phone}[magnify]

    [magnify: width 2; height 1]Ready by[magnify]
    [magnify: width 2; height 2]{order_ready_by}[magnify]

    '''
    if order.ready_by and order.ready_by.lower() == "none":
        order.ready_by = None

    _order_ready_by = order.ready_by.capitalize() if order.ready_by else 'Now'
    _message = _message.format(delivery_service_name=str(delivery_service.type),
                               order_ds_uuid=__format_order_uuid_for_delivery_service(order),
                               order_type=str(order.type),
                               order_status=str(order.status),
                               order_ready_by=str(_order_ready_by),
                               customer_name=str(order.customer_name).upper(),
                               customer_phone=str(order.customer_phone))
    if len(order.order_items) > 0 and failsafe == False:
        _message += '''
        [magnify: width 2; height 2][underline: on]Total items: {order_total_items}[underline: off][magnify]

        '''
        _message = _message.format(order_total_items=str(order.total_number_of_items))

    _message += '''
    [align]
    '''

    return _message

def __generate_order_footer(order, delivery_service, point_of_sale):
    _message = ''
    if order.store_instructions:
        if len(order.store_instructions):
            _message += '''[align: left]
            [magnify: width 2; height 1][underline: on]Store Instructions:[underline: off][magnify]
            [magnify: width 2; height 1]{instructions}[magnify]
            [align]'''
            _message = _message.format(instructions=str(order.store_instructions.capitalize()))
    if order.delivery_address:
        _formatted_address = ''
        if len(order.delivery_address): _formatted_address += str(order.delivery_address)
        if len(order.delivery_city): _formatted_address += ' ' + str(order.delivery_city)
        if len(order.delivery_state): _formatted_address += ' ' + str(order.delivery_state)
        if len(order.delivery_zip): _formatted_address += ' ' + str(order.delivery_zip)
        if len(_formatted_address):
            _message += '''[align: left]
            [magnify: width 2; height 1][underline: on]Delivery Address:[underline: off][magnify]
            [magnify: width 2; height 1]{address}[magnify]
            [align]'''
            _message = _message.format(address=str(_formatted_address))
    if order.delivery_instructions:
        if len(order.delivery_instructions):
            _message += '''[align: left]
            [magnify: width 2; height 1][underline: on]Delivery Instructions:[underline: off][magnify]
            [magnify: width 2; height 1]{instructions}[magnify]
            [align]'''
            _message = _message.format(instructions=str(order.delivery_instructions.capitalize()))

    if len(str(order.charge_mode)) > 0:
        _message += '''[align: centre]
        [magnify: width 2; height 2]{charge_mode}[magnify][align]'''
        _message = _message.format(charge_mode=str(order.charge_mode).upper())

    _message += '[cut: feed; partial]'

    return _message

########
# HELPER
########

# ORDER DELIVERY SERFICE UUID

def __format_order_uuid_for_delivery_service(order):
    _order_ds_uuid = str(order.delivery_service_uuid)
    if order.delivery_service_short_uuid and len(str(order.delivery_service_short_uuid)) > 0:
        _order_ds_uuid =  str(order.delivery_service_short_uuid)
    return _order_ds_uuid

def __format_orderout_logo_url_for_printing():
    _url = get_config_for_key('PROJECT_URL') + '/static/brand/orderout/orderout_logo_for_star_document_markup.png';
    return _url
