# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/16/2019
#

from flask import current_app
from ...model.Printer import Printer
from ...model.PrinterStatus import PrinterStatus
from application.apis.ooexceptions import ResourceDoesNotExist
from datetime import datetime, timedelta
from application.core.settings.app import get_config_for_key
from application.core.error import report_and_abort


def fetch_paired_printers_for_restaurant(restaurant_key, keys_only=True):
    _query = Printer.query()
    _query = _query.filter(Printer.restaurant == restaurant_key)
    _query = _query.filter(Printer.pairingSuccess == True)
    _result = _query.fetch(keys_only=keys_only)
    return _result

def fetch_printer_key_from_mac(mac):
    _query = Printer.query()
    _query = _query.filter(Printer.mac == mac.lower())
    _printer = _query.get()
    if not _printer: raise ResourceDoesNotExist
    return _printer.key

def get_printer_from_pairing_code(pairing_code):
    last_hour_date_time = datetime.now() - timedelta(seconds = get_config_for_key('PRINTER_PAIRING_CODE_EXPIRATION_SECONDS'))
    _query = Printer.query()
    _query = _query.filter(Printer.pairingCode == pairing_code)
    _query = _query.filter(Printer.pairingCodeCreatedAt >= last_hour_date_time)
    _printer = _query.get()
    if not _printer:
        _message = 'No Printer associated with this Pairing Code'
        report_and_abort(_message, 410)
    return _printer

def check_pairing_code_is_available(pairing_code):
    last_hour_date_time = datetime.now() - timedelta(seconds = get_config_for_key('PRINTER_PAIRING_CODE_EXPIRATION_SECONDS'))
    _query = Printer.query()
    _query = _query.filter(Printer.pairingCode == pairing_code)
    _query = _query.filter(Printer.pairingCodeCreatedAt >= last_hour_date_time)
    _nb = _query.count()
    if _nb == 0: return True
    return False

def count_printer_status_event(printer_key, last_seconds):
    last_time = datetime.now() - timedelta(seconds=last_seconds)
    _query = PrinterStatus.query()
    _query = _query.filter(PrinterStatus.printer == printer_key)
    _query = _query.filter(PrinterStatus.api_created_at >= last_time)
    _nb = _query.count()
    return _nb
