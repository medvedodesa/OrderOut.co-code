# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/03/2019
#

from ...model.Job import Job
from application.apis.ooexceptions import ResourceDoesNotExist
from datetime import datetime, timedelta
from application.core.settings.app import get_config_for_key


def check_job_ready_for_printing(printer_key):
    _query = Job.query()
    _query = _query.filter(Job.printer == printer_key)
    _query = _query.filter(Job.printed == False)
    _query = _query.filter(Job.api_created_at >= __get_job_expiration_limit(margin_minutes=1))
    _nb_jobs = _query.count()
    import logging
    logging.info(_nb_jobs)
    if _nb_jobs > 0:
        return True
    return False

def get_job_to_print(printer_key):
    _query = Job.query()
    _query = _query.filter(Job.printer == printer_key)
    _query = _query.filter(Job.printed == False)
    _query = _query.filter(Job.api_created_at >= __get_job_expiration_limit())
    _query = _query.order(Job.api_created_at)
    _job = _query.get()
    return _job

def mark_job_as_printed(job_key):
    _job = job_key.get()
    if not _job: raise ResourceDoesNotExist
    _job.printed = True
    _job.put()
    return True

def __get_job_expiration_limit(margin_minutes=0):
    today = datetime.utcnow()
    expiration_minutes = get_config_for_key('PRINTER_JOB_EXPIRATION_MINUTES')
    expiration_minutes = expiration_minutes - margin_minutes # we could have a few seconds delay between check and get requests
    datetime_limit = today - timedelta(minutes=expiration_minutes)
    return datetime_limit
