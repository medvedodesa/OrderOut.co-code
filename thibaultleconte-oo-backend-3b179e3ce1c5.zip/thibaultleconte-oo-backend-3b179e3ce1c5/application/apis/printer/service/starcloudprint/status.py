# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/03/2019
#

from ...model.PrinterStatus import PrinterStatus
from ...model.JobStatus import JobStatus
from application.apis.ooexceptions import ResourceDoesNotExist
from application.core.email.service import send_support_email, send_admin_email
from application.core.email.service import send_raw_email_to_admin


def update_printer_status(printer_key, status, status_code):
    _printer = printer_key.get()
    if not _printer: raise ResourceDoesNotExist
    _status = PrinterStatus(status=status, status_code=status_code)
    _status.printer = printer_key
    _status.put()
    _printer.status = _status.key
    _printer.put()
    return _printer.key

def update_job_status(printer_key, code, message='', job_key=None):
    _printer = printer_key.get()
    if not _printer: raise ResourceDoesNotExist
    if _printer.jobStatus:
        _last_status = _printer.jobStatus.get()
        if _last_status.code == code:
            return _printer.key
    _status = JobStatus(code=code)
    _status.printer = printer_key
    _status.message = message
    _status.job = job_key
    _status.put()
    _printer.jobStatus = _status.key
    _printer.put()
    if _status.code.startswith('4'): notify_customer(printer_key, _status.key)
    if _status.code.startswith('5'): notify_admin(printer_key, _status.key)
    return _printer.key

def format_printer_status_code_message(code):
    code = str(code)
    message = 'Unknown'
    if code.startswith('21'):
        if code == '210':
            message = 'Paper low'
        else:
            message = 'Printer is online, but a paper related warning is n place, the printer may go offline in the near future.'
    elif code.startswith('2'):
        message = 'Printer is online and able to print'
    elif code.startswith('41'):
        if code == '410':
            message = 'Out of paper'
        elif code == '411':
            message = 'Paper jam'
        else:
            message = 'Paper error'
    elif code.startswith('42'):
        if code == '420':
            message = 'Cover open'
        else:
            message = 'Cover open error'
    elif code.startswith('4'):
        message = 'Printer is online BUT unable to print'
    elif code.startswith('51'):
        if code == '510':
            message = 'Incompatible media type, client does not support the data issued by the server.'
        elif code == '511':
            message = 'Media decoding error. Client supports the media type, but failed to decode it. May indicate a data corruption, or differing versions of the media format.'
        elif code == '512':
            message = 'Unsupported media version. Means that the media type is supported, but the version issued by the server is not compatible. E.g. client may support PDF up to 1.4, but not 1.5.'
        else:
            message = 'Media compatibility error'
    elif code.startswith('52'):
        if code == '520':
            message = 'Timeout, client could not download the job within an internal timeout limit.'
        elif code == '521':
            message = 'Job too large. The job data is too large for the client\'s download buffer or exceeds a specified size limit.'
        else:
            message = 'Job download error'
    elif code.startswith('5'):
        message = 'Client error - all codes beginning with 5 indicate a client issue.'
    return message

def notify_customer(printer_key, status_key):
    _printer = printer_key.get()
    _status = status_key.get()
    _subject = '[PRINTER] - Error'
    _message = 'The printer with the MAC address %s reported the following error "%s".' % (str(_printer.mac), _status.message)
    if _printer.restaurant:
        _restaurant = _printer.restaurant.get()
        if _restaurant.account:
            _account = _restaurant.account.get()
    _recipients = []
    if _account.owner:
        _owner = _account.owner.get()
        _recipients.append(_owner.email)
    for _user_key in _account.users:
        _user = _user_key.get()
        _recipients.append(_user.email)
    return send_support_email(_recipients, _subject, _message)

def notify_admin(printer_key, status_key):
    _printer = printer_key.get()
    _status = status_key.get()
    _subject = '[PRINTER] - Error'
    status_job_id = _status.job.id() if _status and _status.job else "(status with no job)"
    _message = 'The printer with the MAC address %s for the Job %s reported the following error %s "%s".' % (str(_printer.mac), str(status_job_id), str(_status.code), _status.message)
    if _printer.restaurant:
        _restaurant = _printer.restaurant.get()
        if _restaurant.account:
            _account = _restaurant.account.get()
    return send_raw_email_to_admin(_subject, _message)
