# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/05/2019
#

from flask import current_app
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.error import report_error
from application.core.settings.app import get_config_for_key


def convert(mediaType, body):
    _url = get_config_for_key('ORDEROUT_CPUTIL_CONVERT_URL') # For Local Dev: 'http://localhost:8081/cputil/convert'
    _platform = get_config_for_key('ORDEROUT_CPUTIL_CONVERT_PLATFORM') # For Local Dev: 'mac'

    _payload = {'mediaType': mediaType,
                'body': body,
                'platform': _platform}

    import urllib2
    import json
    json_data = json.dumps(_payload)
    opener = urllib2.build_opener(urllib2.HTTPHandler)
    request = urllib2.Request(_url, data=json_data)
    request.add_header('Content-Type', 'application/json')
    request.get_method = lambda: 'PUT'
    response = opener.open(request)
    _status_code = response.getcode()
    _result = response.read()

    if _status_code < 200 or _status_code > 299:
        _message = 'OrderOut StarMicronics CPUtil error for %s' % (str(mediaType))
        data_dict = {'mediaType': mediaType,
                     'body': body,
                     'platform': 'linux64',
                     'result': _result,
                     'status_code': _status_code}
        report_error(500, subject='StarMicronics CPUtil Error', message=_message, data_dict=data_dict)
        return _url, _status_code, None
    return _url, _status_code, _result
