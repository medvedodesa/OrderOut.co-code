# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/08/2019
#

from flask import request, make_response
from flask_restplus import Resource, Namespace
from ..model.Printer import Printer
from ..model.Job import Job
from application.apis.ooexceptions import ResourceDoesNotExist, BadRequest
from application.core.exception import errorHandler
from ..service.common.crud import get_or_create_printer, notify_admin_new_printer_creation
from ..service.common.fetcher import fetch_printer_key_from_mac
from ..service.common.pairing import setup_printer_for_pairing
from ..service.starcloudprint.status import update_printer_status, update_job_status, format_printer_status_code_message
from ..service.starcloudprint.job import check_job_ready_for_printing, get_job_to_print, mark_job_as_printed
from application.core.error import report_error
from application.core.parser.string import sanitize_str
from ..service.pax.connect import create_pax_printer
from application.apis.restaurant.model import Restaurant
from application.apis.pointofsale.model.PointOfSale import PointOfSaleType
from application.apis.pointofsale.service.common import get_point_of_sale_for_restaurant
import logging
from ..service.clover.sandbox import convert_merchant_id_to_sandbox, convert_order_id_to_sandbox

nsApi = Namespace('pax', description='Printer Pax related operations.')

printer_marshal = nsApi.model('Printer', Printer.schema())

@nsApi.route('/connect')
class PrinterPaxConnect(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Connect Pax Printer')
    @nsApi.marshal_with(printer_marshal)
    # @errorHandler
    def post(self):
        json_dict = request.get_json()
        _device_uuid = json_dict.get('device_uuid')
        _device_product_name = json_dict.get('device_product_name')
        _restaurant_key = Restaurant.get_key(_restaurant_id)
        _point_of_sales = get_point_of_sale_for_restaurant(_restaurant_key)
        for _pos in _point_of_sales:
            if _pos.type == PointOfSaleType.CLOVER:
                _printer = create_pax_printer(point_of_sale_key=_pos.key)
                return _printer
        return None
