# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/08/2019
#

from flask import request
from flask_restplus import Resource, Namespace
from ..model.Printer import Printer
from application.apis.ooexceptions import ResourceDoesNotExist
from application.core.marshal import pagination_schema
from application.core.authentication.service import requires_auth_token
from application.core.exception import errorHandler
from application.apis.restaurant.model import Restaurant
from application.apis.order.model import Order
from ..service.common.pairing import pair_printer_with_restaurant_and_pairing_code, clear_pairing
from ..service.common.printjob import publish_order_print_job_for_restaurant, publish_pairing_is_successful_print_job
from application.apis.order.service.fetch import get_last_order_key_for_restaurant
from application.core.parser.string import sanitize_str
from ..service.common.fetcher import fetch_printer_key_from_mac
from ..service.common.formatter import format_fail_safe_order_with_full_info
from application.core.exception import NotFound
import logging


nsApi = Namespace('printer', description='Printer related operations.')

printer_marshal = nsApi.model('Printer', Printer.schema())
printers_pagination_marshal = nsApi.model('PrintersPagination', pagination_schema(printer_marshal))


######
# LIST
######

@nsApi.route('restaurant/<int:restaurant_id>/printers')
@nsApi.param('restaurant_id', 'Restaurant identifier')
class PrinterList(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('List Printers')
    @nsApi.response(200, 'OK', printers_pagination_marshal)
    @nsApi.marshal_with(printers_pagination_marshal)
    @errorHandler
    def get(self, restaurant_id):
        _restaurant = Restaurant.get_by_id(restaurant_id)
        if not _restaurant: raise NotFound
        _cursor = request.args.get('cursor', default=None, type=str)
        _objects, _previous_cursor, _next_cursor, _more = Printer.list_with_pagination_with_restaurant(restaurant_key=_restaurant.key, cursor=_cursor)
        return {'data': _objects,
                'previous_cursor': _previous_cursor.urlsafe() if _previous_cursor else None,
                'next_cursor': _next_cursor.urlsafe() if _next_cursor else None,
                'more': _more}

######
# CRUD
######

@nsApi.route('printer/pairing')
class PrinterPairing(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Check and pair')
    @nsApi.response(200, 'OK')
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    @nsApi.marshal_with(printer_marshal)
    # @errorHandler
    def post(self):
        json_dict = request.get_json()
        _restaurant_id = json_dict.get('restaurantId')
        _restaurant = Restaurant.get_by_id(_restaurant_id)
        _pairing_code = sanitize_str(json_dict.get('pairingCode'))
        _printer = pair_printer_with_restaurant_and_pairing_code(restaurant_key=_restaurant.key, pairing_code=_pairing_code)
        _jobs = publish_pairing_is_successful_print_job(_printer.key, _restaurant.account, _restaurant.key)
        return _printer

@nsApi.route('printer/<int:printer_id>')
@nsApi.param('printer_id', 'Printer identifier')
class PrinterGetDelete(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get a Printer')
    @nsApi.response(200, 'OK', printer_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(404, 'Not found')
    @nsApi.marshal_with(printer_marshal)
    @errorHandler
    def get(self, printer_id):
        _printer = Printer.get_by_id(printer_id)
        if not _printer: raise NotFound
        return _printer

    @nsApi.doc('Delete a Printer')
    @nsApi.response(200, 'OK')
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    @errorHandler
    def delete(self, printer_id):
        _printer = Printer.get_by_id(printer_id)
        clear_pairing(_printer.mac)
        _printer.delete()
        return {}

@nsApi.route('printer/search/<string:mac_address>')
@nsApi.param('mac_address', 'Printer MAC Address')
class PrinterGetSearch(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Get a Printer by Mac Address')
    @nsApi.response(200, 'OK', printer_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(404, 'Not found')
    @nsApi.marshal_with(printer_marshal)
    @errorHandler
    def get(self, mac_address):
        _printer_key = fetch_printer_key_from_mac(mac_address)
        _printer = _printer_key.get()
        if not _printer: raise NotFound
        return _printer

#########
# TESTING
#########

@nsApi.route('restaurant/<int:restaurant_id>/printers/test')
@nsApi.param('restaurant_id', 'Restaurant identifier')
class PrintersTestForRestaurant(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Test printing for all printers paired with restaurant')
    @nsApi.response(200, 'OK')
    # @errorHandler
    def get(self, restaurant_id):
        _restaurant = Restaurant.get_by_id(restaurant_id)
        if not _restaurant: raise NotFound
        _last_order_key = get_last_order_key_for_restaurant(_restaurant.key)
        if _last_order_key:
            logging.info("Printing a test order with id %s" % (str(_last_order_key.id())))
        _jobs = publish_order_print_job_for_restaurant(_restaurant.key,
                                                       _last_order_key,
                                                       testing=True,
                                                       doublePrinting=_restaurant.printDoubleOrder)
        return {'status': 'success'}
