# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/16/2019
#

from flask import request, make_response
from flask_restplus import Resource, Namespace
from ..model.Printer import Printer
from ..model.Job import Job
from application.apis.ooexceptions import ResourceDoesNotExist, BadRequest
from application.core.exception import errorHandler
from ..service.common.crud import get_or_create_printer, notify_admin_new_printer_creation
from ..service.common.fetcher import fetch_printer_key_from_mac
from ..service.common.pairing import setup_printer_for_pairing
from ..service.starcloudprint.status import update_printer_status, update_job_status, format_printer_status_code_message
from ..service.starcloudprint.job import check_job_ready_for_printing, get_job_to_print, mark_job_as_printed
from application.core.error import report_error
from application.core.parser.string import sanitize_str
from ..service.clover.connect import create_clover_printer
from application.apis.restaurant.model import Restaurant
from application.apis.pointofsale.model.PointOfSale import PointOfSaleType
from application.apis.pointofsale.service.common import get_point_of_sale_for_restaurant
import logging
from ..service.clover.sandbox import convert_merchant_id_to_sandbox, convert_order_id_to_sandbox

nsApi = Namespace('clover', description='Printer Clover related operations.')

printer_marshal = nsApi.model('Printer', Printer.schema())

@nsApi.route('/connect')
class PrinterCloverConnect(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Connect Clover Printer')
    @nsApi.marshal_with(printer_marshal)
    # @errorHandler
    def post(self):
        json_dict = request.get_json()
        _restaurant_id = json_dict.get('restaurant_id')
        _restaurant_key = Restaurant.get_key(_restaurant_id)
        _point_of_sales = get_point_of_sale_for_restaurant(_restaurant_key)
        for _pos in _point_of_sales:
            if _pos.type == PointOfSaleType.CLOVER:
                _printer = create_clover_printer(point_of_sale_key=_pos.key)
                return _printer
        return None

@nsApi.route('/')
class PrinterCloverPrint(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Printer polls the server at regular interval for status and actions')
    # @errorHandler
    def post(self):
        json_dict = request.get_json()
        _clover_merchant_id = json_dict.get('clover_merchant_id')
        _clover_merchant_id = convert_merchant_id_to_sandbox(_clover_merchant_id)
        try:
            _printer_key = fetch_printer_key_from_mac(_clover_merchant_id)
            _job_ready_for_printing = check_job_ready_for_printing(printer_key=_printer_key)
        except:
            _job_ready_for_printing = False
        # if _job_ready_for_printing: logging.error(_clover_merchant_id)
        response = {'jobReady': _job_ready_for_printing}
        logging.info(response)
        return response

    @nsApi.doc('Printer pulls a print job from the server to print it')
    # @errorHandler
    def get(self):
        parameters = request.args
        _clover_merchant_id = parameters.get('clover_merchant_id')
        _clover_merchant_id = convert_merchant_id_to_sandbox(_clover_merchant_id)

        # logging.error(_clover_merchant_id)

        _response = {}
        _printer_key = fetch_printer_key_from_mac(_clover_merchant_id)
        _job = get_job_to_print(printer_key=_printer_key)
        if _job:
            if not _job.body: return {}
            _clover_order_uuid = _job.body
            _clover_order_uuid = convert_order_id_to_sandbox(_clover_order_uuid)
            _response = {'job_id': str(_job.key.id()), 'clover_order_uuid': str(_clover_order_uuid)}
        logging.info(_response)
        return _response

    @nsApi.doc('Printer confirms job completion with the server')
    # @errorHandler
    def delete(self):
        parameters = request.args
        _job_id = parameters.get('job_id')
        _job_key = Job.get_key(_job_id)
        _success = mark_job_as_printed(_job_key)
        return {}
