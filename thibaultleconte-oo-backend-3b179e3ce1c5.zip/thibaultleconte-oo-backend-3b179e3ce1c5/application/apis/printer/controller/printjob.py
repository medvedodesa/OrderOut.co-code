# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/16/2019
#

from flask import request
from flask_restplus import Resource, Namespace, reqparse
from ..model.Printer import Printer
from ..model.Job import Job
from ..service.common.printjob import fetch_printjob_offset_pagination_for_printer, fetch_printjob_offset_pagination
from application.apis.ooexceptions import ResourceDoesNotExist
from application.core.marshal import pagination_schema
from application.core.authentication.service import requires_auth_token
from application.core.exception import errorHandler

nsApi = Namespace('printer', description='Printer related operations.')

print_job_marshal = nsApi.model('PrintJob', Job.schema())
print_job_marshal_no_body = nsApi.model('PrintJob', Job.schema(include_body=False))
print_job_pagination_marshal = nsApi.model('PrintJobsPagination', pagination_schema(print_job_marshal_no_body))


from google.appengine.api import memcache
from application.core.model.Base import get_mc_key_for_entity_key
from flask_restplus import marshal

def oo_marshal_list(data, fields):
    _result = []
    for _element_key in data:
        mc_key = get_mc_key_for_entity_key(_element_key, marshalled=True)
        mc_client = memcache.Client()
        __marshalled_element = mc_client.get(mc_key)
        if not __marshalled_element:
            _element = _element_key.get()
            if "{0}" in _element.body: _element.body.replace('{0}', '(0)')
            __marshalled_element = marshal(_element, fields)
            mc_client.set(mc_key, __marshalled_element)
        _result.append(__marshalled_element)
    return _result


@nsApi.route('printer/<int:printer_id>/jobs')
@nsApi.param('printer_id', 'Printer identifier')
class PrinterSpecificPrintJobsList(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('List Print Jobs')
    @nsApi.response(200, 'OK', print_job_pagination_marshal)
    #@nsApi.marshal_with(print_job_pagination_marshal)
    @errorHandler
    def get(self, printer_id):

        parser = reqparse.RequestParser()
        parser.add_argument('page', default=1, type=int)
        parser.add_argument('item_per_page', default=25, type=int)
        args = parser.parse_args()

        _printer = Printer.get_by_id(printer_id)
        if not _printer: raise NotFound

        _page = args.get('page')
        _item_per_page = min(args.get('item_per_page'), 100)

        _objects, _prev, _next, _count = fetch_printjob_offset_pagination_for_printer(printer_key=_printer.key, _page=_page, _item_per_page=_item_per_page)
        __marshalled_result = {'data': oo_marshal_list(_objects, print_job_marshal_no_body),
                               'prev': _prev,
                               'next': _next,
                               'page': _page,
                               'count': _count,
                               'item_per_page': _item_per_page}
        return __marshalled_result

@nsApi.route('printer/job/<int:job_id>')
@nsApi.param('job_id', 'Print Job identifier')
class PrinterSpecificPrintJobGet(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get a Print Job')
    @nsApi.response(200, 'OK', print_job_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(404, 'Not found')
    @nsApi.marshal_with(print_job_marshal)
    @errorHandler
    def get(self, job_id):
        return Job.get_by_id(job_id)

@nsApi.route('printjobs')
@nsApi.param('show_only_not_printed', 'Boolean value to only show print job not printed')
class PrintJobsList(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('List Print Jobs')
    @nsApi.response(200, 'OK', print_job_pagination_marshal)
    #@nsApi.marshal_with(print_job_pagination_marshal)
    # @errorHandler
    def get(self):

        parser = reqparse.RequestParser()
        parser.add_argument('show_only_not_printed', default=0, type=int)
        parser.add_argument('page', default=1, type=int)
        parser.add_argument('item_per_page', default=25, type=int)
        args = parser.parse_args()

        _show_only_not_printed = bool(args.get('show_only_not_printed', 0))
        _page = args.get('page')
        _item_per_page = min(args.get('item_per_page'), 100)

        import logging
        logging.info(_show_only_not_printed)

        _objects, _prev, _next, _count = fetch_printjob_offset_pagination(show_only_not_printed=_show_only_not_printed, _page=_page, _item_per_page=_item_per_page)
        __marshalled_result = {'data': oo_marshal_list(_objects, print_job_marshal_no_body),
                               'prev': _prev,
                               'next': _next,
                               'page': _page,
                               'count': _count,
                               'item_per_page': _item_per_page}
        return __marshalled_result
