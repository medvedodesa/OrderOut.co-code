# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/13/2019
#

from flask import request
from flask_restplus import Resource, Namespace
from werkzeug.exceptions import BadRequest

from .model import Restaurant
from application.apis.user.model.User import User, UserRole, ROLE_MAPPING
from .service import get_by_id_and_populate, check_and_create_with_name
from application.apis.ooexceptions import ResourceDoesNotExist, NotFound, ConflictResourceAlreadyExistsError
from application.core.marshal import create_schema, pagination_schema
from application.apis.authentication import errorHandler
from application.apis.account.model import Account
from application.core.authentication.service import requires_auth_token
from application.core.email.service import send_email_from_dashboard_with_instructions_to_setup_doordash_grubhub

nsApi = Namespace('restaurant', description='Restaurant related operations.')

restaurant_marshal = nsApi.model('Restaurant', Restaurant.schema())
restaurants_create_marshal = nsApi.model('RestaurantsCreate', create_schema(restaurant_marshal))
restaurants_pagination_marshal = nsApi.model('RestaurantsPagination', pagination_schema(restaurant_marshal))
user_marshal = nsApi.model('User', User.schema())
users_create_marshal = nsApi.model('UsersCreate', create_schema(user_marshal))


@nsApi.route('account/<int:account_id>/restaurants')
class RestaurantList(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('List Restaurants')
    @nsApi.response(200, 'OK', restaurants_pagination_marshal)
    @nsApi.marshal_with(restaurants_pagination_marshal)
    @errorHandler
    def get(self, account_id):
        _account = Account.get_by_id(account_id)
        if not _account: raise NotFound
        _cursor = request.args.get('cursor', default=None, type=str)
        _elements, _previous_cursor, _next_cursor, _more = Restaurant.list_with_pagination_with_account(account_key=_account.key, cursor=_cursor)
        return {'data': _elements,
                'previous_cursor': _previous_cursor.urlsafe() if _previous_cursor else None,
                'next_cursor': _next_cursor.urlsafe() if _next_cursor else None,
                'more': _more}

@nsApi.route('restaurant')
class RestaurantCreate(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Create an Restaurant')
    @nsApi.response(200, 'OK', restaurant_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(400, 'Bad Request')
    @nsApi.expect(restaurants_create_marshal, validate=True)
    @nsApi.marshal_with(restaurant_marshal)
    @errorHandler
    def post(self):
        json_dict = request.get_json()
        _account_id = json_dict['parent_id']
        _account = Account.get_by_id(_account_id)
        _entity = json_dict['entity']
        _name = _entity['name']
        return check_and_create_with_name(_name, account_key=_account.key)

@nsApi.route('restaurant/<int:restaurant_id>')
@nsApi.param('restaurant_id', 'Restaurant identifier')
class UserRestaurantGetPutDelete(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get a Restaurant')
    @nsApi.response(200, 'OK', restaurant_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(404, 'Not found')
    @nsApi.marshal_with(restaurant_marshal)
    @errorHandler
    def get(self, restaurant_id):
        try:
            return Restaurant.get_by_id(restaurant_id)
        except ResourceDoesNotExist:
            nsApi.abort(404, 'Not found')
        except NotFound:
            nsApi.abort(404, 'Not found')
        except Exception as e:
            import logging
            logging.error(e)
            nsApi.abort(400, 'Bad request')
        # TODO: Move to something like these to HANDLE ERRORS https://opensource.com/article/17/3/python-flask-exceptions

    @nsApi.doc('Update a Restaurant')
    @nsApi.response(200, 'OK', restaurant_marshal)
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    @nsApi.expect(restaurant_marshal, validate=True)
    @nsApi.marshal_with(restaurant_marshal)
    @errorHandler
    def put(self, restaurant_id):
        json_dict = request.get_json()
        try:
            return get_by_id_and_populate(restaurant_id, json_dict)
        except ResourceDoesNotExist:
            nsApi.abort(404, 'Not found')
        except NotFound:
            nsApi.abort(404, 'Not found')
        except ConflictResourceAlreadyExistsError:
            nsApi.abort(409, 'Resource already exists')
        except Exception as e:
            import logging
            logging.error(e)
            nsApi.abort(400, 'Bad request')
        # TODO: Move to something like these to HANDLE ERRORS https://opensource.com/article/17/3/python-flask-exceptions

    @nsApi.doc('Delete a Restaurant')
    @nsApi.response(200, 'OK')
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    @errorHandler
    def delete(self, restaurant_id):
        try:
            Restaurant.delete_by_id(restaurant_id)
        except ResourceDoesNotExist:
            nsApi.abort(404, 'Not found')
        except NotFound:
            nsApi.abort(404, 'Not found')
        except Exception as e:
            import logging
            logging.error(e)
            nsApi.abort(400, 'Bad request')
        # TODO: Move to something like these to HANDLE ERRORS https://opensource.com/article/17/3/python-flask-exceptions
        return {}

@nsApi.route('restaurant/<int:restaurant_id>/email/ds_setup_instructions')
@nsApi.param('restaurant_id', 'Restaurant identifier')
class UserRestaurantEmailPost(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Send Delivery Service Setup Instructions')
    @nsApi.response(200, 'OK', restaurant_marshal)
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    @nsApi.marshal_with(restaurant_marshal)
    @errorHandler
    def post(self, restaurant_id):
        json_dict = request.get_json()
        _recipient_email = json_dict.get('recipient_email')
        try:
            _restaurant = Restaurant.get_by_id(restaurant_id)
            _account = _restaurant.account.get()
            _doordash_email = None
            _grubhub_email = None
            _chownow_email = None
            send_email_from_dashboard_with_instructions_to_setup_doordash_grubhub(recipient_email=_recipient_email,
                                                                                  account_name=_account.name,
                                                                                  doordash_email=_doordash_email,
                                                                                  grubhub_email=_grubhub_email,
                                                                                  chownow_email=_chownow_email)
            return _restaurant
        except ResourceDoesNotExist:
            nsApi.abort(404, 'Not found')
        except NotFound:
            nsApi.abort(404, 'Not found')
        except ConflictResourceAlreadyExistsError:
            nsApi.abort(409, 'Resource already exists')
        except Exception as e:
            import logging
            logging.error(e)
            nsApi.abort(400, 'Bad request')


@nsApi.route("restaurant/<int:restaurant_id>/user")
@nsApi.param("restaurant_id", "Restaurant identifier")
class RestaurantUserGetPost(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc("List Restaurant's Users")
    @nsApi.response(200, "OK", user_marshal)
    @nsApi.marshal_with(user_marshal)
    @errorHandler
    def get(self, restaurant_id):
        _restaurant = Restaurant.get_by_id(restaurant_id)
        if not _restaurant:
            raise NotFound
        users = _restaurant.users
        response = []
        for u in users:
            if u and u.get():
                response.append(u.get())
        return response

    @nsApi.doc("Create a Restaurant's User")
    @nsApi.response(200, "OK", user_marshal)
    @nsApi.response(409, "Conflict with other resource")
    @nsApi.response(400, "Bad Request")
    @nsApi.expect(users_create_marshal, validate=True)
    @nsApi.marshal_with(user_marshal)
    @errorHandler
    def post(self, restaurant_id):
        json_dict = request.get_json()
        email = json_dict.pop("email", None)
        role = json_dict.pop("role", "")
        role = role.lower()

        if role:
            if role not in ROLE_MAPPING:
                raise BadRequest

            role = ROLE_MAPPING[role]
            json_dict["role"] = role

        if not email:
            raise BadRequest

        restaurant = Restaurant.get_by_id(restaurant_id)
        if not restaurant:
            raise NotFound

        user = User.get_by_email(email)
        if not user:
            user = User.create_and_populate(email, json_dict, role=role)

        restaurant.add_user(user.key)
        return user


@nsApi.route("restaurant/<int:restaurant_id>/user/<int:user_id>")
@nsApi.param("restaurant_id", "Restaurant identifier")
@nsApi.param("user_id", "User identifier")
class RestaurantUserDelete(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc("Delete a Restaurant's User")
    @nsApi.response(200, "OK")
    @nsApi.response(404, "Not found")
    @nsApi.response(400, "Bad Request")
    @errorHandler
    def delete(self, restaurant_id, user_id):
        try:
            user = User.get_by_id(user_id)
            restaurant = Restaurant.get_by_id(restaurant_id)
            if not restaurant:
                raise NotFound

            if user.role == UserRole.OWNER:
                raise BadRequest

            restaurant.remove_user(user.key)
        except ResourceDoesNotExist:
            nsApi.abort(404, "Not found")
        except NotFound:
            nsApi.abort(404, "Not found")
        except Exception as e:
            import logging

            logging.error(e)
            nsApi.abort(400, "Bad request")
        return {}

    @nsApi.doc("Edit a Restaurant's User")
    @nsApi.response(200, "OK")
    @nsApi.response(404, "Not found")
    @nsApi.response(400, "Bad Request")
    @nsApi.marshal_with(user_marshal)
    @errorHandler
    def put(self, restaurant_id, user_id):
        try:
            json_dict = request.get_json()

            role = json_dict.pop("role", "")
            role = role.lower()

            if role:
                if role not in ROLE_MAPPING:
                    raise BadRequest

                role = ROLE_MAPPING[role]
                json_dict["role"] = role

            restaurant = Restaurant.get_by_id(restaurant_id)
            if not restaurant:
                raise NotFound

            _user = User.get_by_id_and_populate(user_id, json_dict)
            return _user

        except ResourceDoesNotExist:
            nsApi.abort(404, "Not found")
        except NotFound:
            nsApi.abort(404, "Not found")
        except Exception as e:
            import logging

            logging.error(e)
            nsApi.abort(400, "Bad request")
