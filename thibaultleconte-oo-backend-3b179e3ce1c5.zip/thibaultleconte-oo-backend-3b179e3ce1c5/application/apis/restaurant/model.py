# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/13/2019
#

from google.appengine.api import search
from google.appengine.ext import ndb, deferred

from application.core.google_search_api.constants import PUT_HOOK_QUEUE
from application.core.model.Base import Base
from flask_restplus import fields, marshal
from application.core.marshal import SchemaFieldKeyFormatter
from application.apis.account.model import AccountSchemaFieldFromKeyFormatter


class Restaurant(Base):
    name = ndb.StringProperty(required=True)
    account = ndb.KeyProperty(required=True)
    group = ndb.KeyProperty()
    point_of_sale = ndb.KeyProperty()
    delivery_services = ndb.KeyProperty(repeated=True)
    street_address_1 = ndb.StringProperty(default='')
    street_address_2 = ndb.StringProperty(default='')
    street_address_3 = ndb.StringProperty(default='')
    city = ndb.StringProperty(default='')
    zipcode = ndb.StringProperty(default='')
    state = ndb.StringProperty(default='')
    country = ndb.StringProperty(default='')
    phone_number = ndb.StringProperty(default='')
    printDoubleOrder = ndb.BooleanProperty(default=False)
    preparation_time = ndb.IntegerProperty(default=900)  # in seconds -> Default 15 minutes
    contacts = ndb.KeyProperty(repeated=True)  # restaurant.Contact
    users = ndb.KeyProperty(repeated=True)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls, with_point_of_sale=True, with_account=False):
        schema = super(cls, cls).schema()
        schema['name'] = fields.String(required=True, description="Name")
        if not with_account: schema['accountId'] = SchemaFieldKeyFormatter(attribute='account', description="Account Id")
        if with_account: schema['account'] = AccountSchemaFieldFromKeyFormatter(attribute='account', description='Account')
        if with_point_of_sale: schema['pointOfSaleId'] = SchemaFieldKeyFormatter(attribute='point_of_sale', description="Point Of Sale Id")
        schema['printDoubleOrder'] = fields.Boolean(description="Print 2 Order Receipts")
        schema['preparation_time'] = fields.Integer(description="Kitchen Preparation Time in Seconds")
        schema['street_address_1'] = fields.String()
        schema['street_address_2'] = fields.String()
        schema['street_address_3'] = fields.String()
        schema['city'] = fields.String()
        schema['zipcode'] = fields.String()
        schema['state'] = fields.String()
        schema['country'] = fields.String()
        schema['phone_number'] = fields.String()
        schema['account_name'] = fields.String()

        return schema

    @property
    def owners(self):
        resp = []
        for u in self.users:
            if u:
                user = u.get()
                if user and user.is_owner:
                    resp.append(user)
        return resp


    ###################
    # List & Pagination
    ###################

    @classmethod
    def list_with_pagination_with_account(cls, account_key, cursor=None, limit=25):
        _cursor =ndb.Cursor(urlsafe=cursor) if cursor else None
        _query = Restaurant.query()
        _query = _query.filter(Restaurant.account == account_key)
        _query = _query.order(Restaurant.name, -Restaurant.api_created_at)
        _objects, _next_cursor, _more = _query.fetch_page(limit, start_cursor=_cursor)
        _previous_cursor = _next_cursor.reversed() if _next_cursor else None
        return _objects, _previous_cursor, _next_cursor, _more

    @classmethod
    def list_with_pagination_with_group(cls, group_key, cursor=None, limit=25):
        _cursor =ndb.Cursor(urlsafe=cursor) if cursor else None
        _query = Restaurant.query()
        _query = _query.filter(Restaurant.group == group_key)
        _objects, _next_cursor, _more = _query.fetch_page(limit, start_cursor=_cursor)
        _previous_cursor = _next_cursor.reversed() if _next_cursor else None
        return _objects, _previous_cursor, _next_cursor, _more

    ######
    # CRUD
    ######

    @classmethod
    def create(cls, name, account_key):
        _obj = cls()
        _obj.name = name
        _obj.account = account_key
        _obj.put()
        return _obj

    @classmethod
    def put_search_document(cls, restaurant_id):
        restaurant = cls.get_by_id(restaurant_id)
        if restaurant:
            address = "{} {} {} {} {} {} {}".format(
                restaurant.street_address_1,
                restaurant.street_address_2,
                restaurant.street_address_3,
                restaurant.zipcode,
                restaurant.city,
                restaurant.state,
                restaurant.country,

            )
            document = search.Document(
                doc_id=str(restaurant.id),
                fields=[
                    search.TextField(name='name', value=restaurant.name),
                    search.TextField(name='address', value=address),
                ])
            index = search.Index(name="RestaurantIndex")
            index.put(document)

    def add_user(self, user_key):
        if user_key and user_key not in self.users:
            self.users.append(user_key)
            self.put()

            user = user_key.get()
            if user and self.key not in user.restaurants:
                user.restaurants.append(self.key)
                user.put()

        account = self.account.get()
        account.add_user(user_key)

    def remove_user(self, user_key):
        try:
            self.users.remove(user_key)
            self.put()
            user = user_key.get()
            if user and self.key in user.restaurants:
                user.restaurants.remove(self.key)
                user.put()
        except ValueError:
            pass

    def add_users(self, user_keys):
        for user_key in user_keys:
            self.add_user(user_key)

    def _post_put_hook(self, future):
        deferred.defer(
            self.__class__.put_search_document,
            self.id,
            _transactional=ndb.in_transaction(),
            _queue=PUT_HOOK_QUEUE,
        )

    @property
    def entity_name(self):
        return "restaurant"

    @property
    def account_name(self):
        if self.account:
            account = self.account.get()
            if account:
                return account.name


class RestaurantSchemaFieldFromKeyFormatter(fields.Raw):
    def format(self, value):
        if value:
            return marshal(value.get(), Restaurant.schema())
        return None
