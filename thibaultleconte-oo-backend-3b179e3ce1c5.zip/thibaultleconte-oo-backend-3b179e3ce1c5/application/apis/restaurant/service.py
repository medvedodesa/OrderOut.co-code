# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/14/2019
#

from .model import Restaurant
from application.apis.ooexceptions import ResourceDoesNotExist, ConflictResourceAlreadyExistsError
from datetime import datetime
import logging


def get_by_name(name, account_key):
    _query = Restaurant.query()
    _query = _query.filter(Restaurant.name == name)
    _query = _query.filter(Restaurant.account == account_key)
    _result = _query.fetch(1)
    if len(_result) > 0: return _result[0]
    return _result


def exists_with_name(name, account_key):
    _account = account_key.get()
    if not _account: raise ResourceDoesNotExist
    _query = Restaurant.query()
    _query = _query.filter(Restaurant.name == name)
    _query = _query.filter(Restaurant.account == _account.key)
    result = _query.count()
    return True if result > 0 else False


def check_and_create_with_name(name, account_key):
    _account = account_key.get()
    if not _account: raise ResourceDoesNotExist
    if exists_with_name(name=name, account_key=_account.key):
        logging.error("Restaurant name \"%s\" already exists in account id %s" % (str(name), str(account_key.id())))
        raise ConflictResourceAlreadyExistsError
    return Restaurant.create(name=name, account_key=_account.key)


def get_by_id_and_populate(id, json_dict):
    _obj = Restaurant.get_by_id(id)
    if not _obj: raise ResourceDoesNotExist
    _name = json_dict.get('name', None)
    if _name:
        if _obj.name != _name and exists_with_name(_name, _obj.account):
            raise ConflictResourceAlreadyExistsError
    _obj.populate(**json_dict)
    _obj.put()
    return _obj


def add_to_group(restaurant_key, group_key):
    _restaurant = restaurant_key.get()
    if not _restaurant: raise ResourceDoesNotExist
    _group = group_key.get()
    if not _group: raise ResourceDoesNotExist
    _restaurant.group = _group.key
    _restaurant.put()
    return _restaurant


def remove_from_group(restaurant_key):
    _restaurant = restaurant_key.get()
    if not _restaurant: raise ResourceDoesNotExist
    _restaurant.group = None
    _restaurant.put()
    return _restaurant


def get_preparation_time_utc_timestamp(restaurant_key):
    _restaurant = restaurant_key.get()
    if not _restaurant: raise ResourceDoesNotExist
    current_utc = int(datetime.now().strftime("%s"))
    preparation_time_utc = current_utc + _restaurant.preparation_time
    return preparation_time_utc

