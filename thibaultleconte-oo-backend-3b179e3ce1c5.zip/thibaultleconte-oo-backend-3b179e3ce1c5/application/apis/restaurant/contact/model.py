from google.appengine.ext import ndb, deferred

from application.core.model.Base import Base
from flask_restplus import fields


class Contact(Base):
    restaurant = ndb.KeyProperty(required=True)
    name = ndb.StringProperty(required=True)
    email = ndb.StringProperty(required=False)
    phone_number = ndb.StringProperty(required=False)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema["name"] = fields.String(required=True, description="Contact name")
        schema["email"] = fields.String(description="Contact e-mail")
        schema["phone_number"] = fields.String(description="Contact phone number")
        return schema

    ###################
    # List & Pagination
    ###################

    @classmethod
    def list_with_pagination(cls, restaurant_key, cursor=None, limit=25):
        _cursor = ndb.Cursor(urlsafe=cursor) if cursor else None
        _query = Contact.query()
        _query = _query.filter(Contact.restaurant == restaurant_key)
        _query = _query.order(Contact.name, -Contact.api_created_at)
        _objects, _next_cursor, _more = _query.fetch_page(limit, start_cursor=_cursor)
        _previous_cursor = _next_cursor.reversed() if _next_cursor else None
        return _objects, _previous_cursor, _next_cursor, _more

    ######
    # CRUD
    ######

    @classmethod
    def create(cls, restaurant_key, json_dict):
        _obj = cls()
        _obj.restaurant = restaurant_key
        _obj.name = json_dict["name"]
        _obj.email = json_dict["email"]
        _obj.phone_number = json_dict["phone_number"]
        _obj.put()
        return _obj
