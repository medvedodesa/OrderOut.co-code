from flask import request
from flask_restplus import Resource, Namespace
from application.apis.restaurant.contact.model import Contact
from application.apis.restaurant.model import Restaurant
from application.apis.restaurant.contact.service import add_contact, remove_contact
from application.apis.ooexceptions import ResourceDoesNotExist, NotFound
from application.core.marshal import create_schema, pagination_schema
from application.apis.authentication import errorHandler
from application.core.authentication.service import requires_auth_token

nsApi = Namespace("contact", description="Restaurant Contact related operations.")

restaurant_marshal = nsApi.model("Restaurant", Restaurant.schema())
restaurants_create_marshal = nsApi.model("RestaurantsCreate", create_schema(restaurant_marshal))
restaurants_pagination_marshal = nsApi.model(
    "RestaurantsPagination", pagination_schema(restaurant_marshal)
)
contact_marshal = nsApi.model("Contact", Contact.schema())
contacts_create_marshal = nsApi.model("ContactsCreate", create_schema(contact_marshal))
contacts_pagination_marshal = nsApi.model("ContactsPagination", pagination_schema(contact_marshal))


@nsApi.route("restaurant/<int:restaurant_id>/contact")
@nsApi.param("restaurant_id", "Restaurant identifier")
class RestaurantContactGetPost(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc("List Restaurant's Contacts")
    @nsApi.response(200, "OK", contacts_pagination_marshal)
    @nsApi.marshal_with(contacts_pagination_marshal)
    @errorHandler
    def get(self, restaurant_id):
        _restaurant = Restaurant.get_by_id(restaurant_id)
        if not _restaurant:
            raise NotFound
        _cursor = request.args.get("cursor", default=None, type=str)
        _elements, _previous_cursor, _next_cursor, _more = Contact.list_with_pagination(
            restaurant_key=_restaurant.key, cursor=_cursor
        )
        return {
            "data": _elements,
            "previous_cursor": _previous_cursor.urlsafe() if _previous_cursor else None,
            "next_cursor": _next_cursor.urlsafe() if _next_cursor else None,
            "more": _more,
        }

    @nsApi.doc("Create a Restaurant's Contact")
    @nsApi.response(200, "OK", contact_marshal)
    @nsApi.response(409, "Conflict with other resource")
    @nsApi.response(400, "Bad Request")
    @nsApi.expect(contacts_create_marshal, validate=True)
    @nsApi.marshal_with(contact_marshal)
    @errorHandler
    def post(self, restaurant_id):
        json_dict = request.get_json()
        restaurant = Restaurant.get_by_id(restaurant_id)
        if not restaurant:
            raise NotFound

        contact = Contact.create(restaurant.key, json_dict)
        add_contact(restaurant, contact)
        return contact


@nsApi.route("restaurant/<int:restaurant_id>/contact/<int:contact_id>")
@nsApi.param("restaurant_id", "Restaurant identifier")
@nsApi.param("contact_id", "Contact identifier")
class RestaurantContactDelete(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc("Delete a Restaurant's Contact")
    @nsApi.response(200, "OK")
    @nsApi.response(404, "Not found")
    @nsApi.response(400, "Bad Request")
    @errorHandler
    def delete(self, restaurant_id, contact_id):
        try:
            contact = Contact.delete_by_id(contact_id)
            restaurant = Restaurant.get_by_id(restaurant_id)
            if not restaurant:
                raise NotFound
            remove_contact(restaurant, contact)
        except ResourceDoesNotExist:
            nsApi.abort(404, "Not found")
        except NotFound:
            nsApi.abort(404, "Not found")
        except Exception as e:
            import logging

            logging.error(e)
            nsApi.abort(400, "Bad request")
        return {}
