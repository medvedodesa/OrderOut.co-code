def add_contact(restaurant, contact):
    restaurant.contacts.append(contact.key)
    restaurant.put()


def remove_contact(restaurant, contact):
    restaurant.contacts.remove(contact.key)
    restaurant.put()
