# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/13/2019
#

from google.appengine.ext import ndb
from application.core.model.Base import Base
from flask_restplus import fields
from application.apis.restaurant.controller import restaurant_marshal
from application.apis.ooexceptions import BadRequest


class Group(Base):
    name = ndb.StringProperty(required=True)
    account = ndb.KeyProperty(required=True)
    restaurants = ndb.KeyProperty(repeated=True)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema['name'] = fields.String(required=True, description="Name")
        schema['restaurants'] = fields.List(fields.Nested(restaurant_marshal))
        return schema

    ###################
    # List & Pagination
    ###################

    @classmethod
    def list_with_pagination(cls, account_key, _next_cursor=None, limit=25, keys_only=False):
        _cursor =ndb.Cursor(urlsafe=_next_cursor) if _next_cursor else None
        _query = Group.query()
        _query = _query.filter(Group.account == account_key)
        _objects, _next_cursor, _more = _query.fetch_page(limit, start_cursor=_cursor)
        _previous_cursor = _next_cursor.reversed() if _next_cursor else None
        _count = _query.count(deadline=30, limit=1000, start_cursor=None, end_cursor=None)
        return _objects, _previous_cursor, _next_cursor, _more, _count

    ######
    # CRUD
    ######

    @classmethod
    def create(cls, name, account_key):
        _obj = cls()
        _obj.name = name
        _obj.account = account_key
        _obj.put()
        return _obj

    def delete(self):
        if len(self.restaurants) > 0: raise ooexceptions.BadRequest
        super(Group, self).delete()
        return self
