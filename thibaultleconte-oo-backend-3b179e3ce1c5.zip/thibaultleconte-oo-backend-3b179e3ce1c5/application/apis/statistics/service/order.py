# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 08/01/2019
#

from flask import current_app
from application.core.gcloud.bigquery.helper import get_project_name, get_database_name
from application.core.gcloud.bigquery.fetcher import fetch
from application.core.settings.app import get_config_for_key
from google.appengine.api import memcache

STATS_MC_PREFIX_KEY = 'STATS_'
CACHE_DURATION_SECONDS = 300


def query_nb_orders_today():
    _mc_key = STATS_MC_PREFIX_KEY + 'nb_orders_today'
    _query = """
    SELECT COUNT(*)
    FROM `%s.%s.%s`
    WHERE api_created_at >= DATETIME(CURRENT_DATE())
    """ % (get_project_name(), get_database_name(), __get_table_name())
    _result = __get_cached_or_big_query(_mc_key, _query)
    return _result

def query_nb_orders_last_days(since_nb_days=0):
    _mc_key = STATS_MC_PREFIX_KEY + 'nb_orders_last_days_' + str(since_nb_days)
    _query = """
    SELECT COUNT(*)
    FROM `%s.%s.%s`
    WHERE api_created_at >= DATETIME(DATE_ADD(CURRENT_DATE(), INTERVAL -%s DAY))
    AND api_created_at < DATETIME(CURRENT_DATE())
    """ % (get_project_name(), get_database_name(), __get_table_name(), since_nb_days)
    _result = __get_cached_or_big_query(_mc_key, _query)
    return _result

def query_nb_orders_total():
    _mc_key = STATS_MC_PREFIX_KEY + 'nb_orders_total'
    _query = """
    SELECT COUNT(*)
    FROM `%s.%s.%s`
    """ % (get_project_name(), get_database_name(), __get_table_name())
    _result = __get_cached_or_big_query(_mc_key, _query)
    return _result

#########
# HELPERS
#########

def __get_cached_or_big_query(mc_key, query):
    # CACHE GET
    _mc_client = memcache.Client()
    _result = _mc_client.get(mc_key)
    # CACHE SET
    if not _result:
        _result = fetch(query)
        _result_ = -1 if _result == 0 else _result
        _mc_client.set(mc_key, _result, time=CACHE_DURATION_SECONDS)
    _result = 0 if _result < 0 else _result
    return _result

def __get_table_name():
    from application import app
    with app.app_context(): _dataset_name = get_config_for_key('GCLOUD_BIGQUERY_TABLE_ORDER')
    return _dataset_name
