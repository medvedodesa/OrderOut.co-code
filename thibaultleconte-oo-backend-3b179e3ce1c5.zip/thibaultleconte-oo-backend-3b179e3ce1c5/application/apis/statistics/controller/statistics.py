# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 07/09/2019
#

from flask import request
from flask_restplus import Resource, Namespace, reqparse
from application.core.authentication.service import requires_auth_token
from application.core.exception import errorHandler
from application.apis.statistics.service.order import query_nb_orders_total, query_nb_orders_today, query_nb_orders_last_days
from application.core.settings.app import get_config_for_key


nsApi = Namespace('statistics', description='Statistics related operations.')

# order_marshal = nsApi.model('Order', Order.schema())
# orders_pagination_marshal = nsApi.model('OrdersPagination', pagination_schema(order_marshal))


@nsApi.route('/')
class StatisticsGet(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get Global Stats')
    # @nsApi.response(200, 'OK', orders_pagination_marshal)
    # @nsApi.marshal_with(orders_pagination_marshal)
    @errorHandler
    def get(self):
        _order_today = query_nb_orders_today()
        _order_yesterday = query_nb_orders_last_days(since_nb_days=1)
        _order_last_7_days = query_nb_orders_last_days(since_nb_days=7)
        _order_last_30_days = query_nb_orders_last_days(since_nb_days=30)
        _orders_total = query_nb_orders_total()
        return {'order_total': _orders_total,
                'order_last_30_days': _order_last_30_days,
                'order_last_7_days': _order_last_7_days,
                'order_yesterday': _order_yesterday,
                'order_today': _order_today}

@nsApi.route('/orders/today')
class StatisticsGetOrdersToday(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get Order Today Stats')
    # @nsApi.response(200, 'OK', orders_pagination_marshal)
    # @nsApi.marshal_with(orders_pagination_marshal)
    @errorHandler
    def get(self):
        _order_today = query_nb_orders_today()
        return {"item": [{"value": _order_today, "text": "Orders today"}]}

@nsApi.route('/orders/last_7_days')
class StatisticsGetOrdersWeek(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get Order Last 7 Days Stats')
    # @nsApi.response(200, 'OK', orders_pagination_marshal)
    # @nsApi.marshal_with(orders_pagination_marshal)
    @errorHandler
    def get(self):
        _order_last_7_days = query_nb_orders_last_days(since_nb_days=7)
        return {"item": [{"value": _order_last_7_days, "text": "Orders in last 7 days"}]}

@nsApi.route('/orders/total')
class StatisticsGetOrdersTotal(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get Order Total Stats')
    # @nsApi.response(200, 'OK', orders_pagination_marshal)
    # @nsApi.marshal_with(orders_pagination_marshal)
    @errorHandler
    def get(self):
        _order_total = query_nb_orders_total()
        return {"item": [{"value": _order_total, "text": "Total Orders"}]}

@nsApi.route('/test/<string:phone_number>')
@nsApi.param('phone_number', 'phone_number')
class StatisticsTest(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Get Order Total Stats')
    # @nsApi.response(200, 'OK', orders_pagination_marshal)
    # @nsApi.marshal_with(orders_pagination_marshal)
    # @errorHandler
    def get(self, phone_number):
        from application.core.twilio.call import trigger_call_for_clover_onboarding
        _result_json, _status_code = trigger_call_for_clover_onboarding(phone_number)
        return _result_json

@nsApi.route('/test')
class StatisticsTestT(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Get Order Total Stats')
    # @nsApi.response(200, 'OK', orders_pagination_marshal)
    # @nsApi.marshal_with(orders_pagination_marshal)
    # @errorHandler
    def get(self):
        response = 200

        from application.core.task.service import startDeferredTask
        startDeferredTask(start_deferred_task_export_clover_lead)

        return response

def start_deferred_task_export_clover_lead():
    from application.apis.pointofsale.model.CloverLead import CloverLead
    _all_leads = CloverLead.query(all_status=True).fetch()
    result ='export\n'
    for _lead in _all_leads:
        result += "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n" % (str(_lead.account_name), str(_lead.street_address_1), str(_lead.street_address_2), str(_lead.street_address_3), str(_lead.city), str(_lead.zipcode), str(_lead.state), str(_lead.phone_number), str(_lead.owner_name), str(_lead.owner_email), str(_lead.api_created_at))
    import logging
    logging.info(result)
    from application.core.email.service import send_admin_email
    from application.core.settings.app import get_config_for_key
    send_admin_email(recipients=get_config_for_key('EMAIL_TO_ADMINS'), subject='Clover Lead Export', body=result)
    return
