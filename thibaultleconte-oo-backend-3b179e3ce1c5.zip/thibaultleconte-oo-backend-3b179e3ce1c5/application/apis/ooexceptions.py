# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

class BaseException(Exception):
    def __init__(self):
        Exception.__init__(self)
        self.status_code = 400
        self.message = "Unknown"

    def json(self):
        return {'status_code': self.status_code,
                'message': self.message}


class BadRequest(BaseException):
    def __init__(self):
        self.status_code = 400
        self.message = "BadRequest"


class Unauthorized(BaseException):
    def __init__(self):
        self.status_code = 401
        self.message = "Unauthorized"


class NotFound(BaseException):
    def __init__(self):
        self.status_code = 404
        self.message = "Not Found"


class ConflictResourceAlreadyExistsError(BaseException):
    def __init__(self):
        self.status_code = 409
        self.message = "Resource already exists"


class IncorrectPassword(BaseException):
    def __init__(self):
        self.status_code = 400
        self.message = "Incorrect password"


class ResourceDoesNotExist(BaseException):
    def __init__(self):
        self.status_code = 410
        self.message = "Resource does not exist"


class InternalServerError(BaseException):
    def __init__(self):
        self.status_code = 500
        self.message = "Internal Server Error"

class PrinterAlreadyPairedError(BaseException):
    def __init__(self):
        self.status_code = 400
        self.message = "Printer Already Paired"
