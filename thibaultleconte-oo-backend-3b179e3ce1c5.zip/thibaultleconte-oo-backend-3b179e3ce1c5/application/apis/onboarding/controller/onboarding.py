# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/22/2019
#

from flask import request
from flask_restplus import Resource, Namespace, marshal
from application.apis.account.model import Account
from application.apis.restaurant.model import Restaurant
from application.apis.pointofsale.model.PointOfSale import PointOfSale
from application.apis.deliveryservice.model.DeliveryService import DeliveryService, DeliveryServiceType
from application.apis.printer.model.Printer import Printer
from application.apis.deliveryservice.service.common.fetch import get_delivery_services_for_restaurant, generate_list_delivery_services_available
from application.apis.printer.service.common.fetcher import fetch_paired_printers_for_restaurant
from application.core.marshal import oo_marshal_list
from application.apis.deliveryservice.service.common.crud import create_from_public_menu_url
from application.core.email.service import send_email_to_onboarding_team
from application.core.slack.onboarding import post_to_self_onboarding_for_new_delivery_service
from flask import url_for
import logging
from application.core.settings.app import get_config_for_key

nsApi = Namespace('Onboarding', description='Get and Update Onboarding information')

ds_marshal = nsApi.model('DeliveryService', DeliveryService.schema())
printer_marshal = nsApi.model('Printer', Printer.schema())

@nsApi.route('/<string:restaurant_id>')
class OnboardingRestaurantGetPut(Resource):

    @nsApi.doc('Get onboarding information for restaurant')
    def get(self, restaurant_id):
        logging.info("Get onboarding")

        # GLOBAL SETTINGS
        #################

        _list_ds_active_to_connect = generate_list_delivery_services_available()

        _marshalled_global_settings = {'ds_available': _list_ds_active_to_connect}

        # RESTAURANT STATUS
        ###################

        # Restaurant Details
        _restaurant = Restaurant.get_by_id(restaurant_id)
        # Account Details
        _account = _restaurant.account.get()
        # POS Details
        _pos_connected = _restaurant.point_of_sale.get() if _restaurant.point_of_sale else None
        # DS Details
        _ds_connected = get_delivery_services_for_restaurant(restaurant_key=_restaurant.key, keys_only=True)
        # Printer Details
        _printer_connected = fetch_paired_printers_for_restaurant(restaurant_key=_restaurant.key, keys_only=True)

        _marshalled_restaurant_status = {'account': marshal(_account, Account.schema()),
                                         'restaurant': marshal(_restaurant, Restaurant.schema())}
        if _pos_connected:
            _marshalled_restaurant_status['pos_connected'] = marshal(_pos_connected, PointOfSale.schema())
        if len(_ds_connected):
            _marshalled_restaurant_status['ds_connected'] = oo_marshal_list(_ds_connected, ds_marshal)
        if len(_printer_connected):
            _marshalled_restaurant_status['printer_connected'] = oo_marshal_list(_printer_connected, printer_marshal)

        _marshalled_result = {'global_settings': _marshalled_global_settings, 'restaurant_status': _marshalled_restaurant_status}
        return _marshalled_result

    @nsApi.doc('Update onboarding information for restaurant')
    def put(self, restaurant_id):
        json_dict = request.get_json()
        _restaurant_key = Restaurant.get_key(restaurant_id)
        _restaurant = _restaurant_key.get()
        _account = _restaurant.account.get()
        _raw_ds_list = json_dict.get('ds', [])
        for _raw_ds in _raw_ds_list:
            _raw_ds_id = _raw_ds.get('id')
            _raw_ds_public_menu_url = _raw_ds.get('service_menu_url')
            _raw_ds_username = _raw_ds.get('service_username')
            _raw_ds_password = _raw_ds.get('service_password')
            _raw_ds_pincode = _raw_ds.get('service_pincode')

            _ds_type = DeliveryServiceType(_raw_ds_id)
            logging.info('Restaurant %s is connecting to %s with menu %s' % (str(restaurant_id), str(_ds_type), str(_raw_ds_public_menu_url)))
            _delivery_service = create_from_public_menu_url(restaurant_key=_restaurant_key,
                                                            delivery_service_type=_ds_type,
                                                            public_menu_url=_raw_ds_public_menu_url,
                                                            username=_raw_ds_username,
                                                            password=_raw_ds_password,
                                                            service_pincode=_raw_ds_pincode)
            # SEND INFO TO ONBOARDING TEAM
            _admin_url = "{}/restaurant/{}".format(get_config_for_key("ADMIN_BASE_URL"), str(restaurant_id))
            _onboarding_url = "{}/restaurant/{}/onboarding".format(get_config_for_key("DASHBOARD_BASE_URL"), str(restaurant_id))
            post_to_self_onboarding_for_new_delivery_service(account_name=_account.name,
                                                             restaurant_name=_restaurant.name,
                                                             delivery_service_name=_ds_type,
                                                             delivery_service_public_menu_url=_raw_ds_public_menu_url,
                                                             delivery_service_username=_raw_ds_username,
                                                             restaurant_dashboard_url=_admin_url,
                                                             restaurant_onboarding_url=_onboarding_url)

        _ds_connected = get_delivery_services_for_restaurant(restaurant_key=_restaurant_key, keys_only=True)
        _marshalled_result = {'ds_connected': oo_marshal_list(_ds_connected, ds_marshal)}
        return _marshalled_result
