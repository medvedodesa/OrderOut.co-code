# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/27/2019
#

from flask import current_app
from application.core.urlFetch.service import fetch_with_json_data, fetch_with_url_encoded_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.error import report_error
import json
from application.core.json import convert_json_dict_to_object
from application.core.settings.app import get_config_for_key
import logging


ANTICAPTCHA_KEY = "ef5b8d879d8b72274358ca9952732b15"

MENU_INTERVAL = 43200  # 12h * 60m * 60s
ORDER_INTERVAL = 15  # 15s

def start_monitor(delivery_service_key):
    _delivery_service = delivery_service_key.get()

    credentials = convert_json_dict_to_object(json.loads(_delivery_service.serviceData))

    _apify_url = __get_url_apify_ubereats_monitor(delivery_service_key)
    _apify_payload = {'username': credentials.username,
                      'password': credentials.password,
                      'pinCode': str(credentials.pincode),
                      'menuInterval': MENU_INTERVAL,
                      'orderInterval': ORDER_INTERVAL,
                      'anticaptchaKey': ANTICAPTCHA_KEY,
                      'webhook': __get_url_orderout_order_webhook(_delivery_service.restaurant, delivery_service_key),
                      'errorWebhook': __get_url_orderout_error_webhook()}
    _apify_headers = {'Content-Type': 'application/json'}

    result_json, status_code, _request_key = fetch_with_json_data(url=_apify_url, service=UrlFetchService.APIFY, method="PUT", data=_apify_payload, headers=_apify_headers)
    if status_code >= 200 and status_code <= 299:
        return True
    report_error(code=status_code, subject="Apify-StartMonitor-Error", message="Delivery service %s returned %s" % (str(delivery_service_key.id()), str(status_code)))
    return False

def stop_monitor(delivery_service_key):
    _delivery_service = delivery_service_key.get()
    _apify_url = __get_url_apify_ubereats_monitor(delivery_service_key)
    import logging
    logging.info(_apify_url)
    result_json, status_code, request_key = fetch_with_url_encoded_data(url=_apify_url, service=UrlFetchService.APIFY, method="DELETE")
    if status_code >= 200 and status_code <= 299:
        return True
    report_error(code=status_code, subject="Apify-StopMonitor-Error", message="Delivery service %s returned %s" % (str(delivery_service_key.id()), str(status_code)))
    return False

def get_list_of_restaurants_being_monitored_for_uber_eats():
    _apify_url = __get_url_apify_list_ubereats_monitored()
    result_json, status_code, _request_key = fetch_with_json_data(url=_apify_url, service=UrlFetchService.APIFY, method="GET")
    if status_code >= 200 and status_code <= 299:
        logging.info(result_json)
        return True
    report_error(code=status_code, subject="Apify-ListMonitor-Error", message="returned %s" % (str(status_code)))
    return False

def launch_run_for_ubereats_monitor():
    _apify_url = __get_url_apify_to_run_ubereats_monitor()
    _apify_payload = {'storeName': "ubereats-monitor-store-v2",
                      'orderActor': "order-out/ubereats-orders-v2",
                      'menuActor': "order-out/ubereats-menu-v2",
                      'loginActor': "order-out/ubereats-login-v2",
                      'errorWebhook': __get_url_orderout_error_webhook()}
    _apify_headers = {'Content-Type': 'application/json'}
    result_json, status_code, _request_key = fetch_with_json_data(url=_apify_url, service=UrlFetchService.APIFY, method="POST", data=_apify_payload, headers=_apify_headers)
    if status_code >= 200 and status_code <= 299:
        logging.info(result_json)
        return True
    report_error(code=status_code, subject="Apify-ListMonitor-Error", message="returned %s" % (str(status_code)))
    return False

################
# WEBHOOKS APIFY
################

def __get_url_apify_ubereats_monitor(delivery_service_key):
    _apify_token = get_config_for_key('APIFY_TOKEN')
    return "https://api.apify.com/v2/key-value-stores/order-out~ubereats-monitor-store-v2/records/%s?token=%s" % (str(delivery_service_key.id()), str(_apify_token))

def __get_url_apify_to_run_ubereats_monitor():
    _apify_token = get_config_for_key('APIFY_TOKEN')
    return "https://api.apify.com/v2/acts/order-out~ubereats-monitor-v2/runs?token=%s" % (str(_apify_token))

###################
# WEBHOOKS ORDEROUT
###################

def __get_url_orderout_order_webhook(restaurant_key, delivery_service_key):
    from application.apis import api # TO-DO: Find a way to not have this import here - Currently we have to to avoid circular import -> THAT'S SUCKS AND UGLY
    from application.apis.deliveryservice.controller.ubereats import DeliveryServiceUberEatsOrder
    _url = api.url_for(DeliveryServiceUberEatsOrder, restaurant_id=restaurant_key.id(), deliveryservice_id=delivery_service_key.id(), _external=True)
    if _url.startswith("http://localhost:8080"):
        _url = _url.replace("http://localhost:8080", get_config_for_key('PROJECT_URL'))
    return _url

def __get_url_orderout_error_webhook():
    from application.apis import api # TO-DO: Find a way to not have this import here - Currently we have to to avoid circular import -> THAT'S SUCKS AND UGLY
    from ..controller.error import ScrapingWebhookError
    _url = api.url_for(ScrapingWebhookError, _external=True)
    if _url.startswith("http://localhost:8080"):
        _url = _url.replace("http://localhost:8080", get_config_for_key('PROJECT_URL'))
    return _url
