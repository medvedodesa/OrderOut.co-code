# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/27/2019
#

from flask import request
from flask_restplus import Resource, Namespace
from application.apis.ooexceptions import NotFound
from application.core.error import report_error
from application.core.webhook.service import save_webhook
from application.core.webhook.model import CoreWebhookService

import logging


nsApi = Namespace('scraping', description='Scraping related operations.')


@nsApi.route('/error')
class ScrapingWebhookError(Resource):

    @nsApi.doc('Report error from Scraping Webhook')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    # @nsApi.marshal_with(restaurant_marshal)
    def post(self):
        json_dict = request.get_json()
        _wh = save_webhook(url=request.url, service=CoreWebhookService.APIFY, payload=json_dict)
        report_error(500, subject="Apify Error", message="Apify reports an error from the webhook", data_dict=json_dict)
        _wh.is_successful()
        return {}, 200
