import logging

from flask import request
from flask_restplus import Resource, Namespace
from google.appengine.api import memcache
from werkzeug.exceptions import BadRequest, NotFound

from application.apis.deliveryservice.service.common.events import save_connect_event
from application.apis.deliveryservice.model.DeliveryService import DeliveryService
from application.apis.deliveryservice.model.DeliveryService import DeliveryServiceType
from application.apis.deliveryservice.service.postmates.connect import connect
from application.apis.deliveryservice.service.postmates.menu.copy import (
    start_task_to_copy_menu,
)
from application.apis.deliveryservice.service.postmates.menu.utils import get_postmates_menus
from application.apis.deliveryservice.service.postmates.serializers.menu_serializer import (
    CatalogSchema,
)

from application.apis.deliveryservice.service.postmates.webhook import process_webhook
from application.apis.menu.service.menusync.creator import create_menu_sync
from application.apis.restaurant.model import Restaurant
from application.core.authentication.service import requires_auth_token
from application.core.delivery_services.postmates.factories import (
    PostmatesApiClientFactory,
)
from application.core.security.token_handler import get_token, read_token
from application.core.settings.app import get_config_for_key
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.urlFetch.service import save_success, save_error
from application.core.webhook.model import CoreWebhookService
from application.core.webhook.service import save_webhook

nsApi = Namespace("DS-postmates", description="Postmates related operations.")

ds_marshal = nsApi.model("DeliveryService", DeliveryService.schema())


@nsApi.route("restaurant/<int:restaurant_id>/ds/postmates/catalog")
@nsApi.param("restaurant_id", "Location identifier")
class DeliveryServicePostmatesCatalog(Resource):
    @nsApi.doc("Create push catalog job")
    @requires_auth_token
    def post(self, restaurant_id):
        json_dict = request.get_json()
        place_id = json_dict.get("place_id")
        account_id = json_dict.get("account_id")

        token = get_token(restaurant_id)
        base_url = get_config_for_key("PROJECT_URL")
        source_url = "{}/api/restaurant/{}/ds/postmates/catalog?token={}".format(
            base_url, restaurant_id, token
        )

        webhook_url = "{}/api/ds/postmates/post_catalog_callback".format(base_url)

        payload = {
            "source_url": source_url,
            "webhook_url": webhook_url,
        }

        postmates_api_client = (
            PostmatesApiClientFactory.instantiate_google_urlfetch_api_client()
        )
        response = postmates_api_client.update_catalog(
            place_id=place_id, account_id=account_id, payload=payload
        )
        return response

    @nsApi.doc("Get catalog json")
    def get(self, restaurant_id):
        token = request.args.get("token")
        if not token:
            raise BadRequest

        data = read_token(token)
        if not data:
            raise NotFound

        token_restaurant_id = data["id"]

        if token_restaurant_id != restaurant_id:
            raise NotFound

        logging.info("Getting catalog for restaurant: {}".format(restaurant_id))
        key = "postmates-menu-{}".format(restaurant_id)
        response = memcache.get(key=key)

        if not response:
            logging.info("Couldn't find postmates menu on cache with key: {}".format(key))
            menu_sections = get_postmates_menus(restaurant_id)

            if not menu_sections:
                raise NotFound

            response = None
            for menu_section in menu_sections:
                schema = CatalogSchema()
                response_menu, errors = schema.dump(menu_section)
                if not response:
                    response = response_menu
                else:
                    response["categories"].extend(response_menu["categories"])
                if errors:
                    raise BadRequest

        response.pop("availability")
        return response


@nsApi.route("ds/postmates/post_catalog_callback")
class DeliveryServicePostmatesCatalog(Resource):
    def post(self):
        data = request.get_json() or {}

        status = data.get("status")

        method = "post"
        url = get_config_for_key("POSTMATES_BASE_URL")
        if status == "succeeded":
            save_success(
                service=UrlFetchService.POSTMATES,
                method=method,
                url=url,
                payload={},
                status_code=200,
                result_json=data,
                success=True,
            )
        else:
            save_error(
                url=url,
                method=method,
                service=UrlFetchService.POSTMATES,
                payload={},
                status_code=400,
                result_json=data,
            )


@nsApi.route("restaurant/<int:restaurant_id>/ds/postmates/connect")
@nsApi.param("restaurant_id", "Restaurant identifier")
class DeliveryServicePostmatesConnect(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc("Connect Postmates Delivery Service to a Restaurant")
    @nsApi.marshal_with(ds_marshal)
    def post(self, restaurant_id):
        json_dict = request.get_json()
        place_id = json_dict.get("place_id")
        account_id = json_dict.get("account_id")
        if not place_id or not account_id:
            raise BadRequest

        restaurant = Restaurant.get_by_id(restaurant_id)

        if not restaurant:
            raise NotFound

        postmates_delivery_service = connect(
            account_key=restaurant.account,
            restaurant_key=restaurant.key,
        )
        if not postmates_delivery_service:
            raise BadRequest
        save_connect_event(
            ds_type=DeliveryServiceType.POSTMATES,
            success=True,
            payload=json_dict,
            account=restaurant.account,
            restaurant=restaurant.key,
            ds=postmates_delivery_service.key,
            pos=restaurant.point_of_sale,
        )

        postmates_delivery_service.service_account_id = account_id
        postmates_delivery_service.serviceLocationId = place_id

        ms = create_menu_sync(
            restaurant_key=postmates_delivery_service.restaurant,
            service_key=postmates_delivery_service.key,
        )
        postmates_delivery_service.menuSync = ms.key
        ds_key = postmates_delivery_service.put()

        already_configured_ds = restaurant.delivery_services

        choosen_ds = None
        for ds in already_configured_ds:
            ds_obj = ds.get()
            if ds_obj.type == DeliveryServiceType.UBEREATS:
                choosen_ds = ds_obj
                break

        if choosen_ds:
            from_ds = str(choosen_ds.type)
            start_task_to_copy_menu(ds_key, from_delivery_service_type=from_ds)

        return postmates_delivery_service


@nsApi.route("ds/postmates/webhook")
class DeliveryServicePostmatesWebhook(Resource):
    @nsApi.doc("Webhook used by Postmates API to send data")
    def post(self):
        import logging

        json_dict = request.get_json()
        store_id = json_dict.get("data", {}).get("place_details", {}).get("place_id")
        logging.info("Request received to place_id {}".format(store_id))
        logging.info(json_dict)
        wh = save_webhook(
            url=request.url, service=CoreWebhookService.POSTMATES, payload=json_dict
        )
        success = process_webhook(json_dict)
        wh.is_successful() if success else wh.failed()
        return {"status": str(success)}
