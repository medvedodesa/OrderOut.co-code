# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/27/2019
#
import json

from flask import request
from flask_restplus import Resource, Namespace
from google.appengine.api import memcache

from application.core.delivery_services.ubereats.factories import UberEatsApiClientFactory
from application.core.exception import errorHandler
from application.core.slack.onboarding import post_to_self_onboarding_for_new_delivery_service
from application.apis.deliveryservice.service.common.events import save_connect_event
from ..model.DeliveryService import DeliveryService, DeliveryServiceType
from ..service.ubereats.connect import connect, after_connect_successful
from ..service.ubereats.webhook import process_webhook
from application.apis.restaurant.model import Restaurant
from application.apis.ooexceptions import NotFound, BadRequest
from application.core.webhook.service import save_webhook
from application.core.webhook.model import CoreWebhookService
from ..service.ubereats.menu.fetch import startTaskToFetchMenu
from application.core.parser.string import sanitize_str
from application.core.settings.app import get_config_for_key


nsApi = Namespace('DS-ubereats', description='Uber Eats related operations.')

marshal_connect = nsApi.schema_model('DeliveryServiceUberEatsConnect',
                                    {'required': ['storeId'],
                                     'properties': {'storeID':{'type': 'string'}},
                                     'type': 'object'})
ds_marshal = nsApi.model('DeliveryService', DeliveryService.schema())

#######
# APIFY
#######


@nsApi.route('restaurant/<int:restaurant_id>/ds/ubereats/connect')
@nsApi.param('restaurant_id', 'Restaurant identifier')
class DeliveryServiceUberEatsConnect(Resource):
    #method_decorators = [requires_auth_token]

    @nsApi.doc('Connect User Eats Delivery Service to a Restaurant')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    @nsApi.expect(marshal_connect, validate=True)
    @nsApi.marshal_with(ds_marshal)
    @errorHandler
    def post(self, restaurant_id):
        _restaurant = Restaurant.get_by_id(restaurant_id)
        if not _restaurant:
            raise NotFound

        account_name = ""
        account_key = _restaurant.account
        if account_key:
            account = account_key.get()
            account_name = account.name

        json_dict = request.get_json()
        _ubereats_store_id = sanitize_str(json_dict.get('storeId'))

        _ds = connect(account_key=_restaurant.account,
                      restaurant_key=_restaurant.key,
                      store_id=_ubereats_store_id)

        ds_type = _ds.type

        if not _ds:
            raise BadRequest

        return after_connect_successful(json_dict, _ubereats_store_id, _restaurant, _ds)


@nsApi.route('restaurant/ubereats/<int:restaurant_id>/store_data')
class DeliveryServiceUberEatsStoreData(Resource):

    def get(self, restaurant_id):
        mc_client = memcache.Client()
        store_data = mc_client.get("ubereats/{}".format(restaurant_id))

        if not store_data:
            return []

        try:
            store_data = json.loads(store_data)
            return store_data

        except Exception:
            raise BadRequest

    def delete(self, restaurant_id):
        try:
            mc_client = memcache.Client()
            mc_client.delete("ubereats/{}".format(restaurant_id))
            mc_client.delete("ubereats/{}/refresh_token".format(restaurant_id))
        except Exception:
            raise BadRequest

        return {"success": True}

#
# @nsApi.route('ds/ubereats/<int:ds_id>/pos_integration')
# class DeliveryServiceUberEatsPosIntegration(Resource):
#     method_decorators = [requires_auth_token]
#
#     def put(self, ds_id):
#         logging.info("Updating pos integration for ds: {}".format(ds_id))
#         delivery_service = DeliveryService.get_by_id(ds_id)
#         if not delivery_service:
#             logging.info("ds not found")
#             raise NotFound
#
#         json_dict = request.get_json()
#
#         pos_integration_enabled = json_dict.get("pos_integration_enabled", False)
#
#         logging.info("pos_integration_enabled: {}".format(pos_integration_enabled))
#
#         if pos_integration_enabled:
#             start_task_to_push_menu(deliveryservice_key=delivery_service.key)
#         else:
#             restaurant = delivery_service.restaurant.get()
#             logging.info("restaurant: {}".format(restaurant))
#             if restaurant:
#                 restaurant_id = restaurant.id
#                 mc_client = memcache.Client()
#                 mc_client.delete("ubereats/{}".format(restaurant_id))
#                 mc_client.delete("ubereats/{}/refresh_token".format(restaurant_id))
#
#         uber_eats_api = UberEatsApiClientFactory.instantiate_google_urlfetch_api_client(
#             refresh_token=delivery_service.refresh_token
#         )
#
#         store_id = delivery_service.serviceLocationId
#
#         logging.info("store_id: {}".format(store_id))
#
#         response, status_code, _ = uber_eats_api.update_integration(
#             store_id=store_id, active=pos_integration_enabled, get_all_args=True
#         )
#
#         logging.info("response: {} - status_code: {}".format(response, status_code))
#
#         success = True if status_code == 200 else False
#
#         if success:
#             delivery_service.integration_enabled = pos_integration_enabled
#             delivery_service.put()
#
#         return {"success": success}


##############
# UBEREATS API
##############

@nsApi.route('ds/ubereats/webhook')
class DeliveryServiceUberEatsWebhook(Resource):

    @nsApi.doc('Webhook used by UserEats API to send data')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)https://5d897299.ngrok.io/api/ds/ubereats/webhook
    # @nsApi.marshal_with(restaurant_marshal)
    def post(self):
        json_dict = request.get_json()
        _wh = save_webhook(url=request.url, service=CoreWebhookService.UBEREATS, payload=json_dict)
        success = process_webhook(webhook_key=_wh.key, json_dict=json_dict)
        _wh.is_successful() if success else _wh.failed()
        return {"status": str(True)}
