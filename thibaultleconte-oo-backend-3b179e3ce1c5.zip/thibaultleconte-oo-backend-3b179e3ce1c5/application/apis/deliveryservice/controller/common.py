# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/07/2019
#
import logging

from flask import request
from flask_restplus import Resource, Namespace
from google.appengine.api import memcache
from werkzeug.exceptions import Conflict

from application.apis.restaurant.model import Restaurant
from application.apis.deliveryservice.model.DeliveryService import (
    DeliveryService, DeliveryServiceType
)
from application.apis.ooexceptions import NotFound, InternalServerError, ResourceDoesNotExist, \
    ConflictResourceAlreadyExistsError, BadRequest
from application.core.authentication.service import requires_auth_token
from application.apis.deliveryservice.service.common.events import save_disconnect_event, save_status_event
from application.core.delivery_services.doordash.doordash_api import DoorDashUnauthorized, INVALID_CREDENTIALS_CODE
from application.core.delivery_services.doordash.factories import DoorDashApiClientFactory
from application.core.delivery_services.grubhub.factories import GrubHubApiClientFactory
from application.core.delivery_services.grubhub.grubhub_api import UnauthorizedException
from ..service.common.fetch import get_delivery_services_for_restaurant
from ..service.common.pos import get_pos_status, enable_pos_functionality, disable_pos_functionality
from ..service.common.disconnect import disconnect
from ..service.common.verification import start_settings_verification
from ..service.common.crud import get_by_id_and_populate
from application.apis.order.model.Order import Order
from application.apis.authentication import errorHandler
from application.apis.menu.model.MenuItem import MenuItem
from application.apis.menu.service.fetch.item import fetch_all_items
from application.apis.menu.service.modifier import fetch_all_modifiers_for_menu_item
from application.apis.order.service.simulator import create_order
from application.apis.order.service.confirmation import set_order_as_confirmed
from application.apis.order.service.push import push_order_to_point_of_sale


nsApi = Namespace('deliveryservice', description='Delivery Service related operations.')

ds_marshal = nsApi.model('DeliveryService', DeliveryService.schema())
order_marshal = nsApi.model('Order', Order.schema())
item_marshal = nsApi.model("MenuItem", MenuItem.schema(expanded=True))

@nsApi.route('restaurant/<int:restaurant_id>/ds')
@nsApi.param('restaurant_id', 'Restaurant identifier')
class DeliveryServiceGetForRestaurant(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('List the Delivery Services for a Restaurant')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    @nsApi.marshal_list_with(ds_marshal)
    def get(self, restaurant_id):
        _restaurant = Restaurant.get_by_id(restaurant_id)
        if not _restaurant: raise NotFound
        return get_delivery_services_for_restaurant(_restaurant.key, keys_only=False)

@nsApi.route('ds/<int:delivery_service_id>')
@nsApi.param('delivery_service_id', 'Delivery Service identifier')
class DeliveryServiceGet(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get a Delivery Service')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    @nsApi.marshal_with(ds_marshal)
    def get(self, delivery_service_id):
        _ds = DeliveryService.get_by_id(delivery_service_id)
        if not _ds: raise NotFound
        return _ds

    @nsApi.doc('Update a Delivery Service')
    @nsApi.response(200, 'OK', ds_marshal)
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    @nsApi.expect(ds_marshal, validate=True)
    @nsApi.marshal_with(ds_marshal)
    @errorHandler
    def put(self, delivery_service_id):
        json_dict = request.get_json()
        try:
            _ds = get_by_id_and_populate(delivery_service_id, json_dict)
            save_status_event(
                enabled=_ds.integration_enabled,
                ds_type=_ds.type,
                success=True,
                account=_ds.account,
                restaurant=_ds.restaurant,
                ds=_ds.key,
                pos=_ds.restaurant.get().point_of_sale,
            )
            if not _ds.menuSync:
                if _ds.type == DeliveryServiceType.UBEREATS:
                    from ..service.ubereats.menu.fetch import startTaskToFetchMenu
                    _ds = startTaskToFetchMenu(deliveryservice_key=_ds.key)
                elif _ds.type == DeliveryServiceType.GRUBHUB:
                    from ..service.grubhub.menu.fetch import startTaskToFetchMenu
                    _ds = startTaskToFetchMenu(deliveryservice_key=_ds.key)
                elif _ds.type == DeliveryServiceType.DOORDASH:
                    from ..service.doordash.menu.fetch import startTaskToFetchMenu
                    _ds = startTaskToFetchMenu(deliveryservice_key=_ds.key)
                elif _ds.type == DeliveryServiceType.WIX:
                    from ..service.wix.menu.fetch import startTaskToFetchMenu
                    _ds = startTaskToFetchMenu(deliveryservice_key=_ds.key)
                elif _ds.type == DeliveryServiceType.CHOWNOW:
                    from ..service.chownow.menu.fetch import startTaskToFetchMenu
                    _ds = startTaskToFetchMenu(deliveryservice_key=_ds.key)
            return _ds
        except ResourceDoesNotExist:
            nsApi.abort(404, 'Not found')
        except NotFound:
            nsApi.abort(404, 'Not found')
        except ConflictResourceAlreadyExistsError:
            nsApi.abort(409, 'Resource already exists')
        except Exception as e:
            import logging
            logging.error(e)
            nsApi.abort(400, 'Bad request')
        # TODO: Move to something like these to HANDLE ERRORS https://opensource.com/article/17/3/python-flask-exceptions

@nsApi.route('ds/<int:delivery_service_id>/menu/fetch')
@nsApi.param('delivery_service_id', 'Delivery Service identifier')
class DeliveryServiceMenuFetch(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Start the process to fetch menu for a Delivery Service')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.marshal_with(restaurant_marshal)
    @errorHandler
    def get(self, delivery_service_id):
        _ds = DeliveryService.get_by_id(delivery_service_id)
        if not _ds: raise NotFound
        _msg = "Delivery Service Menu Fetch not supported"
        if _ds.type == DeliveryServiceType.UBEREATS:
            from ..service.ubereats.menu.fetch import startTaskToFetchMenu
            _ds = startTaskToFetchMenu(deliveryservice_key=_ds.key)
            _msg = "Fetching Delivery Service Menu started"
        elif _ds.type == DeliveryServiceType.GRUBHUB:
            from ..service.grubhub.menu.fetch import startTaskToFetchMenu
            _ds = startTaskToFetchMenu(deliveryservice_key=_ds.key)
            _msg = "Fetching Delivery Service Menu started"
        elif _ds.type == DeliveryServiceType.DOORDASH:
            from ..service.doordash.menu.fetch import startTaskToFetchMenu
            _ds = startTaskToFetchMenu(deliveryservice_key=_ds.key)
            _msg = "Fetching Delivery Service Menu started"
        elif _ds.type == DeliveryServiceType.WIX:
            from ..service.wix.menu.fetch import startTaskToFetchMenu
            _ds = startTaskToFetchMenu(deliveryservice_key=_ds.key)
            _msg = "Fetching Delivery Service Menu started"
        elif _ds.type == DeliveryServiceType.CHOWNOW:
            from ..service.chownow.menu.fetch import startTaskToFetchMenu
            _ds = startTaskToFetchMenu(deliveryservice_key=_ds.key)
            _msg = "Fetching Delivery Service Menu started"
        return {"status": _msg}

@nsApi.route('ds/<int:delivery_service_id>/menu/push')
@nsApi.param('delivery_service_id', 'Delivery Service identifier')
class DeliveryServiceMenuPush(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Start the process to push menu for a Delivery Service')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.marshal_with(restaurant_marshal)
    @errorHandler
    def put(self, delivery_service_id):
        json_dict = request.get_json()
        test_on_biscayne_bakery = json_dict.get('testOnBiscayneBakery', True)
        _ds = DeliveryService.get_by_id(delivery_service_id)
        if not _ds: raise NotFound
        _msg = "Delivery Service Menu Push not supported"
        if _ds.type == DeliveryServiceType.UBEREATS:
            from ..service.ubereats.menu.push import startTaskToPushMenu, processTaskToPushMenuToUberEats
            # _success = startTaskToPushMenu(deliveryservice_key=_ds.key, test_on_biscayne_bakery=test_on_biscayne_bakery)
            _msg = "Pushing Delivery Service Menu started"
            _status_code, _result_json = processTaskToPushMenuToUberEats(deliveryservice_id=_ds.key.id(), test_on_biscayne_bakery=test_on_biscayne_bakery)
            if _status_code < 200 or _status_code > 299:
                return {"status": _result_json}, _status_code
        elif _ds.type == DeliveryServiceType.POSTMATES:
            from ..service.postmates.menu.push import start_task_to_push_menu
            _success = start_task_to_push_menu(deliveryservice_key=_ds.key, test_on_biscayne_bakery=test_on_biscayne_bakery)
            _msg = "Pushing Delivery Service Menu started"
        return {"status": _msg}

@nsApi.route('ds/<int:delivery_service_id>/pos/status')
@nsApi.param('delivery_service_id', 'Delivery Service identifier')
class DeliveryServicePosStatus(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get the system Status for a Delivery Service')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.marshal_with(restaurant_marshal)
    def get(self, delivery_service_id):
        _ds = DeliveryService.get_by_id(delivery_service_id)
        if not _ds: raise NotFound
        status = get_pos_status(_ds.key)
        if not status: raise InternalServerError
        return status

@nsApi.route('ds/<int:delivery_service_id>/pos/enable')
@nsApi.param('delivery_service_id', 'Delivery Service identifier')
class DeliveryServicePosEnable(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Enable POS functionality for a Delivery Service')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.marshal_with(restaurant_marshal)
    def put(self, delivery_service_id):
        _ds = DeliveryService.get_by_id(delivery_service_id)
        if not _ds: raise NotFound
        status = enable_pos_functionality(_ds.key)
        if not status: raise InternalServerError
        return status

@nsApi.route('ds/<int:delivery_service_id>/pos/disable')
@nsApi.param('delivery_service_id', 'Delivery Service identifier')
class DeliveryServicePosDisable(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Disable POS functionality for a Delivery Service')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.marshal_with(restaurant_marshal)
    def put(self, delivery_service_id):
        _ds = DeliveryService.get_by_id(delivery_service_id)
        if not _ds: raise NotFound
        status = disable_pos_functionality(_ds.key)
        if not status: raise InternalServerError
        return status

@nsApi.route('ds/<int:delivery_service_id>/disconnect')
@nsApi.param('delivery_service_id', 'Delivery Service identifier')
class DeliveryServiceDisconnect(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Disconnect Delivery Service from Restaurant')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    # @nsApi.marshal_with(restaurant_marshal)
    def delete(self, delivery_service_id):
        _ds = DeliveryService.get_by_id(delivery_service_id)
        if not _ds:
            logging.info("Couldn't find Delivery Service {}".format(delivery_service_id))
            raise NotFound

        if _ds.integration_enabled:
            logging.info("Delivery Service {} has integration enabled".format(delivery_service_id))
            raise Conflict

        success = disconnect(deliveryservice_key=_ds.key)
        logging.info("disconect success: {}".format(success))

        save_disconnect_event(
            ds_type=_ds.type,
            success=success,
            account=_ds.account,
            restaurant=_ds.restaurant,
            ds=_ds.key,
            pos=_ds.restaurant.get().point_of_sale,
        )

        restaurant = _ds.restaurant.get()
        if restaurant:
            restaurant_id = restaurant.id
            logging.info("restaurant found {}".format(restaurant_id))
            mc_client = memcache.Client()
            mc_client.delete("ubereats/{}".format(restaurant_id))
            mc_client.delete("ubereats/{}/refresh_token".format(restaurant_id))
            logging.info("keys deleted")

        if success: return {"status": "Disconnected Delivery Service successfully"}
        return {"status": "Disconnecting Delivery Service FAILED"}

@nsApi.route('ds/<int:delivery_service_id>/settings/verify')
@nsApi.param('delivery_service_id', 'Delivery Service identifier')
class DeliveryServiceSettingsVerify(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Verify Delivery Service Settings')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    # @nsApi.marshal_with(restaurant_marshal)
    def get(self, delivery_service_id):
        _ds = DeliveryService.get_by_id(delivery_service_id)
        if not _ds: raise NotFound
        start_settings_verification(_ds.key)
        return {"status": "pending"}

@nsApi.route('ds/<int:delivery_service_id>/order/test')
@nsApi.param('delivery_service_id', 'Delivery Service identifier')
class DeliveryServiceOrderTest(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Test receiving an Order from Delivery Service')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    @nsApi.marshal_with(order_marshal)
    @errorHandler
    def post(self, delivery_service_id):

        import logging
        logging.info("ORDERS TEST")

        _ds = DeliveryService.get_by_id(delivery_service_id)
        if not _ds: raise NotFound
        _order = create_order(account_key=_ds.account, restaurant_key=_ds.restaurant, delivery_service_key=_ds.key)
        # ORDER CONFIRMED
        success_confirmed = set_order_as_confirmed(_order.key)
        # POINT OF SALE
        success_pushed = push_order_to_point_of_sale(order_key=_order.key, forced=True)
        return _order

@nsApi.route('ds/<int:delivery_service_id>/mapping/unmapped')
@nsApi.param('delivery_service_id', 'Delivery Service identifier')
class DeliveryServiceGetUnmappedItemsModifiers(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Get Delivery Service Unmappe Items and Modifiers')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    @nsApi.marshal_list_with(item_marshal)
    # @errorHandler
    def get(self, delivery_service_id):
        _ds = DeliveryService.get_by_id(delivery_service_id)
        if not _ds: raise NotFound
        if not _ds.menuSync: raise BadRequest

        _unmapped_items = []

        _menu_items = fetch_all_items(menu_sync_key=_ds.menuSync, keys_only=False)
        for _mi in _menu_items:
            if not _mi.mappedToMenuItem:
                _unmapped_items.append(_mi)
                continue
            _modifiers = fetch_all_modifiers_for_menu_item(menu_item_key=_mi.key)
            for _mod in _modifiers:
                if not _mod.mappedToMenuItemModifier:
                    _unmapped_items.append(_mi)
                    continue

        return _unmapped_items

@nsApi.route('ds/<int:delivery_service_id>/test/connection')
@nsApi.param('delivery_service_id', 'Delivery Service identifier')
class DeliveryServiceTestConnection(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Test Connection with Delivery Service')
    @errorHandler
    def post(self, delivery_service_id):
        ds = DeliveryService.get_by_id(delivery_service_id)

        if not ds:
            raise NotFound

        username = ds.service_username
        password = ds.service_secret
        if not username or not password:
            return "Username and password not stored", 400

        if ds.type == DeliveryServiceType.DOORDASH:
            return self.test_doordash_connection(ds.serviceLocationId, username, password)

        if ds.type == DeliveryServiceType.GRUBHUB:
            return self.test_grubhub_connection(username, password)

        return "Can't test connection for delivery service type: ".format(str(ds.type)), 400

    @staticmethod
    def test_doordash_connection(service_location_id, username, password):
        try:
            doordash_api = DoorDashApiClientFactory.instantiate_google_urlfetch_api_client(username, password)
            doordash_api.get_active_orders(service_location_id)
            return {
                "status": True,
            }, 200

        except DoorDashUnauthorized as e:
            if e.doordash_code == INVALID_CREDENTIALS_CODE:
                return {
                    "status": False,
                    "message": "Invalid credentials",
                }, 200
            else:
                return {
                    "status": False,
                    "message": "Blocked by DoorDash",
                }, 200

    @staticmethod
    def test_grubhub_connection(username, password):
        try:
            grubhub_api = GrubHubApiClientFactory.instantiate_google_urlfetch_api_client(username, password)
            grubhub_api.get_active_orders()
            return {
                "status": True,
            }, 200

        except UnauthorizedException:
            return {
                "status": False,
                "message": "Invalid credentials",
            }, 200
