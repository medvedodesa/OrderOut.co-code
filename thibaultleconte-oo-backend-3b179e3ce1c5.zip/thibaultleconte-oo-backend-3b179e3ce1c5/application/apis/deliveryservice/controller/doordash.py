# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/13/2019
#
import logging

from flask import request
from flask_restplus import Resource, Namespace
from werkzeug.exceptions import BadRequest

from application.apis.deliveryservice.service.common.events import save_connect_event
from ..model.DeliveryService import DeliveryService, DeliveryServiceType
from ..service.doordash.connect import connect
from application.apis.restaurant.model import Restaurant
from application.apis.ooexceptions import NotFound
from application.core.authentication.service import requires_auth_token
from ..service.doordash.menu.fetch import startTaskToFetchMenu
from application.core.webhook.service import save_webhook
from application.core.webhook.model import CoreWebhookService
from ..service.doordash.webhook import process_apify_webhook, process_parseur_webhook, process_parseur_webhook_error
from application.core.task.service import startDeferredTask

nsApi = Namespace('DS-doordash', description='Doordash related operations.')

marshal_connect = nsApi.schema_model('Doordash Connect',
                                    {'required': ['restaurantUrl'],
                                     'properties': {'restaurantUrl':{'type': 'string'}},
                                     'type': 'object'})
marshal_webhook_response = nsApi.schema_model('Doordash Webhook',
                                             {'required': ['status'],
                                              'properties': {'status':{'type': 'string'}},
                                              'type': 'object'})

ds_marshal = nsApi.model('DeliveryService', DeliveryService.schema())

#######
# APIFY
#######

@nsApi.route('restaurant/<int:restaurant_id>/ds/doordash/connect')
@nsApi.param('restaurant_id', 'Restaurant identifier')
class DeliveryServiceDoorDashConnect(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Connect Doordash Delivery Service to a Restaurant')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    @nsApi.expect(marshal_connect, validate=True)
    @nsApi.marshal_with(ds_marshal)
    def post(self, restaurant_id):
        _restaurant = Restaurant.get_by_id(restaurant_id)
        if not _restaurant: raise NotFound
        json_dict = request.get_json()
        _restaurant_url = json_dict.get('restaurantUrl')
        username = json_dict.get("service_username")
        password = json_dict.get("service_password")
        pincode = json_dict.get("service_pincode")

        _ds = connect(
            account_key=_restaurant.account,
            restaurant_key=_restaurant.key,
            restaurant_url=_restaurant_url,
            username=username,
            password=password,
            pincode=pincode,
        )
        if not _ds: raise BadRequest
        save_connect_event(
            ds_type=DeliveryServiceType.DOORDASH,
            success=True,
            payload=json_dict,
            account=_restaurant.account,
            restaurant=_restaurant.key,
            ds=_ds.key,
            pos=_restaurant.point_of_sale,
        )
        _ds = startTaskToFetchMenu(_ds.key)
        return _ds

@nsApi.route('ds/doordash/apify/menu')
class DeliveryServiceDoorDashMenuWebhook(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Webhook for Apify Doordash Actor')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    # @nsApi.marshal_with(ds_marshal)
    def post(self):
        json_dict = request.get_json()
        _wh = save_webhook(url=request.url, service=CoreWebhookService.APIFY, payload=json_dict)
        success = process_apify_webhook(json_dict)
        _wh.is_successful() if success else _wh.failed()
        return {'success': str(success)}

#########
# PARSEUR
#########

@nsApi.route('ds/doordash/parseur/process')
class DeliveryServiceDoorDashParseurProcess(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Receive a delivery service order to process')
    @nsApi.response(200, 'OK', marshal_webhook_response)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    # @nsApi.marshal_with(marshal_webhook)
    def post(self):
        json_dict = request.get_json()
        success = startDeferredTask(process_parseur_webhook, request.url, json_dict)
        return {"status": str(success)}

@nsApi.route('ds/doordash/parseur/error')
class DeliveryServiceDoorDashParseurError(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Receive a delivery service error with template')
    @nsApi.response(200, 'OK', marshal_webhook_response)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    # @nsApi.marshal_with(marshal_webhook)
    def post(self):
        json_dict = request.get_json()
        success = startDeferredTask(process_parseur_webhook_error, request.url, json_dict)
        return {"status": str(success)}


@nsApi.route('restaurant/<int:restaurant_id>/ds/doordash/credential')
class DeliveryServiceDoorDashCredential(Resource):
    method_decorators = [requires_auth_token]

    def post(self, restaurant_id):
        json_dict = request.get_json()

        username = json_dict.get("username")
        password = json_dict.get("password")
        pincode = json_dict.get("pincode") # optional since May 21 2021 -> To remove later in 2021 if it is confirmed we dont need it.

        if not username or not password:
            raise BadRequest

        restaurant = Restaurant.get_by_id(restaurant_id)
        delivery_services = restaurant.delivery_services

        for delivery_service in delivery_services:
            dso = delivery_service.get()
            if dso.type == DeliveryServiceType.DOORDASH:
                dso.service_username = username
                dso.service_secret = password
                dso.service_pincode = pincode # optional since May 21 2021 -> To remove later in 2021 if it is confirmed we dont need it.
                dso.put()

        return {'success': str(True)}
