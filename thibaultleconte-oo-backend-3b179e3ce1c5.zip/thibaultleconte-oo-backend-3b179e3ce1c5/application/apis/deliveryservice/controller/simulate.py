# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 07/18/2019
#

from flask_restplus import Resource, Namespace
from application.apis.ooexceptions import NotFound, BadRequest
from application.apis.restaurant.model import Restaurant
from application.apis.account.model import Account
from application.apis.deliveryservice.model.DeliveryService import DeliveryService, DeliveryServiceType
from application.apis.deliveryservice.service.common.fetch import get_delivery_service_keys_for_restaurant
from application.apis.menu.service.menusync.creator import create_menu_sync
from application.apis.menu.service.creator import generate_item_dict, generate_modifier_group_dict, generate_modifier_dict, startTaskToCreateOrUpdateMenuItemsAndModifiers
from application.apis.menu.service.crud.section import create_update_menu_section
from application.apis.menu.service.crud.category import create_update_menu_category


nsApi = Namespace('delivery service simulate', description='Delivery Service related operations.')

ds_marshal = nsApi.model('DeliveryService', DeliveryService.schema())

@nsApi.route('/<int:account_id>/<int:restaurant_id>/simulate')
@nsApi.param('account_id', 'Account identifier')
@nsApi.param('restaurant_id', 'Restaurant identifier')
class CreateDeliveryService(Resource):
    @nsApi.doc('Create a new order for restaurant X in account Y')
    @nsApi.response(200, 'OK')
    @nsApi.response(409, 'Conflict with other resource')
    @nsApi.response(404, 'Not found')
    @nsApi.marshal_with(ds_marshal)
    # @errorHandler
    def post(self, restaurant_id, account_id):
        _account = Account.get_by_id(account_id)
        _restaurant = Restaurant.get_by_id(restaurant_id)
        _delivery_service_type = DeliveryServiceType.UBEREATS

        _delivery_service_keys = get_delivery_service_keys_for_restaurant(restaurant_key=_restaurant.key,
                                                                          delivery_service_type=_delivery_service_type)
        if len(_delivery_service_keys) == 0:
            _delivery_service = DeliveryService.create(type=_delivery_service_type,
                                                       account_key= _account.key,
                                                       restaurant_key=_restaurant.key)
            _menu_sync = create_menu_sync(_restaurant.key, _delivery_service.key)
            _delivery_service.menuSync = _menu_sync.key
            _delivery_service.put()
            _task = create_menu(_menu_sync)

        else:
            raise BadRequest

        return _delivery_service

def create_menu(menu_sync):
    _section = create_update_menu_section(menu_sync_key=menu_sync.key,
                                          name='Lunch',
                                          availability=[{'day_of_week': 'monday'}],
                                          position=0)
    _category = create_update_menu_category(menu_sync_key=menu_sync.key,
                                            section_key=_section.key,
                                            name='Dish',
                                            position=0)
    _modifier_groups = []
    _mi = generate_item_dict(name='Burger',
                             price='9.99',
                             modifier_groups=_modifier_groups)
    _task = startTaskToCreateOrUpdateMenuItemsAndModifiers(menu_sync, _mi)
    return _task
