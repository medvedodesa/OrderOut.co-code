import logging

from flask import request, Response
from flask_restplus import Resource, Namespace
from werkzeug.exceptions import NotFound, BadRequest

from application.apis.deliveryservice.model.DeliveryService import DeliveryService, DeliveryServiceType
from application.core.authentication.service import requires_auth_token


nsApi = Namespace('DS-doordash-api-switch', description='DoorDash API Switch.')


@nsApi.route('/')
class DoorDashApiSwitchRoot(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc("Get delivery service's DoorDash API Switch")
    def get(self):
        logging.info("DoorDash API - Switch - GET")
        count = request.args.get("count")
        api_active = request.args.get("api_active")
        api_activatable = request.args.get("api_activatable")

        if count and api_activatable:
            raise BadRequest

        query = DeliveryService.query()
        query = query.filter(DeliveryService.type == DeliveryServiceType.DOORDASH)
        if api_active:
            api_active = True if api_active.lower() == "true" else False
            query = query.filter(DeliveryService.service_api_active == api_active)
        if count and count.lower() == "true":
            return query.count()

        delivery_services = query.fetch()
        if api_activatable:
            api_activatable = True if api_activatable.lower() == "true" else False
            delivery_services = self._filter_by_username_and_password(api_activatable, delivery_services)
        delivery_services = self._get_id_and_api_active_fields(delivery_services)
        return delivery_services

    @staticmethod
    def _filter_by_username_and_password(api_activatable, delivery_services):
        if api_activatable:
            return filter(lambda ds: ds.service_username and ds.service_password, delivery_services)
        return filter(lambda ds: not ds.service_username or not ds.service_password, delivery_services)

    @staticmethod
    def _get_id_and_api_active_fields(delivery_services):
        return map(lambda ds: {
            "id": ds.key.id(),
            "api_active": ds.service_api_active if hasattr(ds, "service_api_active") else False,
        }, delivery_services)


@nsApi.route('/<int:delivery_service_id>')
@nsApi.param('delivery_service_id', 'Delivery Service identifier')
class DoorDashApiSwitchActivate(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Activate or deactivate DoorDash API Switch')
    def put(self, delivery_service_id):
        logging.info("DoorDash API - Switch - PUT")
        json_dict = request.get_json()
        delivery_service = DeliveryService.get_by_id(delivery_service_id)

        if not delivery_service:
            raise NotFound

        if "active" not in json_dict:
            raise BadRequest

        active = json_dict.get("active")

        delivery_service.service_api_active = active
        delivery_service.put()

        return Response("success", 200)
