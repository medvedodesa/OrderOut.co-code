# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 08/21/2019
#

from flask import request
from flask_restplus import Resource, Namespace

from application.apis.deliveryservice.service.common.events import save_connect_event
from ..model.DeliveryService import DeliveryService, DeliveryServiceType
from ..service.wix.connect import connect
from ..service.wix.webhook import process_webhook
from application.apis.restaurant.model import Restaurant
from application.apis.ooexceptions import NotFound, BadRequest
from application.core.authentication.service import requires_auth_token
from application.core.webhook.service import save_webhook
from application.core.webhook.model import CoreWebhookService
from ..service.wix.menu.fetch import startTaskToFetchMenu
from application.core.parser.string import sanitize_str

nsApi = Namespace('DS-wix', description='Wix related operations.')

marshal_connect = nsApi.schema_model('DeliveryServiceWixConnect',
                                    {'required': ['storeId'],
                                     'properties': {'storeId':{'type': 'string'}},
                                     'type': 'object'})
ds_marshal = nsApi.model('DeliveryService', DeliveryService.schema())

#######
# WIX
#######


@nsApi.route('restaurant/<int:restaurant_id>/ds/wix/connect')
@nsApi.param('restaurant_id', 'Restaurant identifier')
class DeliveryServiceWixConnect(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Connect Wix Delivery Service to a Restaurant')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    @nsApi.expect(marshal_connect, validate=True)
    @nsApi.marshal_with(ds_marshal)
    def post(self, restaurant_id):
        _restaurant = Restaurant.get_by_id(restaurant_id)
        if not _restaurant: raise NotFound
        json_dict = request.get_json()
        _wix_store_id = sanitize_str(json_dict.get('storeId'))
        _ds = connect(account_key=_restaurant.account,
                      restaurant_key=_restaurant.key,
                      store_id=_wix_store_id)
        if not _ds: raise BadRequest
        save_connect_event(
            ds_type=DeliveryServiceType.WIX,
            success=True,
            payload=json_dict,
            account=_restaurant.account,
            restaurant=_restaurant.key,
            ds=_ds.key,
            pos=_restaurant.point_of_sale,
        )
        _ds = startTaskToFetchMenu(_ds.key)
        return _ds

@nsApi.route('ds/wix/webhook')
class DeliveryServiceWixWebhook(Resource):

    @nsApi.doc('Webhook used by Wix to send data')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    # @nsApi.marshal_with(restaurant_marshal)
    def post(self):
        json_dict = request.get_json()
        _wh = save_webhook(url=request.url, service=CoreWebhookService.WIX, payload=json_dict)
        success = process_webhook(webhook_key=_wh.key, json_dict=json_dict)
        _wh.is_successful() if success else _wh.failed()
        return {"status": str(True)}
