# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/13/2019
#

from ...model.DeliveryService import DeliveryService, DeliveryServiceType
from ..common.fetch import check_delivery_service_already_connected
from application.apis.ooexceptions import ConflictResourceAlreadyExistsError
from ..common.crud import create_delivery_service
import json

def connect(account_key, restaurant_key, restaurant_url, username=None, password=None, pincode=None):
    _delivery_service_type = DeliveryServiceType.DOORDASH
    if check_delivery_service_already_connected(restaurant_key=restaurant_key,
                                                delivery_service_type=_delivery_service_type):
        raise ConflictResourceAlreadyExistsError

    credentials = {'restaurant_url': restaurant_url}

    _ds = create_delivery_service(
        restaurant_key=restaurant_key,
        delivery_service_type=_delivery_service_type,
        service_menu_url=restaurant_url,
        service_raw_data=credentials,
        service_username=username,
        service_password=password,
        service_pincode=pincode,
    )

    return _ds
