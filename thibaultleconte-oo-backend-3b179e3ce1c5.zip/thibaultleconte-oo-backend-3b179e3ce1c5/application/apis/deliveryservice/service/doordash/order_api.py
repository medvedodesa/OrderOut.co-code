import logging

from application.apis.deliveryservice.model.DeliveryService import DeliveryServiceType
from application.apis.deliveryservice.service.common.menuitem import get_menu_item_key_by_name, \
    get_menu_item_modifier_key_by_group_and_name
from application.apis.menu.service.fetch.item import fetch_all_items
from application.apis.menu.service.modifier import fetch_all_modifiers_for_menu_item
from application.apis.order.model.OrderItem import OrderItem
from application.apis.order.model.OrderItemModifier import OrderItemModifier
from application.apis.order.service.orderItem import clear_order_item_for_order
from application.core.delivery_services.doordash.doordash_api import DoorDashUnauthorized, INVALID_CREDENTIALS_CODE
from application.core.delivery_services.doordash.factories import DoorDashApiClientFactory
from application.core.event.model import CoreEventCategory
from application.core.event.service import create_event
from application.core.notification_hub.notifications.invalid_credentials import InvalidCredentialsNotification
from application.core.notification_hub.sender.factory import NotificationSlackSenderFactory
from application.core.parser.price import sanitize_price
from application.core.parser.string import sanitize_str


PROCESSED_WITH_API = True
PROCESS_WITH_PARSEUR = False

def process_order_using_doordash_api(order, ds, doordash_order_id):
    try:
        if not ds:
            return PROCESS_WITH_PARSEUR, False

        username = ds.service_username
        password = ds.service_secret
        if not (ds.type == DeliveryServiceType.DOORDASH and username and password):
            return PROCESS_WITH_PARSEUR, False

        logging.info("DoorDash API - Try to get order - order {} - delivery_service {}".format(order.key.id(), ds.key.id()))
        logging.info("DoorDash API - Complete order {}".format(order))

        save = ds.service_api_active
        logging.info("DoorDash API - Save: {}".format(str(save)))

        return process_order(order, ds, doordash_order_id, username, password, save)

    except DoorDashUnauthorized as e:
        logging.warning("DoorDash API - Unauthorized DoorDash login {}".format(order.key.id()))
        if e.doordash_code == INVALID_CREDENTIALS_CODE:
            _notify_invalid_credentials(order)
            _create_core_event_credentials(order)
        return PROCESS_WITH_PARSEUR, False

    except Exception as e:
        logging.exception("DoorDash API - Error trying to get order {} - Exception: {}".format(order.key.id(), e))
        return PROCESS_WITH_PARSEUR, False

def process_order(order, ds, doordash_order_id, username, password, save):
    doordash_api = DoorDashApiClientFactory.instantiate_google_urlfetch_api_client(username, password)
    active_orders_response = doordash_api.get_active_orders(ds.serviceLocationId)
    if not active_orders_response:
        logging.warning("DoorDash API - Invalid active orders response {}".format(active_orders_response))
        return PROCESS_WITH_PARSEUR, False

    logging.info("DoorDash API - Active orders {}".format(active_orders_response))
    _log_active_orders_ids(active_orders_response)

    fail_safe_printing = False
    all_menu_items = fetch_all_items(menu_sync_key=ds.menuSync, keys_only=False)
    logging.info("DoorDash API - All menu items {}".format(all_menu_items))

    for doordash_active_order in active_orders_response.get("kitchen"):
        doordash_order_details = doordash_active_order.get("order")
        if not doordash_order_details:
            logging.info("DoorDash API - Couldn't find order details {}".format(doordash_active_order))
            continue

        doordash_order_uuid = doordash_order_details.get("delivery_uuid")
        if not doordash_order_uuid or not doordash_order_uuid.endswith(doordash_order_id):
            logging.info("DoorDash API - Skip active order {}".format(doordash_active_order))
            continue

        doordash_order = doordash_api.get_order(doordash_order_uuid)
        logging.info("DoorDash API - Get order {}".format(doordash_order))

        if save:
            clear_order_item_for_order(order_key=order.key)

        for doordash_item in doordash_order.get("order").get("items"):
            menu_item_key = get_menu_item_key_by_name(all_menu_items, sanitize_str(doordash_item.get("item_name")))

            if not menu_item_key:
                fail_safe_printing = True
            else:
                order_item = OrderItem()
                order_item.order = order.key
                order_item.menu_item = menu_item_key
                order_item.unit_price = sanitize_price(doordash_item.get("price_monetary_fields").get("amount") / 100)
                order_item.quantity = int(doordash_item.get("quantity"))
                order_item.price = sanitize_price(order_item.unit_price * order_item.quantity)
                order_item.store_instructions = doordash_item.get("special_instruction")
                logging.info("DoorDash API - Order item {}".format(order_item))
                if save:
                    order_item.put()

                    order.order_items.append(order_item.key)
                    order.put()

                all_menu_item_modifiers = fetch_all_modifiers_for_menu_item(menu_item_key)

                for doordash_modifier_group in doordash_item.get("extras"):
                    for doordash_modifier_item in doordash_modifier_group.get("options"):
                        category_and_name = "{} {}".format(
                            sanitize_str(doordash_modifier_group.get("title")),
                            sanitize_str(doordash_modifier_item.get("name"))
                        )
                        menu_modifier_key = get_menu_item_modifier_key_by_group_and_name(all_menu_item_modifiers, category_and_name)

                        if not menu_modifier_key:
                            fail_safe_printing = True
                        else:
                            order_item_modifier = OrderItemModifier()
                            order_item_modifier.order = order.key
                            order_item_modifier.order_item = order_item.key
                            order_item_modifier.menu_item_modifier = menu_modifier_key
                            order_item_modifier.price = sanitize_price(doordash_modifier_item.get("price_monetary_fields").get("amount") / 100)
                            logging.info("DoorDash API - Order modifier item {}".format(order_item_modifier))
                            if save:
                                order_item_modifier.put()

                                order_item.selected_modifier.append(order_item_modifier.key)
                                order_item.put()

        if save:
            return PROCESSED_WITH_API, fail_safe_printing
        return PROCESS_WITH_PARSEUR, fail_safe_printing

    logging.info("DoorDash API - No matching active orders")
    return PROCESS_WITH_PARSEUR, False

def _log_active_orders_ids(active_orders_response):
    for order_status in active_orders_response.keys():
        for order in active_orders_response.get(order_status):
            if "order" in order and "delivery_uuid" in order.get("order"):
                doordash_order_uuid = order.get("order").get("delivery_uuid")
                logging.info("DoorDash API - Active order '{}' in '{}'".format(doordash_order_uuid, order_status))

def _notify_invalid_credentials(order):
    notification = InvalidCredentialsNotification(
        restaurant_id=order.restaurant.id(),
        ds_id=order.delivery_service.id(),
        ds_type=DeliveryServiceType.DOORDASH
    )
    notification_sender_group = NotificationSlackSenderFactory().create(
        monitored_channel="alerts-doordash-credentials"
    )
    notification_sender_group.dispatch(notification)

def _create_core_event_credentials(order):
    create_event(
        category=CoreEventCategory.DS_CREDENTIALS,
        name="DOORDASH Invalid credentials",
        success=False,
        message="Failed to authenticate with DoorDash",
        parent_entities_keys=[key for key in [
            order.account,
            order.restaurant,
            order.delivery_service,
            order.point_of_sale,
            order.key
        ] if key],
    )
