# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/25/2019
#

from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from application.apis.menu.service.menusync.fetch import fetch_menu_task_started, fetch_menu_task_finished
from application.apis.menu.model.MenuSync import MenuSync
from application.core.urlFetch.service import fetch_with_json_data
from flask import current_app
from application.core.error import report_error
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.apis.menu.service.creator import generate_item_dict, generate_modifier_group_dict, generate_modifier_dict, startTaskToCreateOrUpdateMenuItemsAndModifiers
from application.apis.menu.service.menusync.process import process_menu_task_started
from application.core.parser.string import sanitize_str
from application.core.settings.app import get_config_for_key
from application.apis.menu.service.crud.section import create_update_menu_section
from application.apis.menu.service.crud.category import create_update_menu_category

DEFAULT_DOORDASH_MENU_CATEGORY_IS = '1'

def startTaskToProcessMenu(menusync_key, _apify_kvs_output_id):
    _ms = menusync_key.get()
    _ms.process_external_id = str(_apify_kvs_output_id)
    _ms.put()
    _task = addTask(category=CoreTaskCategory.DOORDASH_MENU_PROCESS, entity=_ms)
    _ms = fetch_menu_task_started(menuSync_key=_ms.key, task_key=_task.key)
    return _ms

def processTaskToProcessMenuFromDoorDash(menu_sync_id):
    _task_result_json = {}
    _ms = MenuSync.get_by_id(menu_sync_id)
    if not _ms: _task_result_json['processTaskToProcessMenuFromDoorDash'] = {'message': 'MenuSync with id %s not found' % (str(menu_sync_id))}
    if not _ms.service: _task_result_json['processTaskToFetchMenuFromDoorDash'] = {'message': 'MenuSync with id %s has no ds' % (str(menu_sync_id))}
    _url, _status_code, _result_json = __start_process_menu_request(menuSync_key=_ms.key)
    _task_result_json['__start_process_menu_request'] = {'url': _url, 'status_code': _status_code, 'result_json': _result_json}

    if _status_code >= 200 and _status_code <= 299:

        _restaurant_id = sanitize_str(_result_json.get('restaurant').get('id'))
        _ds = _ms.service.get()
        _ds.serviceLocationId = str(_restaurant_id)
        _ds.put()

        fetch_menu_task_finished(menuSync_key=_ms.key, success=True)
        _menu_items = __process_menu(_ms, _result_json)
        process_menu_task_started(menuSync_key=_ms.key, tasks_keys=_menu_items)
        _task_result_json['__process_menu'] = {'message': "Delivery Service has fetched %s menu items" % (str(len(_menu_items)))}
    else:
        fetch_menu_task_finished(menuSync_key=_ms.key, success=False)

    return _task_result_json

def __start_process_menu_request(menuSync_key):
    _ms = menuSync_key.get()

    _url = __get_url_apify_doordash_process_menu(_ms.process_external_id)
    _apify_headers = {'Content-Type': 'application/json'}

    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.APIFY, method="GET", headers=_apify_headers)

    if _status_code < 200 or _status_code > 299:
        report_error(code=_status_code, subject="Apify-ProcessDoorDashMenu-Error", message="Delivery service %s returned %s" % (str(_ds.key.id()), str(_status_code)))
        return _url, _status_code, None
    return _url, _status_code, _result_json

##############
# Process Menu
##############

def __process_menu(menu_sync, raw_data):
    _sections = []
    _categories = []
    _items_tasks = []
    # SECTIONS & CATEGORIES
    if 'menus' in raw_data:
        raw_menus = raw_data['menus']
        # SECTIONS
        for raw_menu in raw_menus:
            # SECTION
            _raw_section_name = sanitize_str(raw_menu.get('name')) if raw_menu.get('name') else _raw_section_name
            _raw_section_uuid = sanitize_str(raw_menu.get('id'))
            _raw_section_description = sanitize_str(raw_menu.get('subtitle'))
            _section = create_update_menu_section(menu_sync_key=menu_sync.key,
                                                  name=_raw_section_name,
                                                  uuid=_raw_section_uuid,
                                                  description=_raw_section_description)
            _sections.append(_section)
            # CATEGORIES
            for raw_category in raw_menu.get('menu_categories'):
                # CATEGORY
                _raw_menu_category_uuid = sanitize_str(raw_category.get('id')) if raw_category.get('id') > 0 else None
                if _raw_menu_category_uuid: # DO NOT PROCESS COMPUTER GENERATED "MOST POPULAR" SECTION. It repeats some items twice.
                    _raw_menu_category_name = sanitize_str(raw_category.get('title'))
                    _category = create_update_menu_category(menu_sync_key=menu_sync.key,
                                                            section_key=_section.key,
                                                            name=_raw_menu_category_name,
                                                            uuid=_raw_menu_category_uuid)
                    _categories.append(_category)

    # ITEMS, MODIFIERS GROUPS & MODIFIERS
    if 'items' in raw_data:
        _raw_items = raw_data['items']
        for _raw_item in _raw_items:
            _raw_category_name = sanitize_str(_raw_item.get('category_title'))
            _categories, _category = get_category_for_name(_categories, _raw_category_name, menu_sync, _section)
            _item_task = __parse_item(menu_sync, _raw_item, _category.key)
            if _item_task: _items_tasks.append(_item_task)
    return _items_tasks

def get_category_for_name(categories, category_name, menu_sync, section):
    for _c in categories:
        if str(_c.name) == str(category_name):
            return categories, _c
    _c = create_update_menu_category(menu_sync_key=menu_sync.key,
                                     section_key=section.key,
                                     name=category_name,
                                     uuid=DEFAULT_DOORDASH_MENU_CATEGORY_IS)
    categories.append(_c)
    return categories, _c

def __parse_item(menu_sync, raw_item, category_key):
    _modifier_groups = __parse_modifier_groups(raw_item)
    _raw_position = raw_item.get('menu_item_number') - 1 if raw_item.get('menu_item_number') else 0
    _mi = generate_item_dict(name=raw_item.get('name'),
                             price=raw_item.get('price_monetary_fields').get('display_string'),
                             modifier_groups=_modifier_groups,
                             uuid=raw_item.get('id'),
                             position=_raw_position,
                             category_id=category_key.id())
    _task = startTaskToCreateOrUpdateMenuItemsAndModifiers(menu_sync, _mi)
    if _task: return _task.key
    return None

def __parse_modifier_groups(raw_item):
    modifier_groups = []
    if 'extras' in raw_item:
        for raw_extras in raw_item.get('extras'):
            _idx_group = raw_item.get('extras').index(raw_extras)
            _group_name = raw_extras.get('title')
            _group_uuid = raw_extras.get('id', None)
            _min_permitted = raw_extras.get('min_num_options', 0)
            _max_permitted = raw_extras.get('max_num_options', 0)
            _modifiers = __parse_modifiers(raw_extras)
            _group = generate_modifier_group_dict(name=_group_name,
                                                  modifiers=_modifiers,
                                                  uuid=_group_uuid,
                                                  min_permitted=_min_permitted,
                                                  max_permitted=_max_permitted,
                                                  position=_idx_group)
            modifier_groups.append(_group)
    return modifier_groups

def __parse_modifiers(raw_extras):
    modifiers = []
    if 'options' in raw_extras:
        for raw_option in raw_extras.get('options'):
            _idx_modifier = raw_extras.get('options').index(raw_option)
            _mod = generate_modifier_dict(name=raw_option.get('name'),
                                          price=raw_option.get('price_monetary_fields').get('display_string'),
                                          uuid=raw_option.get('id'),
                                          position=_idx_modifier)
            modifiers.append(_mod)
    return modifiers

################
# WEBHOOKS APIFY
################

def __get_url_apify_doordash_process_menu(apify_kvs_output_id):
    _apify_token = get_config_for_key('APIFY_TOKEN')
    url = "https://api.apify.com/v2/key-value-stores/%s/records/OUTPUT?disableRedirect=1&token=%s" % (str(apify_kvs_output_id), str(_apify_token))
    return url
