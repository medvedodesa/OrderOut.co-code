# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/03/2019
#
from application.core.parser.string import sanitize_str
from ..common.fetch import get_delivery_service_for_service_location_id
from application.apis.order.service.creator import create_update_order
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.error import report_error
from application.core.task.service import startDeferredTask
from application.apis.order.service.confirmation import check_order_is_confirmed, set_order_as_confirmed


def confirm_order(order_id, store_id, json_dict):

    _order_id = sanitize_str(order_id)
    _store_id = sanitize_str(store_id)

    _delivery_service = get_delivery_service_for_service_location_id(_store_id)
    if not _delivery_service: return None # Delivery Service has been disabled but DoorDash email has not been updated.
    _restaurant = _delivery_service.restaurant.get()

    _confirmation_url = json_dict.get('confirmationLink')
    _order_type = json_dict.get('orderType', '')
    _type_delivery = True if 'delivery' in _order_type.lower() else False

    _order = create_update_order(delivery_service_key=_delivery_service.key,
                                 delivery_service_uuid=_order_id,
                                 type_delivery=_type_delivery,
                                 raw_data=json_dict)

    if _delivery_service.integration_enabled == False: return _order
    if check_order_is_confirmed(_order.key): return _order

    startDeferredTask(_send_confirmation_request, _order.key, _confirmation_url)

    return _order


def _send_confirmation_request(order_key, confirmation_url):
    _result_json, _status_code, _request_key = fetch_with_json_data(url=confirmation_url, service=UrlFetchService.DOORDASH, method="GET")
    if _status_code < 200 or _status_code > 299:
        _message = 'Order %s - DoorDash order confirmation link error %s' % (str(order_key.id()), str(object=confirmation_url))
        data_dict = {'order': order_key.id(),
                     'confirmation_url': confirmation_url,
                     'status_code': _status_code,
                     'result_json': _result_json}
        report_error(500, subject='DoordDash Order Confirmation Error', message=_message, data_dict=data_dict)
        return confirmation_url, _status_code, None
    else:
        set_order_as_confirmed(order_key)
    return confirmation_url, _status_code, _result_json
