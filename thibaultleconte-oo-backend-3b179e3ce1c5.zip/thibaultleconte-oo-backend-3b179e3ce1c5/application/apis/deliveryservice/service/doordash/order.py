# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/03/2019
#
from application.core.notification_hub.notifications.order_failed_with_url import OrderFailedNotificationWithUrl
from application.core.notification_hub.sender.factory import NotificationSenderGroupFactory
from application.core.parser.string import sanitize_str
from application.core.parser.price import sanitize_price
from ..common.fetch import get_delivery_service_for_service_location_id
from application.apis.order.service.creator import create_update_order
from application.apis.order.service.orderItemModifier import create_order_item_modifier
from application.core.error import report_error
from application.apis.order.service.orderItem import clear_order_item_for_order, add_order_item_to_order
from google.appengine.ext import ndb
from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from application.apis.order.model.Order import Order
from application.apis.menu.service.fetch.item import fetch_all_items
from application.apis.menu.service.modifier import fetch_all_modifiers_for_menu_item
from application.apis.order.service.push import push_order_to_point_of_sale, push_fail_safe_order_to_printers
from ..common.menuitem import get_menu_item_key_by_name, get_menu_item_modifier_key_by_group_and_name
from application.core.event.service import create_event, CoreEventCategory
import logging

from ...model.DeliveryService import DeliveryServiceType

DICT_NAME_KEY = 'name'
DICT_DESCRIPTION_KEY = 'description'
DICT_UNIT_PRICE_KEY = 'unit_price'
DICT_QUANTITY_KEY = 'quantity'
DICT_PRICE_KEY = 'unitPrice'
DICT_MODIFIERS_KEY = 'modifiers'
DICT_INSTRUCTIONS_KEY = 'instructions'

#############
# LAUNCH TASK
#############

def process_order(order_id, store_id, json_dict):
    _order_id = sanitize_str(order_id)
    _store_id = sanitize_str(store_id)

    _delivery_service = get_delivery_service_for_service_location_id(_store_id)
    if not _delivery_service: return None # Delivery Service has been disabled but DoorDash email has not been updated.

    _order_type = json_dict.get('orderType', '')
    _type_delivery = True if 'delivery' in _order_type.lower() else False
    _ready_by = sanitize_str(json_dict.get('dateTime'))

    # _order_state = json_dict.get('current_state')
    _customer_first_name = sanitize_str(json_dict.get('dropoffName', ''))
    _customer_phone = sanitize_str(json_dict.get('dropoffPhone', ''))

    _charges_subtotal = sanitize_price(json_dict.get('subTotal', '0'))
    _charges_tax = sanitize_price(json_dict.get('tax', '0'))
    _charges_total = sanitize_price(json_dict.get('grandTotal', '0'))
    _charges_payment_mode = sanitize_str(json_dict.get('paymentMode', ''))

    _store_instructions = sanitize_str(json_dict.get('dropoffDescription'))
    _delivery_address = sanitize_str(json_dict.get('dropoffAddress'))
    _delivery_city = sanitize_str(json_dict.get('dropoffCity'))
    _delivery_state = sanitize_str(json_dict.get('dropoffState'))
    _delivery_zip = sanitize_str(json_dict.get('dropoffZip'))
    _delivery_instructions = sanitize_str(json_dict.get('deliveryInstructions'))

    _order = create_update_order(delivery_service_key=_delivery_service.key,
                                 delivery_service_uuid=_order_id,
                                 type_delivery=_type_delivery,
                                 raw_data=json_dict,
                                 customer_name=_customer_first_name,
                                 customer_phone=_customer_phone,
                                 charge_tax=_charges_tax,
                                 charge_subtotal=_charges_subtotal,
                                 charge_total=_charges_total,
                                 charge_payment_mode=_charges_payment_mode,
                                 store_instructions=_store_instructions,
                                 delivery_address=_delivery_address,
                                 delivery_city=_delivery_city,
                                 delivery_state=_delivery_state,
                                 delivery_zip=_delivery_zip,
                                 delivery_instructions=_delivery_instructions,
                                 ready_by=_ready_by)

    _task = addTask(category=CoreTaskCategory.DOORDASH_ORDER_PROCESS, entity=_order, data_dict=json_dict)

    return _order

##############
# PROCESS TASK
##############

def processTaskToProcessOrderFromDoorDash(order_id, json_dict):
    logging.info("Processing order id {} for DoorDash".format(order_id))

    _fail_safe_printing = False

    _order = Order.get_by_id(order_id)
    delivery_service = _order.delivery_service.get()

    try:
        logging.info("DoorDash API - Complete parseur payload {}".format(json_dict))

        _raw_items = json_dict.get('items')
        _order_items_keys, _fail_safe_printing = __return_list_of_order_items_keys(_order.key, delivery_service.menuSync,  _raw_items)
        logging.info("DoorDash API - Final parseur order items {}".format(_order_items_keys))

        _order.order_items = _order_items_keys
        _order.put()

        if _fail_safe_printing:
            # FAIL SAFE PRINTING MODE
            push_fail_safe_order_to_printers(_order.key, json_dict)
            logging.exception("Fail to process doordash order from parseur")

            restaurant = delivery_service.restaurant.get()

            notification = OrderFailedNotificationWithUrl(
                order_id=order_id,
                ds_type=str(DeliveryServiceType.DOORDASH),
                order_info_url=json_dict.get("OriginalDocument", ()).get("url"),
            )

            notification_sender_group = NotificationSenderGroupFactory(restaurant).create(
                monitored_channel="order-alerts"
            )

            notification_sender_group.dispatch(notification)
        else:
            # POINT OF SALE
            push_order_to_point_of_sale(_order.key)

        return {'order_id': str(_order.key.id()), 'fail_safe_printing': str(_fail_safe_printing)}
    except Exception as e:
        logging.exception("Exception on processing doordash order from parseur {}".format(e))

        restaurant = delivery_service.restaurant.get()

        notification = OrderFailedNotificationWithUrl(
            order_id=order_id,
            ds_type=str(DeliveryServiceType.DOORDASH),
            order_info_url=json_dict.get("OriginalDocument", ()).get("url"),
        )

        notification_sender_group = NotificationSenderGroupFactory(restaurant).create(
            monitored_channel="order-alerts"
        )

        notification_sender_group.dispatch(notification)

#########################
# ORDER DETAIL PROCESSING
#########################

def __return_list_of_order_items_keys(order_key, menuSync_key, raw_menu_items):
    _fail_safe_printing = False
    _order_items_keys = []
    clear_order_item_for_order(order_key=order_key)
    _all_menu_items = fetch_all_items(menu_sync_key=menuSync_key, keys_only=False)
    logging.info(order_key)
    _built_menu_items = build_items_array_from_raw_menu_items(raw_menu_items=raw_menu_items)

    # MENU ITEMS
    ############
    for _built_menu_item in _built_menu_items:
        _item_name = _built_menu_item.get(DICT_NAME_KEY)
        _item_unit_price = _built_menu_item.get(DICT_UNIT_PRICE_KEY)
        _item_quantity = _built_menu_item.get(DICT_QUANTITY_KEY)
        _item_price = _built_menu_item.get(DICT_PRICE_KEY)
        _item_instruction = _built_menu_item.get(DICT_INSTRUCTIONS_KEY)

        _menu_item_key = get_menu_item_key_by_name(_all_menu_items, _item_name)
        if not _menu_item_key:
            report_item_not_found(order_key=order_key, raw_order_item_name=_item_name, raw_order_item_price=_item_price, raw_menu_items=raw_menu_items, built_menu_items=_built_menu_items)
            _fail_safe_printing = True
        else:
            _order_item = add_order_item_to_order(order_key=order_key,
                                                  menu_item_key=_menu_item_key,
                                                  unit_price=_item_unit_price,
                                                  quantity=_item_quantity,
                                                  price=_item_price,
                                                  store_instructions=_item_instruction)
            _order_items_keys.append(_order_item.key)

            # MODIFIERS
            ###########
            _modifiers = fetch_all_modifiers_for_menu_item(_order_item.menu_item)
            _built_modifiers_names = _built_menu_item.get(DICT_MODIFIERS_KEY)
            _order_item_modifiers = []

            for _built_modifier_name in _built_modifiers_names:
                _modifier_key = get_menu_item_modifier_key_by_group_and_name(_modifiers, _built_modifier_name)

                if not _modifier_key:
                    report_modifier_not_found(order_key=order_key, built_modifier_name=_built_modifier_name, built_modifiers_names=_built_modifiers_names, raw_menu_items=raw_menu_items, built_menu_items=_built_menu_items)
                    _fail_safe_printing = True
                else:
                    _order_item_modifier = create_order_item_modifier(order_key=order_key,
                                                                      order_item_key=_order_item.key,
                                                                      menu_item_modifier_key=_modifier_key)
                    _order_item_modifiers.append(_order_item_modifier)

            if len(_order_item_modifiers) > 0: ndb.put_multi(_order_item_modifiers)

            # save modifier to order item selected modifier list
            _order_item_modifiers_keys = []
            for _order_item_modifier in _order_item_modifiers: _order_item_modifiers_keys.append(_order_item_modifier.key)
            _order_item.selected_modifier = _order_item_modifiers_keys
            _order_item.put()

    return _order_items_keys, _fail_safe_printing


#######################
# ORDER DETAILS PARSING
#######################

def build_items_array_from_raw_menu_items(raw_menu_items):
    _items_array = []
    for _raw_menu_item in raw_menu_items:
        _item_dict = {}
        # Order item attributes
        _item_quantity = _raw_menu_item.get('quantity')
        _item_unit_price = parse_order_menu_item_unit_price(_raw_menu_item)
        _item_price = parse_order_menu_item_price(_raw_menu_item)
        # Order item name formatting
        _raw_name, _item_name, _item_category, _item_extra = parse_order_menu_item_to_split_name_and_category_and_extra(_raw_menu_item)
        _raw_modifiers_names, _item_instructions = parse_order_item_modifier_names_and_instructions(raw_extra=_item_extra)
        # Generate Order Item Dictionary
        _item_dict = {DICT_QUANTITY_KEY: _item_quantity,
                      DICT_UNIT_PRICE_KEY: _item_unit_price,
                      DICT_PRICE_KEY: _item_price,
                      DICT_NAME_KEY: _item_name,
                      DICT_MODIFIERS_KEY: _raw_modifiers_names,
                      DICT_INSTRUCTIONS_KEY: _item_instructions}
        _items_array.append(_item_dict)

    return _items_array

def parse_order_menu_item_unit_price(raw_menu_item):
    _raw_price = raw_menu_item.get('price')
    _raw_unit_price = raw_menu_item.get('unitPrice')
    if not _raw_price:
        if _raw_unit_price.count('$') > 0:
            _prices = _raw_unit_price.split(' $')
            if _prices:
                _price = sanitize_price(_prices[0])
                return _price
    _raw_unit_price = raw_menu_item.get('unitPrice')
    if _raw_unit_price:
        _price = sanitize_price(_raw_unit_price)
        return _price
    return None

def parse_order_menu_item_price(raw_menu_item):
    _raw_price = raw_menu_item.get('price')
    _raw_unit_price = raw_menu_item.get('unitPrice')
    if _raw_price:
        _price = sanitize_price(_raw_price)
        return _price
    elif not _raw_price and _raw_unit_price:
        if _raw_unit_price.count('$') > 0:
            _prices = _raw_unit_price.split('$')
            if _prices:
                _price = sanitize_price(_prices[-1])
                return _price
    return None

def parse_order_menu_item_to_split_name_and_category_and_extra(raw_menu_item):
    _raw_name = sanitize_str(raw_menu_item.get('description'))
    _raw_extra = sanitize_str(raw_menu_item.get('extra'))

    # merge description and extra if doordash format poorly
    if _raw_name and _raw_extra:
        if _raw_name.count('(') != _raw_name.count(')') and _raw_extra.count('(') != _raw_extra.count(')'):
            _raw_name = _raw_name + ' ' + _raw_extra

    # name and category parsing
    _keyword_category_separator_start = '(in'
    _keyword_category_separator_end = ')'
    _final_name = None
    _final_category = None
    _final_extra = None
    _parse_extra_from_name = None
    if _raw_name:
        if _keyword_category_separator_start in _raw_name:
            _raw_names = _raw_name.split(_keyword_category_separator_start)
            if len(_raw_names) > 1:
                _final_name = sanitize_str(_raw_names[0])
                _raw_category = sanitize_str(_keyword_category_separator_start + ' ' + _raw_names[1])
                if _keyword_category_separator_end in _raw_category:
                    _raw_categories = _raw_category.split(_keyword_category_separator_end)
                    if len(_raw_categories) > 1:
                        _final_category = sanitize_str(_raw_categories[0] + _keyword_category_separator_end)
                        _parse_extra_from_name = sanitize_str(_keyword_category_separator_end.join(_raw_categories[1:]))

    # handle extra logic if extra was part of description
    if _parse_extra_from_name:
        _final_extra = _parse_extra_from_name
    else:
        _final_extra = _raw_extra
    if _final_extra and _final_category:
        if _final_extra in _final_category:
            _final_extra = None

    return _raw_name, _final_name, _final_category, _final_extra

def parse_order_item_modifier_names_and_instructions(raw_extra):
    _raw_order_item_modifiers_names = []
    _raw_item_instruction = None
    if not raw_extra: return _raw_order_item_modifiers_names, _raw_item_instruction
    for _line in raw_extra.split('\xe2\x80\xa2'):
        if len(_line) == 0: continue
        _instructions_separator = 'special instructions:'
        if _instructions_separator in _line.lower():
            _raw_item_instruction = _line.lower().replace(_instructions_separator, '')
            _raw_item_instruction = sanitize_str(_raw_item_instruction)
        else:
            _order_item_price_separator = '(+ $'
            if _order_item_price_separator in _line:
                _line = _line.split(_order_item_price_separator)[0]
            _raw_modifier_name = sanitize_str(_line)
            _raw_order_item_modifiers_names.append(_raw_modifier_name)
    return _raw_order_item_modifiers_names, _raw_item_instruction

########
# HELPER
########

def report_item_not_found(order_key, raw_order_item_name, raw_order_item_price, raw_menu_items, built_menu_items):
    logging.warning(raw_order_item_name)
    logging.warning(raw_order_item_price)
    logging.warning(raw_menu_items)
    _name = "Doordash Order MenuItem Not Found"
    _message = 'Order %s - "%s" at %s not found' % (str(order_key.id()), raw_order_item_name, str(raw_order_item_price))
    _data_dict = {'order': order_key.id(),
                  'raw_order_item_name': raw_order_item_name,
                  'raw_order_item_price': raw_order_item_price,
                  'raw_menu_items': raw_menu_items,
                  'built_menu_items': built_menu_items}
    _order = order_key.get()
    _parent_entities_keys = [order_key]
    if _order.account: _parent_entities_keys.append(_order.account)
    if _order.restaurant: _parent_entities_keys.append(_order.restaurant)
    if _order.point_of_sale: _parent_entities_keys.append(_order.point_of_sale)
    if _order.delivery_service: _parent_entities_keys.append(_order.delivery_service)
    create_event(category=CoreEventCategory.UNKNOWN_MENU_ITEM,
                 name=_name,
                 success=False,
                 message=_message,
                 payload=_data_dict,
                 entity_key=order_key,
                 parent_entities_keys=_parent_entities_keys)
    report_error(400, subject=_name, message=_message, data_dict=_data_dict)
    return

def report_modifier_not_found(order_key, built_modifier_name, built_modifiers_names, raw_menu_items, built_menu_items):
    logging.warning(built_modifier_name)
    logging.warning(built_modifiers_names)
    logging.warning(raw_menu_items)
    _name = "Doordash Order MenuItemModifier Not Found"
    _message = 'Order %s - Modifiers not found "%s"' % (str(order_key.id()), built_modifier_name)
    _data_dict = {'order': order_key.id(),
                  'built_modifier_name': built_modifier_name,
                  'built_modifiers_names': built_modifiers_names,
                  'raw_menu_items': raw_menu_items,
                  'built_menu_items': built_menu_items}
    _order = order_key.get()
    _parent_entities_keys = [order_key]
    if _order.account: _parent_entities_keys.append(_order.account)
    if _order.restaurant: _parent_entities_keys.append(_order.restaurant)
    if _order.point_of_sale: _parent_entities_keys.append(_order.point_of_sale)
    if _order.delivery_service: _parent_entities_keys.append(_order.delivery_service)
    create_event(category=CoreEventCategory.UNKNOWN_MENU_MODIFIER,
                 name=_name,
                 success=False,
                 message=_message,
                 payload=_data_dict,
                 entity_key=order_key,
                 parent_entities_keys=_parent_entities_keys)
    report_error(400, subject=_name, message=_message, data_dict=_data_dict)
    return
