# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/13/2019
#
from application.core.delivery_services.ubereats.factories import UberEatsApiClientFactory
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from .authentication import get_ubereats_header
from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from application.apis.order.model.Order import Order
from application.apis.deliveryservice.service.ubereats.order import start_task_fetch_order_details
from application.core.email.service import send_admin_email
import logging
from json import dumps as json_dumps
from application.core.settings.app import get_config_for_key
from application.apis.restaurant.service import get_preparation_time_utc_timestamp


####################
# POINT OF SALE DATA
####################

def get_pos_data(store_id):
    _url = 'https://api.uber.com/v1/eats/stores/' + store_id + '/pos_data'
    _method = "GET"
    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.UBEREATS, method=_method, headers=get_ubereats_header())
    logging.info(_status_code)
    if _status_code < 200 or _status_code > 299:
        _json_message = _result_json.get('message')
        _subject = "[UberEats] - %s" % (str(_json_message))
        _body = "UUID: %s\nUrl: %s\nMethod: %s\nStatus Code:%s\nResponse: %s" % (str(store_id), str(_url), str(_method), str(_status_code), json_dumps(_result_json))
        logging.info(_body)
        _success = send_admin_email(recipients=get_config_for_key('EMAIL_TO_SUPPORT_MANAGER'), subject=_subject, body=_body)
        logging.info(_success)
        return _url, _status_code, None
    return _url, _status_code, _result_json

def update_pos_data(delivery_service, pos_integration_enabled=True, order_release_enabled=True):
    store_id = delivery_service.serviceLocationId
    _parameters = {'pos_integration_enabled': pos_integration_enabled, 'order_release_enabled': order_release_enabled}
    _url = 'https://api.uber.com/v1/eats/stores/' + store_id + '/pos_data'
    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.UBEREATS, method="PATCH", headers=get_ubereats_header(), data=_parameters)
    if _status_code < 200 or _status_code > 299: return _url, _status_code, None
    return _url, _status_code, _result_json


def update_pos_data_v2(delivery_service, pos_integration_enabled):
    uber_eats_api = UberEatsApiClientFactory.instantiate_google_urlfetch_api_client(
        refresh_token=delivery_service.refresh_token
    )

    store_id = delivery_service.serviceLocationId

    logging.info("store_id: {}".format(store_id))

    response, status_code, _ = uber_eats_api.update_integration(
        store_id=store_id, active=pos_integration_enabled, get_all_args=True
    )

    return "", status_code, response

##############
# ACCEPT ORDER
##############

def start_task_accept_order(order_key, json_dict):
    _order = order_key.get()
    _task = addTask(category=CoreTaskCategory.UBEREATS_ORDER_ACCEPT, entity=_order, data_dict=json_dict)
    return _task

def process_task_to_accept_order(order_id, json_dict):
    _order = Order.get_by_id(order_id)
    _parameters = {"reason": "Order has been accepted.",
                   "external_reference_id": str(order_id),
                   "pickup_time": get_preparation_time_utc_timestamp(_order.restaurant)}
    _url = 'https://api.uber.com/v1/eats/orders/' + _order.delivery_service_uuid + '/accept_pos_order'
    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.UBEREATS, method="POST", headers=get_ubereats_header(), data=_parameters)
    if _status_code < 200 or _status_code > 299: return _url, _status_code, None
    logging.info(_result_json)
    # Next task to fetch order details and process order
    _task = start_task_fetch_order_details(_order.key, json_dict)
    _task_result_json = {'url': _url,
                         'status_code': _status_code,
                         'result_json': _result_json,
                         'fetch_order_details_task': str(_task.key.id())}
    return _task_result_json

############
# DENY ORDER
############

def start_task_deny_order(order_key, reason, json_dict):
    _order = order_key.get()
    _task = addTask(category=CoreTaskCategory.UBEREATS_ORDER_DENY, entity=_order, data_dict=json_dict)
    return _task

def process_task_to_deny_order(order_id):
    _order = Order.get_by_id(order_id)
    _parameters = {'reason': {'explanation': 'out of stock'}}
    _url = 'https://api.uber.com/v1/eats/orders/' + _order.delivery_service_uuid + '/deny_pos_order'
    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.UBEREATS, method="POST", headers=get_ubereats_header(), data=_parameters)
    if _status_code < 200 or _status_code > 299: return _url, _status_code, None
    logging.info(_result_json)
    _task_result_json = {'url': _url,
                         'status_code': _status_code,
                         'result_json': _result_json}
    return _task_result_json
