# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/13/2019
#

from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from .authentication import get_ubereats_header
from .order import create_order
from .cancel import cancel_order
from application.core.error import report_error
from application.apis.order.service.fetch import fetch_order_from_delivery_service_uuid
import logging
from application.apis.order.service.push import push_canceled_order_to_printers
from .pointofsale import start_task_accept_order, start_task_deny_order
from application.core.event.service import create_event, CoreEventCategory


def process_webhook(webhook_key, json_dict):
    # event
    _event_type = json_dict.get('event_type')
    if _event_type == 'orders.notification':
        _order_uuid = json_dict.get('meta').get('resource_id')
        _store_id = json_dict.get('meta').get('user_id')
        _order = create_order(order_uuid=_order_uuid, store_id=_store_id, json_dict=json_dict)
        if _order:
            if _order.delivery_service:
                _delivery_service = _order.delivery_service.get()
                if _delivery_service.integration_enabled:
                    _task = start_task_accept_order(order_key=_order.key, json_dict=json_dict)
                    # _task = start_task_deny_order(order_key=_order.key, reason='No inventory', json_dict=json_dict)
                else:
                    _parent_entities_keys = [webhook_key, _order.key]
                    if _order.account:
                        _parent_entities_keys.append(_order.account)
                    if _order.restaurant:
                        _parent_entities_keys.append(_order.restaurant)
                    if _order.delivery_service:
                        _parent_entities_keys.append(_order.delivery_service)
                    if _order.point_of_sale:
                        _parent_entities_keys.append(_order.point_of_sale)
                    _message = 'Delivery Service Integration is disabled. Order details are not fetched.'
                    create_event(category=CoreEventCategory.DS_DISCONNECT,
                                 name='UBEREATS',
                                 success=False,
                                 message=_message,
                                 payload=json_dict,
                                 parent_entities_keys=_parent_entities_keys)
    elif _event_type == 'orders.release':
        _order_uuid = json_dict.get('meta').get('resource_id')
        _store_id = json_dict.get('meta').get('user_id')
        _order = fetch_order_from_delivery_service_uuid(_order_uuid)
        _parent_entities_keys = [webhook_key, _order.key]
        if _order.account:
            _parent_entities_keys.append(_order.account)
        if _order.restaurant:
            _parent_entities_keys.append(_order.restaurant)
        if _order.delivery_service:
            _parent_entities_keys.append(_order.delivery_service)
        if _order.point_of_sale:
            _parent_entities_keys.append(_order.point_of_sale)
        _message = 'UberEats Order Release Notification'
        create_event(category=CoreEventCategory.ORDER_RELEASE,
                     name='UBEREATS',
                     success=True,
                     message=_message,
                     payload=json_dict,
                     parent_entities_keys=_parent_entities_keys)
    elif _event_type == 'orders.cancel':
        _order_uuid = json_dict.get('meta').get('resource_id')
        _store_id = json_dict.get('meta').get('user_id')
        _order = create_order(order_uuid=_order_uuid, store_id=_store_id, json_dict=json_dict)
        cancel_order(order_uuid=_order_uuid, store_id=_store_id)
        if _order:
            push_canceled_order_to_printers(_order.key)
    else:
        _message = 'event type received is %s' % (str(_event_type))
        _subject = 'UberEats API - Unknown event type'
        report_error(code=500, message=_message, subject=_subject, data_dict=json_dict)

    return True
