# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/27/2019
#
import logging

from google.appengine.api import memcache

from application.core.delivery_services.ubereats.factories import UberEatsApiClientFactory
from application.core.exception import ConflictResourceAlreadyExistsError
from application.core.settings.app import get_config_for_key
from application.core.slack.onboarding import post_to_self_onboarding_for_new_delivery_service
from .menu.fetch import startTaskToFetchMenu
from ..common.events import save_connect_event
from ...model.DeliveryService import DeliveryServiceType
from ..common.fetch import check_delivery_service_already_connected
from .store import get_store_details
from ..common.crud import create_delivery_service


logger = logging.getLogger(__name__)


def connect(account_key, restaurant_key, store_id):
    _delivery_service_type = DeliveryServiceType.UBEREATS
    if check_delivery_service_already_connected(restaurant_key=restaurant_key, delivery_service_type=_delivery_service_type):
        raise ConflictResourceAlreadyExistsError

    _url, _status_code, _result_json = get_store_details(store_id)

    mc_client = memcache.Client()
    refresh_token = mc_client.get("ubereats/{}/refresh_token".format(restaurant_key.id()))

    _ds = create_delivery_service(restaurant_key=restaurant_key,
                                  delivery_service_type=_delivery_service_type,
                                  service_raw_data=_result_json,
                                  service_location_uuid=store_id,
                                  refresh_token=refresh_token,
                                  )

    return _ds


def after_connect_successful(payload, store_id, restaurant, ds):
    save_connect_event(
        ds_type=DeliveryServiceType.UBEREATS,
        success=True,
        payload=payload,
        account=restaurant.account,
        restaurant=restaurant.key,
        ds=ds.key,
        pos=restaurant.point_of_sale,
    )

    if ds.refresh_token:
        uber_eats_api_client = UberEatsApiClientFactory.instantiate_google_urlfetch_api_client(
            refresh_token=ds.refresh_token,
        )
        uber_eats_api_client.update_integration(store_id=store_id, active=False)

        _admin_url = "{}/restaurant/{}".format(get_config_for_key("ADMIN_BASE_URL"), str(restaurant.key.id()))
        _onboarding_url = "{}/restaurant/{}/onboarding".format(get_config_for_key("DASHBOARD_BASE_URL"),
                                                               str(restaurant.key.id()))

        post_to_self_onboarding_for_new_delivery_service(
            account_name=restaurant.account.get().name,
            restaurant_name=restaurant.name,
            delivery_service_name=ds.type,
            delivery_service_public_menu_url="",
            delivery_service_username="",
            restaurant_dashboard_url=_admin_url,
            restaurant_onboarding_url=_onboarding_url
        )

    _ds = startTaskToFetchMenu(ds.key)

    return _ds
