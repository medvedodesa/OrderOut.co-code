# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/03/2019
#

from application.core.parser.string import sanitize_str
from application.apis.deliveryservice.service.common.fetch import get_delivery_service_for_service_location_id
from application.apis.order.service.fetch import fetch_order_by_restaurant_and_delivery_service
from application.apis.order.service.cancel import order_is_canceled


def cancel_order(order_uuid, store_id):

    _order_uuid = sanitize_str(order_uuid)
    _store_id = sanitize_str(store_id)

    _delivery_service = get_delivery_service_for_service_location_id(_store_id)

    if _delivery_service:
        _order = fetch_order_by_restaurant_and_delivery_service(_delivery_service.restaurant, [_delivery_service.key], _order_uuid)
        if _order:
            _order = order_is_canceled(_order.key)

        return _order
