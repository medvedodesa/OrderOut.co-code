from marshmallow import Schema, fields


from application.core.util.date_utils import validate_hour_minute_format
from application.shared.fields import String, PositiveFloat
from application.shared.schemas import BaseNDBSchema


class MenuSectionAvailabilityTimePeriodSchema(Schema):
    start_time = fields.Str(validate=validate_hour_minute_format, required=True)
    end_time = fields.Str(validate=validate_hour_minute_format, required=True)


class MenuSectionAvailabilitySchema(Schema):
    day_of_week = fields.Str(
        required=True,
        validate=lambda dow: dow
        in [
            "monday",
            "tuesday",
            "wednesday",
            "thursday",
            "friday",
            "saturday",
            "sunday",
        ],
    )
    enabled = fields.Bool(default=True)
    time_periods = fields.Nested(
        MenuSectionAvailabilityTimePeriodSchema, many=True, required=True
    )


class MenuItemModifierSchema(Schema):
    price = PositiveFloat(required=True)
    external_id = fields.Str(attribute="id", required=True)
    title = String(stylize=lambda s: s.capitalize(), attribute="name", required=True)


class MenuItemModifierGroupSchema(BaseNDBSchema):
    customization_options = fields.Nested(
        MenuItemModifierSchema, attribute="modifiers", many=True, required=True
    )
    max_permitted = fields.Function(
        lambda obj: obj.max_permitted
        if obj.max_permitted <= len(obj.modifiers)
        else len(obj.modifiers),
        required=True,
    )
    min_permitted = fields.Int(required=True)
    title = String(
        stylize=lambda s: s.capitalize(), attribute="name", required=True
    )


class MenuItemSchema(BaseNDBSchema):
    item_description = String(
        stylize=lambda s: s.capitalize(), attribute="description", required=True
    )
    title = String(stylize=lambda s: s.capitalize(), attribute="name", required=True)
    external_id = fields.Str(attribute="id", required=True)
    price = PositiveFloat(required=True)
    customizations = fields.Nested(
        MenuItemModifierGroupSchema,
        attribute="modifier_groups",
        many=True,
        required=True,
    )
    vat_rate_percentage = PositiveFloat(required=True)
    image_url = fields.Str(required=True)
    is_alcohol = fields.Bool(required=True)
    tax_rate = PositiveFloat(required=True)
    disable_instructions = fields.Bool(required=True)
    currency_code = fields.Str(attribute="currency", required=True)


class MenuCategorySchema(BaseNDBSchema):
    title = String(stylize=lambda s: s.capitalize(), attribute="name", required=True)
    items = fields.Nested(
        MenuItemSchema, attribute="menuitems", many=True, required=True
    )


class PushMenuSectionSchema(BaseNDBSchema):
    title = String(stylize=lambda s: s.capitalize(), attribute="name", required=True)
    subtitle = String(
        stylize=lambda s: s.capitalize(), attribute="description", required=True
    )
    service_availability = fields.Nested(
        MenuSectionAvailabilitySchema,
        attribute="availability",
        many=True,
        required=True,
    )
    subsections = fields.Nested(
        MenuCategorySchema, attribute="categories", many=True, required=True
    )


class PushMenuSchema(BaseNDBSchema):
    sections = fields.Nested(PushMenuSectionSchema, attribute="menu_sections", many=True, required=True)
