from marshmallow import Schema, fields, post_load

from application.apis.restaurant.model import Restaurant


class StoreLocationSchema(Schema):
    street_address_1 = fields.Str(load_from="address")
    street_address_2 = fields.Str(load_from="address_2")
    city = fields.Str()
    country = fields.Str()
    zipcode = fields.Str(load_from="postal_code")
    state = fields.Str()


class StoreSerializerSchema(Schema):
    name = fields.Str()
    store_id = fields.Str()
    location = fields.Nested(StoreLocationSchema)

    @post_load
    def post_load(self, data):
        location = data["location"]
        restaurant = Restaurant(
            name="{address_1} {address_2}, {city}, {state}, {zipcode}".format(
                address_1 = location.get("street_address_1", ""),
                address_2 = location.get("street_address_2", ""),
                city=location.get("city", ""),
                state=location.get("state", ""),
                zipcode=location.get("zipcode", ""),
            ),
            **location
        )
        return restaurant