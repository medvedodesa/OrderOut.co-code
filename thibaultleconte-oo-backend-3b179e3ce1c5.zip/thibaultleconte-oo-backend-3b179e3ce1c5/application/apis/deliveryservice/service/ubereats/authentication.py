# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/09/2019
#

from flask import current_app
from authlib.client import OAuth2Session
from google.appengine.api import memcache
from application.core.settings.app import get_config_for_key
import logging

__MEMCACHE_KEY_UBER_EATS_ACCESS_TOKEN = 'ds_ubereats_access_token_v2'

def get_ubereats_header():
    _access_token = __get_access_token()
    _headers = { 'Content-Type': 'application/json',
                 'Authorization': 'Bearer ' + _access_token}
    return _headers

def __generate_ubereats_access_token():
    client_id = get_config_for_key('UBEREATS_CLIENT_ID')
    client_secret = get_config_for_key('UBEREATS_CLIENT_SECRET')
    scope = get_config_for_key('UBEREATS_SCOPE')
    token_url = get_config_for_key('UBEREATS_TOKEN_URL')
    session = OAuth2Session(client_id, client_secret, scope=scope)
    data = session.fetch_access_token(token_url, grant_type='client_credentials')
    __store_authentication_data(data)
    return __get_access_token()

def __get_access_token():
    mc_client = memcache.Client()
    result_json = mc_client.get(__MEMCACHE_KEY_UBER_EATS_ACCESS_TOKEN)
    if not result_json:
        _access_token = __generate_ubereats_access_token()
    else:
        _access_token = result_json.get('access_token')
        if not _access_token:
            _access_token = __generate_ubereats_access_token()
    return _access_token

def __store_authentication_data(auth_data):
    _expires_in = auth_data.get('expires_in', 60*5)
    _expires_in = _expires_in - 60
    mc_client = memcache.Client()
    return mc_client.set(key=__MEMCACHE_KEY_UBER_EATS_ACCESS_TOKEN,
                         value=auth_data,
                         time=_expires_in)

def reset_ubereats_access_token():
    mc_client = memcache.Client()
    result = mc_client.delete(__MEMCACHE_KEY_UBER_EATS_ACCESS_TOKEN)
    logging.warning("UberEats Access Token reset: %s" % (str(result)))
    return True
