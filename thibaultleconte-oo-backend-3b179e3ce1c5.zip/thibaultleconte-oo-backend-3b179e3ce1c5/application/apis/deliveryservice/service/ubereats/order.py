# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/11/2019
#

from application.apis.menu.model.MenuItem import MenuItem
from ..common.fetch import get_delivery_service_for_service_location_id
from application.apis.order.service.creator import create_update_order, update_order
from application.apis.order.service.orderItem import add_order_item_to_order
from application.apis.order.service.orderItemModifier import create_order_item_modifier
from application.apis.order.service.push import push_order_to_point_of_sale
import logging
from application.core.parser.string import sanitize_str
from application.core.parser.price import sanitize_price
from google.appengine.ext import ndb
from application.apis.menu.service.modifier import fetch_all_menu_item_modifiers_keys_for_ids
from application.core.error import report_error
from application.apis.order.service.confirmation import check_order_is_confirmed, set_order_as_confirmed
from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from application.apis.order.model.Order import Order
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from .authentication import get_ubereats_header
from application.core.event.service import create_event, CoreEventCategory
from application.core.settings.app import get_config_for_key
from application.core.slack.alert_ubereats import post_to_alert_ubereats_menu_for_missing_external_id


######################
# GENERIC ORDER HELPER
######################

def create_order(order_uuid, store_id, json_dict):
    _order_uuid = sanitize_str(order_uuid)
    _store_id = sanitize_str(store_id)
    logging.info("UberEats Order UUID %s" % str(_order_uuid))
    logging.info("UberEats Store UUID %s" % str(_store_id))
    _delivery_service = get_delivery_service_for_service_location_id(_store_id)

    if not _delivery_service:
        _message = "Delivery Service NOT FOUND for UberEats Store UUID %s" % str(_store_id)
        logging.info(_message)
        create_event(category=CoreEventCategory.UUID,
                     name='UBEREATS',
                     success=False,
                     message=_message,
                     payload=json_dict)
        return None

    _account = _delivery_service.account.get()
    _restaurant = _delivery_service.restaurant.get()
    if _account.api_status == False or _restaurant.api_status == False: return None

    logging.info(json_dict)

    _order = create_update_order(delivery_service_key=_delivery_service.key,
                                 delivery_service_uuid=_order_uuid,
                                 type_delivery=True,
                                 raw_data=json_dict)
    return _order


###############
# ORDER DETAILS
###############

def start_task_fetch_order_details(order_key, json_dict):
    _order = order_key.get()
    _task = addTask(category=CoreTaskCategory.UBEREATS_ORDER_DETAILS, entity=_order, data_dict=json_dict)
    return _task

def process_task_to_fetch_order_details(order_id, json_dict):
    import logging
    logging.info("UberEats Order ID %s" % str(order_id))
    _order = Order.get_by_id(order_id)
    _account = _order.account.get()
    _restaurant = _order.restaurant.get()
    if _account.api_status == False or _restaurant.api_status == False: return {'account api_status': _account.api_status, ' restaurant api_status': _restaurant.api_status}

    _task_result_json = process_task_to_fetch_order_details_for_ubereats_api_v2(order=_order)
    return _task_result_json

##################
# UBER EATS API V2
##################

def process_task_to_fetch_order_details_for_ubereats_api_v2(order):
    _url = 'https://api.uber.com/v2/eats/order/' + order.delivery_service_uuid
    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.UBEREATS, method="GET", headers=get_ubereats_header())
    _task_result_json = {'url': _url,
                         'status_code': _status_code,
                         'result_json': _result_json}
    if _status_code < 200 or _status_code > 299: return _task_result_json
    logging.info(_result_json)
    _order = _process_order_v2(order_key=order.key, json_dict=_result_json)
    _task_result_json['order'] = str(_order.key.id())
    return _task_result_json

def _process_order_v2(order_key, json_dict):

    _order = order_key.get()

    # ORDER CONFIRMED
    if check_order_is_confirmed(order_key) == False:
        set_order_as_confirmed(_order.key)

    _delivery_service = _order.delivery_service.get()

    _order_id_short = sanitize_str(json_dict.get('display_id'))
    _order_state = sanitize_str(json_dict.get('current_state'))
    _customer_first_name = sanitize_str(json_dict.get('eater', {}).get('first_name'))

    # _raw_charges_subtotal_array = filter(lambda charge: charge['charge_type'] == 'subtotal', json_dict.get('charges'))
    # _raw_charges_subtotal = _raw_charges_subtotal_array[0].get('formatted_price') if len(_raw_charges_subtotal_array) > 0 else 0.0
    _raw_charges_subtotal = json_dict.get('payment', {}).get('charges', {}).get('sub_total', {}).get('amount', 0.0) / 100.0
    _charges_subtotal = sanitize_price(_raw_charges_subtotal)

    # _raw_charges_service_fee_array = filter(lambda charge: charge['charge_type'] == 'delivery_fee', json_dict.get('charges'))
    # _raw_charges_service_fee = _raw_charges_service_fee_array[0].get('formatted_price') if len(_raw_charges_service_fee_array) > 0 else 0.0
    _raw_charges_service_fee = json_dict.get('payment', {}).get('charges', {}).get('total_fee', {}).get('amount', 0.0) / 100.0
    _charges_service_fee = sanitize_price(_raw_charges_service_fee)

    _raw_charges_tax = json_dict.get('payment', {}).get('charges', {}).get('tax', {}).get('amount', 0.0) / 100.0
    _charges_delivery_tax = sanitize_price(_raw_charges_tax)

    _raw_charges_total = json_dict.get('payment', {}).get('charges', {}).get('total', {}).get('amount', 0.0) / 100.0
    _charges_delivery_total = sanitize_price(_raw_charges_total)

    _raw_cart = json_dict.get('cart')
    _store_instructions = sanitize_str(_raw_cart.get('special_instructions'))
    _raw_items = _raw_cart.get('items')

    _order = update_order(order_key=_order.key,
                          type_delivery=True,
                          raw_data=json_dict,
                          customer_name=_customer_first_name,
                          delivery_service_short_uuid=_order_id_short,
                          charge_subtotal=_charges_subtotal,
                          charge_fee=_charges_service_fee,
                          charge_tax=_charges_delivery_tax,
                          charge_total=_charges_delivery_total,
                          store_instructions=_store_instructions)

    _order_items_keys = __return_list_of_order_items_keys_v2(_order.key, _delivery_service.menuSync, _raw_items)
    _order.order_items = _order_items_keys
    _order.put()

    # POINT OF SALE
    success = push_order_to_point_of_sale(_order.key)

    return _order

def __return_list_of_order_items_keys_v2(order_key, menuSync_key, raw_menu_items):
    _order_items_keys = []

    import logging
    logging.info(raw_menu_items)

    for _raw_menu_item in raw_menu_items:

        _raw_id = sanitize_str(_raw_menu_item.get('external_data'))
        _raw_unit_price = sanitize_price(_raw_menu_item.get('price').get('unit_price').get('amount', 0.0)) / 100.0
        _raw_price = sanitize_price(_raw_menu_item.get('price').get('total_price').get('amount', 0.0)) / 100.0
        _raw_quantity = _raw_menu_item.get('quantity')
        _raw_name = sanitize_str(_raw_menu_item.get('title'))
        _store_instructions = sanitize_str(_raw_menu_item.get('special_instructions'))

        _order = order_key.get()

        try:
            _menu_item_key_id = int(_raw_id)
        except Exception as e:
            __report_to_slack_ubereats_menu_item_id_issue(order=_order, raw_item_name=_raw_name, exception_message=str(e))
            return _order_items_keys
        _menu_item_key = MenuItem.get_key(_menu_item_key_id)
        if not _menu_item_key:
            _message = 'Order %s - UberEats External_data missing in menu item' % (str(order_key.id()))
            data_dict = {'order': order_key.id(),
                         '_raw_menu_item_id': _menu_item_key_id,
                         '_raw_menu_item': _raw_menu_item}
            __report_to_slack_ubereats_menu_item_id_issue(order=_order, exception_message=_message)
            _parent_entities_keys = [order_key, menuSync_key]

            if _order.account:
                _parent_entities_keys.append(_order.account)
            if _order.restaurant:
                _parent_entities_keys.append(_order.restaurant)
            if _order.delivery_service:
                _parent_entities_keys.append(_order.delivery_service)
            if _order.point_of_sale:
                _parent_entities_keys.append(_order.point_of_sale)
            create_event(category=CoreEventCategory.MISSING_DATA,
                         name='UBEREATS',
                         success=False,
                         message=_message,
                         payload=data_dict,
                         entity_key=order_key,
                         parent_entities_keys=_parent_entities_keys)
            report_error(500, subject='UberEats Order MenuItem External_data Not Found', message=_message, data_dict=data_dict)
            continue

        _order_item = add_order_item_to_order(order_key=order_key,
                                              menu_item_key=_menu_item_key,
                                              unit_price=_raw_unit_price,
                                              quantity=_raw_quantity,
                                              price=_raw_price,
                                              store_instructions=_store_instructions)

        # Modifiers
        _order_item_modifiers = []
        if _raw_menu_item.get('selected_modifier_groups'):
            for _raw_modifier_group in _raw_menu_item.get('selected_modifier_groups'):
                _raw_modifier_group_title = sanitize_str(_raw_modifier_group.get('title'))
                if _raw_modifier_group.get('selected_items'):
                    for _raw_modifier in _raw_modifier_group.get('selected_items'):
                        _raw_modifier_title = sanitize_str(_raw_modifier.get('title'))
                        _raw_modifier_id = sanitize_str(_raw_modifier.get('external_data'))
                        _raw_modifier_price = sanitize_price(_raw_modifier.get('price').get('total_price').get('amount', 0.0)) / 100.0
                        if not _raw_modifier_id:
                            _message = 'Order %s - UberEats External_data is None for item %s modifier group %s modifier %s' % (str(order_key.id()), str(_raw_name), str(_raw_modifier_group_title), str(_raw_modifier_title))
                            data_dict = {'order': order_key.id(),
                                         '_raw_modifier_id': _raw_modifier_id,
                                         '_raw_name': _raw_name,
                                         '_raw_modifier_group_title': _raw_modifier_group_title,
                                         '_raw_modifier_title': _raw_modifier_title,
                                         '_raw_modifier_price': _raw_modifier_price}

                            _parent_entities_keys = []
                            if order_key:
                                _parent_entities_keys.append(order_key)
                            if menuSync_key:
                                _parent_entities_keys.append(menuSync_key)
                            _order = order_key.get()
                            if _order.account:
                                _parent_entities_keys.append(_order.account)
                            if _order.restaurant:
                                _parent_entities_keys.append(_order.restaurant)
                            if _order.delivery_service:
                                _parent_entities_keys.append(_order.delivery_service)
                            if _order.point_of_sale:
                                _parent_entities_keys.append(_order.point_of_sale)
                            create_event(category=CoreEventCategory.MISSING_DATA,
                                         name='UBEREATS',
                                         success=False,
                                         message=_message,
                                         payload=data_dict,
                                         entity_key=order_key,
                                         parent_entities_keys=_parent_entities_keys)
                            report_error(500, subject='UberEats Order MenuItemModifier External_data Not Found', message=_message, data_dict=data_dict)
                            continue

                        _menu_item_modifiers_keys = fetch_all_menu_item_modifiers_keys_for_ids([_raw_modifier_id])
                        if len(_menu_item_modifiers_keys) == 0:
                            _message = 'Order %s - Modifiers not found %s' % (str(order_key.id()), _raw_modifier_id)
                            data_dict = {'order': order_key.id(),
                                         '_raw_modifier_id': _raw_modifier_id}
                            report_error(500, subject='UberEats Order MenuItemModifier Not Found', message=_message, data_dict=data_dict)
                            # _fail_safe_printing = True
                            return _order_items_keys #, _fail_safe_printing


                        _menu_item_modifier_key = _menu_item_modifiers_keys[0]
                        _order_item_modifier = create_order_item_modifier(order_key=order_key,
                                                                          order_item_key=_order_item.key,
                                                                          menu_item_modifier_key=_menu_item_modifier_key,
                                                                          price=_raw_modifier_price)
                        _order_item_modifiers.append(_order_item_modifier)

            ndb.put_multi(_order_item_modifiers)

            for _order_item_modifier in _order_item_modifiers:
                if _order_item_modifier.key not in _order_item.selected_modifier:
                    _order_item.selected_modifier.append(_order_item_modifier.key)

            _order_item.put()

        _order_items_keys.append(_order_item.key)
    return _order_items_keys


def __report_to_slack_ubereats_menu_item_id_issue(order, raw_item_name, exception_message):
    _account_name = order.account.get().name
    _restaurant_name = order.restaurant.get().name
    _restaurant_admin_url = "{}/restaurant/{}".format(get_config_for_key("ADMIN_BASE_URL"), str(order.restaurant.id()))
    _order_admin_url = "{}/order/{}".format(get_config_for_key("ADMIN_BASE_URL"), str(order.key.id()))
    post_to_alert_ubereats_menu_for_missing_external_id(account_name=_account_name,
                                                        restaurant_name=_restaurant_name,
                                                        restaurant_admin_url=_restaurant_admin_url,
                                                        order_admin_url=_order_admin_url,
                                                        raw_item_name=raw_item_name,
                                                        exception_message=exception_message)
    return
