# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/27/2019
#

from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from ..authentication import get_ubereats_header
from .generator import generate_menu_for_ubereats
from application.core.settings.app import get_config_for_key
from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from application.apis.deliveryservice.model.DeliveryService import DeliveryService


def startTaskToPushMenu(deliveryservice_key, test_on_biscayne_bakery=True):
    _ds = deliveryservice_key.get()
    _data_dict = {"test_on_biscayne_bakery": test_on_biscayne_bakery}
    _task = addTask(
        category=CoreTaskCategory.UBEREATS_MENU_PUSH, entity=_ds, data_dict=_data_dict
    )
    return _ds


def processTaskToPushMenuToUberEats(deliveryservice_id, test_on_biscayne_bakery=True):
    _ds_key = DeliveryService.get_key(deliveryservice_id)
    _menu_json = generate_menu_for_ubereats(deliveryservice_key=_ds_key)
    _url, _status_code, _result_json = __sendRequestToUberEats(
        _ds_key, _menu_json, test_on_biscayne_bakery
    )
    return _status_code, _result_json


def __sendRequestToUberEats(deliveryservice_key, menu_json, test_on_biscayne_bakery=True):
    _ds = deliveryservice_key.get()
    _ubereats_location_id = str(_ds.serviceLocationId)
    if test_on_biscayne_bakery == True: _ubereats_location_id = get_config_for_key("UBEREATS_LOCATION_ID_BISCAYNE_BAKERY")
    _url = "https://api.uber.com/v2/eats/stores/" + _ubereats_location_id + "/menus"
    _result_json, _status_code, _request_key = fetch_with_json_data(
        url=_url,
        service=UrlFetchService.UBEREATS,
        method="PUT",
        headers=get_ubereats_header(),
        data=menu_json,
    )
    if _status_code < 200 or _status_code > 299:
        return _url, _status_code, None
    return _url, _status_code, _result_json
