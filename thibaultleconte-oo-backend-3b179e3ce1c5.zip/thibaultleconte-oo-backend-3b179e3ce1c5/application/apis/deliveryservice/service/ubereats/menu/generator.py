# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/14/2019
#

from application.apis.menu.service.fetch.section import fetch_all_sections
from application.apis.menu.service.fetch.item import fetch_all_items
import json
import logging

from application.core.parser.price import sanitize_price


def generate_menu_for_ubereats(deliveryservice_key):
    _ds = deliveryservice_key.get()
    _menu_sync_key = _ds.menuSync
    _sections = fetch_all_sections(_menu_sync_key)
    _items = fetch_all_items(menu_sync_key=_menu_sync_key, keys_only=True)
    return __get_menu_for_ubereats(_sections, _items)


def __get_menu_for_ubereats(sections, items):
    menus = []
    categories = []
    category_keys = []
    for section in sections:
        menus.append(__get_menu(section))
        for category_key in section.categories:
            if category_key not in category_keys:
                category = category_key.get()
                if category.enabled:
                    category_keys.append(category_key)
                    categories.append(__get_category(category))

    items_set = set()
    modifier_groups_set = set()
    modifier_items_set = set()
    for menu_item_key in items:
        menu_item = menu_item_key.get()
        if any(menu_item_category in category_keys for menu_item_category in menu_item.categories):
            items_set.add(menu_item_key)
            for modifier_group_key in menu_item.modifiergroups:
                modifier_groups_set.add(modifier_group_key)
                for modifier_item in modifier_group_key.get().modifiers:
                    modifier_items_set.add(modifier_item)

    return {
        "menus": menus,
        "categories": categories,
        "items": __get_items_removing_duplicates(items_set, modifier_items_set),
        "modifier_groups": __get_modifier_groups(modifier_groups_set),
        "display_options": {
            "disable_item_instructions": True
        }
    }


def __get_menu(section):
    return {
        "id": section.uuid if section.uuid else str(section.key.id()),
        "title": __get_menu_title(section),
        "service_availability": __get_menu_service_availability(section.availability),
        "category_ids": __get_menu_category_ids(section.categories)
    }


def __get_menu_title(section):
    return {
        "translations": {
            "en": str(section.name.capitalize())
        }
    }


def __get_menu_service_availability(availability):
    if isinstance(availability, (unicode, str)):
        availability = json.loads(availability)

    return availability


def __get_menu_category_ids(categories):
    enabled_categories = filter(lambda category: category.get().enabled, categories)
    return map(lambda category: category.get().uuid, enabled_categories)


def __get_category(category):
    return {
        "id": category.uuid if category.uuid else str(category.key.id()),
        "title": __get_category_title(category),
        "entities": __get_category_entities(category.menuitems)
    }


def __get_category_title(category):
    return {
        "translations": {
            "en": str(category.name.capitalize())
        }
    }


def __get_category_entities(menu_items):
    return map(lambda menu_item: __get_category_entity(menu_item.get()), menu_items)


def __get_category_entity(menu_item):
    return {
        "id": menu_item.uuid if menu_item.uuid else str(menu_item.key.id()),
        "type": "ITEM"
    }


def __get_modifier_groups(modifier_groups_set):
    return map(lambda modifier_group: __get_modifier_group(modifier_group.get()), modifier_groups_set)


def __get_modifier_group(modifier_group):
    return {
        "id": modifier_group.uuid if modifier_group.uuid else str(modifier_group.key.id()),
        "title": __get_modifier_group_title(modifier_group),
        "quantity_info": __get_modifier_group_quantity_info(modifier_group),
        "modifier_options": __get_modifier_options(modifier_group)
    }


def __get_modifier_group_title(modifier_group):
    return {
        "translations": {
            "en": str(modifier_group.name.capitalize())
        }
    }


def __get_modifier_group_quantity_info(modifier_group):
    return {
        "quantity": {
            "min_permitted": modifier_group.min_permitted,
            "max_permitted": modifier_group.max_permitted
        },
        "overrides": []
    }


def __get_modifier_options(modifier_group):
    return map(lambda modifier_item: __get_modifier_option(modifier_item), modifier_group.modifiers)


def __get_modifier_option(modifier_option_key):
    modifier_option = modifier_option_key.get()
    if modifier_option:
        return {
            "id": modifier_option.uuid if modifier_option.uuid else modifier_option.key.id(),
            "type": "ITEM"
        }
    else:
        logging.warning("Modifier option %s not found", modifier_option_key)


def __get_items_removing_duplicates(item_keys, modifier_item_keys):
    unique = {}

    for item_key in item_keys:
        item = item_key.get()
        unique[item.uuid if item.uuid else item_key.id()] = __get_item(item)

    for modifier_item_key in modifier_item_keys:
        modifier_item = modifier_item_key.get()
        unique[modifier_item.uuid if modifier_item.uuid else modifier_item_key.id()] = __get_modifier_item(modifier_item_key)

    return unique.values()


def __get_item(item):
    return {
        "id": item.uuid if item.uuid else str(item.key.id()),
        "dish_info": __get_item_dish_info(item),
        "external_data": str(item.id),
        "tax_info": __get_item_tax_info(item),
        "title": __get_item_title(item),
        "description": __get_item_description(item),
        "modifier_group_ids": __get_item_modifier_group_ids(item),
        "image_url": item.image_url,
        "price_info": __get_item_price(item)
    }


def __get_item_dish_info(item):
    return {
        "classifications": {
            "alcoholic_items": 1 if item.is_alcohol else 0
        }
    }


def __get_item_tax_info(item):
    return {
        "tax_rate": item.tax_rate,
        "vat_rate_percentage": item.vat_rate_percentage
    }


def __get_item_title(item):
    return {
        "translations": {
            "en": str(item.name.capitalize())
        }
    }


def __get_item_description(item):
    if item.description:
        return {
            "translations": {
                "en": str(item.description.capitalize())
            }
        }


def __get_item_price(item):
    return {
        "overrides": [],
        "price": int(sanitize_price(item.price * 100))
    }


def __get_item_modifier_group_ids(item):
    return {
        "ids": map(lambda modifier_group: modifier_group.get().uuid if modifier_group.get().uuid else str(modifier_group.key.id()), item.modifier_groups),
        "overrides": []
    }


def __get_modifier_item(modifier_item_key):
    modifier_item = modifier_item_key.get()
    if modifier_item:
        return {
            "id": modifier_item.uuid if modifier_item.uuid else str(modifier_item.key.id()),
            "external_data": str(modifier_item.id),
            "title": __get_modifier_item_title(modifier_item),
            "price_info": __get_modifier_item_price(modifier_item)
        }
    else:
        logging.warning("Modifier item %s not found", modifier_item_key)


def __get_modifier_item_title(modifier_item):
    return {
        "translations": {
            "en": str(modifier_item.name.capitalize())
        }
    }


def __get_modifier_item_price(modifier_item):
    return {
        "overrides": [],
        "price": int(sanitize_price(modifier_item.price * 100))
    }
