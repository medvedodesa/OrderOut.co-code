# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/27/2019
#

from application.apis.menu.service.menusync.creator import create_menu_sync
from application.core.delivery_services.ubereats.factories import UberEatsApiClientFactory
from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from application.apis.menu.service.menusync.fetch import fetch_menu_task_started, fetch_menu_task_finished
from application.apis.menu.model.MenuSync import MenuSync
from flask import current_app
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.error import report_error
from ..authentication import get_ubereats_header
from application.apis.menu.service.creator import generate_item_dict, generate_modifier_group_dict, generate_modifier_dict, startTaskToCreateOrUpdateMenuItemsAndModifiers
from application.apis.menu.service.menusync.process import process_menu_task_started
import json
from application.apis.menu.service.crud.section import create_update_menu_section
from application.apis.menu.service.crud.category import create_update_menu_category
from application.core.parser.string import sanitize_str
from application.core.parser.price import sanitize_ubereats_price

UBEREATS_CATEGORY_NAMES_TO_IGNORE = ['most popular']

def startTaskToFetchMenu(deliveryservice_key, name=None, description=None, author=None):
    _ds = deliveryservice_key.get()
    _ms = create_menu_sync(
        restaurant_key=_ds.restaurant,
        service_key=_ds.key,
        name=name,
        description=description,
        author=author,
    )
    _ds.menuSync = _ms.key
    _ds.put()
    _task = addTask(category=CoreTaskCategory.UBEREATS_MENU_FETCH, entity=_ms)
    _ms = fetch_menu_task_started(menuSync_key=_ms.key, task_key=_task.key)
    return _ds

def processTaskToFetchMenuFromUberEats(menu_sync_id):
    _task_result_json = {}
    _ms = MenuSync.get_by_id(menu_sync_id)
    if not _ms:
        _task_result_json['processTaskToFetchMenuFromUbereats'] = {'message': 'MenuSync with id %s not found' % (str(menu_sync_id))}
    elif not _ms.service:
        _task_result_json['processTaskToFetchMenuFromUbereats'] = {'message': 'MenuSync with id %s has no ds' % (str(menu_sync_id))}
    else:
        _url, _status_code, _result_json = __start_fetch_menu_request(_ms.service)
        _task_result_json['__start_fetch_menu_request'] = {'url': _url,
                                                           'status_code': _status_code,
                                                           'result_json': _result_json}
        if _status_code >= 200 and _status_code <= 299:
            # _menu_items = __process_menu_v1(_ms, _result_json)
            # _nb_menu_items = len(_menu_items)
            _nb_menu_items = __process_menu_v2(_ms, _result_json)
            process_menu_task_started(menuSync_key=_ms.key, tasks_keys=None)
            _task_result_json['__parse_menu'] = {'message': "Delivery Service has fetched %s menu items" % (str(_nb_menu_items))}

            from application.apis.menu.service.stats import refresh_stats
            refresh_stats(menu_sync_key=_ms.key)
            from application.apis.menu.service.menusync.process import manage_menu_task
            manage_menu_task(menu_sync_key=_ms.key)
        else:
            report_error(code=_status_code, subject="GetUbereatsMenu-Error", message="Menu Sync %s returned %s" % (str(_ms.key.id()), str(_status_code)))
    return _task_result_json

############
# Fetch Menu
############

def __start_fetch_menu_request(delivery_service_key):
    _ds = delivery_service_key.get()
    location_id = _ds.serviceLocationId

    _url = "https://api.uber.com/v2/eats/stores/" + location_id + "/menus"

    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.UBEREATS, method="GET", headers=get_ubereats_header())

    if _status_code < 200 or _status_code > 299:
        fetch_menu_task_finished(menuSync_key=_ds.menuSync, success=False)
        return _url, _status_code, None
    fetch_menu_task_finished(menuSync_key=_ds.menuSync, success=True)
    return _url, _status_code, _result_json

#################
# Process Menu V1
#################

def __process_menu_v1(menu_sync, raw_data):
    _items_tasks = []

    if 'menus' in raw_data:
        for raw_section in raw_data.get('menus'):
            _idx_section = raw_data.get('menus').index(raw_section)
            _section = __parse_section(menu_sync.key, raw_section, _idx_section)

            if 'categories' in raw_data:
                _categories_key = []
                item_dict = __create_item_dict(raw_data)
                modifiers_dict = __create_modifiers_dict(raw_data)

                for raw_subsection in raw_data.get('categories', []):
                    _raw_category_name = sanitize_str(__get_title_translations_english(raw_subsection.get('title')))
                    if _raw_category_name not in UBEREATS_CATEGORY_NAMES_TO_IGNORE:
                        _category = __parse_category(menu_sync.key, _section.key, raw_subsection)
                        _categories_key.append(_category.key)
                        _items_tasks.extend(__parse_items(menu_sync, _category.key, raw_subsection, item_dict, modifiers_dict))
                _section.categories = _categories_key
                _section.put()
    return _items_tasks

def __parse_section(menu_sync_key, raw_section, raw_index):
    _raw_name = sanitize_str(__get_title_translations_english(raw_section.get('title')))
    _raw_availability = _enable_service_availability(raw_section.get('service_availability'))
    _raw_uuid = sanitize_str(raw_section.get('id', None))
    _section = create_update_menu_section(menu_sync_key=menu_sync_key,
                                          name=_raw_name,
                                          availability=_raw_availability,
                                          position=raw_index,
                                          uuid=_raw_uuid,
                                          description=None)
    return _section

def __parse_category(menu_sync_key, section_key, raw_subsection):
    _raw_name = sanitize_str(__get_title_translations_english(raw_subsection.get('title')))
    _raw_uuid = sanitize_str(raw_subsection.get('id', None))
    _category = create_update_menu_category(menu_sync_key=menu_sync_key,
                                            section_key=section_key,
                                            name=_raw_name,
                                            uuid=_raw_uuid)
    return _category

def __parse_items(menu_sync, category_key, raw_subsection, item_dict, modifiers_dict):
    _items_tasks = []
    if 'entities' in raw_subsection:
        for raw_entity in raw_subsection.get('entities'):
            _idx_item = raw_subsection.get('entities').index(raw_entity)
            entity_id = raw_entity.get('id')
            raw_item = item_dict[entity_id]

            _modifier_groups = __parse_modifier_groups(raw_item, item_dict, modifiers_dict)

            is_alcohol = 0
            if raw_item.get('dish_info') != None:
                if raw_item.get('dish_info').get('classifications') != None:
                    is_alcohol = raw_item.get('dish_info').get('classifications').get('alcoholic_items', 0)

            description = None
            if raw_item.get('description') != None:
                if raw_item.get('description').get('translations') != None:
                    description = __get_title_translations_english(raw_item.get('description'))

            _mi = generate_item_dict(name=__get_title_translations_english(raw_item.get('title')),
                                    price=sanitize_ubereats_price(raw_item.get('price_info').get('price')),
                                    modifier_groups=_modifier_groups,
                                    id=raw_item.get('external_data'),
                                    uuid=raw_item.get('id'),
                                    category_id=category_key.id(),
                                    image_url=raw_item.get('image_url', None),
                                    is_alcohol=is_alcohol,
                                    position=_idx_item,
                                    description=description,
                                    disable_instructions=True,
                                    tax_rate=raw_item.get('tax_info').get('tax_rate', 0),
                                    )
            _task = startTaskToCreateOrUpdateMenuItemsAndModifiers(menu_sync, _mi)
            if _task: _items_tasks.append(_task.key)
    return _items_tasks

def __parse_modifier_groups(raw_item, item_dict, modifiers_dict):

    modifier_groups = []
    if 'modifier_group_ids' in raw_item:
        if 'ids' in raw_item.get('modifier_group_ids'):
            for raw_modifiers_group_id in raw_item.get('modifier_group_ids').get('ids'):
                _idx_group = raw_item.get('modifier_group_ids').get('ids').index(raw_modifiers_group_id)
                group_id = raw_modifiers_group_id

                raw_customization = modifiers_dict[group_id]
                _group_name = __get_title_translations_english(raw_customization.get('title'))
                _min_permitted = raw_customization.get('quantity_info').get('quantity').get('min_permitted', 0)
                _max_permitted = raw_customization.get('quantity_info').get('quantity').get('max_permitted', 0)
                _uuid = raw_customization.get('id')
                _modifiers = __parse_modifiers(raw_customization, item_dict)
                _group = generate_modifier_group_dict(name=_group_name,
                                                    modifiers=_modifiers,
                                                    uuid=_uuid,
                                                    min_permitted=_min_permitted,
                                                    max_permitted=_max_permitted,
                                                    position=_idx_group)
                modifier_groups.append(_group)
    return modifier_groups

def __parse_modifiers(raw_customization, item_dict):
    modifiers = []
    if 'modifier_options' in raw_customization:
        for raw_option in raw_customization.get('modifier_options'):
            _idx_modifier = raw_customization.get('modifier_options').index(raw_option)
            option_id = raw_option.get('id')
            raw_item = item_dict[option_id]

            _mod = generate_modifier_dict(name=__get_title_translations_english(raw_item.get('title')),
                                          price=sanitize_ubereats_price(raw_item.get('price_info').get('price')),
                                          uuid=option_id,
                                          position=_idx_modifier)
            modifiers.append(_mod)
    return modifiers

def __create_item_dict(raw_data):
    itemdict = {}
    if 'items' in raw_data and raw_data.get('items') is not None:
        for itemsection in raw_data.get('items'):
            itemdict[itemsection.get("id")] = itemsection
    return itemdict

def __create_modifiers_dict(raw_data):
    modifierdict = {}
    if 'modifier_groups' in raw_data and raw_data.get('modifier_groups') is not None:
        for modifiersection in raw_data.get('modifier_groups'):
            modifierdict[modifiersection.get("id")] = modifiersection
    return modifierdict

#################
# Process Menu V2
#################

from google.appengine.ext import ndb
from application.apis.menu.model.MenuSection import MenuSection
from application.apis.menu.model.MenuCategory import MenuCategory
from application.apis.menu.model.MenuItem import MenuItem
from application.apis.menu.model.MenuModifierGroup import MenuModifierGroup
from application.apis.menu.model.MenuItemModifier import MenuItemModifier
import logging

def __process_menu_v2(menu_sync, raw_data):
    _raw_sections = raw_data.get('menus') if raw_data.get('menus') else []
    _raw_categories = raw_data.get('categories') if raw_data.get('categories') else []
    _raw_items = raw_data.get('items') if raw_data.get('items') else []
    _raw_modifier_groups = raw_data.get('modifier_groups') if raw_data.get('modifier_groups') else []

    ########
    # CREATE
    ########

    # Menu Modifier Groups
    _modifier_groups_dict, _modifiers_dict = __create_modifier_groups_v2(menu_sync, _raw_modifier_groups)

    # Menu Categories
    _categories_dict, _items_dict = __create_categories_v2(menu_sync, _raw_categories)

    # Items for UberEats which means Menu Item and Modifiers all together
    _items_dict = __create_items_v2(menu_sync, _raw_items, _items_dict)

    # Modifiers for UberEats which means Menu Item and Modifiers all together
    _modifiers_dict = __create_modifiers_v2(menu_sync, _raw_items, _modifiers_dict)

    # Menu Sections
    _sections = __create_sections_v2(menu_sync, _raw_sections, _categories_dict)

    #####
    # MAP
    #####

    # MAP Menu Items to Categories
    _items_dict, categories_dict = __map_items_to_categories_v2(_raw_categories, _items_dict, _categories_dict)

    # MAP Menu Items and Modifier Groups
    items_dict, modifier_groups_dict = _map_modifier_groups_to_items_v2(_raw_items, _items_dict, _modifier_groups_dict)

    # MAP Menu Modifiers and Modifier Groups
    _modifiers_dict, modifier_groups_dict = _map_modifiers_to_modifier_groups_v2(_raw_modifier_groups, _modifiers_dict, _modifier_groups_dict)

    _total_items_and_modifiers = len(items_dict) + len(_modifiers_dict)
    return _total_items_and_modifiers

def __create_sections_v2(menu_sync, raw_sections, categories_dict):
    _sections = []
    for _raw_section in raw_sections:
        _raw_category_ids = _raw_section.get('category_ids') if _raw_section.get('category_ids') else []
        _categories_keys = __build_categories_keys_for_section(_raw_category_ids, categories_dict)
        _section = MenuSection(menuSync=menu_sync.key,
                               name=__get_title_translations_english(_raw_section.get('title', {})),
                               availability=_enable_service_availability(_raw_section.get('service_availability', [])),
                               position=raw_sections.index(_raw_section),
                               uuid=sanitize_str(_raw_section.get('id', None), lower_case=False),
                               description=None,
                               categories=_categories_keys)
        _sections.append(_section)
    _ = ndb.put_multi(_sections)
    return _sections

def __create_categories_v2(menu_sync, raw_categories):
    _categories = []
    _categories_dict = {}
    _items_dict = {}

    for _raw_category in raw_categories:
        _raw_category_uuid = sanitize_str(_raw_category.get('id', None), lower_case=False)
        _category = MenuCategory(menuSync=menu_sync.key,
                                 name=__get_title_translations_english(_raw_category.get('title', {})),
                                 uuid=_raw_category_uuid)
        _categories.append(_category)

        _categories_dict[_raw_category_uuid] = _category

        # pre-create dict of items with uuid
        for _raw_entity in _raw_category.get('entities', []):
            _items_dict[sanitize_str(_raw_entity.get('id'), lower_case=False)] = None

    _ = ndb.put_multi(_categories)

    return _categories_dict, _items_dict

def __create_items_v2(menu_sync, raw_items, items_dict):
    _items = []
    for _raw_item in raw_items:

        _raw_item_uuid = sanitize_str(_raw_item.get('id', None), lower_case=False)

        if _raw_item_uuid in items_dict:

            is_alcohol = 0
            if _raw_item.get('dish_info') != None:
                if _raw_item.get('dish_info').get('classifications') != None:
                    is_alcohol = _raw_item.get('dish_info').get('classifications').get('alcoholic_items', 0)

            _item = MenuItem(menuSync=menu_sync.key,
                             name=__get_title_translations_english(_raw_item.get('title', {})),
                             uuid=_raw_item_uuid,
                             price=sanitize_ubereats_price(_raw_item.get('price_info', {}).get('price')),
                             description=__get_title_translations_english(_raw_item.get('description', {})),
                             is_alcohol=bool(is_alcohol),
                             tax_rate=_raw_item.get('tax_info', {}).get('tax_rate', 0),
                             vat_rate_percentage=_raw_item.get('tax_info', {}).get('vat_rate_percentage', 0),
                             disable_instructions=True,
                             image_url=_raw_item.get('image_url', None))
            _items.append(_item)

            items_dict[_raw_item_uuid] = _item

    _ = ndb.put_multi(_items)

    return items_dict

def __create_modifier_groups_v2(menu_sync, _raw_modifier_groups):
    _modifier_groups = []
    _modifier_groups_dict = {}
    _modifiers_dict = {}
    for _raw_modifier_group in _raw_modifier_groups:

        _raw_modifier_group_uuid = sanitize_str(_raw_modifier_group.get('id', None), lower_case=False)

        _modifier_group = MenuModifierGroup(menuSync=menu_sync.key,
                                            name=__get_title_translations_english(_raw_modifier_group.get('title', {})),
                                            uuid=_raw_modifier_group_uuid,
                                            min_permitted=_raw_modifier_group.get('quantity_info', {}).get('quantity', {}).get('min_permitted', 0),
                                            max_permitted=_raw_modifier_group.get('quantity_info', {}).get('quantity', {}).get('max_permitted', 0))
        _modifier_groups.append(_modifier_group)

        _modifier_groups_dict[_raw_modifier_group_uuid] = _modifier_group

        # pre-create dict of modifiers with uuid
        _modifier_options_raw = _raw_modifier_group.get('modifier_options') if _raw_modifier_group.get('modifier_options') is not None else []
        for _raw_modifier in _modifier_options_raw:
            _modifiers_dict[sanitize_str(_raw_modifier.get('id'), lower_case=False)] = None

    _ = ndb.put_multi(_modifier_groups)

    return _modifier_groups_dict, _modifiers_dict

def __create_modifiers_v2(menu_sync, raw_items, modifiers_dict):
    _modifiers = []
    for _raw_modifier in raw_items:

        _raw_modifier_uuid = sanitize_str(_raw_modifier.get('id', None), lower_case=False)

        if _raw_modifier_uuid in modifiers_dict:

            _modifier = MenuItemModifier(menuSync=menu_sync.key,
                                         name=__get_title_translations_english(_raw_modifier.get('title', {})),
                                         uuid=_raw_modifier_uuid,
                                         price=sanitize_ubereats_price(_raw_modifier.get('price_info', {}).get('price')))
            _modifiers.append(_modifier)

            modifiers_dict[_raw_modifier_uuid] = _modifier

    _ = ndb.put_multi(_modifiers)

    return modifiers_dict

#####
# MAP
#####

def __map_items_to_categories_v2(raw_categories, items_dict, categories_dict):
    _items = []

    for _raw_category in raw_categories:

        _raw_category_uuid = sanitize_str(_raw_category.get('id', None), lower_case=False)
        _category = categories_dict.get(_raw_category_uuid)

        for _raw_entity in _raw_category.get('entities', []):
            _raw_item_uuid = sanitize_str(_raw_entity.get('id'), lower_case=False)
            _item = items_dict.get(_raw_item_uuid)

            _categories_keys = _item.categories if _item.categories else []
            if _category.key not in _categories_keys: _categories_keys.append(_category.key)
            _item.categories = _categories_keys
            _items.append(_item)

    _ = ndb.put_multi(_items)
    return items_dict, categories_dict

def _map_modifier_groups_to_items_v2(raw_items, items_dict, modifier_groups_dict):
    _items = []
    _modifier_groups = []

    for _raw_item in raw_items:
        _raw_item_uuid = sanitize_str(_raw_item.get('id', None), lower_case=False)

        if _raw_item_uuid in items_dict:
            _item = items_dict.get(_raw_item_uuid)
            _item_modifiers_groups_keys = _item.modifier_groups if _item.modifier_groups else []

            _raw_modifier_group_uuids = _raw_item.get('modifier_group_ids', {}).get('ids', []) if _raw_item.get('modifier_group_ids', {}).get('ids', []) else []
            for _raw_modifier_group_uuid in _raw_modifier_group_uuids:
                if not _raw_modifier_group_uuid:
                    continue

                _raw_modifier_group_uuid = sanitize_str(_raw_modifier_group_uuid, lower_case=False)
                _modifier_group = modifier_groups_dict.get(_raw_modifier_group_uuid)

                _modifier_group_items_keys = _modifier_group.items if _modifier_group and _modifier_group.items else []
                if _item.key not in _modifier_group_items_keys: _modifier_group_items_keys.append(_item.key)
                _modifier_group.items = _modifier_group_items_keys
                _modifier_groups.append(_modifier_group)

                if _modifier_group.key not in _item_modifiers_groups_keys: _item_modifiers_groups_keys.append(_modifier_group.key)

            if _item_modifiers_groups_keys:
                _item.modifier_groups = _item_modifiers_groups_keys
                _items.append(_item)

    _ = ndb.put_multi(_items)
    _ = ndb.put_multi(_modifier_groups)
    return items_dict, modifier_groups_dict

def _map_modifiers_to_modifier_groups_v2(raw_modifier_groups, modifiers_dict, modifier_groups_dict):
    _modifiers = []
    _modifier_groups = []

    for _raw_modifier_group in raw_modifier_groups:
        _raw_modifier_group_uuid = sanitize_str(_raw_modifier_group.get('id', None), lower_case=False)

        _modifier_group = modifier_groups_dict.get(_raw_modifier_group_uuid)
        _modifier_group_property_modifiers_keys = _modifier_group.modifiers if _modifier_group.modifiers else []

        _modifier_options_raw = _raw_modifier_group.get('modifier_options') if _raw_modifier_group.get('modifier_options') is not None else []
        for _raw_modifier in _modifier_options_raw:
            _raw_modifier_uuid = sanitize_str(_raw_modifier.get('id', None), lower_case=False)
            _modifier = modifiers_dict.get(_raw_modifier_uuid)

            _modifier_property_groups_keys = _modifier.groups if _modifier.groups else []
            if _modifier_group.key not in _modifier_property_groups_keys: _modifier_property_groups_keys.append(_modifier_group.key)
            _modifier.groups = _modifier_property_groups_keys
            _modifiers.append(_modifier)

            if _modifier.key not in _modifier_group_property_modifiers_keys: _modifier_group_property_modifiers_keys.append(_modifier.key)

        if _modifier_group_property_modifiers_keys:
            _modifier_group.modifiers = _modifier_group_property_modifiers_keys
            _modifier_groups.append(_modifier_group)

    _ = ndb.put_multi(_modifiers)
    _ = ndb.put_multi(_modifier_groups)
    return modifiers_dict, modifier_groups_dict

#########
# SECTION
#########

def __build_categories_keys_for_section(raw_section_category_ids, categories_dict):
    _categories_keys = []
    for _raw_category_id in raw_section_category_ids:
        _category = categories_dict.get(sanitize_str(_raw_category_id, lower_case=False))
        _categories_keys.append(_category.key)
    return _categories_keys

########
# COMMON
########

def __get_title_translations_english(raw_title):
    _english_initials = ['en', 'en_us', 'en_US']
    for _lang in _english_initials:
        _result = raw_title.get('translations', {}).get(_lang, "")
        if _result: return _result
    return None

def _enable_service_availability(_raw_availability):
    days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]

    if _raw_availability is None: _raw_availability = []
    for _day_availability in _raw_availability:
        #adding enabled attribute for available day of weeks
        _day_availability["enabled"] = True
        days.remove(_day_availability["day_of_week"])

    #adding days in the list which are not available in given json
    for d in days:
        _raw_availability.append({"day_of_week":d, "time_periods":[], "enabled":False})

    return _raw_availability
