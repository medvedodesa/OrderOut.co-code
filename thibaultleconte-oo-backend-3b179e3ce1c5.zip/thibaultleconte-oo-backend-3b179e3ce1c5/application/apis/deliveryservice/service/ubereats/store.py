# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/09/2019
#

from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from .authentication import get_ubereats_header
import logging

def get_store_details(store_id):
    _url = "https://api.uber.com/v1/eats/stores/" + store_id
    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.UBEREATS, method="GET", headers=get_ubereats_header())
    if _status_code < 200 or _status_code > 299: return _url, _status_code, None
    return _url, _status_code, _result_json
