# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/05/2019
#

from ...model.DeliveryService import DeliveryService, DeliveryServiceType
from ..common.fetch import check_delivery_service_already_connected
from application.apis.ooexceptions import ConflictResourceAlreadyExistsError, BadRequest
from ..common.crud import create_delivery_service
import json

def connect(account_key, restaurant_key, restaurant_url, username=None, password=None):
    _delivery_service_type = DeliveryServiceType.GRUBHUB
    if check_delivery_service_already_connected(restaurant_key=restaurant_key,
                                                delivery_service_type=_delivery_service_type):
        raise ConflictResourceAlreadyExistsError

    if not restaurant_url or len(restaurant_url) == 0: return BadRequest

    credentials = {'restaurant_url': restaurant_url}
    _ds = create_delivery_service(
        restaurant_key=restaurant_key,
        delivery_service_type=_delivery_service_type,
        service_menu_url=restaurant_url,
        service_raw_data=credentials,
        service_username=username,
        service_password=password,
    )
    return _ds
