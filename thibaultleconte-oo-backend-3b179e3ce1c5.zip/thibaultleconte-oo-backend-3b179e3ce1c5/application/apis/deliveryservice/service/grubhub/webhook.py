# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/24/2019
#

from application.apis.menu.service.menusync.creator import get_menu_sync_key_by_fetch_external_id
from application.apis.menu.service.menusync.fetch import fetch_menu_task_finished
from application.core.parser.string import remove_non_alphanumeric_chars
from .menu.process import startTaskToProcessMenu
from ..common.verification import verify_code
from ..common.parseur import get_and_validate_store_id_from_incoming_email
from .order import process_order
from .cancel import cancel_order
from application.core.error import report_error
from application.apis.order.service.push import push_canceled_order_to_printers
from application.core.webhook.service import save_webhook
from application.core.webhook.model import CoreWebhookService
from ..common.parseur import get_value_name_for_key_in_webhook_json


def process_apify_webhook(json_dict):
    if json_dict.get('eventType') == 'TEST': return True

    _apify_event_type = json_dict.get('eventType')
    _apify_run_id = json_dict.get('resource').get('id')
    _apify_kvs_output_id = json_dict.get('resource').get('defaultKeyValueStoreId')

    _ms_key = get_menu_sync_key_by_fetch_external_id(_apify_run_id)
    if not _ms_key: return False

    if _apify_event_type == 'ACTOR.RUN.CREATED':
        return True
    elif _apify_event_type == 'ACTOR.RUN.SUCCEEDED':
        _ms = fetch_menu_task_finished(menuSync_key=_ms_key, success=True)
        _ms = startTaskToProcessMenu(_ms.key, _apify_kvs_output_id)
        return True
    elif _apify_event_type in ['ACTOR.RUN.TIMED_OUT', 'ACTOR.RUN.ABORTED', 'ACTOR.RUN.FAILED']:
        _subject = 'APIFY WEBHOOK ERROR - Apify event type %s' % (str(_apify_event_type))
        _message = 'APify reported an error during menu fetching by reporting the event type %s for GRUBHUB' % (str(_apify_event_type))
        report_error(code=400, message=_message, subject=_subject, data_dict=json_dict)
        return False
    else:
        import logging
        logging.info('TASK EVENT %s' % (str(_apify_event_type)))
    return False

def process_parseur_webhook(request_url, json_dict):
    json_dict["reference"] = remove_non_alphanumeric_chars(json_dict.get("reference", ""))
    _wh = save_webhook(url=request_url, service=CoreWebhookService.PARSEUR, payload=json_dict)
    _email_subject = get_value_name_for_key_in_webhook_json('Subject', json_dict)
    if not _email_subject:
        _message = 'Parseur webhook sent no email subject %s' % (str(_email_subject))
        _wh.failed()
        report_error(400, subject="Parseur Warning", message=_message, data_dict=json_dict)
        return True
    if 'orderout settings verification' in _email_subject:
        _recipient_email = json_dict.get('Recipient')
        _deliveryservice_id = json_dict.get('verification').get('deliveryservice').get('id')
        _code_to_verify = json_dict.get('verification').get('code')
        success = verify_code(recipient_email=_recipient_email,
                              deliveryservice_id=_deliveryservice_id,
                              code_to_verify=_code_to_verify)
        _wh.is_successful() if success else _wh.failed()
    elif 'cancelled' in _email_subject:
        _order_id = json_dict.get('reference')
        _store_email = json_dict.get('Recipient')
        _store_id = get_and_validate_store_id_from_incoming_email(_store_email, source_entity_key=_wh.key)
        if _store_id:
            _order = cancel_order(order_id=_order_id, store_id=_store_id)
            push_canceled_order_to_printers(_order.key)
        _wh.is_successful() if _store_id else _wh.failed()
    elif 'confirmation' in _email_subject:
        _order_id = json_dict.get('reference')
        _store_email = json_dict.get('Recipient')
        _store_id = get_and_validate_store_id_from_incoming_email(_store_email, source_entity_key=_wh.key)
        if _store_id:
            _order = process_order(order_id=_order_id, store_id=_store_id, json_dict=json_dict)
        _wh.is_successful() if _store_id else _wh.failed()
    else:
        _message = 'Parseur webhook template %s not recognized' % (str(_email_subject))
        _wh.failed()
        report_error(500, subject="Parseur ERROR", message=_message, data_dict=json_dict)
    return True
