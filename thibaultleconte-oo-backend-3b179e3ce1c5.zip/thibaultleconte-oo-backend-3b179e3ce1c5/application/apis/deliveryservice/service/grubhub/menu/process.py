# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/22/2019
#

from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from application.apis.menu.service.menusync.fetch import fetch_menu_task_started, fetch_menu_task_finished
from application.apis.menu.model.MenuSync import MenuSync
from application.core.urlFetch.service import fetch_with_json_data
from flask import current_app
from application.core.error import report_error
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.apis.menu.service.menusync.process import process_menu_task_started
from application.apis.menu.service.creator import generate_item_dict, generate_modifier_group_dict, generate_modifier_dict, startTaskToCreateOrUpdateMenuItemsAndModifiers
from application.core.parser.string import sanitize_str
from application.core.settings.app import get_config_for_key
from application.apis.menu.service.crud.section import create_update_menu_section
from application.apis.menu.service.crud.category import create_update_menu_category

DEFAULT_GRUBHUB_MENU_SECTION_NAME = 'Menu'

def startTaskToProcessMenu(menusync_key, _apify_kvs_output_id):
    _ms = menusync_key.get()
    _ms.process_external_id = str(_apify_kvs_output_id)
    _ms.put()
    _task = addTask(category=CoreTaskCategory.GRUBHUB_MENU_PROCESS, entity=_ms)
    _ms = fetch_menu_task_started(menuSync_key=_ms.key, task_key=_task.key)
    return _ms

def processTaskToProcessMenuFromGrubhub(menu_sync_id):
    _task_result_json = {}
    _ms = MenuSync.get_by_id(menu_sync_id)
    if not _ms: _task_result_json['processTaskToProcessMenuFromGrubhub'] = {'message': 'MenuSync with id %s not found' % (str(menu_sync_id))}
    if not _ms.service: _task_result_json['processTaskToFetchMenuFromGrubhub'] = {'message': 'MenuSync with id %s has no ds' % (str(menu_sync_id))}
    _url, _status_code, _result_json = __start_process_menu_request(menuSync_key=_ms.key)
    _task_result_json['__start_process_menu_request'] = {'url': _url, 'status_code': _status_code, 'result_json': _result_json}

    if _status_code >= 200 and _status_code <= 299:

        _restaurant_id = sanitize_str(_result_json.get('restaurant').get('id'))
        _ds = _ms.service.get()
        _ds.serviceLocationId = str(_restaurant_id)
        _ds.put()

        fetch_menu_task_finished(menuSync_key=_ms.key, success=True)
        _menu_items = __process_menu(_ms, _result_json)
        process_menu_task_started(menuSync_key=_ms.key, tasks_keys=_menu_items)
        _task_result_json['__process_menu'] = {'message': "Delivery Service has fetched %s menu items" % (str(len(_menu_items)))}
    else:
        fetch_menu_task_finished(menuSync_key=_ms.key, success=False)

    return _task_result_json

def __start_process_menu_request(menuSync_key):
    _ms = menuSync_key.get()

    _url = __get_url_apify_grubhub_process_menu(_ms.process_external_id)
    _apify_headers = {'Content-Type': 'application/json'}

    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.APIFY, method="GET", headers=_apify_headers)

    if _status_code < 200 or _status_code > 299:
        report_error(
            code=_status_code,
            subject="Apify-ProcessGrubhubMenu-Error",
            message="Delivery service %s returned %s (Menu sync %s)" % (str(_ms.service.id() if _ms.service else "-"), str(_status_code), _ms.key.id())
        )
        return _url, _status_code, None
    return _url, _status_code, _result_json


##############
# Process Menu
##############

def __process_menu(menu_sync, raw_data):
    _items_tasks = []
    _section = create_update_menu_section(menu_sync_key=menu_sync.key, name=DEFAULT_GRUBHUB_MENU_SECTION_NAME)
    if 'restaurant' in raw_data:
        raw_restaurant = raw_data['restaurant']
        if 'menu_category_list' in raw_restaurant:
            raw_menu_category_list = raw_restaurant['menu_category_list']
            for raw_menu_category in raw_menu_category_list:
                if 'menu_item_list' in raw_menu_category:
                    raw_menu_item_list = raw_menu_category['menu_item_list']
                    _items_tasks.extend(__parse_items(menu_sync, raw_menu_item_list, _section.key))
    return _items_tasks

def __parse_items(menu_sync, raw_menu_item_list, section_key):
    _items_tasks = []
    for raw_item in raw_menu_item_list:
        _idx_item = raw_menu_item_list.index(raw_item)
        _modifier_groups = __parse_modifier_groups(raw_item)
        _price = raw_item.get('price').get('amount')
        _price = _price / 100 if _price else 0

        # CATEGORY
        _raw_menu_category_name = sanitize_str(raw_item.get('menu_category_name'))
        _raw_menu_category_uuid = sanitize_str(raw_item.get('menu_category_id'))
        _category = create_update_menu_category(menu_sync_key=menu_sync.key,
                                                section_key=section_key,
                                                name=_raw_menu_category_name,
                                                uuid=_raw_menu_category_uuid)

        _mi = generate_item_dict(name=raw_item.get('name'),
                                 price=_price,
                                 modifier_groups=_modifier_groups,
                                 uuid=raw_item.get('id'),
                                 position=_idx_item,
                                 category_id=_category.get_id())
        _task = startTaskToCreateOrUpdateMenuItemsAndModifiers(menu_sync, _mi)
        if _task: _items_tasks.append(_task.key)
    return _items_tasks

def __parse_modifier_groups(raw_item):
    modifier_groups = []
    if 'choice_category_list' in raw_item:
        for raw_customization in raw_item.get('choice_category_list'):
            _idx_group = raw_item.get('choice_category_list').index(raw_customization)
            _group_name = raw_customization.get('name')
            _group_uuid = raw_customization.get('id')
            _min_permitted = raw_customization.get('min_choice_options', 0)
            _max_permitted = 0 #raw_customization.get('max_permitted', 0)
            _modifiers = __parse_modifiers(raw_customization)
            _group = generate_modifier_group_dict(name=_group_name,
                                                  modifiers=_modifiers,
                                                  uuid=_group_uuid,
                                                  min_permitted=_min_permitted,
                                                  max_permitted=_max_permitted,
                                                  position=_idx_group)
            modifier_groups.append(_group)
    return modifier_groups

def __parse_modifiers(raw_customization):
    modifiers = []
    if 'choice_option_list' in raw_customization:
        for raw_option in raw_customization.get('choice_option_list'):
            _idx_modifier = raw_customization.get('choice_option_list').index(raw_option)
            _price = raw_option.get('price').get('amount')
            _price = _price / 100 if _price else 0
            _mod = generate_modifier_dict(name=raw_option.get('description'),
                                          price=_price,
                                          uuid=raw_option.get('id'),
                                          position=_idx_modifier)
            modifiers.append(_mod)
    return modifiers

################
# WEBHOOKS APIFY
################

def __get_url_apify_grubhub_process_menu(apify_kvs_output_id):
    _apify_token = get_config_for_key('APIFY_TOKEN')
    url = "https://api.apify.com/v2/key-value-stores/%s/records/OUTPUT?disableRedirect=1&token=%s" % (str(apify_kvs_output_id), str(_apify_token))
    return url
