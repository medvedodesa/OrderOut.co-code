# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/23/2019
#

from application.core.settings.app import get_config_for_key

def get_incoming_order_email(deliveryservice_key):
    _ds = deliveryservice_key.get()
    if not _ds.serviceLocationId: return None
    _email = get_config_for_key('PARSEUR_INCOMING_EMAIL_PREFIX_GRUBHUB')
    _email += str(_ds.serviceLocationId)
    _email += get_config_for_key('PARSEUR_INCOMING_EMAIL_DOMAIN')
    return _email.lower()
