# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/03/2019
#

from application.core.urlFetch.service import fetch_with_url_encoded_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.error import report_error
from application.core.task.service import startDeferredTask
from application.apis.order.service.confirmation import check_order_is_confirmed, set_order_as_confirmed

import logging

def confirm_order(order_key, confirmation_url, json_dict):
    if check_order_is_confirmed(order_key): return True
    if confirmation_url:
        startDeferredTask(__send_confirmation_request, order_key, confirmation_url)
    else:
        _message = 'Order %s - Grubhub order confirmation link error' % (str(order_key.id()))
        report_error(500, subject='Grubhub Order Confirmation Error', message=_message, data_dict=json_dict)
    return True

def __send_confirmation_request(order_key, confirmation_url):
    _str_to_replace = 'https://orderemails.grubhub.com/'
    _str_replacing_with = 'https://api-order-processing-gtm.grubhub.com/order/email/confirm/'
    _grubhub_backend_url = confirmation_url.replace(_str_to_replace, _str_replacing_with)
    _result_json, _status_code, request_key = fetch_with_url_encoded_data(url=_grubhub_backend_url, service=UrlFetchService.GRUBHUB, method="POST")
    if _status_code < 200 or _status_code > 299:
        _message = 'Order %s - Grubhub order confirmation link error %s' % (str(order_key.id()), str(object=confirmation_url))
        data_dict = {'order': order_key.id(),
                     'confirmation_url': confirmation_url,
                     'status_code': _status_code,
                     'result_json': _result_json}
        report_error(500, subject='Grubhub Order Confirmation Error', message=_message, data_dict=data_dict)
        return confirmation_url, _status_code, None
    else:
        set_order_as_confirmed(order_key)
    return confirmation_url, _status_code, _result_json
