import logging

from marshmallow import Schema, fields, post_load

from application.apis.deliveryservice.service.common.fetch import (
    get_delivery_service_keys_for_restaurant,
)

from application.apis.menu.service.modifier import (
    fetch_menu_item_modifier_for_menu_sync,
)
from application.apis.order.model.Order import OrderType, Order, OrderStatus
from application.apis.order.model.OrderItem import OrderItem
from application.apis.order.model.OrderItemModifier import OrderItemModifier
from application.apis.order.service.fetch import (
    fetch_order_by_restaurant_and_delivery_service,
)
from application.core.parser.string import sanitize_str
from application.shared.schemas import BaseSchema
from application.apis.menu.service.fetch.item import fetch_first_by_uuid


MAP_HANDOFF_OPTIONS = {
    "CONTACTLESS_CONTACT_METHOD_TEXT": "Text customer",
    "CONTACTLESS": "Contact-free delivery",
    "CONTACTLESS_DROPOFF_LOCATION_FRONTDOOR": "Leave order at front door of house/apartment unit",
}


class OrderItemModifierSchema(Schema):
    id = fields.Str()
    name = fields.Str()
    price = fields.Float()
    merchant_price = fields.Float()
    quantity = fields.Int()

    @post_load
    def create_order_item_modifier(self, data):
        delivery_service_key = self.context["delivery_service_key"]
        delivery_service = delivery_service_key.get()
        menu_sync_key = delivery_service.menuSync
        menu_item_modifier = fetch_menu_item_modifier_for_menu_sync(
            data["id"], menu_sync_key
        )

        if sanitize_str(menu_item_modifier.name) != sanitize_str(data["name"]):
            logging.warning(
                """Mapped menu item modifier has different name.
                Name from the order {}, Name from the mapped modifier {}""".format(
                    data["name"], menu_item_modifier.name
                )
            )

        order_item_modifier = OrderItemModifier(
            menu_item_modifier=menu_item_modifier.key, price=data["merchant_price"]
        )
        return order_item_modifier


class TaxSchema(Schema):
    total = fields.Float()

    @post_load
    def create_taxes(self, data):
        return {
            "total": data["total"],
        }


class OrderItemSchema(Schema):
    id = fields.Str()
    name = fields.Str()
    unit_price = fields.Float()
    quantity = fields.Int()
    special_instructions = fields.Str()
    price = fields.Float()
    merchant_price = fields.Float()
    merchant_total = fields.Float()
    total = fields.Float()
    line_options = fields.Nested(OrderItemModifierSchema, many=True)

    @post_load
    def create_order_item(self, data, **kwargs):
        delivery_service_key = self.context["delivery_service_key"]
        delivery_service = delivery_service_key.get()
        menu_sync_key = delivery_service.menuSync
        menu_item = fetch_first_by_uuid(menu_sync_key=menu_sync_key, uuid=data["id"])

        if sanitize_str(menu_item.name) != sanitize_str(data["name"]):
            logging.warning(
                """Mapped menu item has different name.
                Name from the order {}, Name from the mapped item {}""".format(
                    data["name"], menu_item.name
                )
            )

        modifiers = []
        for modifier in data.get("line_options"):
            modifiers.append(modifier)

        order_item = OrderItem(
            menu_item=menu_item.key,
            unit_price=data["merchant_price"],
            quantity=data["quantity"],
            price=data["merchant_total"],
            store_instructions=data.get("special_instructions", ""),
        )
        return {"obj": order_item, "selected_modifier": modifiers}


class ChargeSchema(Schema):
    sub_total = fields.Float()
    restaurant_grand_total = fields.Float()
    taxes = fields.Nested(TaxSchema)
    lines = fields.Nested(OrderItemSchema, many=True)
    tip_amount = fields.Float()
    delivery_fee = fields.Float()
    service_fee = fields.Float()

    @post_load
    def create_charge(self, data):
        return {
            "sub_total": data["sub_total"],
            "taxes": data["taxes"],
            "total": data["restaurant_grand_total"],
            "items": data["lines"],
            "tip": data["tip_amount"],
            "delivery_fee": data["delivery_fee"],
            "service_fee": data["service_fee"],
        }


class ContactInfoSchema(Schema):
    name = fields.Str()
    phone = fields.Str()

    @post_load
    def create_contact_info(self, data):
        return {
            "name": data["name"],
            "phone": data["phone"],
        }


class DeliveryAddressSchema(Schema):
    city = fields.Str()
    state = fields.Str()
    country = fields.Str()
    zip_code = fields.Str()
    address_line1 = fields.Str()
    address_line2 = fields.Str()

    @post_load
    def create_delivery_address(self, data):
        return {
            "city": data["city"],
            "state": data["state"],
            "country": data["country"],
            "zip_code": data["zip_code"],
            "address_line1": data.get("address_line1", ""),
            "address_line2": data.get("address_line2", ""),
        }


class DeliverySchema(Schema):
    delivery_address = fields.Nested(DeliveryAddressSchema)

    @post_load
    def create_delivery(self, data):
        return {
            "delivery_address": data["delivery_address"],
        }


class OrderSchema(BaseSchema):
    store_id = fields.Str()
    payment_mode = fields.Str()
    contact_info = fields.Nested(ContactInfoSchema)
    special_instructions = fields.Str()
    dining_supplies = fields.Str()
    charges = fields.Nested(ChargeSchema)
    order_number = fields.Str()
    is_pickup = fields.Bool()
    delivery = fields.Nested(DeliverySchema)
    handoff_options = fields.List(fields.Str())

    @post_load
    def create_order(self, data, **kwargs):
        delivery_service_key = self.context["delivery_service_key"]
        delivery_service = delivery_service_key.get()
        deliveryservice_keys = get_delivery_service_keys_for_restaurant(
            delivery_service.restaurant, delivery_service.type, include_deleted=True
        )

        order_id = data["order_number"]
        order = fetch_order_by_restaurant_and_delivery_service(
            delivery_service.restaurant, deliveryservice_keys, order_id
        )
        if order:
            if not self.overwrite:
                return order
        else:
            order = Order()

        raw_data = self.context["raw_data"]

        is_pickup = data["is_pickup"]

        customer_name = data["contact_info"]["name"]
        customer_phone = data["contact_info"]["phone"]

        order.delivery_address = sanitize_str(
            "{} {}".format(
                data.get("delivery", {})
                .get("delivery_address", {})
                .get("address_line1", ""),
                data.get("delivery", {})
                .get("delivery_address", {})
                .get("address_line2", ""),
            )
        )
        order.delivery_city = sanitize_str(
            data.get("delivery", {}).get("delivery_address", {}).get("city", "")
        )
        order.delivery_state = sanitize_str(
            data.get("delivery", {}).get("delivery_address", {}).get("state", "")
        )
        order.delivery_zip = sanitize_str(
            data.get("delivery", {}).get("delivery_address", {}).get("zip_code", "")
        )

        restaurant_key = delivery_service.restaurant
        restaurant = restaurant_key.get()

        type_delivery = OrderType.PICKUP if is_pickup else OrderType.DELIVERY

        order.account = restaurant.account
        order.restaurant = restaurant_key
        order.status = OrderStatus.RECEIVED
        order.type = type_delivery
        order.delivery_service = delivery_service_key
        order.delivery_service_uuid = order_id
        order.customer_name = customer_name
        order.customer_phone = customer_phone
        order.delivery_service_raw_data = raw_data
        order.charge_tax = data["charges"]["taxes"]["total"]
        order.charge_subtotal = data["charges"]["sub_total"]
        order.charge_total = data["charges"]["total"]
        order.charge_fee = data["charges"]["service_fee"]
        order.charge_tip = data["charges"]["tip"]
        order.charge_customer_delivery_fee = data["charges"]["delivery_fee"]
        order.store_instructions = data.get("special_instructions", "")
        order.charge_mode = data.get("payment_mode", "")

        handoff_options = []
        for handoff_option in data.get("handoff_options", []):
            if handoff_option in MAP_HANDOFF_OPTIONS:
                handoff_options.append(
                    "* {}".format(MAP_HANDOFF_OPTIONS[handoff_option])
                )
        handoff_options.append(order.store_instructions)
        order.delivery_instructions = "\n".join(handoff_options)

        if data.get("dining_supplies", "").lower() == "include":
            order.store_instructions = "{} - include napkins and utensils".format(
                order.store_instructions
            )
        order_key = order.put()

        order_items_key = []

        for loaded_order_item in data["charges"]["items"]:
            selected_modifier = loaded_order_item["selected_modifier"]
            order_item = loaded_order_item["obj"]

            order_item.order = order_key
            order_item_key = order_item.put()
            modifiers_keys = []
            for modifier in selected_modifier:
                modifier.order = order_key
                modifier.order_item = order_item_key
                modifiers_keys.append(modifier.put())

            order_item.selected_modifier = modifiers_keys
            order_items_key.append(order_item.put())

        order.order_items = order_items_key
        order.put()
        return order
