# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/22/2019
#
import logging

from application.apis.deliveryservice.service.grubhub.serializers.order_serializer import OrderSchema
from application.apis.pointofsale.model.PointOfSale import PointOfSaleType
from application.core.delivery_services.grubhub.grubhub_api import UnauthorizedException
from application.core.notification_hub.notifications.invalid_credentials import InvalidCredentialsNotification
from application.core.notification_hub.sender.factory import NotificationSenderGroupFactory, NotificationSlackSenderFactory
from application.core.notification_hub.notifications.order_failed_with_items import OrderFailedNotificationWithItems
from ..common.parseur import get_and_validate_store_id_from_incoming_email
from application.core.delivery_services.grubhub.factories import GrubHubApiClientFactory
from ..common.fetch import get_delivery_service_for_service_location_id
from application.apis.order.service.creator import create_update_order, get_create_order
from application.apis.menu.service.fetch.item import fetch_all_items
from application.apis.menu.service.modifier import fetch_all_modifiers_for_menu_item
from application.apis.order.service.orderItem import clear_order_item_for_order, add_order_item_to_order
from application.apis.order.service.orderItemModifier import create_order_item_modifier
from application.core.error import report_error
from application.core.parser.string import sanitize_str
from application.core.parser.price import sanitize_price
from google.appengine.ext import ndb
from .confirmation import confirm_order
from application.apis.order.service.push import push_order_to_point_of_sale, push_fail_safe_order_to_printers
from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from application.apis.order.model.Order import Order
from ..common.menuitem import get_menu_item_key_by_name, get_menu_item_modifier_key_by_name
from application.core.event.service import create_event, CoreEventCategory
from ...model.DeliveryService import DeliveryServiceType

DICT_NAME_KEY = 'name'
DICT_DESCRIPTION_KEY = 'description'
DICT_UNIT_PRICE_KEY = 'unit_price'
DICT_QUANTITY_KEY = 'quantity'
DICT_PRICE_KEY = 'price'
DICT_MODIFIERS_KEY = 'modifiers'
DICT_INSTRUCTIONS_KEY = 'instructions'

#############
# LAUNCH TASK
#############

def process_order(order_id, store_id, json_dict):
    order_id = sanitize_str(order_id)
    store_id = sanitize_str(store_id)

    delivery_service = get_delivery_service_for_service_location_id(store_id)
    if not delivery_service:
        return None  # Delivery Service has been disabled but Grubhub email has not been updated.

    # Create dummy order so we can create the task.
    order = get_create_order(
        order_id=order_id, delivery_service_key=delivery_service.key
    )
    addTask(
        category=CoreTaskCategory.GRUBHUB_ORDER_PROCESS,
        entity=order,
        data_dict=json_dict,
    )

    return order


##############
# PROCESS TASK
##############


def processTaskToProcessOrderFromGrubhub(order_id, json_dict):
    logging.info("Processing order id {} for Grubhub".format(order_id))
    order = Order.get_by_id(order_id)
    order_id = order.delivery_service_uuid
    parseur_payment_mode = json_dict.get("paymentMode", "")
    response = process_task_to_process_order_from_grubhub_using_api(
        order, order_id, json_dict, parseur_payment_mode
    )
    if response:
        logging.info("Order processed using grubhub api")
        return response

    logging.info("Order processed using parseur json")
    return processTaskToProcessOrderFromGrubhubUsingParseurJson(order_id, json_dict)


def processTaskToProcessOrderFromGrubhubUsingParseurJson(order_id, json_dict):
    store_email = json_dict.get('Recipient')
    store_id = get_and_validate_store_id_from_incoming_email(store_email, source_entity_key=None)
    store_id = sanitize_str(store_id)
    if not store_id: return None

    delivery_service = get_delivery_service_for_service_location_id(store_id)

    try:
        _order_type = json_dict.get('orderType', '')
        _type_delivery = True if 'delivery' in _order_type.lower() else False
        _ready_by = sanitize_str(json_dict.get('dateTime'))

        # _order_state = json_dict.get('current_state')
        _customer_first_name = sanitize_str(json_dict.get('dropoffName', ''))
        _customer_phone = sanitize_str(json_dict.get('dropoffPhone', ''))

        _charges_subtotal = sanitize_price(json_dict.get('subTotal', '0'))
        _charges_tax = sanitize_price(json_dict.get('tax', '0'))
        _charges_tip = sanitize_price(json_dict.get('tip', '0'))
        _charges_service_fee = sanitize_price(json_dict.get('serviceFee', '0'))
        _charges_customer_delivery_fee = sanitize_price(json_dict.get('customerFee', '0'))
        _charges_total = sanitize_price(json_dict.get('grandTotal', '0'))
        _charges_payment_mode = sanitize_str(json_dict.get('paymentMode', ''))

        _store_instructions = sanitize_str(json_dict.get('dropoffDescription', ''))
        _delivery_address = sanitize_str(json_dict.get('dropoffAddress'))
        _delivery_unit_number = sanitize_str(json_dict.get('unitNumber'))
        if _delivery_unit_number: _delivery_address = _delivery_address + ' ' + _delivery_unit_number
        _delivery_city = sanitize_str(json_dict.get('dropoffCity'))
        _delivery_state = sanitize_str(json_dict.get('dropoffState'))
        _delivery_zip = sanitize_str(json_dict.get('dropoffZip'))
        _delivery_instructions = sanitize_str(json_dict.get('deliveryInstructions', ''))

        _order = create_update_order(delivery_service_key=delivery_service.key,
                                     delivery_service_uuid=order_id,
                                     type_delivery=_type_delivery,
                                     raw_data=json_dict,
                                     customer_name=_customer_first_name,
                                     customer_phone=_customer_phone,
                                     charge_tax=_charges_tax,
                                     charge_subtotal=_charges_subtotal,
                                     charge_fee=_charges_service_fee,
                                     charge_tip=_charges_tip,
                                     charge_customer_delivery_fee=_charges_customer_delivery_fee,
                                     charge_total=_charges_total,
                                     charge_payment_mode=_charges_payment_mode,
                                     store_instructions=_store_instructions,
                                     delivery_address=_delivery_address,
                                     delivery_city=_delivery_city,
                                     delivery_state=_delivery_state,
                                     delivery_zip=_delivery_zip,
                                     delivery_instructions=_delivery_instructions,
                                     ready_by=_ready_by)

        _raw_items = json_dict.get('items')
        _order_items_keys, _fail_safe_printing, unmapped_order_itens = __return_list_of_order_items_keys(
            _order.key,
            delivery_service.menuSync,
            _raw_items
        )

        _order.order_items = _order_items_keys
        _order.put()

        return finish_processing_order(_order, json_dict, _fail_safe_printing, unmapped_order_itens)

    except Exception as e:
        logging.exception("Exception on processing grubhub order from parseur {}".format(e))

        restaurant = delivery_service.restaurant.get()

        notification = OrderFailedNotificationWithItems(
            order_id=order_id,
            ds_type=str(DeliveryServiceType.GRUBHUB),
            restaurant_name=json_dict.get("getSwiftTemplate", ""),
            order_confirmation_code=json_dict.get("confirmationCode", ""),
            order_reference=json_dict.get("reference", ""),
            order_datetime=json_dict.get("dateTime", ""),
            order_type=json_dict.get("orderType", ""),
            dropoff_datetime=json_dict.get("dropoffEarliestDateTime", ""),
            dropoff_name=json_dict.get("dropoffName", ""),
            dropoff_phone=json_dict.get("dropoffPhone", ""),
            dropoff_instructions=json_dict.get("deliveryInstructions", ""),
            order_items=json_dict.get("items", ""),
            payment_mode=json_dict.get("paymentMode", ""),
            subtotal=json_dict.get("subTotal", ""),
            tax=json_dict.get("tax", ""),
            grand_total=json_dict.get("grandTotal", ""),
        )

        notification_sender_group = NotificationSenderGroupFactory(restaurant).create(
            monitored_channel="order-alerts"
        )

        notification_sender_group.dispatch(notification)


def process_task_to_process_order_from_grubhub_using_api(
    order, order_id, json_dict, parseur_payment_mode=""
):
    logging.info("Processing grubhub order uuid:{} using api".format(order_id))
    store_email = json_dict.get("Recipient")
    store_id = get_and_validate_store_id_from_incoming_email(store_email, source_entity_key=None)
    if not store_id: return None

    delivery_service = get_delivery_service_for_service_location_id(
        sanitize_str(store_id)
    )

    if not delivery_service: return None

    logging.info(delivery_service.restaurant)

    service_username = delivery_service.service_username
    try:
        service_password = delivery_service.service_secret
    except:
        service_password = None

    api_client = GrubHubApiClientFactory.instantiate_google_urlfetch_api_client(
        username=service_username, password=service_password
    )

    try:
        grubhub_order = api_client.get_active_order(order_id)
        if not grubhub_order:
            logging.info("Couldn't get the order using grubhub api.")
            return None

        grubhub_order["payment_mode"] = parseur_payment_mode

    except UnauthorizedException:
        logging.warning(
            "Invalid username/password for delivery_service: {}".format(delivery_service.id)
        )
        _notify_invalid_credentials(order)
        _create_core_event_credentials(order)
        return None

    except Exception as e:
        logging.warning("Error on getting grubhub order {}".format(e))
        return None

    try:
        schema = OrderSchema(
            context={"delivery_service_key": delivery_service.key}, overwrite=True
        )
        schema.context["raw_data"] = grubhub_order
        order, errors = schema.load(grubhub_order)

        if errors:
            logging.exception("Error on serializing grubhub order {}".format(errors))
            return None

    except Exception as e:
        logging.exception("Unknown error on serializing grubhub order {}".format(e))
        return None

    return finish_processing_order(order, json_dict)


def _notify_invalid_credentials(order):
    notification = InvalidCredentialsNotification(
        restaurant_id=order.restaurant.id(),
        ds_id=order.delivery_service.id(),
        ds_type=DeliveryServiceType.GRUBHUB
    )
    notification_sender_group = NotificationSlackSenderFactory().create(
        monitored_channel="alerts-grubhub-credentials"
    )
    notification_sender_group.dispatch(notification)


def _create_core_event_credentials(order):
    create_event(
        category=CoreEventCategory.DS_CREDENTIALS,
        name="GRUBHUB Invalid credentials",
        success=False,
        message="Failed to authenticate with GrubHub",
        parent_entities_keys=[key for key in [
            order.account,
            order.restaurant,
            order.delivery_service,
            order.point_of_sale,
            order.key
        ] if key],
    )


def finish_processing_order(order, json_dict, fail_safe_printing=False, unmapped_order_itens=None):
    if not unmapped_order_itens:
        unmapped_order_itens = []

    _delivery_service = order.delivery_service.get()

    confirmation_url = json_dict.get('confirmationLink')
    if _delivery_service.integration_enabled:
        confirm_order(order_key=order.key, confirmation_url=confirmation_url, json_dict=json_dict)

    if fail_safe_printing:
        # FAIL SAFE PRINTING MODE
        success = push_fail_safe_order_to_printers(order.key, json_dict)
        logging.exception("Fail to process grubhub order from parseur")

        restaurant = _delivery_service.restaurant.get()

        notification = OrderFailedNotificationWithItems(
            order_id=str(order.key.id()),
            ds_type=str(DeliveryServiceType.GRUBHUB),
            restaurant_name=json_dict.get("getSwiftTemplate", ""),
            order_confirmation_code=json_dict.get("confirmationCode", ""),
            order_reference=json_dict.get("reference", ""),
            order_datetime=json_dict.get("dateTime", ""),
            order_type=json_dict.get("orderType", ""),
            dropoff_datetime=json_dict.get("dropoffEarliestDateTime", ""),
            dropoff_name=json_dict.get("dropoffName", ""),
            dropoff_phone=json_dict.get("dropoffPhone", ""),
            dropoff_instructions=json_dict.get("deliveryInstructions", ""),
            order_items=json_dict.get("items", ""),
            payment_mode=json_dict.get("paymentMode", ""),
            subtotal=json_dict.get("subTotal", ""),
            tax=json_dict.get("tax", ""),
            grand_total=json_dict.get("grandTotal", ""),
        )

        notification_sender_group = NotificationSenderGroupFactory(restaurant).create(
            monitored_channel="order-alerts"
        )

        notification_sender_group.dispatch(notification)

        point_of_sale = restaurant.point_of_sale.get() if restaurant.point_of_sale else None
        if point_of_sale and point_of_sale.type == PointOfSaleType.TABIT:
            logging.info("pushing unmapped itens to POS {}".format(order.id))
            push_order_to_point_of_sale(order.key, unmapped_order_itens=unmapped_order_itens)

    else:
        # POINT OF SALE
        success = push_order_to_point_of_sale(order.key)

    return {'order_id': str(order.key.id()), 'fail_safe_printing': str(fail_safe_printing)}

#########################
# ORDER DETAIL PROCESSING
#########################

def __return_list_of_order_items_keys(order_key, menuSync_key, raw_menu_items):
    _fail_safe_printing = False

    unmapped_items = []

    _order_items_keys = []
    clear_order_item_for_order(order_key=order_key)
    _all_menu_items = fetch_all_items(menu_sync_key=menuSync_key, keys_only=False)
    _built_menu_items = build_items_array_from_raw_menu_items(raw_menu_items=raw_menu_items)

    # MENU ITEMS
    ############
    for _built_menu_item in _built_menu_items:
        _item_name = _built_menu_item.get(DICT_NAME_KEY)
        _item_unit_price = _built_menu_item.get(DICT_UNIT_PRICE_KEY)
        _item_quantity = _built_menu_item.get(DICT_QUANTITY_KEY)
        _item_price = _built_menu_item.get(DICT_PRICE_KEY)
        _item_instruction = _built_menu_item.get(DICT_INSTRUCTIONS_KEY)

        _built_modifiers_names = _built_menu_item.get(DICT_MODIFIERS_KEY)

        _menu_item_key = get_menu_item_key_by_name(_all_menu_items, _item_name)
        if not _menu_item_key:
            report_item_not_found(
                order_key=order_key,
                raw_order_item_name=_item_name,
                raw_order_item_price=_item_price,
                raw_menu_items=raw_menu_items,
                built_menu_items=_built_menu_items,
            )
            unmapped_order_item = {
                "name": _item_name,
                "quantity": _item_quantity,
                "unit_price": _item_unit_price,
                "price": _item_price,
                "instruction": _item_instruction,
                "modifiers": _built_modifiers_names,
            }
            unmapped_items.append(unmapped_order_item)

            _fail_safe_printing = True
        else:
            _order_item = add_order_item_to_order(order_key=order_key,
                                                  menu_item_key=_menu_item_key,
                                                  unit_price=_item_unit_price,
                                                  quantity=_item_quantity,
                                                  price=_item_price,
                                                  store_instructions=_item_instruction)
            _order_items_keys.append(_order_item.key)

            # MODIFIERS
            ###########
            _modifiers = fetch_all_modifiers_for_menu_item(_order_item.menu_item)
            _order_item_modifiers = []

            for _built_modifier_name in _built_modifiers_names:
                _modifier_key = get_menu_item_modifier_key_by_name(_modifiers, _built_modifier_name)

                if not _modifier_key:
                    report_modifier_not_found(order_key=order_key, built_modifier_name=_built_modifier_name, built_modifiers_names=_built_modifiers_names, raw_menu_items=raw_menu_items, built_menu_items=_built_menu_items)
                    _fail_safe_printing = True
                else:
                    _order_item_modifier = create_order_item_modifier(order_key=order_key,
                                                                      order_item_key=_order_item.key,
                                                                      menu_item_modifier_key=_modifier_key)
                    _order_item_modifiers.append(_order_item_modifier)

            if len(_order_item_modifiers) > 0: ndb.put_multi(_order_item_modifiers)

            # save modifier to order item selected modifier list
            _order_item_modifiers_keys = []
            for _order_item_modifier in _order_item_modifiers: _order_item_modifiers_keys.append(_order_item_modifier.key)
            _order_item.selected_modifier = _order_item_modifiers_keys
            _order_item.put()

    return _order_items_keys, _fail_safe_printing, unmapped_items

#######################
# ORDER DETAILS PARSING
#######################

def build_items_array_from_raw_menu_items(raw_menu_items):
    _items_array = []
    _previous_item_dict = None

    for _raw_menu_item in raw_menu_items:
        _item_dict = {}

        _raw_quantity = _raw_menu_item.get('quantity')
        _raw_price = _raw_menu_item.get('price')
        _raw_description = _raw_menu_item.get('description')

        if _raw_quantity and _raw_price:
            _item_quantity = _raw_quantity
            _item_name = sanitize_str(_raw_description)

            _item_instructions = None
            if 'instructions:' in _item_name:
                _item_instructions_split = _item_name.split('instructions:')
                _item_name = sanitize_str(_item_instructions_split[0])
                _item_instructions = sanitize_str(_item_instructions_split[1])

            _item_price = sanitize_price(_raw_price)
            _item_unit_price = float(_item_price) / float(_item_quantity)
            _item_dict = {DICT_QUANTITY_KEY: _item_quantity,
                          DICT_NAME_KEY: _item_name,
                          DICT_UNIT_PRICE_KEY:_item_unit_price,
                          DICT_PRICE_KEY: _item_price,
                          DICT_MODIFIERS_KEY: [],
                          DICT_INSTRUCTIONS_KEY: _item_instructions}
            _items_array.append(_item_dict)
            _previous_item_dict = _item_dict
        else:
            _modifiers = _previous_item_dict[DICT_MODIFIERS_KEY]
            for _raw_modifier_name in _raw_description.split('\n'):
                _modifier_name = sanitize_str(_raw_modifier_name)
                _modifiers.append(_modifier_name)

            _previous_item_dict[DICT_MODIFIERS_KEY] = _modifiers

    return _items_array

########
# HELPER
########

def report_item_not_found(order_key, raw_order_item_name, raw_order_item_price, raw_menu_items, built_menu_items=None):
    _name = "Grubhub Order MenuItem Not Found"
    _message = 'Order %s - Item not found "%s" at %s' % (str(order_key.id()), raw_order_item_name, str(raw_order_item_price))
    _data_dict = {'order': order_key.id(),
                  'raw_order_item_name': raw_order_item_name,
                  'raw_order_item_price': raw_order_item_price,
                  'raw_menu_items': raw_menu_items,
                  'built_menu_items': built_menu_items}
    _order = order_key.get()
    _parent_entities_keys = [order_key]
    if _order.account: _parent_entities_keys.append(_order.account)
    if _order.restaurant: _parent_entities_keys.append(_order.restaurant)
    if _order.point_of_sale: _parent_entities_keys.append(_order.point_of_sale)
    if _order.delivery_service: _parent_entities_keys.append(_order.delivery_service)
    create_event(category=CoreEventCategory.UNKNOWN_MENU_ITEM,
                 name=_name,
                 success=False,
                 message=_message,
                 payload=_data_dict,
                 entity_key=order_key,
                 parent_entities_keys=_parent_entities_keys)
    report_error(400, subject=_name, message=_message, data_dict=_data_dict)

    return

def report_modifier_not_found(order_key, built_modifier_name, built_modifiers_names, raw_menu_items, built_menu_items=None):
    _name = "Grubhub Order MenuItemModifier Not Found"
    _message = 'Order %s - Modifier not found "%s"' % (str(order_key.id()), built_modifier_name)
    _data_dict = {'order': order_key.id(),
                  'built_modifier_name': built_modifier_name,
                  'built_modifiers_names': built_modifiers_names,
                  'raw_menu_items': raw_menu_items,
                  'built_menu_items': built_menu_items}
    _order = order_key.get()
    _parent_entities_keys = [order_key]
    if _order.account: _parent_entities_keys.append(_order.account)
    if _order.restaurant: _parent_entities_keys.append(_order.restaurant)
    if _order.point_of_sale: _parent_entities_keys.append(_order.point_of_sale)
    if _order.delivery_service: _parent_entities_keys.append(_order.delivery_service)
    create_event(category=CoreEventCategory.UNKNOWN_MENU_MODIFIER,
                 name=_name,
                 success=False,
                 message=_message,
                 payload=_data_dict,
                 entity_key=order_key,
                 parent_entities_keys=_parent_entities_keys)
    report_error(400, subject=_name, message=_message, data_dict=_data_dict)
    return
