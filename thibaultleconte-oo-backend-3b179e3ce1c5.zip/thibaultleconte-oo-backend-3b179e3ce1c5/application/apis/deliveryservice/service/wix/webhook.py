# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 09/10/2019
#

from .order import create_order
from application.core.error import report_error


def process_webhook(webhook_key, json_dict):
    _raw_order = json_dict.get('order')
    _order_status = _raw_order.get('status')
    if _order_status == 'new':
        _order_uuid = _raw_order.get('id')
        _store_id = _raw_order.get('restaurantId')
        _order = create_order(order_uuid=_order_uuid, store_id=_store_id, json_dict=json_dict)
    else:
        _message = 'event type received is %s' % (str(_event_type))
        _subject = 'WIX Webhook - Unknown event type'
        report_error(code=500, message=_message, subject=_subject, data_dict=json_dict)
    return True
