# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 08/25/2019
#

from application.apis.menu.service.menusync.creator import create_menu_sync
from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from application.apis.menu.service.menusync.fetch import fetch_menu_task_started, fetch_menu_task_finished
from application.apis.menu.model.MenuSync import MenuSync
# from flask import current_app
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.error import report_error
from application.apis.menu.service.creator import generate_item_dict, generate_modifier_group_dict, generate_modifier_dict, startTaskToCreateOrUpdateMenuItemsAndModifiers
from application.apis.menu.service.menusync.process import process_menu_task_started
# import json
from application.apis.menu.service.crud.section import create_update_menu_section
from application.apis.menu.service.crud.category import create_update_menu_category


def startTaskToFetchMenu(deliveryservice_key):
    _ds = deliveryservice_key.get()
    _ms = create_menu_sync(restaurant_key=_ds.restaurant, service_key=_ds.key)
    _ds.menuSync = _ms.key
    _ds.put()
    _task = addTask(category=CoreTaskCategory.WIX_MENU_FETCH, entity=_ms)
    _ms = fetch_menu_task_started(menuSync_key=_ms.key, task_key=_task.key)
    return _ds

def processTaskToFetchMenuFromWix(menu_sync_id):
    _task_result_json = {}
    _ms = MenuSync.get_by_id(menu_sync_id)
    if not _ms:
        _task_result_json['processTaskToFetchMenuFromWix'] = {'message': 'MenuSync with id %s not found' % (str(menu_sync_id))}
    elif not _ms.service:
        _task_result_json['processTaskToFetchMenuFromWix'] = {'message': 'MenuSync with id %s has no ds' % (str(menu_sync_id))}
    else:
        _url, _status_code, _result_json = __start_fetch_menu_request(_ms.service)
        _task_result_json['__start_fetch_menu_request'] = {'url': _url,
                                                           'status_code': _status_code,
                                                           'result_json': _result_json}
        if _status_code >= 200 and _status_code <= 299:
            _menu_items = __process_menu(_ms, _result_json)
            process_menu_task_started(menuSync_key=_ms.key, tasks_keys=_menu_items)
            _task_result_json['__parse_menu'] = {'message': "Delivery Service has fetched %s menu items" % (str(len(_menu_items)))}
        else:
            report_error(code=_status_code, subject="GetWixMenu-Error", message="Menu Sync %s returned %s" % (str(_ms.key.id()), str(_status_code)))
    return _task_result_json

############
# Fetch Menu
############

def __start_fetch_menu_request(delivery_service_key):
    _ds = delivery_service_key.get()
    _url = "https://api.wixrestaurants.com/v2/organizations/" + _ds.serviceLocationId + "/menu"
    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.WIX, method="GET")
    if _status_code < 200 or _status_code > 299:
        fetch_menu_task_finished(menuSync_key=_ds.menuSync, success=False)
        return _url, _status_code, None
    fetch_menu_task_finished(menuSync_key=_ds.menuSync, success=True)
    return _url, _status_code, _result_json

##############
# Process Menu
##############

def __format_price_from_wix(price):
    if not price: return 0.0
    return float(price) / 100.0

def __return_item_from_raw_items(raw_items, item_id):
    for _element in raw_items:
        _raw_item_id = _element.get('id')
        if _raw_item_id == item_id:
            return _element
    return None

def __process_menu(menu_sync, raw_data):
    _items_tasks = []
    _raw_items = raw_data.get('items') if 'items' in raw_data else []
    if 'sections' in raw_data:
        for raw_section in raw_data.get('sections'):
            _section_id = raw_section.get('id')
            if _section_id.lower() != 'trash':
                _idx_section = raw_data.get('sections').index(raw_section)
                _section = _parse_section(menu_sync.key, raw_section, _idx_section)
                if 'children' in raw_section:
                    _categories_key = []
                    for raw_children in raw_section.get('children'):
                        _category = __parse_category(menu_sync.key, _section.key, raw_children)
                        _categories_key.append(_category.key)
                        _items_tasks.extend(__parse_items(menu_sync, _category.key, raw_children, _raw_items))
                    _section.categories = _categories_key
                    _section.put()
    return _items_tasks

def _parse_section(menu_sync_key, raw_section, raw_index):
    _raw_uuid = raw_section.get('id')
    _raw_name = raw_section.get('title', {}).get('en_US')
    _raw_description = raw_section.get('description', {}).get('en_US')
    _section = create_update_menu_section(menu_sync_key=menu_sync_key,
                                          name=_raw_name,
                                          position=raw_index,
                                          uuid=_raw_uuid,
                                          description=_raw_description)
    return _section

def __parse_category(menu_sync_key, section_key, raw_subsection):
    _raw_uuid = raw_subsection.get('id', None)
    _raw_name = raw_subsection.get('title').get('en_US')
    _category = create_update_menu_category(menu_sync_key=menu_sync_key,
                                            section_key=section_key,
                                            name=_raw_name,
                                            uuid=_raw_uuid)
    return _category

def __parse_items(menu_sync, category_key, raw_children, raw_items):
    _items_tasks = []
    if 'itemIds' in raw_children:
        for raw_item_id in raw_children.get('itemIds'):
            # _idx_item = raw_children.get('itemIds').index(raw_item_id)
            _raw_item = __return_item_from_raw_items(raw_items, raw_item_id)
            _modifier_groups = __parse_modifier_groups(_raw_item, raw_items)

            _mi = generate_item_dict(name=_raw_item.get('title').get('en_US'),
                                     price=__format_price_from_wix(_raw_item.get('price')),
                                     modifier_groups=_modifier_groups,
                                     uuid=raw_item_id,
                                     category_id=category_key.id(),
                                     image_url=_raw_item.get('media').get('logo'),
                                     description=_raw_item.get('description').get('en_US'))
            _task = startTaskToCreateOrUpdateMenuItemsAndModifiers(menu_sync, _mi)
            if _task: _items_tasks.append(_task.key)
    return _items_tasks

def __parse_modifier_groups(raw_item, raw_items):
    modifier_groups = []
    if 'variations' in raw_item:
        for raw_variation in raw_item.get('variations'):
            # _idx_group = raw_item.get('variations').index(raw_variation)
            _group_name = raw_variation.get('title').get('en_US')
            _min_permitted = raw_variation.get('minNumAllowed', 0)
            _max_permitted = raw_variation.get('maxNumAllowed', 0)
            _modifiers = __parse_modifiers(raw_variation, raw_items)
            _group = generate_modifier_group_dict(name=_group_name,
                                                  modifiers=_modifiers,
                                                  min_permitted=_min_permitted,
                                                  max_permitted=_max_permitted)
            modifier_groups.append(_group)
    return modifier_groups

def __parse_modifiers(raw_variation, raw_items):
    modifiers = []
    _modifier_prices = raw_variation.get('prices')
    if 'itemIds' in raw_variation:
        for raw_modifier_id in raw_variation.get('itemIds'):
            # _idx_modifier = raw_variation.get('itemIds').index(raw_modifier_id)
            _raw_modifier = __return_item_from_raw_items(raw_items, raw_modifier_id)
            _modifier_price = 0
            if _modifier_prices:
                _modifier_price = _modifier_prices[raw_modifier_id] if raw_modifier_id in raw_variation.get('prices') else 0
            _mod = generate_modifier_dict(name=_raw_modifier.get('title').get('en_US'),
                                          price=__format_price_from_wix(_modifier_price),
                                          uuid=raw_modifier_id)
            modifiers.append(_mod)
    return modifiers
