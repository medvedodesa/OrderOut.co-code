# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 09/10/2019
#
import json
from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from application.apis.order.model.Order import Order
from application.core.parser.string import sanitize_str
from application.core.parser.price import sanitize_price
from application.apis.deliveryservice.service.common.fetch import get_delivery_service_for_service_location_id
from application.apis.order.service.creator import create_update_order, update_order
from datetime import datetime
from application.apis.order.service.confirmation import check_order_is_confirmed, set_order_as_confirmed
from application.apis.order.service.push import push_order_to_point_of_sale, push_fail_safe_order_to_printers
from application.apis.menu.service.modifier import fetch_menu_item_modifiers_keys_with_uuids
from application.core.error import report_error
from application.apis.order.service.orderItem import add_order_item_to_order
from application.apis.order.service.orderItemModifier import create_order_item_modifier
from google.appengine.ext import ndb
from application.core.event.service import create_event
from application.core.event.model import CoreEventCategory
from application.core.event.service import create_event, CoreEventCategory
from application.apis.menu.service.fetch.item import fetch_first_by_uuid
import logging


######################
# GENERIC ORDER HELPER
######################

def create_order(order_uuid, store_id, json_dict):
    _raw_order = json_dict.get('order')

    _order_uuid = sanitize_str(order_uuid)
    _store_id = sanitize_str(store_id)
    _delivery_service = get_delivery_service_for_service_location_id(_store_id)
    _type_delivery = __is_type_delivery(_raw_order.get('delivery').get('type'))

    if not _delivery_service:
        _raw_restaurant_name = json_dict.get('restaurant', {}).get('title', {}).get('en_US', 'Unknown-Name')
        _raw_restaurant_address = json_dict.get('restaurant', {}).get('address', {}).get('formatted', "Unknown-Address")
        _message = 'WIX store_id %s not found while searching for delivery service for restaurant %s %s' % (str(_store_id), str(_raw_restaurant_name), str(_raw_restaurant_address))
        create_event(category=CoreEventCategory.UUID,
                     name=' Unknown WIX Store ID',
                     success=False,
                     message=_message,
                     payload=json_dict)
        logging.error(_message)
        return None

    _order = create_update_order(delivery_service_key=_delivery_service.key,
                                 delivery_service_uuid=_order_uuid,
                                 type_delivery=_type_delivery,
                                 raw_data=json_dict,
                                 )

    _task = __start_task_process_order_details(_order.key, json_dict)

    return _order

###############
# ORDER DETAILS
###############

def __start_task_process_order_details(order_key, json_dict):
    _order = order_key.get()
    _task = addTask(category=CoreTaskCategory.WIX_ORDER_PROCESS, entity=_order, data_dict=json_dict)
    return _task

def processTaskToProcessOrderDetailsFromWix(order_id, json_dict):
    _order = Order.get_by_id(order_id)
    _delivery_service = _order.delivery_service.get()
    _task_result_json = {'order_id': order_id}

    # ORDER CONFIRMED
    if check_order_is_confirmed(_order.key) == False:
        set_order_as_confirmed(_order.key)

    _raw_order = json_dict.get('order',{})
    _type_delivery = __is_type_delivery(_raw_order.get('delivery').get('type'))

    _customer_first_name = _raw_order.get('contact').get('firstName')
    _customer_last_name = _raw_order.get('contact').get('lastName')
    _customer_name = _customer_first_name + ' ' + _customer_last_name
    _customer_phone = _raw_order.get('contact').get('phone')
    _customer_email = _raw_order.get('contact').get('email')

    _raw_payment = _raw_order.get('payments', [])
    if len(_raw_payment) > 0:
        _raw_payment = _raw_payment[0]
        _charges_total = sanitize_price(float(_raw_payment.get('amount'))/100)
        _charges_payment_mode = str(_raw_payment.get('type')).lower()
    else:
        _charges_total = sanitize_price(float(_raw_order.get('price'))/100)
        _charges_payment_mode = 'UNKNOWN'

    _store_instructions = str(_raw_order.get('comment'))
    _ready_by = 'ASAP'

    delivery_address = _raw_order.get("delivery", {}).get("address", {}).get("formatted", "")
    delivery_city = _raw_order.get("delivery", {}).get("address", {}).get("city", "")
    delivery_state = _raw_order.get("delivery", {}).get("address", {}).get("properties", {}).get("com.wix.restaurants", "")
    if delivery_state:
        try:
            delivery_state = json.loads(delivery_state)
            delivery_state = delivery_state.get("subdivision", "")
        except Exception:
            delivery_state = ""

    delivery_zip = _raw_order.get("delivery", {}).get("address", {}).get("postalCode", "")
    delivery_instructions = _raw_order.get("delivery", {}).get("address", {}).get("comment", "")

    _order = update_order(order_key=_order.key,
                          type_delivery=_type_delivery,
                          raw_data=json_dict,
                          customer_name=_customer_name,
                          customer_phone=_customer_phone,
                          customer_email=_customer_email,
                          charge_total=_charges_total,
                          charge_payment_mode=_charges_payment_mode,
                          store_instructions=_store_instructions,
                          ready_by=_ready_by,
                          delivery_address=delivery_address,
                          delivery_city=delivery_city,
                          delivery_state=delivery_state,
                          delivery_zip=delivery_zip,
                          delivery_instructions=delivery_instructions,
                          )

    _raw_items = _raw_order.get('orderItems')
    _order_items_keys, _fail_safe_printing = __return_list_of_order_items_keys(_order.key, _delivery_service.menuSync, _raw_items)
    _order.order_items = _order_items_keys
    _order.put()

    if _fail_safe_printing:
        # FAIL SAFE PRINTING MODE
        success = push_fail_safe_order_to_printers(_order.key, json_dict)
    else:
        # POINT OF SALE
        success = push_order_to_point_of_sale(_order.key)

    return _task_result_json

######################
# Delivery Type Helper
######################

def __is_type_delivery(raw_delivery_type):
    if raw_delivery_type == 'delivery': return True
    return False

############
# MENU ITEMS
############

def __return_list_of_order_items_keys(order_key, menuSync_key, raw_menu_items):
    _fail_safe_printing = False
    _order_items_keys = []

    for _raw_menu_item in raw_menu_items:

        import logging
        logging.info(_raw_menu_item)

        # MENU ITEM
        _raw_id = sanitize_str(_raw_menu_item.get('itemId'))
        _raw_unit_price = sanitize_price(float(_raw_menu_item.get('price', 0.0)/100.0))
        _raw_quantity = _raw_menu_item.get('count')
        _raw_price = sanitize_price(float(_raw_menu_item.get('price', 0.0)/100.0) * _raw_quantity)
        _raw_comment = sanitize_str(_raw_menu_item.get('comment'))

        _menu_item = fetch_first_by_uuid(menu_sync_key=menuSync_key, uuid=_raw_id)
        if not _menu_item:
            _name = "Wix Order MenuItem UUID Not Found"
            _message = 'Order %s - Wix UUID not found in menu item' % (str(order_key.id()))
            _data_dict = {'order': order_key.id(),
                         '_raw_menu_item_id': _raw_id,
                         '_raw_menu_item': _raw_menu_item}
            _order = order_key.get()
            _parent_entities_keys = [order_key]
            if _order.account: _parent_entities_keys.append(_order.account)
            if _order.restaurant: _parent_entities_keys.append(_order.restaurant)
            if _order.point_of_sale: _parent_entities_keys.append(_order.point_of_sale)
            if _order.delivery_service: _parent_entities_keys.append(_order.delivery_service)
            create_event(category=CoreEventCategory.UNKNOWN_MENU_ITEM,
                         name=_name,
                         success=False,
                         message=_message,
                         payload=_data_dict,
                         entity_key=order_key,
                         parent_entities_keys=_parent_entities_keys)
            report_error(500, subject=_name, message=_message, data_dict=_data_dict)
            _fail_safe_printing = True
            return _order_items_keys, _fail_safe_printing

        _order_item = add_order_item_to_order(order_key=order_key,
                                              menu_item_key=_menu_item.key,
                                              unit_price=_raw_unit_price,
                                              quantity=_raw_quantity,
                                              price=_raw_price,
                                              store_instructions=_raw_comment)

        # MODIFIERS
        _raw_order_item_modifiers_uuids = []
        if 'variationsChoices' in _raw_menu_item:
            for _raw_choices in _raw_menu_item.get('variationsChoices'):
                for _raw_options in _raw_choices:
                    _raw_modifier_id = sanitize_str(_raw_options.get('itemId'))
                    _raw_order_item_modifiers_uuids.append(_raw_modifier_id)

        if len(_raw_order_item_modifiers_uuids) > 0:
            _menu_item_modifiers_keys = fetch_menu_item_modifiers_keys_with_uuids(menu_sync_key=menuSync_key, uuids=_raw_order_item_modifiers_uuids)
            if len(_raw_order_item_modifiers_uuids) != len(_menu_item_modifiers_keys):
                _name = "Wix Order MenuItemModifier Not Found"
                _message = 'Order %s - Some Modifiers not found %s' % (str(order_key.id()), _raw_order_item_modifiers_uuids)
                _data_dict = {'order': order_key.id(),
                             '_raw_order_item_modifiers_uuids': _raw_order_item_modifiers_uuids}
                _order = order_key.get()
                _parent_entities_keys = [order_key]
                if _order.account: _parent_entities_keys.append(_order.account)
                if _order.restaurant: _parent_entities_keys.append(_order.restaurant)
                if _order.point_of_sale: _parent_entities_keys.append(_order.point_of_sale)
                if _order.delivery_service: _parent_entities_keys.append(_order.delivery_service)
                create_event(category=CoreEventCategory.UNKNOWN_MENU_MODIFIER,
                             name=_name,
                             success=False,
                             message=_message,
                             payload=_data_dict,
                             entity_key=order_key,
                             parent_entities_keys=_parent_entities_keys)
                report_error(500, subject=_name, message=_message, data_dict=_data_dict)
                _fail_safe_printing = True
                return _order_items_keys, _fail_safe_printing

            _order_item_modifiers = []
            for _menu_item_modifier_key in _menu_item_modifiers_keys:
                _order_item_modifier = create_order_item_modifier(order_key=order_key,
                                                                  order_item_key=_order_item.key,
                                                                  menu_item_modifier_key=_menu_item_modifier_key)
                _order_item_modifiers.append(_order_item_modifier)

            ndb.put_multi(_order_item_modifiers)

            for _order_item_modifier in _order_item_modifiers:
                if _order_item_modifier.key not in _order_item.selected_modifier:
                    _order_item.selected_modifier.append(_order_item_modifier.key)

            _order_item.put()

        # ADD TO ORDER
        _order_items_keys.append(_order_item.key)

    return _order_items_keys, _fail_safe_printing
