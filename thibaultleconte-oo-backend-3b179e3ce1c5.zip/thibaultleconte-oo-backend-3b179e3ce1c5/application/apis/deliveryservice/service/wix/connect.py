# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 08/25/2019
#

from ...model.DeliveryService import DeliveryService, DeliveryServiceType
from ..common.fetch import check_delivery_service_already_connected
from application.apis.ooexceptions import ConflictResourceAlreadyExistsError
import json

def connect(account_key, restaurant_key, store_id):
    if check_delivery_service_already_connected(restaurant_key=restaurant_key,
                                                delivery_service_type=DeliveryServiceType.WIX):
        raise ConflictResourceAlreadyExistsError

    _ds = __createDeliveryService(account_key=account_key,
                                  restaurant_key=restaurant_key,
                                  serviceLocationId=store_id)
    return _ds

def __createDeliveryService(account_key, restaurant_key, serviceLocationId):
    _ds = DeliveryService()
    _ds.type = DeliveryServiceType.WIX
    _ds.account = account_key
    _ds.restaurant = restaurant_key
    _ds.serviceLocationId = serviceLocationId
    _ds.put()
    _restaurant = restaurant_key.get()
    _restaurant.delivery_services.append(_ds.key)
    _restaurant.put()
    return _ds
