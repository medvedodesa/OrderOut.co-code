import logging
from google.appengine.api import memcache


from application.apis.deliveryservice.service.postmates.menu.utils import get_postmates_menus
from application.apis.deliveryservice.service.postmates.serializers.menu_serializer import CatalogSchema
from application.core.security.token_handler import get_token
from application.core.settings.app import get_config_for_key, get_test_config_for_key
from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from application.apis.deliveryservice.model.DeliveryService import DeliveryService
from application.core.delivery_services.postmates.factories import PostmatesApiClientFactory


def start_task_to_push_menu(deliveryservice_key, test_on_biscayne_bakery=True):
    ds = deliveryservice_key.get()
    data_dict = {"test_on_biscayne_bakery": test_on_biscayne_bakery}
    addTask(
        category=CoreTaskCategory.POSTMATES_MENU_PUSH, entity=ds, data_dict=data_dict
    )
    return ds


def process_task_to_push_menu_to_postmates(deliveryservice_id, test_on_biscayne_bakery=True):
    base_url = get_config_for_key("PROJECT_URL")
    ds_key = DeliveryService.get_key(deliveryservice_id)
    ds = ds_key.get()
    restaurant_id = ds.restaurant.id()

    if test_on_biscayne_bakery:
        place_id = get_test_config_for_key("POSTMATES_PLACE_ID")
        account_id = get_test_config_for_key("POSTMATES_ACCOUNT_ID")
    else:
        place_id = ds.serviceLocationId
        account_id = ds.service_account_id

    api_client = PostmatesApiClientFactory.instantiate_google_urlfetch_api_client(test_on_biscayne_bakery)

    token = get_token(restaurant_id)

    source_url = "{}/api/restaurant/{}/ds/postmates/catalog?token={}".format(
        base_url, restaurant_id, token
    )

    webhook_url = "{}/api/ds/postmates/post_catalog_callback".format(base_url)

    # Generate JSON payload here as postmates have a real short timeout
    menu_sections = get_postmates_menus(restaurant_id)
    if menu_sections:
        all_errors = []
        response = None
        for menu_section in menu_sections:
            schema = CatalogSchema()
            response_menu, errors = schema.dump(menu_section)
            if not response:
                response = response_menu
            else:
                response["categories"].extend(response_menu["categories"])
            if errors:
                all_errors.append(errors)
            logging.info(response)

        if not all_errors:
            key = "postmates-menu-{}".format(restaurant_id)
            value = response
            logging.info("Adding menu to cache with key: {}".format(key))
            memcache.add(key=key, value=value, time=300)

    payload = {
        "source_url": source_url,
        "webhook_url": webhook_url,
    }

    api_client.update_catalog(place_id=place_id, account_id=account_id, payload=payload)
    return True