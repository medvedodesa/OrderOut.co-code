from application.apis.deliveryservice.model.DeliveryService import DeliveryService
from application.apis.deliveryservice.model.DeliveryService import DeliveryServiceType
from application.apis.menu.model.MenuSection import MenuSection
from application.apis.restaurant.model import Restaurant


def get_postmates_menus(restaurant_id):
    restaurant = Restaurant.get_by_id(restaurant_id)
    if not restaurant:
        return None

    _query = DeliveryService.query()
    _query = _query.filter(DeliveryService.restaurant == restaurant.key)
    _query = _query.filter(DeliveryService.type == DeliveryServiceType.POSTMATES)
    delivery_service = _query.get()

    if not delivery_service:
        return None

    menu_sync_key = delivery_service.menuSync

    query = MenuSection.query()
    query = query.filter(MenuSection.menuSync == menu_sync_key)
    menu_sections = query.fetch()
    return menu_sections
