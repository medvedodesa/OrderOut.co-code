import logging

from application.apis.deliveryservice.model.DeliveryService import (
    DeliveryService,
    DeliveryServiceType,
)
from application.apis.deliveryservice.service.postmates.serializers.menu_serializer import (
    CatalogSchema,
)
from application.apis.menu.model.MenuSection import MenuSection
from application.apis.menu.model.MenuSync import MenuSync
from application.apis.menu.service.menusync.creator import create_menu_sync
from application.apis.menu.service.menusync.fetch import (
    fetch_menu_task_started,
    fetch_menu_task_finished,
)
from application.apis.menu.service.stats import refresh_stats
from application.core.task.model import CoreTaskCategory
from application.core.task.service import addTask


def start_task_to_copy_menu(
    delivery_service_key, from_delivery_service_type=DeliveryServiceType.UBEREATS
):
    ds = delivery_service_key.get()
    ms = create_menu_sync(restaurant_key=ds.restaurant, service_key=ds.key)
    ds.menuSync = ms.key
    ds.put()
    data_dict = {"from_delivery_service_type": from_delivery_service_type}
    task = addTask(
        category=CoreTaskCategory.POSTMATES_MENU_COPY, entity=ms, data_dict=data_dict
    )
    ms = fetch_menu_task_started(menuSync_key=ms.key, task_key=task.key)
    return ms


def process_menu_copy(menu_sync_id, from_delivery_service_type):
    task_result_json = {}
    menu_sync = MenuSync.get_by_id(menu_sync_id)

    if not menu_sync:
        task_result_json["process_menu_copy"] = {
            "message": "MenuSync with id %s not found" % (str(menu_sync_id))
        }
        return task_failed(menu_sync.key, task_result_json)

    if not menu_sync.restaurant:
        task_result_json["process_menu_copy"] = {
            "message": "MenuSync with id %s has no restaurant" % (str(menu_sync_id))
        }
        return task_failed(menu_sync.key, task_result_json)

    query = DeliveryService.query()
    query = query.filter(DeliveryService.restaurant == menu_sync.restaurant)
    query = query.filter(DeliveryService.type == from_delivery_service_type)
    from_delivery_service = query.get()

    if not from_delivery_service:
        task_result_json["process_menu_copy"] = {
            "message": "Couldn't find delivery service: %s"
            % str(from_delivery_service_type)
        }
        return task_failed(menu_sync.key, task_result_json)

    from_ds_menu_sync_key = from_delivery_service.menuSync

    query = MenuSection.query()
    query = query.filter(MenuSection.menuSync == from_ds_menu_sync_key)

    from_menu_sections = query.fetch()

    if not from_menu_sections:
        task_result_json["process_menu_copy"] = {
            "message": "Couldn't find a menu for the delivery service: %s"
            % str(from_delivery_service_type)
        }
        return task_failed(menu_sync.key, task_result_json)

    schema = CatalogSchema()
    schema.context["menu_sync_key"] = menu_sync.key
    errors_load = []
    errors_dump = []
    for from_menu_section in from_menu_sections:
        print("from menu section: {}".format(from_menu_section))
        response, e_dump = schema.dump(from_menu_section)
        if e_dump:
            errors_dump.append(e_dump)

        menu_section, e_load = schema.load(response)
        if e_load:
            errors_load.append(e_load)

    if errors_dump or errors_load:
        logging.exception("Exception on copy menu: dump: {}, load: {}".format(
                errors_load, errors_dump
            )
        )
        task_result_json["process_menu_copy"] = {
            "message": "Error on creating menu: %s, %s" % (str(errors_dump), str(errors_load))
        }
        return task_failed(menu_sync.key, task_result_json)

    refresh_stats(menu_sync_key=menu_sync.key)
    fetch_menu_task_finished(menuSync_key=menu_sync.key, success=True)


def task_failed(menu_sync_key, task_result_json):
    fetch_menu_task_finished(menuSync_key=menu_sync_key, success=False)
    return task_result_json
