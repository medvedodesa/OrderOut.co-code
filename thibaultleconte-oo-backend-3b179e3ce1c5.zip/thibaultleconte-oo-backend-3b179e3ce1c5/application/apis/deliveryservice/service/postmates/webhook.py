import logging

from application.apis.deliveryservice.service.postmates.serializers.order_serializer import (
    OrderSchema,
)
from application.apis.order.model.Order import Order
from application.apis.order.service.push import push_order_to_point_of_sale
from application.core.delivery_services.postmates.factories import PostmatesApiClientFactory
from application.core.task.model import CoreTaskCategory
from application.core.task.service import addTask


def process_webhook(json_dict):
    schema = OrderSchema()
    schema.context["raw_data"] = json_dict
    try:
        order, errors = schema.load(json_dict)
        logging.info("Order created")
    except Exception as e:
        logging.exception("Process Postmates webhook: Unknown error {}".format(e))
        return False

    order_id = json_dict.get("order_id")
    external_order_id = json_dict.get("data", {}).get("external_order_id")
    event_id = json_dict.get("id")
    if errors:
        logging.exception("Process Postmates webhook: Error {} on parse payload: {}".format(errors, json_dict))
        postmates_api_client = PostmatesApiClientFactory.instantiate_google_urlfetch_api_client()
        # request to postmates warning that we couldn't handle the order
        postmates_api_client.update_order(
            order_id=order_id, external_order_id=external_order_id, event_id=event_id, success=False
        )
        return False

    _delivery_service = order.delivery_service.get()
    logging.info("delivery_service: {} has integration_enabled? {}".format(
        _delivery_service, _delivery_service.integration_enabled)
    )
    if _delivery_service.integration_enabled:
        start_task_accept_postmates_order(json_dict=json_dict, order=order)
    return True


def start_task_accept_postmates_order(json_dict, order):
    task = addTask(
        category=CoreTaskCategory.POSTMATES_ORDER_ACCEPT,
        data_dict=json_dict,
        entity=order,
    )
    return task


def process_task_to_accept_postmates_order(order_id):
    logging.info("Process task to accept postmates order: {}".format(order_id))
    order = Order.get_by_id(order_id)

    if not order:
        logging.info("Order {} not found".format(order_id))
        return False

    push_order_to_point_of_sale(order.key)

    order_id = order.delivery_service_uuid

    raw_data = order.delivery_service_raw_data

    external_order_id = raw_data.get("data", {}).get("external_order_id")
    event_id = raw_data.get("id")

    logging.info("sending event to postmates")

    postmates_api_client = PostmatesApiClientFactory.instantiate_google_urlfetch_api_client()
    postmates_api_client.update_order(
        order_id=order_id, external_order_id=external_order_id, event_id=event_id, success=True
    )
    return True
