from marshmallow import Schema, fields, post_load, pre_dump
from marshmallow.validate import Range

from application.apis.menu.model.MenuItem import MenuItem
from application.apis.menu.model.MenuItemModifier import MenuItemModifier
from application.apis.menu.model.MenuModifierGroup import MenuModifierGroup
from application.apis.menu.model.MenuCategory import MenuCategory
from application.apis.menu.model.MenuSection import MenuSection
from application.shared.fields import SkipMissingNested
from application.shared.schemas import BaseNDBSchema


MAP_DAY_OF_WEEK = {
    "monday": 0,
    "tuesday": 1,
    "wednesday": 2,
    "thursday": 3,
    "friday": 4,
    "saturday": 5,
    "sunday": 6,
}

class CatalogItemAvailabilitySchema(Schema):
    kind = fields.Str(default="availability")
    day_of_week = fields.Int(required=True, validate=Range(min=1, max=6))
    start_time = fields.Str(required=True)
    end_time = fields.Str(required=True)


class DumpCatalogItemTimePeriodAvailabilitySchema(Schema):
    start_time = fields.String(required=True)
    end_time = fields.String(required=True)


class DumpCatalogItemAvailabilitySchema(Schema):
    day_of_week = fields.Str(required=True)
    enabled = fields.Bool(required=False)
    time_periods = fields.Nested(DumpCatalogItemTimePeriodAvailabilitySchema, required=True, many=True)


class CatalogModifierSchema(BaseNDBSchema):
    kind = fields.Str(default="modifier", dump_only=True)
    id = fields.Str(required=True, attribute="uuid")
    created = fields.DateTime(attribute="api_created_at", dump_only=True)
    updated = fields.DateTime(attribute="api_updated_at", dump_only=True)
    name = fields.Str(required=True, attribute="name")
    price = fields.Float(required=True, attribute="price")
    price_currency = fields.Str(default="USD", dump_only=True)
    ordinal = fields.Int()
    modifier_groups = fields.Nested(
        "CatalogModifierGroupSchema",
        exclude=("modifiers",),
        attribute="groups",
        many=True,
        required=False,
    )

    @post_load
    def create_menu_item_modifier(self, data, **kwargs):
        menu_sync_key = self.context["menu_sync_key"]
        data["uuid"] = str(data.get("uuid"))
        menu_item_modifier = MenuItemModifier(**data)
        menu_item_modifier.menuSync = menu_sync_key
        return menu_item_modifier.put()


class CatalogModifierGroupSchema(BaseNDBSchema):
    kind = fields.Str(default="modifier_group", dump_only=True)
    id = fields.Str(required=True, attribute="uuid")
    created = fields.DateTime(attribute="api_created_at", dump_only=True)
    updated = fields.DateTime(attribute="api_updated_at", dump_only=True)
    name = fields.Str(required=True, attribute="name")
    min_allowed = fields.Int(required=True, attribute="min_permitted")
    max_allowed = fields.Int(attribute="max_permitted")
    description = fields.Str()
    ordinal = fields.Int()
    modifiers = fields.Nested(
        CatalogModifierSchema, exclude=("modifier_groups",), many=True, required=False
    )

    @post_load
    def create_menu_modifier_group(self, data, **kwargs):
        menu_sync_key = self.context["menu_sync_key"]
        data["uuid"] = str(data.get("uuid"))
        menu_modifier_group = MenuModifierGroup(**data)
        menu_modifier_group.menuSync = menu_sync_key
        return menu_modifier_group.put()


class CatalogItemSchema(BaseNDBSchema):
    kind = fields.Str(default="item", dump_only=True)
    id = fields.Str(required=True, attribute="uuid")
    created = fields.DateTime(attribute="api_created_at", dump_only=True)
    updated = fields.DateTime(attribute="api_updated_at", dump_only=True)
    name = fields.Str(required=True, attribute="name")
    price = fields.Float(required=True, attribute="price")
    price_currency = fields.Str(default="USD", attribute="currency")
    description = fields.Str(attribute="description", allow_none=True)
    ordinal = fields.Int()
    is_available = fields.Bool(attribute="is_available")
    tax_rate = fields.Float(attribute="tax_rate")
    modifier_groups = SkipMissingNested(
        CatalogModifierGroupSchema, attribute="modifiergroups", required=False, many=True
    )
    availability = fields.Nested(
        CatalogItemAvailabilitySchema, attribute="availability", many=True, dump_only=True
    )
    photo_url = fields.Str(attribute="image_url", allow_none=True, required=False)

    @pre_dump
    def pre_dump(self, data):
        formatted_availabilities = []
        for availability in self.context.get("availability", []):
            for time_period in availability["time_periods"]:
                formatted_availabilities.append({
                    "day_of_week": MAP_DAY_OF_WEEK[availability["day_of_week"]],
                    "start_time": "{}:00.000".format(time_period["start_time"]),
                    "end_time": "{}:00.000".format(time_period["end_time"]),
                })
        data.availability = formatted_availabilities

    @post_load
    def create_menu_item(self, data, **kwargs):
        modifier_groups = data.pop("modifiergroups", [])
        data["uuid"] = str(data.get("uuid"))
        menu_sync_key = self.context["menu_sync_key"]
        menu_item = MenuItem(**data)
        menu_item.modifier_groups = modifier_groups
        menu_item.menuSync = menu_sync_key
        return menu_item


class CatalogCategorySchema(BaseNDBSchema):
    kind = fields.Str(default="category", dump_only=True)
    id = fields.Str(required=True, attribute="uuid")
    created = fields.DateTime(attribute="api_created_at", dump_only=True)
    updated = fields.DateTime(attribute="api_updated_at", dump_only=True)
    name = fields.Str(required=True, attribute="name")
    ordinal = fields.Int()
    items = fields.Nested(
        CatalogItemSchema, attribute="menuitems", many=True, required=True
    )

    @post_load
    def create_menu_category(self, data, **kwargs):
        data["uuid"] = str(data.get("uuid"))
        menu_items = data.pop("menuitems")
        menu_sync_key = self.context["menu_sync_key"]
        menu_category = MenuCategory(**data)
        menu_category.menu_items = menu_items
        menu_category.menuSync = menu_sync_key
        return menu_category


class CatalogSchema(BaseNDBSchema):
    external_id = fields.Str(required=True, attribute="uuid")
    kind = fields.Str(default="catalog", dump_only=True)
    name = fields.Str(required=True)
    created = fields.DateTime(attribute="api_created_at", dump_only=True)
    updated = fields.DateTime(attribute="api_updated_at", dump_only=True)
    categories = fields.Nested(CatalogCategorySchema, many=True, required=True)
    availability = fields.Nested(DumpCatalogItemAvailabilitySchema, many=True)

    @pre_dump
    def pre_dump(self, data):
        self.context["availability"] = data.availability

    @post_load
    def create_menu_section(self, data, **kwargs):
        menu_sync_key = self.context["menu_sync_key"]
        categories = data.pop("categories")

        data["uuid"] = str(data.get("uuid"))

        menu_section = MenuSection(**data)
        menu_section.menuSync = menu_sync_key
        menu_section_key = menu_section.put()
        self.context["menu_section_key"] = menu_section_key

        category_keys = []
        for category in categories:
            category.section = menu_section_key
            category_key = category.put()
            category_keys.append(category_key)
            for menu_item in category.menu_items:
                menu_item.categories.append(category_key)
                menu_item_key = menu_item.put()
                for modifier_group in menu_item.modifier_groups:
                    modifier_group = modifier_group.get()
                    modifier_group.items.append(menu_item_key)
                    modifier_group.put()

        menu_section.categories = category_keys
        menu_section.put()
        return menu_section
