import logging

from marshmallow import Schema, fields, post_load

from application.apis.deliveryservice.service.common.fetch import (
    get_delivery_service_for_service_location_id,
)
from application.apis.menu.model.MenuItem import MenuItem
from application.apis.menu.model.MenuItemModifier import MenuItemModifier
from application.apis.order.model.Order import Order, OrderStatus, OrderType
from application.apis.order.model.OrderItem import OrderItem
from application.apis.order.model.OrderItemModifier import OrderItemModifier
from application.shared.schemas import BaseSchema


class PlaceDetailsSchema(Schema):
    place_id = fields.Str(required=True)
    external_place_id = fields.Str()
    timezone = fields.Str()


class PickupDetailsSchema(Schema):
    estimated_ready_time = fields.Str(allow_none=True)
    display_name = fields.Str(required=True)
    fulfillment_type = fields.Str()
    order_number = fields.Int()


class OrderItemModifierSchema(Schema):
    id = fields.Str()
    external_id = fields.Str()
    name = fields.Str()
    price = fields.Float(required=True)

    @post_load
    def create_ordem_item_modifier(self, data, **kwargs):
        menu_item_modifier = (
            MenuItemModifier.query()
            .filter(MenuItemModifier.uuid == data["external_id"])
            .get()
        )
        order_item_modifier = OrderItemModifier(
            menu_item_modifier=menu_item_modifier.key, price=data["price"]
        )
        return order_item_modifier


class OrderItemModifierListSchema(Schema):
    name = fields.Str()
    modifiers = fields.Nested(OrderItemModifierSchema, many=True)

    @post_load
    def create_order_item_modifiers_list(self, data, **kwargs):
        return data.get("modifiers")


class OrderItemSchema(Schema):
    id = fields.Str()
    base_price = fields.Float(required=True)
    name = fields.Str()
    external_id = fields.Str()
    modifier_lists = fields.Nested(OrderItemModifierListSchema, many=True)
    category_name = fields.Str()
    quantity = fields.Int(required=True)

    @post_load
    def create_order_item(self, data, **kwargs):
        menu_item = MenuItem.query().filter(MenuItem.uuid == data["external_id"]).get()
        modifiers = []
        for modifier_list in data.get("modifier_lists"):
            for modifier in modifier_list:
                modifiers.append(modifier)

        order_item = OrderItem(
            menu_item=menu_item.key,
            unit_price=data["base_price"],
            quantity=data["quantity"],
            price=data["base_price"],
        )
        return {"obj": order_item, "selected_modifier": modifiers}


class OrderDataSchema(Schema):
    pickup_details = fields.Nested(PickupDetailsSchema, required=True)
    place_details = fields.Nested(PlaceDetailsSchema, required=True)
    order_id = fields.Str()
    external_order_id = fields.Str()
    subtotal = fields.Float(required=True)
    kind = fields.Str()
    delivery_id = fields.Str()
    tax = fields.Float(required=True)
    status = fields.Str()
    items = fields.Nested(OrderItemSchema, many=True)

    @post_load
    def create_order_items(self, data, **kwargs):
        return {
            "pickup_details": data["pickup_details"],
            "place_details": data["place_details"],
            "subtotal": data["subtotal"],
            "tax": data["tax"],
            "items": data["items"],
        }


class OrderSchema(BaseSchema):
    kind = fields.Str()
    id = fields.Str()
    created = fields.DateTime()
    developer_id = fields.Str()
    order_id = fields.Str()
    account_id = fields.Str()
    customer_id = fields.Str()
    status = fields.Str()

    data = fields.Nested(OrderDataSchema, required=True)

    @post_load
    def create_order(self, data, **kwargs):
        order_id = data["order_id"].encode("utf-8").strip()

        order = Order.query().filter(Order.delivery_service_uuid == order_id).get()
        if order:
            if not self.overwrite:
                return order
        else:
            order = Order()

        raw_data = self.context["raw_data"]
        store_id = data["data"]["place_details"]["place_id"]
        logging.info("postmates create_order store_id: {}".format(store_id))
        type_delivery = data["data"]["pickup_details"].get("fulfillment_type")
        delivery_service = get_delivery_service_for_service_location_id(store_id)

        logging.info("delivery service: {}".format(delivery_service))

        delivery_service_key = delivery_service.key
        customer_name = data["data"]["pickup_details"]["display_name"]

        restaurant = delivery_service.restaurant

        logging.info("restaurant: {}".format(restaurant))

        type_delivery = (
            OrderType.PICKUP if type_delivery == "pickup" else OrderType.DELIVERY
        )

        account = restaurant.get().account
        order.account = account

        logging.info("account: {}".format(account))

        order.restaurant = restaurant
        order.status = OrderStatus.RECEIVED
        order.type = type_delivery
        order.delivery_service = delivery_service_key
        order.delivery_service_uuid = data["order_id"].encode("utf-8").strip()
        order.customer_name = customer_name
        order.delivery_service_raw_data = raw_data
        order.charge_tax = data["data"]["tax"]
        order.charge_subtotal = data["data"]["subtotal"]
        order.charge_total = data["data"]["tax"] + data["data"]["subtotal"]

        order_key = order.put()

        logging.info("order key: {}".format(order_key))

        order_items_key = []

        for loaded_order_item in data["data"]["items"]:
            selected_modifier = loaded_order_item["selected_modifier"]
            order_item = loaded_order_item["obj"]

            order_item.order = order_key
            order_item_key = order_item.put()
            modifiers_keys = []
            for modifier in selected_modifier:
                modifier.order = order_key
                modifier.order_item = order_item_key
                modifiers_keys.append(modifier.put())

            order_item.selected_modifier = modifiers_keys
            order_items_key.append(order_item.put())

        order.order_items = order_items_key

        logging.info("order_items: {}".format(order_items_key))

        order.put()
        return order
