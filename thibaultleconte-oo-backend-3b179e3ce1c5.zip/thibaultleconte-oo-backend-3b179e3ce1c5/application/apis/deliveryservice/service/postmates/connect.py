from ...model.DeliveryService import DeliveryService, DeliveryServiceType
from ..common.fetch import check_delivery_service_already_connected
from application.apis.ooexceptions import ConflictResourceAlreadyExistsError
from ..common.crud import create_delivery_service


def connect(account_key, restaurant_key):
    _delivery_service_type = DeliveryServiceType.POSTMATES
    _restaurant = restaurant_key.get()
    for _ds_key in _restaurant.delivery_services:
        ds = _ds_key.get()
        if ds.type == _delivery_service_type:
            return ds
    _ds = create_delivery_service(restaurant_key=restaurant_key,
                                  delivery_service_type=_delivery_service_type)
    return _ds
