# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/25/2019
#

def disconnect(deliveryservice_key):
    _ds = deliveryservice_key.get()
    _restaurant = _ds.restaurant.get()
    if _ds.key in _restaurant.delivery_services:
        _restaurant.delivery_services.remove(_ds.key)
        _restaurant.put()
    _ds.delete()
    return True
