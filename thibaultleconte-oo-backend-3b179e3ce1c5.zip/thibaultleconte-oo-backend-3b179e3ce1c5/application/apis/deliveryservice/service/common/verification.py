# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/23/2019
#

from datetime import datetime
from random import randint
from ...model.IncomingOrderEmailVerification import IncomingOrderEmailVerification
from ...model.DeliveryService import DeliveryService
from application.core.email.service import send_admin_email
from application.apis.deliveryservice.model.DeliveryService import DeliveryService, DeliveryServiceType


def start_settings_verification(delivery_service_key):
    _ds = delivery_service_key.get()
    if _ds.type == DeliveryServiceType.UBEREATS:
        return None
    elif _ds.type == DeliveryServiceType.GRUBHUB:
        from ..grubhub.store import get_incoming_order_email
        _recipient_email = get_incoming_order_email(delivery_service_key)
        _ds = __start_verification_process(delivery_service_key, _recipient_email)
        return _ds
    elif _ds.type == DeliveryServiceType.DOORDASH:
        from ..doordash.store import get_incoming_order_email
        _recipient_email = get_incoming_order_email(delivery_service_key)
        _ds = __start_verification_process(delivery_service_key, _recipient_email)
        return _ds
    return None

def __start_verification_process(deliveryservice_key, recipient_email):
    _ioev = IncomingOrderEmailVerification()
    _ioev.deliveryservice = deliveryservice_key
    _ioev.recipientEmail = recipient_email
    _ioev.verificationCode = str(randint(000000, 999999))
    _ioev.put()
    __send_verification_email(_ioev.recipientEmail, deliveryservice_key, _ioev.verificationCode)
    _ds = deliveryservice_key.get()
    _ds.incomingOrderEmailVerification = _ioev.key
    _ds.put()
    return _ds

def verify_code(recipient_email, deliveryservice_id, code_to_verify):
    _ds_key = DeliveryService.get_key(deliveryservice_id)
    _query = IncomingOrderEmailVerification.query()
    _query = _query.filter(IncomingOrderEmailVerification.deliveryservice == _ds_key)
    _query = _query.filter(IncomingOrderEmailVerification.recipientEmail == recipient_email)
    _query = _query.filter(IncomingOrderEmailVerification.success == False)
    _query = _query.order(-IncomingOrderEmailVerification.api_created_at)
    _ioev = _query.get()
    if not _ioev: return None
    if str(_ioev.verificationCode) == str(code_to_verify):
        _ioev.success = True
        _ioev.successCreatedAt = datetime.utcnow()
        _ioev.put()
        return True
    return False

def __send_verification_email(recipient_email, deliveryservice_key, verification_code):
    _subject = 'OrderOut Settings Verification'
    _body = 'Delivery Service:\n'
    _body += '%s\n' % (str(deliveryservice_key.id()))
    _body += 'Verification code:\n'
    _body += '%s\n' % (str(verification_code))
    return send_admin_email([recipient_email], _subject, _body)
