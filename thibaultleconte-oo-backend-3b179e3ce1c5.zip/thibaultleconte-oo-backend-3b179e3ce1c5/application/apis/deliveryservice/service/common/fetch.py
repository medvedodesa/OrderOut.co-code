# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/25/2019
#

from application.apis.deliveryservice.model.DeliveryService import DeliveryService, DeliveryServiceType


def check_delivery_service_already_connected(restaurant_key, delivery_service_type):
    _restaurant = restaurant_key.get()
    for _ds_key in _restaurant.delivery_services:
        _ds = _ds_key.get()
        if _ds:
            if _ds.type == delivery_service_type and _ds.api_status:
                return True
    return False

def get_delivery_service_for_account(account_key, keys_only=True):
    _query = DeliveryService.query()
    _query = _query.filter(DeliveryService.account == account_key)
    _query = _query.order(DeliveryService.api_created_at)
    _results = _query.fetch(keys_only=keys_only)
    return _results

def get_delivery_services_for_restaurant(restaurant_key, keys_only=True):
    _query = DeliveryService.query()
    _query = _query.filter(DeliveryService.restaurant == restaurant_key)
    _query = _query.order(DeliveryService.api_created_at)
    _results = _query.fetch(keys_only=keys_only)
    return _results

def get_delivery_service_keys_for_restaurant(restaurant_key, delivery_service_type, include_deleted=False):
    _query = DeliveryService.query(all_status=True)
    _query = _query.filter(DeliveryService.restaurant == restaurant_key)
    _query = _query.filter(DeliveryService.type == delivery_service_type)
    _query = _query.order(-DeliveryService.api_created_at)
    _results = _query.fetch(keys_only=True)
    return _results

def get_delivery_service_for_service_location_id(service_location_id):
    _query = DeliveryService.query()
    _query = _query.filter(DeliveryService.serviceLocationId == service_location_id)
    _results = _query.get()
    return _results

def generate_list_delivery_services_available():
    _ds_to_ignore = [DeliveryServiceType.UNKNOWN,
                     DeliveryServiceType.DELIVERYCOM,
                     DeliveryServiceType.SLICE,
                     DeliveryServiceType.CAVIAR]
    _elements = []
    for e in DeliveryServiceType:
        if e not in _ds_to_ignore:
            _elements.append({'name': e.name, 'id': e.number})
    return _elements
