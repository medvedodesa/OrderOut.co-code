# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/13/2020
#

from ...model.DeliveryService import DeliveryService
from ..common.fetch import check_delivery_service_already_connected
from application.apis.ooexceptions import ResourceDoesNotExist, ConflictResourceAlreadyExistsError
import json

def get_by_id_and_populate(id, json_dict):
    _obj = DeliveryService.get_by_id(id)
    if not _obj: raise ResourceDoesNotExist
    _obj.populate(**json_dict)
    _obj.put()
    return _obj

def create_from_public_menu_url(restaurant_key, delivery_service_type, public_menu_url, username='', password='', service_pincode=''):
    if check_delivery_service_already_connected(restaurant_key=restaurant_key, delivery_service_type=delivery_service_type):
        raise ConflictResourceAlreadyExistsError
    _ds = create_delivery_service(restaurant_key=restaurant_key,
                                  delivery_service_type=delivery_service_type,
                                  service_menu_url=public_menu_url,
                                  service_username=username,
                                  service_password=password,
                                  service_pincode=service_pincode)
    return _ds

def create_delivery_service(restaurant_key,
                            delivery_service_type,
                            service_menu_url=None,
                            service_account_id=None,
                            service_username=None,
                            service_password=None,
                            service_raw_data=None,
                            service_location_uuid=None,
                            service_pincode=None,
                            refresh_token=None,
                            ):
    _restaurant = restaurant_key.get()
    # Delivery Service Info
    _ds = DeliveryService()
    _ds.type = delivery_service_type
    _ds.account = _restaurant.account
    _ds.restaurant = _restaurant.key
    _ds.service_menu_url = service_menu_url
    _ds.service_account_id = service_account_id
    _ds.service_username = service_username
    _ds.service_secret = service_password
    _ds.serviceData = json.dumps(service_raw_data) if service_raw_data else None
    _ds.serviceLocationId = service_location_uuid
    _ds.service_pincode = service_pincode
    _ds.refresh_token = refresh_token
    _ds.put()
    # Restaurant Info
    _restaurant.delivery_services.append(_ds.key)
    _restaurant.put()
    return _ds
