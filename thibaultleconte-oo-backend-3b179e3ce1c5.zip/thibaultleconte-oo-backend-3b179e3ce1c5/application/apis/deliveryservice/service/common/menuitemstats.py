# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/25/2019
#
import logging

from application.apis.ooexceptions import NotFound


def update_menu_sync_menu_stats(menu_sync_key, total_items, mapped_items, unmapped_items, total_modifiers, mapped_modifiers, unmapped_modifiers):
    logging.info("updating menu sync menu stats")
    _menu_sync = menu_sync_key.get()
    if not _menu_sync:
        logging.info("menu sync not found")
        raise NotFound
    _menu_sync.map_total_menu_items = total_items
    _menu_sync.map_mapped_menu_items = mapped_items
    _menu_sync.map_unmapped_menu_items = unmapped_items
    _menu_sync.map_total_menu_modifiers = total_modifiers
    _menu_sync.map_mapped_menu_modifiers = mapped_modifiers
    _menu_sync.map_unmapped_menu_modifiers = unmapped_modifiers
    _menu_sync.put()
    logging.info("menu sync updated.")
    return True
