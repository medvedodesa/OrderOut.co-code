# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 10/22/2019
#

from flask import current_app
from application.apis.ooexceptions import NotFound
from application.core.settings.app import get_config_for_key
from application.core.event.service import create_event, CoreEventCategory
from .fetch import get_delivery_service_for_service_location_id
from application.apis.restaurant.model import Restaurant
import logging

def get_value_name_for_key_in_webhook_json(key, json_dict):
    if key in json_dict:
        _email_subject = json_dict.get(key)
        if _email_subject:
            return _email_subject.lower()
    return None

def get_store_id_from_incoming_email(store_email, source_entity_key):
    from application import app
    with app.app_context():
        _store_id = ''
        _store_id = store_email.replace(get_config_for_key('PARSEUR_INCOMING_EMAIL_PREFIX_GRUBHUB_OLD'), '')
        _store_id = _store_id.replace(get_config_for_key('PARSEUR_INCOMING_EMAIL_PREFIX_GRUBHUB'), '')
        _store_id = _store_id.replace(get_config_for_key('PARSEUR_INCOMING_EMAIL_PREFIX_CHOWNOW'), '')
        _store_id = _store_id.replace(get_config_for_key('PARSEUR_INCOMING_EMAIL_PREFIX_DOORDASH'), '')
        _store_id = _store_id.replace(get_config_for_key('PARSEUR_INCOMING_EMAIL_DOMAIN'), '')
    if len(_store_id) == 0:
        _message = "Incorrect store_email received from Parseur \"%s\"" % (str(store_email))
        logging.error(_message)
        create_event(category=CoreEventCategory.PARSEUR,
                     name='INCORRECT_EMAIL',
                     success=False,
                     message=_message,
                     entity_key=source_entity_key)
        # raise NotFound
        return None
    return _store_id

def get_and_validate_store_id_from_incoming_email(store_email, source_entity_key):
    _store_id = get_store_id_from_incoming_email(store_email, source_entity_key)
    if not _store_id: return None

    _delivery_service = get_delivery_service_for_service_location_id(_store_id)
    if not _delivery_service: return None
    if not _delivery_service.restaurant: return None
    if not Restaurant.get_by_id(_delivery_service.restaurant.id()): return None

    return _store_id
