# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/25/2019
#

from application.apis.deliveryservice.model.DeliveryService import DeliveryServiceType


def get_pos_status(delivery_service_key):
    _ds = delivery_service_key.get()
    if _ds.type == DeliveryServiceType.UBEREATS:
        from ..ubereats.pointofsale import get_pos_data
        _url, _status_code, _result_json = get_pos_data(_ds.serviceLocationId)
        return _result_json
    return {'online_status': 'UNKNOWN'}

def enable_pos_functionality(delivery_service_key):
    _ds = delivery_service_key.get()
    if _ds.type == DeliveryServiceType.UBEREATS:
        from ..ubereats.pointofsale import update_pos_data, update_pos_data_v2

        if _ds.refresh_token:
            update_pos_data_function = update_pos_data_v2
        else:
            update_pos_data_function = update_pos_data

        _url, _status_code, _result_json = update_pos_data_function(
            delivery_service=_ds, pos_integration_enabled=True
        )
        if _status_code >= 200 and _status_code <= 299:
            return True
    return False

def disable_pos_functionality(delivery_service_key):
    _ds = delivery_service_key.get()
    if _ds.type == DeliveryServiceType.UBEREATS:
        from ..ubereats.pointofsale import update_pos_data, update_pos_data_v2

        if _ds.refresh_token:
            update_pos_data_function = update_pos_data_v2
        else:
            return True
            # update_pos_data_function = update_pos_data

        _url, _status_code, _result_json = update_pos_data_function(
            delivery_service=_ds, pos_integration_enabled=False
        )
        if _status_code >= 200 and _status_code <= 299:
            return True
    return False
