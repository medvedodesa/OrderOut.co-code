from application.apis.user.service.user import get_current_user
from application.core.event.model import CoreEventCategory
from application.core.event.service import create_event


def save_connect_event(ds_type, success, account, restaurant, ds, pos, payload=None):
    name = str(ds_type)
    message = "Delivery Service CONNECT"
    save_event(CoreEventCategory.DS_CONNECT, name, message, success, payload, account, restaurant, ds, pos)

def save_disconnect_event(ds_type, success, account, restaurant, ds, pos, payload=None):
    name = str(ds_type)
    message = "Delivery Service DISCONNECT"
    save_event(CoreEventCategory.DS_DISCONNECT, name, message, success, payload, account, restaurant, ds, pos)

def save_status_event(enabled, ds_type, success, account, restaurant, ds, pos, payload=None):
    category = CoreEventCategory.DS_ENABLE if enabled else CoreEventCategory.DS_DISABLE
    name = str(ds_type)
    message = "Delivery Service %s" % str(category)[3:]
    save_event(category, name, message, success, payload, account, restaurant, ds, pos)

def save_event(category, name, message, success, payload, account, restaurant, ds, pos):
    current_user = get_current_user()
    create_event(
        category=category,
        name=name,
        success=success,
        message=message,
        payload=payload,
        user_key=current_user.key if current_user else None,
        parent_entities_keys=[key for key in [account, restaurant, ds, pos] if key],
    )
