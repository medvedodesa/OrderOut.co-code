# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/11/2019
#

def get_menu_item_key_by_name(all_menu_items, raw_name):
    for _mi in all_menu_items:
        if _mi.name == raw_name:
            return _mi.key
    return None

def get_menu_item_modifier_key_by_name(menu_item_modifiers, raw_name):
    for _modifier in menu_item_modifiers:
        if _modifier.name == raw_name:
            return _modifier.key
    return None

def get_menu_item_modifier_key_by_group_and_name(menu_item_modifiers, raw_name):
    import logging
    logging.info(' --- Searching for -%s-' % (raw_name))
    for _modifier in menu_item_modifiers:
        for _modifier_group_key in _modifier.groups:
            _modifier_group = _modifier_group_key.get()
            _group_name_and_name = '%s %s' % (str(_modifier_group.name).lower(), str(_modifier.name).lower())
            if _group_name_and_name == raw_name:
                logging.info('Found -%s-' % (_group_name_and_name))
                return _modifier.key
    return None
