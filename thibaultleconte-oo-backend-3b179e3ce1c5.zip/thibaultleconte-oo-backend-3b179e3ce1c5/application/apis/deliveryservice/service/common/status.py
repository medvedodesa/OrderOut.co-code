# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 10/22/2019
#

import logging

def compute_status(delivery_service_key):
    from application.apis.deliveryservice.model.DeliveryService import DeliveryServiceStatus

    _ds = delivery_service_key.get()
    if not _ds.menuSync:
        return DeliveryServiceStatus.CONNECTING
    _menusync = _ds.menuSync.get()
    if _menusync.map_total_menu_items == 0: # We found 0 menu items -> Problem
        return DeliveryServiceStatus.EMPTY_MENU
    elif _menusync.map_unmapped_menu_items > 0: # We still have some unmapped items, we cannot go live.
        return DeliveryServiceStatus.MAPPING
    elif _menusync.map_total_menu_items == _menusync.map_mapped_menu_items and _ds.integration_enabled == False:
        return DeliveryServiceStatus.READY
    elif _ds.integration_enabled:
        return DeliveryServiceStatus.LIVE
    return DeliveryServiceStatus.UNKNOWN
