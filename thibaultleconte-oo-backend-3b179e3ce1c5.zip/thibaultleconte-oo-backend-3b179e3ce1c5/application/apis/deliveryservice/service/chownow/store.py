#
# chirag@orderout.co
#
# 03/11/2020
#

from flask import current_app
from application.apis.ooexceptions import NotFound
from application.core.settings.app import get_config_for_key

def get_incoming_order_email(deliveryservice_key):
    _ds = deliveryservice_key.get()
    if not _ds.serviceLocationId: return None
    _email = get_config_for_key('PARSEUR_INCOMING_EMAIL_PREFIX_CHOWNOW')
    _email += str(_ds.serviceLocationId)
    _email += get_config_for_key('PARSEUR_INCOMING_EMAIL_DOMAIN')
    return _email.lower()
