# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 09/11/2019
#

from application.apis.menu.service.menusync.creator import create_menu_sync
from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from application.apis.menu.service.menusync.fetch import fetch_menu_task_started
from application.apis.menu.model.MenuSync import MenuSync
from flask import current_app
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.error import report_error
from application.core.settings.app import get_config_for_key
import json


def startTaskToFetchMenu(deliveryservice_key):
    _ds = deliveryservice_key.get()
    _ms = create_menu_sync(restaurant_key=_ds.restaurant, service_key=_ds.key)
    _ds.menuSync = _ms.key
    _ds.put()
    _task = addTask(category=CoreTaskCategory.CHOWNOW_MENU_FETCH, entity=_ms)
    _ms = fetch_menu_task_started(menuSync_key=_ms.key, task_key=_task.key)
    return _ds

def processTaskToFetchMenuFromChownow(menu_sync_id):
    _task_result_json = {}
    _ms = MenuSync.get_by_id(menu_sync_id)
    if not _ms: _task_result_json['processTaskToFetchMenuFromChownow'] = {'message': 'MenuSync with id %s not found' % (str(menu_sync_id))}
    if not _ms.service: _task_result_json['processTaskToFetchMenuFromChownow'] = {'message': 'MenuSync with id %s has no ds' % (str(menu_sync_id))}
    _url, _status_code, _result_json = __start_fetch_menu_request(_ms.service)
    _task_result_json['__start_fetch_menu_request'] = {'url': _url, 'status_code': _status_code, 'result_json': _result_json}
    return _task_result_json

def __start_fetch_menu_request(delivery_service_key):
    _ds = delivery_service_key.get()
    _ms = _ds.menuSync.get()

    _url = __get_url_apify_chownow_fetch_menu()
    _apify_headers = {'Content-Type': 'application/json'}
    _parameters = {'url': _get_chownow_restaurant_url_from_credentials(_ds.key)}

    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.APIFY, method="POST", headers=_apify_headers, data=_parameters)

    _apify_run_id = _result_json.get('data').get('id')
    _ms.fetch_external_id = _apify_run_id
    _ms.put()

    if _status_code < 200 or _status_code > 299:
        report_error(code=_status_code, subject="Apify-FetchChownowMenu-Error", message="Delivery service %s returned %s" % (str(_ds.key.id()), str(_status_code)))
        return _url, _status_code, None
    return _url, _status_code, _result_json

################
# WEBHOOKS APIFY
################

def __get_url_apify_chownow_fetch_menu():
    _apify_token = get_config_for_key('APIFY_TOKEN')
    url = "https://api.apify.com/v2/acts/order-out~chownow-menu/runs?token=%s" % (str(_apify_token))
    return url

###########################
# CREDENTIALS AND ID HELPER
###########################

def _get_chownow_restaurant_url_from_credentials(deliveryservice_key):
    _restaurant_url = None
    _ds = deliveryservice_key.get()
    if _ds.service_menu_url:
        _restaurant_url = _ds.service_menu_url
    if _ds.serviceData:
        _credentials = json.loads(_ds.serviceData)
        _restaurant_url = _credentials.get('restaurant_url', None)
    return _restaurant_url
