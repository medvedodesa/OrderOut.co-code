# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# chirag@orderout.co
#
# 02/17/2019
#

from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from application.apis.menu.service.menusync.fetch import fetch_menu_task_started, fetch_menu_task_finished
from application.apis.menu.model.MenuSync import MenuSync
from application.core.urlFetch.service import fetch_with_json_data
from flask import current_app
from application.core.error import report_error
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.apis.menu.service.menusync.process import process_menu_task_started
from application.apis.menu.service.creator import generate_item_dict, generate_modifier_group_dict, generate_modifier_dict, startTaskToCreateOrUpdateMenuItemsAndModifiers
from application.core.parser.string import sanitize_str
from application.core.settings.app import get_config_for_key
from application.apis.menu.service.crud.section import create_update_menu_section
from application.apis.menu.service.crud.category import create_update_menu_category
import re

DEFAULT_CHOWNOW_MENU_SECTION_NAME = 'Menu'
INPUT_URL_TEXT = 'INPUT'
OUTPUT_URL_TEXT = 'OUTPUT'

def startTaskToProcessMenu(menusync_key, _apify_kvs_output_id):
    _ms = menusync_key.get()
    _ms.process_external_id = str(_apify_kvs_output_id)
    _ms.put()
    _task = addTask(category=CoreTaskCategory.CHOWNOW_MENU_PROCESS, entity=_ms)
    _ms = fetch_menu_task_started(menuSync_key=_ms.key, task_key=_task.key)
    return _ms


def processTaskToProcessMenuFromChownow(menu_sync_id):
    _task_result_json = {}
    _ms = MenuSync.get_by_id(menu_sync_id)
    if not _ms: _task_result_json['processTaskToProcessMenuFromChownow'] = {'message': 'MenuSync with id %s not found' % (str(menu_sync_id))}
    if not _ms.service: _task_result_json['processTaskToFetchMenuFromChownow'] = {'message': 'MenuSync with id %s has no ds' % (str(menu_sync_id))}
    _url, _status_code, _result_json = __start_process_menu_request(menuSync_key=_ms.key, url_type=OUTPUT_URL_TEXT)
    _task_result_json['__start_process_menu_request'] = {'url': _url, 'status_code': _status_code, 'result_json': _result_json}

    if _status_code >= 200 and _status_code <= 299:
        _restaurant_id = sanitize_str(_result_json.get('id')) # Require update: get restaturant id

        _input_url, _input_status_code, _input_result_json = __start_process_menu_request(menuSync_key=_ms.key, url_type=INPUT_URL_TEXT)
        if _input_status_code >= 200 and _input_status_code <= 299:
            _store_id_array = re.findall('\d+', _input_result_json.get('url'))
            _store_id = _store_id_array[0] if len(_store_id_array) > 0 else None
            if _store_id:
                _restaurant_id = _store_id # Temperory Fix, We need to update after fix by the Chownow team
        _ds = _ms.service.get()
        _ds.serviceLocationId = str(_restaurant_id)
        _ds.put()

        fetch_menu_task_finished(menuSync_key=_ms.key, success=True)
        _menu_items = __process_menu(_ms, _result_json)
        process_menu_task_started(menuSync_key=_ms.key, tasks_keys=_menu_items)
        _task_result_json['__process_menu'] = {'message': "Delivery Service has fetched %s menu items" % (str(len(_menu_items)))}
    else:
        fetch_menu_task_finished(menuSync_key=_ms.key, success=False)

    return _task_result_json

def __start_process_menu_request(menuSync_key, url_type):
    _ms = menuSync_key.get()

    _url = __get_url_apify_chownow_process_menu(_ms.process_external_id, url_type)
    _apify_headers = {'Content-Type': 'application/json'}

    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.APIFY, method="GET", headers=_apify_headers)

    if _status_code < 200 or _status_code > 299:
        report_error(
            code=_status_code,
            subject="Apify-ProcessChowNowMenu-Error",
            message="Delivery service %s returned %s (Menu sync %s)" % (str(_ms.service.id() if _ms.service else "-"), str(_status_code), _ms.key.id())
        )
        return _url, _status_code, None
    return _url, _status_code, _result_json


##############
# Process Menu
##############

def __process_menu(menu_sync, raw_data):
    _items_tasks = []
    _section = create_update_menu_section(menu_sync_key=menu_sync.key, name=DEFAULT_CHOWNOW_MENU_SECTION_NAME)
    if 'menu_categories' in raw_data:
        raw_menu_categories = raw_data['menu_categories']
        for raw_menu_category in raw_menu_categories:
            # CATEGORY
            _raw_menu_category_name = sanitize_str(raw_menu_category.get('name'))
            _raw_menu_category_uuid = sanitize_str(raw_menu_category.get('id'))
            _category = create_update_menu_category(menu_sync_key=menu_sync.key,
                                                    section_key=_section.key,
                                                    name=_raw_menu_category_name,
                                                    uuid=_raw_menu_category_uuid)
            if 'items' in raw_menu_category:
                raw_menu_item_list = raw_menu_category['items']
                category_id = _category.get_id()
                _items_tasks.extend(__parse_items(raw_data, menu_sync, raw_menu_item_list, category_id))
    return _items_tasks

def __parse_items(raw_data, menu_sync, raw_menu_item_list, category_id):
    _items_tasks = []
    for idx_item, raw_item in enumerate(raw_menu_item_list):
        _modifier_groups = __parse_modifier_groups(raw_data, raw_item)
        _price = raw_item.get('price') if raw_item.get('price') else 0

        # ITEM
        _mi = generate_item_dict(name=raw_item.get('name'),
                                 price=_price,
                                 modifier_groups=_modifier_groups,
                                 uuid=raw_item.get('id'),
                                 position=idx_item,
                                 category_id=category_id)
        _task = startTaskToCreateOrUpdateMenuItemsAndModifiers(menu_sync, _mi)
        if _task: _items_tasks.append(_task.key)
    return _items_tasks

def __parse_modifier_groups(raw_data, raw_item):
    modifier_groups = []
    if 'modifier_categories' in raw_item:
        for idx_group, modifier_group_id in enumerate(raw_item.get('modifier_categories')):
            _modifier_group_dict = filter(lambda modifier_group: modifier_group['id'] == modifier_group_id, raw_data.get('modifier_categories'))[0]
            if _modifier_group_dict:
                _group_name = _modifier_group_dict.get('name')
                _group_uuid = _modifier_group_dict.get('id')
                _min_permitted = _modifier_group_dict.get('min_qty', 0)
                _max_permitted = _modifier_group_dict.get('max_qty', 0)
                _modifiers = __parse_modifiers(raw_data, _modifier_group_dict)

                # MODIFIER_GROUP
                _group = generate_modifier_group_dict(name=_group_name,
                                                    modifiers=_modifiers,
                                                    uuid=_group_uuid,
                                                    min_permitted=_min_permitted,
                                                    max_permitted=_max_permitted,
                                                    position=idx_group)
                modifier_groups.append(_group)
    return modifier_groups

def __parse_modifiers(raw_data, modifier_group):
    modifiers = []
    if 'modifiers' in modifier_group:
        for idx_modifier, modifier_id in enumerate(modifier_group.get('modifiers')):
            _modifier_dict = filter(lambda modifier: modifier['id'] == modifier_id, raw_data.get('modifiers'))[0]
            if _modifier_dict:
                _price = _modifier_dict.get('price') if _modifier_dict.get('price') else 0

                # MODIFIER
                _mod = generate_modifier_dict(name=_modifier_dict.get('name'),
                                            price=_price,
                                            uuid=_modifier_dict.get('id'),
                                            position=idx_modifier)
                modifiers.append(_mod)
    return modifiers

################
# WEBHOOKS APIFY
################

def __get_url_apify_chownow_process_menu(apify_kvs_output_id, url_type):
    _apify_token = get_config_for_key('APIFY_TOKEN')
    url = "https://api.apify.com/v2/key-value-stores/%s/records/%s?disableRedirect=1&token=%s" % (str(apify_kvs_output_id), str(url_type), str(_apify_token))
    return url
