#
# thibault@orderout.co
#
# 03/17/2020
#

from application.core.urlFetch.service import fetch_with_url_encoded_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.error import report_error
from application.core.task.service import startDeferredTask
from application.apis.order.service.confirmation import check_order_is_confirmed, set_order_as_confirmed

import logging

def confirm_order(order_key, json_dict):
    if check_order_is_confirmed(order_key): return True
    _confirmation_url = json_dict.get('confirmationLink')
    if _confirmation_url:
        startDeferredTask(__send_confirmation_request, order_key, _confirmation_url)
    else:
        _message = 'Order %s - Chownow order confirmation link error' % (str(order_key.id()))
        report_error(500, subject='Chownow Order Confirmation Error', message=_message, data_dict=json_dict)
    return True

def __send_confirmation_request(order_key, confirmation_url):
    _str_to_replace = 'https://orderemails.grubhub.com/' # We may need to change this URL as per Chownow
    _str_replacing_with = 'https://api-order-processing-gtm.grubhub.com/order/email/confirm/'  # We may need to change this URL as per Chownow
    _chownow_backend_url = confirmation_url.replace(_str_to_replace, _str_replacing_with)
    _result_json, _status_code, request_key = fetch_with_url_encoded_data(url=_chownow_backend_url, service=UrlFetchService.CHOWNOW, method="POST")
    if _status_code < 200 or _status_code > 299:
        _message = 'Order %s - Chownow order confirmation link error %s' % (str(order_key.id()), str(object=confirmation_url))
        data_dict = {'order': order_key.id(),
                     'confirmation_url': confirmation_url,
                     'status_code': _status_code,
                     'result_json': _result_json}
        report_error(500, subject='Chownow Order Confirmation Error', message=_message, data_dict=data_dict)
        return confirmation_url, _status_code, None
    else:
        set_order_as_confirmed(order_key)
    return confirmation_url, _status_code, _result_json
