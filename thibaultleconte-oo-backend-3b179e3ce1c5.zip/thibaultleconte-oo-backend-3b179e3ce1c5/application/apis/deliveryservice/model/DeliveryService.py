# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/27/2019
#

from google.appengine.ext import ndb
from google.appengine.ext.ndb import msgprop
from protorpc import messages
from application.core.model.Base import Base
from application.core.security.cryptography import AESCipher
from flask_restplus import fields, marshal
from application.core.marshal import SchemaFieldKeyFormatter
from application.apis.menu.model.MenuSync import MenySyncSchemaFieldFromKeyFormatter
from application.core.settings.app import get_config_for_key
from .IncomingOrderEmailVerification import IncomingOrderEmailVerificationSchemaFieldFromKeyFormatter
from ..service.common.status import compute_status


class DeliveryServiceType(messages.Enum):
    UNKNOWN = 0
    UBEREATS = 1
    GRUBHUB = 2
    DOORDASH = 3
    POSTMATES = 4
    DELIVERYCOM = 5
    SLICE = 6
    CHOWNOW = 7
    CAVIAR = 8
    WIX = 9

class DeliveryServiceStatus(messages.Enum):
    UNKNOWN = 0
    CONNECTING = 10
    EMPTY_MENU = 20
    MAPPING = 30
    READY = 40
    LIVE = 50

class DeliveryService(Base):
    type = msgprop.EnumProperty(DeliveryServiceType, required=True)
    account = ndb.KeyProperty(required=True)
    restaurant = ndb.KeyProperty(required=True)
    serviceLocationId = ndb.StringProperty(default='')
    serviceData = ndb.JsonProperty(default=None)
    point_of_sale_tender_id = ndb.StringProperty(indexed=False, default=None)
    point_of_sale_order_type_id = ndb.StringProperty(indexed=False, default=None)
    menuSync = ndb.KeyProperty()
    incomingOrderEmailVerification = ndb.KeyProperty()
    integration_enabled = ndb.BooleanProperty(default=False)
    service_menu_url = ndb.StringProperty(default='')
    service_account_id = ndb.StringProperty(default='')
    service_username = ndb.StringProperty(default='')
    service_password = ndb.StringProperty(default='')
    service_pincode = ndb.StringProperty(default='')
    service_api_active = ndb.BooleanProperty(default=False)
    refresh_token = ndb.StringProperty(required=False)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls, with_menu_sync=True, with_email_verification=True):
        schema = super(cls, cls).schema()
        schema['type'] = fields.String()
        schema['status'] = fields.String(attribute='status')
        schema['serviceLocationId'] = fields.String()
        schema['service_account_id'] = fields.String()
        schema['service_menu_url'] = fields.String()
        schema['service_username'] = fields.String()
        schema['integration_enabled'] = fields.Boolean(description="Enable Delivery Service Integration with Point Of Sale")
        if with_menu_sync:
            schema['menuSync'] = MenySyncSchemaFieldFromKeyFormatter(attribute='menuSync', description='Menu Sync Status')
        if with_email_verification:
            schema['incomingOrderEmailVerification'] = IncomingOrderEmailVerificationSchemaFieldFromKeyFormatter(attribute='incomingOrderEmailVerification',
                                                                                                                 description='Incoming Order Email Verification Status')
        return schema

    @property
    def service_secret(self):
        decrypted_password = ""
        if self.service_password:
            decrypted_password = AESCipher(key=get_config_for_key("SECRET_KEY")).decrypt(
                self.service_password
            )
        return decrypted_password

    @service_secret.setter
    def service_secret(self, value):
        password = ""
        if value:
            password = AESCipher(key=get_config_for_key("SECRET_KEY")).encrypt(value)

        self.service_password = password

    ######
    # CRUD
    ######

    @classmethod
    def create(cls, type, account_key, restaurant_key):
        _obj = cls()
        _obj.type = type
        _obj.account = account_key
        _obj.restaurant = restaurant_key
        _obj.put()
        return _obj

    @property # FOR DELIVERY SERVICE STATUS DURING ONBOARDING
    def status(self):
        return compute_status(delivery_service_key=self.key)


class DeliveryServiceSchemaFieldFromKeyFormatter(fields.Raw):
    def format(self, value):
        if value: return marshal(value.get(), DeliveryService.schema(with_menu_sync=False))
        return None

class DeliveryServiceSchemaFieldServicePassword(fields.Raw):
    def format(self, value):
        if value: return "******"
        return "-"
