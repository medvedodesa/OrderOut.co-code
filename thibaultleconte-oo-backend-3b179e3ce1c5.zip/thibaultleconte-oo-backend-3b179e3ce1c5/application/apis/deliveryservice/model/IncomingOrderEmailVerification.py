# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/23/2019
#

from google.appengine.ext import ndb
from application.core.model.Base import Base
from flask_restplus import fields, marshal


class IncomingOrderEmailVerification(Base):
    deliveryservice = ndb.KeyProperty(required=True)
    recipientEmail = ndb.StringProperty(required=True)
    success = ndb.BooleanProperty(default=False)
    successCreatedAt = ndb.DateTimeProperty()
    verificationCode = ndb.StringProperty(default='')

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema['recipientEmail'] = fields.String(required=True, description="Email used to get incoming orders")
        schema['success'] = fields.Boolean(description="Verification Success")
        return schema

class IncomingOrderEmailVerificationSchemaFieldFromKeyFormatter(fields.Raw):
    def format(self, value):
        if value:
            return marshal(value.get(), IncomingOrderEmailVerification.schema())
        return None
