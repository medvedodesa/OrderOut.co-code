import logging
from collections import defaultdict
from datetime import datetime, timedelta

from application.apis.order.model.Order import Order, OrderStatus


def get_order_report_by_entity(entity, from_date, to_date, count_days=None):
    orders_query = Order.query()

    if count_days:
        to_date = datetime.now()
        from_date = to_date - timedelta(days=int(count_days))

        orders_query = orders_query.filter(
            Order.api_created_at >= from_date
        )

        from_date = from_date + timedelta(days=1)
        to_date = to_date + timedelta(days=1)

    else:
        from_date = datetime.strptime(from_date, '%Y-%m-%d')
        to_date = datetime.strptime(to_date, '%Y-%m-%d')

        to_date = to_date + timedelta(days=1)

        orders_query = orders_query.filter(
            Order.api_created_at >= from_date
        )
        orders_query = orders_query.filter(
            Order.api_created_at < to_date
        )

    orders_query = orders_query.filter(getattr(Order, entity.entity_name) == entity.key)
    orders_query = orders_query.filter(Order.status == OrderStatus.CONFIRMED).order(
        Order.api_created_at
    )
    orders = orders_query.fetch(
        projection=[Order.api_created_at, Order.delivery_service, Order.charge_total]
    )

    response = {}

    summary_map = defaultdict(dict)

    day_summary_map = defaultdict(dict)

    for date in [from_date+timedelta(days=x) for x in range((to_date-from_date).days)]:
        order_date = date.strftime('%Y-%m-%d')
        day_summary_map[order_date]["summary"] = defaultdict(dict)
        day_summary_map[order_date]["orders"] = 0
        day_summary_map[order_date]["amount"] = 0
        day_summary_map[order_date]["date"] = order_date

    for order in orders:
        ds = order.delivery_service.get()
        ds_type = str(ds.type)

        if not ds:
            continue

        if "orders" not in summary_map[ds_type]:
            summary_map[ds_type]["orders"] = 0
        if "amount" not in summary_map[ds_type]:
            summary_map[ds_type]["amount"] = 0

        summary_map[ds_type]["orders"] += 1
        summary_map[ds_type]["amount"] += order.charge_total

        order_date = order.api_created_at.strftime('%Y-%m-%d')

        if "orders" not in day_summary_map[order_date]["summary"][ds_type]:
            day_summary_map[order_date]["summary"][ds_type]["orders"] = 0

        if "amount" not in day_summary_map[order_date]["summary"][ds_type]:
            day_summary_map[order_date]["summary"][ds_type]["amount"] = 0

        day_summary_map[order_date]["summary"][ds_type]["orders"] += 1
        day_summary_map[order_date]["summary"][ds_type]["amount"] += order.charge_total

        day_summary_map[order_date]["orders"] += 1
        day_summary_map[order_date]["amount"] += order.charge_total
        day_summary_map[order_date]["date"] = order_date

    response["summary"] = summary_map
    response["report"] = day_summary_map.values()

    return response


def get_order_report_by_restaurants(restaurants, from_date, to_date, count_days=None):
    response = {}
    for restaurant_key in restaurants:
        restaurant = restaurant_key.get()
        if restaurant:
            order_report = get_order_report_by_entity(restaurant, from_date, to_date, count_days)
            logging.info("restaurant_id {} order_report {}".format(restaurant.id, order_report))
            response[restaurant.id] = order_report

    return response


def get_order_report_by_account(account, from_date, to_date, count_days=None):
    return get_order_report_by_entity(account, from_date, to_date, count_days)
