from flask import request
from flask_restplus import Resource, Namespace
from werkzeug.exceptions import NotFound, BadRequest

from application.apis.account.model import Account
from application.apis.order.model.Order import Order
from application.apis.reports.order.reports import get_order_report_by_account
from application.core.marshal import pagination_schema
from application.core.authentication.service import requires_auth_token

nsApi = Namespace("order_report", description="Order Reports.")

order_marshal = nsApi.model("Order", Order.schema())
orders_pagination_marshal_response = nsApi.model(
    "OrdersPaginationResponse", pagination_schema(order_marshal)
)


@nsApi.route("/<int:account_id>/order/total")
class OrderList(Resource):
    method_decorators = [requires_auth_token]

    def get(self, account_id):
        account = Account.get_by_id(account_id)
        if not account:
            raise NotFound

        count_days = request.args.get("count_days")
        from_date = request.args.get("from_date")
        to_date = request.args.get("to_date")

        if not count_days:
            if not from_date or not to_date:
                raise BadRequest

        return get_order_report_by_account(account, from_date, to_date, count_days)
