# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

from functools import wraps
from flask import g
from flask_restplus import abort
import logging
from application.apis.ooexceptions import ResourceDoesNotExist, NotFound, Unauthorized


def authenticated_user_required(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if g.current_user: # should be if not g.current_user:
            abort(401)
        else:
            logging.info('no current_user for user authentication')
            return func(*args, **kwargs)
    return wrapper


def errorHandler(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ResourceDoesNotExist:
            abort(404, "Not found")
        except NotFound:
            abort(404, "Not found")
        except Unauthorized:
            abort(404, "Tibo UnauthorizedError")
        except Exception as e:
            import logging
            logging.error(e)
            abort(400, "Bad request")
    return wrapper
