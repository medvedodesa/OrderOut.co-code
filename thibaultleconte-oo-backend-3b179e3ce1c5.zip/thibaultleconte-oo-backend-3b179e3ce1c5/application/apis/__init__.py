# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

from flask_restplus import Api, abort
from flask import Blueprint
from application.apis.user.controller.user import nsApi as nsUser
from application.apis.customer.controller import nsApi as nsCustomer
from application.apis.account.controller import nsApi as nsAccount
from application.apis.restaurant.controller import nsApi as nsRestaurant
from application.apis.restaurant.contact.controller import nsApi as nsRestaurantContact
from application.apis.scraping.controller.error import nsApi as nsScrapingError
from application.apis.pointofsale.controller.common import nsApi as nsPointOfSale
from application.apis.pointofsale.controller.clover import nsApi as nsPointOfSaleClover
from application.apis.pointofsale.controller.cloverlead import nsApi as nsPointOfSaleCloverLead
from application.apis.pointofsale.controller.newtek import nsApi as nsPointOfSaleNewTek
from application.apis.pointofsale.controller.tabit import nsApi as nsPointOfSaleTabit
from application.apis.pointofsale.controller.aldelo import nsApi as nsPointOfSaleAldelo
from application.apis.deliveryservice.controller.common import nsApi as nsDeliveryService
from application.apis.deliveryservice.controller.simulate import nsApi as nsDeliveryServiceSimulator
from application.apis.deliveryservice.controller.ubereats import nsApi as nsDeliveryServiceUberEats
from application.apis.deliveryservice.controller.grubhub import nsApi as nsDeliveryServiceGrubhub
from application.apis.deliveryservice.controller.doordash import nsApi as nsDeliveryServiceDoordash
from application.apis.deliveryservice.controller.doordash_api_switch import nsApi as nsDeliveryServiceDoordashApiSwitch
from application.apis.deliveryservice.controller.wix import nsApi as nsDeliveryServiceWix
from application.apis.deliveryservice.controller.chownow import nsApi as nsDeliveryServiceChownow
from application.apis.deliveryservice.controller.postmates import nsApi as nsDeliveryServicePostmates
from application.apis.printer.controller.common import nsApi as nsPrinter
from application.apis.printer.controller.printjob import nsApi as nsPrintJob
from application.apis.printer.controller.starcloudprint import nsApi as nsPrinterStarCloudPrint
from application.apis.printer.controller.clover import nsApi as nsPrinterClover
from application.apis.menu.controller.menu import nsApi as nsMenu
from application.apis.menu.controller.menusync import nsApi as nsMenuSync
from application.apis.menu.controller.magicmapping import nsApi as nsMenuMagicMapping
from application.apis.menu.controller.menusection import nsApi as nsMenuSection
from application.apis.menu.controller.menucategory import nsApi as nsMenuCategory
from application.apis.menu.controller.menuitem import nsApi as nsMenuItem
from application.apis.menu.controller.menumodifiergroup import nsApi as nsMenuModifierGroup
from application.apis.menu.controller.menumodifier import nsApi as nsMenuModifier
from application.apis.order.controller import nsApi as nsOrder
from application.apis.onboarding.controller.onboarding import nsApi as nsOnboarding
from application.apis.reports.order.controller import nsApi as nsOrderReport
from application.apis.statistics.controller.statistics import nsApi as nsStatistics
from application.apis.monitoring.controller.order import nsApi as nsMonitoringOrder
from application.apis.monitoring.controller.printjob import nsApi as nsMonitoringPrintJob
from application.apis.monitoring.controller.clover import nsApi as nsMonitoringClover
from application.apis.monitoring.controller.menu import nsApi as nsMonitoringMenu
from application.apis.monitoring.controller.maintenance import nsApi as nsMonitoringMaintenance
from application.apis.monitoring.controller.onboarding import nsApi as nsMonitoringOnboarding
from application.apis.monitoring.controller.ubereats import nsApi as nsMonitoringUberEats
from application.apis.automation.controller.zapier import nsApi as nsAutomationZapier
from application.apis.automation.controller.typeform import nsApi as nsAutomationTypeform
from application.apis.oauth.ubereats.controller import nsApi as nsUberOauth


blueprint = Blueprint('api', __name__)

api_description = "These are all the elements and tools that are available for business logic related to OrderOut."

api = Api(blueprint,
          title = 'OrderOut API',
          version = '1.0',
          description = api_description,
          doc = '/doc')

api.add_namespace(nsUser, path='/user')
api.add_namespace(nsCustomer, path='/customer')
api.add_namespace(nsAccount, path='/account')
api.add_namespace(nsRestaurant, path='/')
api.add_namespace(nsRestaurantContact, path='/')
api.add_namespace(nsScrapingError, path='/scraping')
api.add_namespace(nsPointOfSale, path='/')
api.add_namespace(nsPointOfSaleClover, path='/')
api.add_namespace(nsPointOfSaleCloverLead, path='/pos/lead/clover')
api.add_namespace(nsPointOfSaleNewTek, path='/pos/newtek')
api.add_namespace(nsPointOfSaleTabit, path='/pos/tabit')
api.add_namespace(nsPointOfSaleAldelo, path='/pos/aldelo')
api.add_namespace(nsDeliveryService, path='/')
api.add_namespace(nsDeliveryServiceSimulator, path='/ds')
api.add_namespace(nsDeliveryServiceUberEats, path='/')
api.add_namespace(nsDeliveryServiceGrubhub, path='/')
api.add_namespace(nsDeliveryServiceDoordash, path='/')
api.add_namespace(nsDeliveryServiceDoordashApiSwitch, path='/ds/doordash/api_switch')
api.add_namespace(nsDeliveryServiceWix, path='/')
api.add_namespace(nsDeliveryServiceChownow, path='/')
api.add_namespace(nsDeliveryServicePostmates, path='/')
api.add_namespace(nsPrinter, path='/')
api.add_namespace(nsPrintJob, path='/')
api.add_namespace(nsPrinterStarCloudPrint, path='/printer/starcloudprint')
api.add_namespace(nsPrinterClover, path='/printer/clover')
api.add_namespace(nsMenu, path='/')
api.add_namespace(nsMenuSync, path='/')
api.add_namespace(nsMenuMagicMapping, path='/menu/magicmapping')
api.add_namespace(nsMenuSection, path='/')
api.add_namespace(nsMenuCategory, path='/menu/category')
api.add_namespace(nsMenuItem, path='/')
api.add_namespace(nsMenuModifierGroup, path='/menu/modifiergroup')
api.add_namespace(nsMenuModifier, path='/menu/modifier')
api.add_namespace(nsOrder, path='/order')
api.add_namespace(nsOnboarding, path='/onboarding')
api.add_namespace(nsStatistics, path='/stats')
api.add_namespace(nsMonitoringOrder, path='/monitoring/order')
api.add_namespace(nsMonitoringPrintJob, path='/monitoring/printjob')
api.add_namespace(nsMonitoringClover, path='/monitoring/clover')
api.add_namespace(nsMonitoringMenu, path='/monitoring/menu')
api.add_namespace(nsMonitoringMaintenance, path='/monitoring/maintenance')
api.add_namespace(nsMonitoringOnboarding, path='/monitoring/onboarding')
api.add_namespace(nsMonitoringUberEats, path='/monitoring/ubereats')
api.add_namespace(nsAutomationZapier, path='/automation/zapier')
api.add_namespace(nsAutomationTypeform, path='/automation/typeform')
api.add_namespace(nsUberOauth, path='/oauth/ubereats')
api.add_namespace(nsOrderReport, path='/report')
