# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#
import uuid

from application.apis.account.model import Account

from application.core.model.Base import Base
from google.appengine.ext import ndb
from google.appengine.ext.ndb import msgprop
from protorpc import messages
from flask_restplus import fields, marshal
from application.apis import ooexceptions
import json


class UserRole(messages.Enum):
    UNKNOWN = 0
    ADMIN = 1
    USER = 2
    CUSTOMER = 3
    MANAGER = 4
    OWNER = 5


MANAGER_ROLES = [UserRole.MANAGER, UserRole.ADMIN, UserRole.OWNER]


ROLE_MAPPING = {
    "user": UserRole.USER,
    "manager": UserRole.MANAGER,
    "owner": UserRole.OWNER,
    "admin": UserRole.ADMIN,
}


class User(Base):
    provider_uuid = ndb.StringProperty(required=True)
    email = ndb.StringProperty(required=True)
    provider_payload = ndb.JsonProperty(default=None, indexed=False)
    firstname = ndb.StringProperty(default="", indexed=False)
    lastname = ndb.StringProperty(default="", indexed=False)
    role = msgprop.EnumProperty(UserRole, default=UserRole.UNKNOWN)
    phone = ndb.StringProperty()
    receives_notification = ndb.BooleanProperty(default=False)
    restaurants = ndb.KeyProperty(repeated=True)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema['email'] = fields.String(required=True, description="Email")
        schema['firstname'] = fields.String(description="Last Name")
        schema['phone'] = fields.String(description="Phone")
        schema['lastname'] = fields.String(description="First Name")
        schema['receives_notification'] = fields.Boolean(description="Receives Notification")
        schema['role'] = fields.String()
        return schema

    @property
    def phone_number(self):
        return self.phone

    @property
    def is_owner(self):
        return self.role == UserRole.OWNER

    ###################
    # List & Pagination
    ###################

    @classmethod
    def list_with_pagination(cls, _next_cursor=None, limit=25, keys_only=False):
        _cursor =ndb.Cursor(urlsafe=_next_cursor) if _next_cursor else None
        _query = User.query()
        _objects, _next_cursor, _more = _query.fetch_page(limit, start_cursor=_cursor)
        _previous_cursor = _next_cursor.reversed() if _next_cursor else None
        _count = _query.count(deadline=30, limit=1000, start_cursor=None, end_cursor=None)
        return _objects, _previous_cursor, _next_cursor, _more, _count

    #################
    # Check if exists
    #################

    @classmethod
    def exists_with_provider_uuid(cls, provider_uuid):
        _query = User.query()
        _query = _query.filter(User.provider_uuid == provider_uuid)
        result = _query.count()
        return True if result > 0 else False

    @classmethod
    def exists_with_email(cls, email):
        _query = User.query()
        _query = _query.filter(User.email == email)
        result = _query.count()
        return True if result > 0 else False

    ######
    # GET
    ######

    @classmethod
    def get_by_id_and_populate(cls, id, json_dict):
        _obj = User.get_by_id(id)
        if not _obj: raise ooexceptions.ResourceDoesNotExist
        _email = json_dict['email']
        if _obj.email != _email and User.exists_with_email(_email): raise ooexceptions.ConflictResourceAlreadyExistsError
        _obj.populate(**json_dict)
        _obj.put()
        return _obj

    @classmethod
    def get_by_provider_uuid(cls, provider_uuid):
        _query = User.query()
        _query = _query.filter(User.provider_uuid == provider_uuid)
        _obj = _query.get()
        if _obj: return _obj
        return None

    @classmethod
    def get_by_email(cls, email):
        _query = User.query()
        _query = _query.filter(User.email == email)
        _obj = _query.get()
        if _obj: return _obj
        return None

    ########
    # CREATE
    ########

    @classmethod
    def create(cls, provider_uuid, provider_payload, email, firstname, lastname, is_admin=False):
        if User.exists_with_provider_uuid(provider_uuid):
            raise ooexceptions.ConflictResourceAlreadyExistsError
        if User.exists_with_email(email):
            raise ooexceptions.ConflictResourceAlreadyExistsError

        _obj = cls()
        _obj.provider_uuid = provider_uuid
        _obj.email = email
        _obj.firstname = firstname
        _obj.lastname = lastname
        _obj.provider_payload = json.dumps(provider_payload)
        _obj.role = User.__format_role(is_admin)
        _obj.put()
        return _obj

    @classmethod
    def create_and_populate(cls, email, json_dict, role=None):
        if not role:
            role = UserRole.USER

        if User.exists_with_email(email):
            raise ooexceptions.ConflictResourceAlreadyExistsError

        provider_uuid = json_dict.pop("provider_uuid", None)
        if not provider_uuid:
            provider_uuid = str(uuid.uuid4())

        _obj = cls()
        _obj.email = email
        _obj.provider_uuid = provider_uuid
        _obj.role = role
        _obj.phone = json_dict.pop("phone", None)
        _obj.receives_notification = json_dict.pop("receives_notification", False)
        _obj.put()

        _obj.populate(**json_dict)
        _obj.put()
        return _obj

    @property
    def account(self):
        return Account.query().filter(Account.users == self.key).get()

    ######
    # ROLE
    ######

    @staticmethod
    def __format_role(is_admin):
        if is_admin: return UserRole.ADMIN
        return UserRole.USER

    @property
    def is_admin(self):
        owner_domain = self.email.split("@")[1]
        if owner_domain == "orderout.co":
            return True

        return self.role == UserRole.ADMIN

    @property
    def is_manager(self):
        return self.role in MANAGER_ROLES

    def update_role(self, is_admin):
        if self.role == UserRole.UNKNOWN:
            self.role = User.__format_role(is_admin)
            self.put()

    def get_restaurants(self):
        restaurants = []
        for r in self.restaurants:
            if r:
                restaurant = r.get()
                if restaurant and restaurant.api_status:
                    restaurants.append(restaurant)

        return restaurants


class UserSchemaFieldFromKeyFormatter(fields.Raw):
    def format(self, value):
        if value:
            return marshal(value.get(), User.schema())
        return None
