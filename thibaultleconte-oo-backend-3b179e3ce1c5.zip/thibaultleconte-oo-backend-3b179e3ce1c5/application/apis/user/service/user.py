# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

from flask import _request_ctx_stack


def get_current_user():
    if _request_ctx_stack and _request_ctx_stack.top and hasattr(_request_ctx_stack.top, 'current_user'):
        return _request_ctx_stack.top.current_user
