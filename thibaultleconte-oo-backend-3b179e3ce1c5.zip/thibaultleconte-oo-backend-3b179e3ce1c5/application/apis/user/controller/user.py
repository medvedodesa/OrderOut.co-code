# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

from flask import request
from flask_restplus import Resource, Namespace
from ..model.User import User, UserRole
from application.apis import ooexceptions
from application.core.marshal import pagination_schema
from application.core.authentication.service import requires_auth_token


nsApi = Namespace('user', description='User related operations. These are restaurant owners, managers and OrderOut team members')

user_marshal = nsApi.model('User', User.schema())
users_pagination_marshal = nsApi.model('UsersPagination', pagination_schema(user_marshal))

@nsApi.route('/list')
class UserList(Resource):

    @nsApi.doc('List Users')
    @nsApi.response(200, 'OK', users_pagination_marshal)
    @nsApi.marshal_with(users_pagination_marshal)
    def get(self):
        _cursor = request.args.get('cursor', default=None, type=str)
        _users, _previous_cursor, _next_cursor, _more, _count = User.list_with_pagination(_cursor, keys_only=False)
        return {'data': _users,
                'previous_cursor': _previous_cursor.urlsafe() if _previous_cursor else None,
                'next_cursor': _next_cursor.urlsafe() if _next_cursor else None,
                'more': _more}

@nsApi.route('/')
class UserCreate(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Create a User')
    @nsApi.response(200, 'OK', user_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(400, 'Bad Request')
    @nsApi.expect(user_marshal, validate=True)
    @nsApi.marshal_with(user_marshal)
    def post(self):
        json_dict = request.get_json()
        email = json_dict['email']
        try:
            return User.create_and_populate(email, json_dict)
        except ooexceptions.ResourceDoesNotExist:
            nsApi.abort(404, 'Not found')
        except ooexceptions.NotFound:
            nsApi.abort(404, 'Not found')
        except Exception as e:
            import logging
            logging.error(e)
            nsApi.abort(400, 'Bad request')
        # TODO: Move to something like these to HANDLE ERRORS https://opensource.com/article/17/3/python-flask-exceptions

@nsApi.route('/<int:user_id>')
@nsApi.param('user_id', 'User identifier')
class UserGetPutDelete(Resource):

    @nsApi.doc('Get a User')
    @nsApi.response(200, 'OK', user_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(404, 'Not found')
    @nsApi.marshal_with(user_marshal)
    def get(self, user_id):
        try:
            return User.get_by_id(user_id)
        except ooexceptions.ResourceDoesNotExist:
            nsApi.abort(404, 'Not found')
        except ooexceptions.NotFound:
            nsApi.abort(404, 'Not found')
        except Exception as e:
            import logging
            logging.error(e)
            nsApi.abort(400, 'Bad request')
        # TODO: Move to something like these to HANDLE ERRORS https://opensource.com/article/17/3/python-flask-exceptions

    @nsApi.doc('Update a User')
    @nsApi.response(200, 'OK', user_marshal)
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    @nsApi.expect(user_marshal, validate=True)
    @nsApi.marshal_with(user_marshal)
    def put(self, user_id):
        json_dict = request.get_json()
        role = json_dict.pop("role", None)

        if role and role not in ["user", "manager"]:
            raise ooexceptions.BadRequest

        if role == "manager":
            role = UserRole.MANAGER

        elif role == "user":
            role = UserRole.USER

        if role:
            json_dict["role"] = role

        try:
            return User.get_by_id_and_populate(user_id, json_dict)
        except ooexceptions.ResourceDoesNotExist:
            nsApi.abort(404, 'Not found')
        except ooexceptions.NotFound:
            nsApi.abort(404, 'Not found')
        except ooexceptions.ConflictResourceAlreadyExistsError:
            nsApi.abort(409, 'Resource already exists')
        except Exception as e:
            import logging
            logging.error(e)
            nsApi.abort(400, 'Bad request')
        # TODO: Move to something like these to HANDLE ERRORS https://opensource.com/article/17/3/python-flask-exceptions

    @nsApi.doc('Delete a User')
    @nsApi.response(200, 'OK')
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    def delete(self, user_id):
        try:
            User.delete_by_id(user_id)
        except ooexceptions.ResourceDoesNotExist:
            nsApi.abort(404, 'Not found')
        except ooexceptions.NotFound:
            nsApi.abort(404, 'Not found')
        except Exception as e:
            import logging
            logging.error(e)
            nsApi.abort(400, 'Bad request')
        # TODO: Move to something like these to HANDLE ERRORS https://opensource.com/article/17/3/python-flask-exceptions
        return {}
