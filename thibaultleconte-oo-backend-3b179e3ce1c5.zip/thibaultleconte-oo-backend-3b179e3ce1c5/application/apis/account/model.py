# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/13/2019
#

from google.appengine.api import search
from google.appengine.ext import ndb, deferred

from application.core.google_search_api.constants import PUT_HOOK_QUEUE
from application.core.model.Base import Base
from flask_restplus import fields, marshal
from application.apis.ooexceptions import BadRequest
from application.core.marshal import SchemaFieldKeyFormatter


class Account(Base):
    name = ndb.StringProperty(required=True)
    owner = ndb.KeyProperty(default=None)
    users = ndb.KeyProperty(repeated=True)
    groups = ndb.KeyProperty(repeated=True)
    restaurants = ndb.KeyProperty(repeated=True)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema['name'] = fields.String(required=True, description="Name")
        schema['ownerId'] = SchemaFieldKeyFormatter(attribute='owner', description='Owner id')
        # schema['users'] = fields.List(fields.Nested(user_marshal))
        # schema['groups'] = fields.List(fields.Nested(group_marshal))
        # schema['restaurants'] = fields.List(fields.Nested(restaurant_marshal))
        return schema

    ######
    # CRUD
    ######

    @classmethod
    def create(cls, name):
        _obj = cls()
        _obj.name = name
        _obj.put()
        return _obj

    @classmethod
    def put_search_document(cls, account_id):
        account = cls.get_by_id(account_id)
        if account:
            document = search.Document(
                doc_id=str(account_id),
                fields=[
                    search.TextField(name='name', value=account.name),
                ])
            index = search.Index(name="AccountIndex")
            index.put(document)

    def _post_put_hook(self, future):
        deferred.defer(
            self.__class__.put_search_document,
            self.id,
            _transactional=ndb.in_transaction(),
            _queue=PUT_HOOK_QUEUE,
        )

    def add_user(self, user_key):
        if user_key and user_key not in self.users:
            self.users.append(user_key)
            self.put()

    def delete(self):
        if self.owner: raise BadRequest
        if len(self.users) > 0: raise BadRequest
        if len(self.groups) > 0: raise BadRequest
        if len(self.restaurants) > 0: raise BadRequest
        super(Account, self).delete()
        return self

    @property
    def entity_name(self):
        return "account"

class AccountSchemaFieldFromKeyFormatter(fields.Raw):
    def format(self, value):
        if value:
            account = value.get()
            if account.api_status:
                return marshal(account, Account.schema())
        return None
