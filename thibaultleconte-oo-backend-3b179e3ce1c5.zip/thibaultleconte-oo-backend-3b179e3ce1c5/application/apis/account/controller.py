# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/13/2019
#

from flask import request, g
from flask_restplus import Resource, Namespace, reqparse
from google.appengine.ext import ndb

from .model import Account
from .service import get_by_id_and_populate, fetch_accounts_offset_pagination
from application.apis.ooexceptions import ResourceDoesNotExist, NotFound, ConflictResourceAlreadyExistsError
from application.core.marshal import pagination_schema
from application.apis.group.model import Group
from application.apis.group.service import check_name_and_create as group_check_name_and_create
from application.apis.account.service import check_name_and_create
from application.apis.restaurant.model import Restaurant
from application.apis.restaurant.service import check_and_create_with_name
from application.apis.restaurant.controller import restaurant_marshal, restaurants_pagination_marshal
from application.core.authentication.service import requires_auth_token
from application.apis.user.service.user import get_current_user
from application.core.exception import errorHandler
from application.core.marshal import oo_marshal_list
from ...core.google_search_api.search import get_accounts_ids_by_account_or_restaurant_name

nsApi = Namespace('account', description='Account related operations.')


account_marshal = nsApi.model('Account', Account.schema())
accounts_pagination_marshal = nsApi.model('AccountsPagination', pagination_schema(account_marshal))

PAGINATION_MAX_SIZE = 100

@nsApi.route('/list')
class UserAccountList(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('List Accounts')
    @nsApi.response(200, 'OK', accounts_pagination_marshal)
    # @nsApi.marshal_with(accounts_pagination_marshal)
    # @errorHandler
    def get(self):
        parser = reqparse.RequestParser()
        parser.add_argument('page', default=1, type=int)
        parser.add_argument('item_per_page', default=25, type=int)
        parser.add_argument('sort_order', default='desc', type=str)
        parser.add_argument('name', default=None, type=str)
        args = parser.parse_args()

        _page = args.get('page')
        _item_per_page = min(args.get('item_per_page'), PAGINATION_MAX_SIZE)
        _sort = args.get('sort_order')
        _name = args.get('name')

        if _name:
            accounts_ids = get_accounts_ids_by_account_or_restaurant_name(_name)
            _objects = [ndb.Key(Account, int(account_id)) for account_id in accounts_ids[0:PAGINATION_MAX_SIZE]]

            _prev = False
            _next = False
            _page = 1
            _item_per_page = PAGINATION_MAX_SIZE
            _count = len(accounts_ids)
        else:
            _objects, _prev, _next, _count = fetch_accounts_offset_pagination(_page=_page, _item_per_page=_item_per_page, sort=_sort)

        __marshalled_result = {'data': oo_marshal_list(_objects, account_marshal),
                               'prev': _prev,
                               'next': _next,
                               'page': _page,
                               'count': _count,
                               'item_per_page': _item_per_page}

        return __marshalled_result

@nsApi.route('/')
class UserAccountCreate(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Create a Account')
    @nsApi.response(200, 'OK', account_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(400, 'Bad Request')
    @nsApi.expect(account_marshal, validate=True)
    @nsApi.marshal_with(account_marshal)
    @errorHandler
    def post(self):
        json_dict = request.get_json()
        name = json_dict['name']
        owner_key = get_current_user().key if "get_current_user().isNotAdmin()" == "1" else None
        return check_name_and_create(name=name, owner_key=owner_key)

        # TODO: Move to something like these to HANDLE ERRORS https://opensource.com/article/17/3/python-flask-exceptions

@nsApi.route('/<int:account_id>')
@nsApi.param('account_id', 'Account identifier')
class UserAccountGetPutDelete(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get a Account')
    @nsApi.response(200, 'OK', account_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(404, 'Not found')
    @nsApi.marshal_with(account_marshal)
    @errorHandler
    def get(self, account_id):
        return Account.get_by_id(account_id, ignore_status=True)
        # TODO: Move to something like these to HANDLE ERRORS https://opensource.com/article/17/3/python-flask-exceptions

    @nsApi.doc('Update a Account')
    @nsApi.response(200, 'OK', account_marshal)
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    @nsApi.expect(account_marshal, validate=True)
    @nsApi.marshal_with(account_marshal)
    @errorHandler
    def put(self, account_id):
        json_dict = request.get_json()
        return get_by_id_and_populate(account_id, json_dict)
        # TODO: Move to something like these to HANDLE ERRORS https://opensource.com/article/17/3/python-flask-exceptions

    @nsApi.doc('Delete a Account')
    @nsApi.response(200, 'OK')
    @nsApi.response(404, 'Not found')
    @nsApi.response(400, 'Bad Request')
    @errorHandler
    def delete(self, account_id):
        Account.delete_by_id(account_id)
        # TODO: Move to something like these to HANDLE ERRORS https://opensource.com/article/17/3/python-flask-exceptions
        return {}
