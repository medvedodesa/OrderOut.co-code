# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/14/2019
#
from google.appengine.ext import ndb

from .model import Account
from application.core.exception import AccountDoesNotExist, NameNotChanged, ConflictResourceAlreadyExistsError
import logging

from ..ooexceptions import ResourceDoesNotExist


def get_by_name(name):
    _query = Account.query()
    _query = _query.filter(Account.name == name)
    _result = _query.fetch(1)
    if len(_result) > 0: return _result[0]
    return _result

def exists_with_name(name):
    _query = Account.query()
    _query = _query.filter(Account.name == name)
    result = _query.count()
    return True if result > 0 else False

def check_name_and_create(name, owner_key=None):
    if exists_with_name(name=name):
        logging.error("Account name \"%s\" already exists" % str(name))
        raise ConflictResourceAlreadyExistsError
    _account = Account.create(name=name)
    if owner_key:
        _account.owner = owner_key
    return _account

def get_by_id_and_populate(id, json_dict):
    _obj = Account.get_by_id(id)
    if not _obj: raise AccountDoesNotExist
    _name = json_dict["name"]
    if not _obj.name != _name: raise NameNotChanged
    if exists_with_name(_name): raise ConflictResourceAlreadyExistsError
    _obj.populate(**json_dict)
    _obj.put()
    return _obj

def add_user_to_account(user_key, account_key):
    _user = user_key.get()
    if not _user: raise ResourceDoesNotExist
    _account = account_key.get()
    if not _account: raise ResourceDoesNotExist
    _account.add_user(user_key)

def remove_user_from_account(user_key, account_key):
    _user = user_key.get()
    if not _user: raise ResourceDoesNotExist
    _account = account_key.get()
    if not _account: raise ResourceDoesNotExist
    _account.users.remove(user_key)

def fetch_accounts_offset_pagination(_page=1, _item_per_page=25, sort='desc'):
    _query = Account.query()

    _objects, _prev, _next, _count = Account.list_with_offset_pagination(query=_query, page=_page, item_per_page=_item_per_page, keys_only=True, sort=sort)
    return _objects, _prev, _next, _count