# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 07/26/2019
#

from google.appengine.ext import ndb
from application.core.model.Base import Base
from flask_restplus import fields
from application.core.exception import NotFound
import json


class CloverLead(Base):
    merchant_id = ndb.StringProperty(required=True)
    employee_id = ndb.StringProperty(required=True)
    client_id = ndb.StringProperty(default='')
    auth_code = ndb.StringProperty(default='')
    access_token = ndb.StringProperty(default='')
    account_name = ndb.StringProperty(default='')
    street_address_1 = ndb.StringProperty(default='')
    street_address_2 = ndb.StringProperty(default='')
    street_address_3 = ndb.StringProperty(default='')
    city = ndb.StringProperty(default='')
    zipcode = ndb.StringProperty(default='')
    state = ndb.StringProperty(default='')
    country = ndb.StringProperty(default='')
    phone_number = ndb.StringProperty(default='')
    owner_name = ndb.StringProperty(default='')
    owner_email = ndb.StringProperty(default='')
    delivery_services = ndb.JsonProperty(indexed=False)
    raw_data = ndb.JsonProperty(indexed=False)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls, is_new=False):
        schema = super(cls, cls).schema()
        schema['merchant_id'] = fields.String()
        schema['employee_id'] = fields.String()
        schema['client_id'] = fields.String()
        schema['account_name'] = fields.String()
        # TO-DELETE - Used on July 9 2020 to Debug Clover AUth Token error
        # schema['auth_code'] = fields.String()
        # schema['access_token'] = fields.String()
        schema['street_address_1'] = fields.String()
        schema['street_address_2'] = fields.String()
        schema['street_address_3'] = fields.String()
        schema['city'] = fields.String()
        schema['zipcode'] = fields.String()
        schema['state'] = fields.String()
        schema['country'] = fields.String()
        schema['phone_number'] = fields.String()
        schema['owner_name'] = fields.String()
        schema['owner_email'] = fields.String()
        schema['delivery_services'] = SchemaFieldDeliveryServicesList(attribute='delivery_services', description='Delivery Services List')
        schema['is_new'] = fields.Boolean(default=is_new, description='Clover Lead created for this Merchant id')
        return schema

class SchemaFieldDeliveryServicesList(fields.Raw):
    def format(self, value):
        if value:
            value_dict = json.loads(value)
            return value_dict
        return []
