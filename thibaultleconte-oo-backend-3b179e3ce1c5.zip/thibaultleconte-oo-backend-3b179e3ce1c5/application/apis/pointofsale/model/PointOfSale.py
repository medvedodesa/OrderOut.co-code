# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/18/2019
#

from google.appengine.ext import ndb
from google.appengine.ext.ndb import msgprop
from protorpc import messages
from application.core.model.Base import Base
from flask_restplus import fields, marshal
from application.apis.menu.model.MenuSync import MenySyncSchemaFieldFromKeyFormatter


class PointOfSaleType(messages.Enum):
    UNKNOWN = 0
    CLOVER = 1
    SQUARE = 2
    POYNT = 3
    OMNIVORE = 4
    NEWTEK = 5
    TABIT = 6
    ALDELO = 7

class PointOfSale(Base):
    account = ndb.KeyProperty(required=True)
    restaurant = ndb.KeyProperty(required=True)
    type = msgprop.EnumProperty(PointOfSaleType, required=True)
    access_token = ndb.StringProperty(indexed=False, default=None)
    service_merchant_id = ndb.StringProperty(default=None)
    service_employee_id = ndb.StringProperty(indexed=False, default=None)
    service_client_id = ndb.StringProperty(indexed=False, default=None)
    service_data = ndb.JsonProperty(indexed=False)
    menuSync = ndb.KeyProperty()
    support_employee_id = ndb.StringProperty(indexed=False, default=None)
    settings = ndb.JsonProperty(indexed=False)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls, with_menu_sync=True):
        schema = super(cls, cls).schema()
        schema['type'] = fields.String()
        schema['service_merchant_id'] = fields.String()
        schema['service_employee_id'] = fields.String()
        schema['support_employee_id'] = fields.String()
        schema['settings'] = fields.Raw(description="settings")
        if with_menu_sync: schema['menuSync'] = MenySyncSchemaFieldFromKeyFormatter(attribute='menuSync', description='Menu Sync Status')
        return schema

    #####
    # Get
    #####

    @classmethod
    def get_by_merchant_id(cls, merchant_id, all_status=False):
        _pos_query = PointOfSale.query(all_status=all_status)
        _pos_query = _pos_query.filter(PointOfSale.service_merchant_id == merchant_id)
        _pos_query = _pos_query.order(-PointOfSale.api_created_at)
        _pos = _pos_query.get()
        return _pos

class PointOfSaleSchemaFieldFromKeyFormatter(fields.Raw):
    def format(self, value):
        if value:
            return marshal(value.get(), PointOfSale.schema(with_menu_sync=False))
        return None
