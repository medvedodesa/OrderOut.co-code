# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 01/21/2019
#

from flask import request
from flask_restplus import Resource, Namespace
from ..model.PointOfSale import PointOfSale
from application.apis.account.model import Account
from application.apis.restaurant.model import Restaurant
from ..service.newtek.connect import connect_newtek_store_uuid_to_restaurant
from application.core.authentication.service import requires_auth_token
from application.core.exception import errorHandler


nsApi = Namespace('POS-NewTek', description='NewTek related operations.')

pos_marshal = nsApi.model('PointOfSale', PointOfSale.schema())


@nsApi.route('/connect')
class PointOfSaleNewtekConnect(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Point Of Sale to NewTek Location UUID')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_clover_link, validate=True)
    @nsApi.marshal_with(pos_marshal)
    # @errorHandler
    def post(self):
        json_dict = request.get_json()
        _account_id = json_dict['account_id']
        _restaurant_id = json_dict['restaurant_id']
        _newtek_store_uuid = str(json_dict['newtek_store_uuid'])

        _account = Account.get_by_id(_account_id)
        if not _account: raise NotFound

        _restaurant = Restaurant.get_by_id(_restaurant_id)
        if not _restaurant: raise NotFound

        _pos = connect_newtek_store_uuid_to_restaurant(account_key=_account.key,
                                                       restaurant_key=_restaurant.key,
                                                       newtek_store_uuid=_newtek_store_uuid)
        return _pos
