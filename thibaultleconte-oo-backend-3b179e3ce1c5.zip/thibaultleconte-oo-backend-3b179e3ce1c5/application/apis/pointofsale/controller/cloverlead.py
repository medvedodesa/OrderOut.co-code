# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 07/18/2020
#

from flask import request
from flask_restplus import Resource, Namespace, reqparse
from application.core.authentication.service import requires_auth_token
from application.core.exception import errorHandler
from application.apis.pointofsale.service.clover.lead import fetch_clover_lead_offset_pagination_for_clover_merchant_id
from application.core.marshal import oo_marshal_list
from ..model.CloverLead import CloverLead
from ..service.clover.lead import fetch_by_merchant_id as fetch_clover_lead
from application.core.marshal import pagination_schema
from application.core.parser.string import sanitize_str
from application.core.exception import NotFound


nsApi = Namespace('POS-clover-lead', description='Clover Lead related operations.')

clover_lead_marshal = nsApi.model('CloverLead', CloverLead.schema())
clover_lead_pagination_marshal = nsApi.model('CloverLeadsPagination', pagination_schema(clover_lead_marshal))

@nsApi.route('/')
class LeadCloverList(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('List Clover Leads')
    @nsApi.response(200, 'OK', clover_lead_pagination_marshal)
    @errorHandler
    def get(self):

        parser = reqparse.RequestParser()
        parser.add_argument('page', default=1, type=int)
        parser.add_argument('item_per_page', default=25, type=int)
        parser.add_argument('merchant_uuid', type=str)
        args = parser.parse_args()

        _page = args.get('page')
        _item_per_page = min(args.get('item_per_page'), 100)
        _clover_merchant_id = sanitize_str(args.get('merchant_uuid', None))

        _objects, _prev, _next, _count = fetch_clover_lead_offset_pagination_for_clover_merchant_id(clover_merchant_id=_clover_merchant_id, _page=_page, _item_per_page=_item_per_page)
        __marshalled_result = {'data': oo_marshal_list(_objects, clover_lead_marshal),
                               'prev': _prev,
                               'next': _next,
                               'page': _page,
                               'count': _count,
                               'item_per_page': _item_per_page}
        return __marshalled_result

@nsApi.route('/<int:clover_lead_id>')
@nsApi.param('clover_lead_id', 'Clover Lead identifier')
class LeadCloverGet(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get Clover Point Of Sale Lead')
    @nsApi.marshal_with(clover_lead_marshal)
    @errorHandler
    def get(self, clover_lead_id):
        _clover_lead = CloverLead.get_by_id(clover_lead_id)
        if not _clover_lead: raise NotFound
        return _clover_lead


@nsApi.route('/mid/<string:clover_merchant_id>/eid/<string:clover_employee_id>')
@nsApi.param('clover_merchant_id', 'Clover Merchant identifier')
@nsApi.param('clover_employee_id', 'Clover Employee identifier')
class LeadCloverGetByMerchant(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get Clover Point Of Sale Lead')
    @nsApi.marshal_with(clover_lead_marshal)
    @errorHandler
    def get(self, clover_merchant_id, clover_employee_id):
        _clover_lead = fetch_clover_lead(clover_merchant_id, clover_employee_id)
        if not _clover_lead: raise NotFound
        return _clover_lead