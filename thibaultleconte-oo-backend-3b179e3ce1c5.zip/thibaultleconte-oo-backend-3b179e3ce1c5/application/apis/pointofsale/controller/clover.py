# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/19/2019
#
from werkzeug.exceptions import BadRequest as HTTPExceptionBadRequest
from flask import request
from flask_restplus import Resource, Namespace
from ..service.clover.authentication import process_web_callback, process_pos_callback
from application.apis.pointofsale.service.clover.employee.employee import (
    create_or_update_clover_support_employee,
    delete_clover_support_employee,
)
from ..service.clover.webhook import processWebhookVerification, processWebhookMessage
from ..model.PointOfSale import PointOfSale
from application.apis.restaurant.model import Restaurant
from application.core.exception import NotFound, OrderDoesNotExist, BadRequest
from application.core.authentication.service import requires_auth_token
from application.apis.order.controller import order_marshal
from application.apis.order.service.fetch import get_last_order_key_for_point_of_sale
import logging
from application.core.exception import errorHandler
from ..model.CloverLead import CloverLead
from application.apis.account.model import Account
from ..service.clover.lead import update as update_clover_lead
from ..service.clover.lead import link_restaurant_to_clover_lead, notify_new_lead
from flask_restplus import marshal
from ..service.clover.authentication import update_clover_access_token


nsApi = Namespace('POS-clover', description='Clover related operations.')

marshal_clover_callback = nsApi.schema_model('PointOfSaleCloverCallback',
                                            {'required': ['merchant_id', 'code'],
                                             'properties': {'merchant_id':{'type': 'string'},
                                                            'code':{'type': 'string'}},
                                             'type': 'object'})
cloverlead_marshal = nsApi.model('CloverLead', CloverLead.schema())

marshal_clover_link = nsApi.schema_model('PointOfSaleCloverLink',
                                        {'required': ['account_id', 'restaurant_id', 'clover_lead_id'],
                                         'properties': {'account_id':{'type': 'number'},
                                                        'restaurant_id':{'type': 'number'},
                                                        'clover_lead_id':{'type': 'string'}},
                                         'type': 'object'})
pos_marshal = nsApi.model('PointOfSale', PointOfSale.schema())


############
# CLOVER WEB
############

@nsApi.route('pos/clover/callback')
class PointOfSaleCloverCallback(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Clover Point Of Sale Authentication Callback')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    @nsApi.expect(marshal_clover_callback, validate=True)
    # @nsApi.marshal_with(marshal_clover_response)
    def post(self):
        json_dict = request.get_json()
        _clover_merchant_id = json_dict['merchant_id']
        _clover_employee_id = json_dict['employee_id']
        _clover_client_id = json_dict['client_id']
        _clover_code = json_dict['code']
        try:
            _clover_lead, _clover_lead_is_new = process_web_callback(clover_merchant_id=_clover_merchant_id,
                                                                 clover_employee_id=_clover_employee_id,
                                                                 clover_client_id=_clover_client_id,
                                                                 clover_auth_code=_clover_code)
        except BadRequest:
            raise HTTPExceptionBadRequest

        return marshal(_clover_lead, CloverLead.schema(is_new=_clover_lead_is_new))

@nsApi.route('pos/clover/lead/<int:clover_lead_id>')
@nsApi.param('clover_lead_id', 'Clover Lead identifier')
class PointOfSaleCloverLead(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Clover Point Of Sale Lead Submit')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(cloverlead_marshal, validate=True)
    @nsApi.marshal_with(cloverlead_marshal)
    def post(self, clover_lead_id):
        json_dict = request.get_json()
        _clover_lead_key = CloverLead.get_key(clover_lead_id)
        if not _clover_lead_key: raise NotFound
        _clover_lead = update_clover_lead(clover_lead_key=_clover_lead_key, raw_json=json_dict)
        notify_new_lead(_clover_lead_key)
        return _clover_lead

@nsApi.route('pos/clover/link')
class PointOfSaleCloverLink(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Clover Point Of Sale Link to Clover Lead')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_clover_link, validate=True)
    @nsApi.marshal_with(pos_marshal)
    def post(self):
        json_dict = request.get_json()
        _account_id = json_dict['account_id']
        _restaurant_id = json_dict['restaurant_id']
        _clover_lead_id = json_dict['clover_lead_id']

        _account = Account.get_by_id(_account_id)
        if not _account: raise NotFound

        _restaurant = Restaurant.get_by_id(_restaurant_id)
        if not _restaurant: raise NotFound

        _clover_lead = CloverLead.get_by_id(_clover_lead_id)
        if not _clover_lead: raise NotFound

        _pos = link_restaurant_to_clover_lead(account_key=_account.key, restaurant_key=_restaurant.key, clover_lead_key=_clover_lead.key)
        return _pos

@nsApi.route('pos/<int:point_of_sale_id>/clover/lead/<int:clover_lead_id>/update')
@nsApi.param('point_of_sale_id', 'Point Of Sale identifier')
@nsApi.param('clover_lead_id', 'Clover Lead identifier')
class PointOfSaleCloverLead(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Clover Point Of Sale Lead Submit')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(cloverlead_marshal, validate=True)
    @nsApi.marshal_with(pos_marshal)
    def put(self, point_of_sale_id, clover_lead_id):

        _pos = PointOfSale.get_by_id(point_of_sale_id)
        if not _pos: raise NotFound

        _clover_lead = CloverLead.get_by_id(clover_lead_id)
        if not _clover_lead: raise NotFound

        _pos = update_clover_access_token(_pos.key, _clover_lead.key)

        return _pos

################
# CLOVER WEBHOOK
################

@nsApi.route('pointofsale/clover/webhook')
class PointOfSaleCloverWebhookCreate(Resource):
    # method_decorators = [requires_auth_token] // Dont Allow because CLOVER settings are not Authenticated

    @nsApi.doc('Handle Clover Webhook Callback URL')
    @nsApi.response(200, 'OK')
    # @nsApi.expect(marshal_webhook_create, validate=True)
    def post(self):
        json_dict = request.get_json()
        import logging
        logging.info(json_dict)
        _key_verificationCode = 'verificationCode'
        if _key_verificationCode in json_dict:
            # Someone is trying to register a Clover Webhook to OrderOut App account
            verification_code = json_dict[_key_verificationCode]
            processWebhookVerification(verification_code)
        else:
            processWebhookMessage(url=request.url, json_dict=json_dict)
        return {}

##############################################
# Endpoints used in the Clover Android APK App
##############################################

@nsApi.route('pointofsale/clover/<string:merchant_id>/install')
@nsApi.param('merchant_id', 'Clover Merchant identifier')
class PointOfSaleCloverPostMerchantInstall(Resource):
    # method_decorators = [requires_auth_token] // Dont Allow because CLOVER POS does not have authentication

    @nsApi.doc('Save the Access Token when a Clover Merchant Id installs the app')
    @nsApi.response(200, 'OK')
    # @nsApi.marshal_with(order_marshal)
    # @errorHandler
    def post(self, merchant_id):
        json_dict = request.get_json()
        # DEBUGGING
        json_dict['merchant_id'] = str(merchant_id)
        # DEBUGGING
        _clover_merchant_id = str(merchant_id)
        _clover_access_token = str(json_dict.get('access_token'))
        _clover_lead, _clover_lead_is_new = process_pos_callback(clover_merchant_id=merchant_id, clover_access_token=_clover_access_token)
        if _clover_lead_is_new == True:
            notify_new_lead(_clover_lead.key)
        return {'success': True}

@nsApi.route('pointofsale/clover/<string:merchant_id>/order/last')
@nsApi.param('merchant_id', 'Clover Merchant identifier')
class PointOfSaleCloverGetLastOrderForMerchant(Resource):
    # method_decorators = [requires_auth_token] // Dont Allow because CLOVER POS does not have authentication

    @nsApi.doc('Return the last order for a specific Clover Merchant Id')
    @nsApi.response(200, 'OK', order_marshal)
    @nsApi.marshal_with(order_marshal)
    @errorHandler
    def get(self, merchant_id):
        from application.apis.printer.service.clover.sandbox import convert_merchant_id_to_sandbox
        merchant_id = convert_merchant_id_to_sandbox(merchant_id)
        _pos = PointOfSale.get_by_merchant_id(merchant_id)
        if not _pos: raise OrderDoesNotExist # raise PointOfSaleDoesNotExist
        _order_key = get_last_order_key_for_point_of_sale(_pos.key)
        if not _order_key: raise OrderDoesNotExist
        return _order_key.get()

###########
# To-Review
###########

@nsApi.route('pointofsale/clover/subscribe')
class PointOfSaleCloverSubscribeCreate(Resource):
    # method_decorators = [requires_auth_token] // Dont Allow because CLOVER settings are not Authenticated

    @nsApi.doc('Handle Clover Webhook Callback URL when connecting')
    @nsApi.response(200, 'OK')
    # @nsApi.expect(marshal_webhook_create, validate=True)
    def post(self):
        json_dict = request.get_json()
        logging.info(json_dict)
        return {}

##########
# Employee
##########

@nsApi.route('pos/<int:point_of_sale_id>/clover/employee')
@nsApi.param('point_of_sale_id', 'Point Of Sale identifier')
class PointOfSaleCloverPostEmployee(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Create support employee at Clover POS')
    @nsApi.response(200, 'OK')
    @nsApi.response(404, "Not Found")
    @nsApi.response(502, "Clover employee permissions")
    @errorHandler
    def post(self, point_of_sale_id):
        pos = PointOfSale.get_by_id(point_of_sale_id)
        if not pos:
            raise NotFound

        create_or_update_clover_support_employee(pos)
        return {'success': True}

    @nsApi.doc('Create support employee at Clover POS')
    @nsApi.response(200, 'OK')
    @nsApi.response(404, "Not Found")
    @nsApi.response(502, "Clover employee permissions")
    @errorHandler
    def delete(self, point_of_sale_id):
        pos = PointOfSale.get_by_id(point_of_sale_id)
        if not pos:
            raise NotFound

        delete_clover_support_employee(pos)
        return {'success': True}
