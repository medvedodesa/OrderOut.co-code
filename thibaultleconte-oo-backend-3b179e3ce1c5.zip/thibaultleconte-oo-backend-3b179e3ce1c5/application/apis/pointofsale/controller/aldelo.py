import uuid

from flask import request
from flask_restplus import Resource, Namespace
from werkzeug.exceptions import BadRequest

from ..model.PointOfSale import PointOfSale
from application.apis.account.model import Account
from application.apis.restaurant.model import Restaurant
from application.apis.pointofsale.service.aldelo.connect import connect_store_uuid_to_restaurant
from application.core.authentication.service import requires_auth_token
from application.core.exception import errorHandler
from application.core.exception import NotFound
from application.apis.pointofsale.service.aldelo.order import (
    pull_messages, confirm_messages, push_order
)
from application.apis.order.model.Order import Order

nsApi = Namespace('POS-Aldelo', description='Aldelo related operations.')

pos_marshal = nsApi.model('PointOfSale', PointOfSale.schema())


@nsApi.route('/connect')
class PointOfSaleAldeloConnect(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Point Of Sale to Aldelo UUID')
    @nsApi.marshal_with(pos_marshal)
    @errorHandler
    def post(self):
        json_dict = request.get_json()
        _account_id = json_dict['account_id']
        _restaurant_id = json_dict['restaurant_id']
        _store_uuid = json_dict['aldelo_store_uuid']

        _account = Account.get_by_id(_account_id)
        if not _account:
            raise NotFound

        _restaurant = Restaurant.get_by_id(_restaurant_id)
        if not _restaurant:
            raise NotFound

        _pos = connect_store_uuid_to_restaurant(account_key=_account.key,
                                                restaurant_key=_restaurant.key,
                                                store_uuid=_store_uuid)
        return _pos


@nsApi.route('/orders', methods=["GET", "PUT", "POST"])
class PointOfSaleAldeloConnect(Resource):
    method_decorators = [requires_auth_token]

    def get(self):
        customer_id = request.args.get("customer_id")

        messages = pull_messages(customer_id=customer_id)
        return messages

    def post(self):
        json_data = request.get_json()
        order_id = json_data.get("order_id")

        _order = Order.get_by_id(order_id)

        push_order(_order.key)

    def put(self):
        json_data = request.get_json()

        customer_id = json_data.get("customer_id")
        order_ids = json_data.get("order_ids", [])

        if not customer_id or not order_ids:
            raise BadRequest

        messages = confirm_messages(customer_id=customer_id, order_ids=order_ids)
        return messages
