# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/06/2019
#

from flask import request
from flask_restplus import Resource, Namespace
from application.apis.restaurant.model import Restaurant
from application.apis.pointofsale.model.PointOfSale import PointOfSale
from application.apis.ooexceptions import NotFound
from application.core.authentication.service import requires_auth_token
from ..service.clover.settings.factory import PointOfSaleSettingsFactory
from ..service.common import get_point_of_sale_for_restaurant, start_fetching_menu_for_point_of_sale, disconnect, test_connection_for_point_of_sale
from application.core.exception import errorHandler, BadRequest
from application.core.webhook.service import save_webhook
from application.core.webhook.model import CoreWebhookService
from application.core.email.service import send_admin_email
from application.core.settings.app import get_config_for_key


nsApi = Namespace('pointofsale', description='Point Of Sale related operations.')

pos_marshal = nsApi.model('PointOfSale', PointOfSale.schema())

@nsApi.route('restaurant/<int:restaurant_id>/pos')
@nsApi.param('restaurant_id', 'Restaurant identifier')
class PointOfSaleGetForRestaurant(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('List the Point Of Sale for a Restaurant')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    @nsApi.marshal_list_with(pos_marshal)
    @errorHandler
    def get(self, restaurant_id):
        _restaurant = Restaurant.get_by_id(restaurant_id)
        if not _restaurant: raise NotFound
        return get_point_of_sale_for_restaurant(_restaurant.key)

@nsApi.route('pos/<int:point_of_sale_id>')
@nsApi.param('point_of_sale_id', 'Point Of Sale identifier')
class PointOfSaleGet(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get a Point Of Sale')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    @nsApi.marshal_with(pos_marshal)
    @errorHandler
    def get(self, point_of_sale_id):
        _pos = PointOfSale.get_by_id(point_of_sale_id)
        if not _pos:
            raise BadRequest

        if _pos.settings is None:
            _pos.settings = PointOfSaleSettingsFactory(
                pos_type=_pos.type
            ).default_as_dict

        return _pos

@nsApi.route('pos/<int:point_of_sale_id>/menu/fetch')
@nsApi.param('point_of_sale_id', 'Point Of Sale identifier')
class PointOfSaleFetchMenu(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Start the process to fetch menu for a Point Of Sale')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.marshal_with(restaurant_marshal)
    @errorHandler
    def get(self, point_of_sale_id):
        _pos = PointOfSale.get_by_id(point_of_sale_id)
        if not _pos: raise BadRequest
        start_fetching_menu_for_point_of_sale(point_of_sale_key=_pos.key)
        return {"status": "Fetching Point Of Sale Menu started"}

@nsApi.route('pos/<int:point_of_sale_id>/test/connection')
@nsApi.param('point_of_sale_id', 'Point Of Sale identifier')
class PointOfSaleTestConnection(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Test Connection with Point Of Sale ')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    # @nsApi.marshal_with(restaurant_marshal)
    # @errorHandler
    def get(self, point_of_sale_id):
        _pos_key = PointOfSale.get_key(point_of_sale_id)
        if not _pos_key: raise NotFound
        success = test_connection_for_point_of_sale(_pos_key)
        if success: return {"status": "Connection with Point Of Sale SUCCESSFUL"}
        return {"status": "Connection with Point Of Sale FAILED"}

@nsApi.route('pos/<int:point_of_sale_id>/disconnect')
@nsApi.param('point_of_sale_id', 'Point Of Sale identifier')
class PointOfSaleDisconnect(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Disconnect Point Of Sale from the Restaurant')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    # @nsApi.marshal_with(restaurant_marshal)
    @errorHandler
    def delete(self, point_of_sale_id):
        _pos_key = PointOfSale.get_key(point_of_sale_id)
        if not _pos_key: raise NotFound
        success = disconnect(_pos_key)
        if success:
            return {"status": "Disconnected Point Of Sale successfully"}
        return {"status": "Disconnecting Point Of Sale FAILED"}

@nsApi.route('pos/menu/notify/<string:pos_type>')
@nsApi.param('pos_type', 'Point Of Sale Type')
class PointOfSaleMenuNotify(Resource):
    # method_decorators = [requires_auth_token] We dont have api authentication Supported

    @nsApi.doc('Disconnect Point Of Sale from the Restaurant')
    # @nsApi.response(200, 'OK', restaurant_marshal)
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    # @nsApi.marshal_with(restaurant_marshal)
    @errorHandler
    def post(self, pos_type):
        json_dict = request.get_json()
        _location_uuid = json_dict['store_uuid']
        import logging
        _wh = save_webhook(url=request.url, service=CoreWebhookService.MENU_UPDATE_NOTIFY, payload=json_dict)
        _subject = "POS MENU NOTIFY"
        _message = "%s menu update notification for location uuid %s" % (str(pos_type), str(_location_uuid))
        logging.info("[%s] - POS notifies Menu Has Changed for %s Location UUID %s" % (str(_subject), str(pos_type), str(_location_uuid)))
        send_admin_email(recipients=get_config_for_key('EMAIL_TO_ADMINS'), subject=_subject, body=_message)
        _wh.is_successful() # if success else _wh.failed()
        return {"status": "OK"}


@nsApi.route("pos/<int:point_of_sale_id>/update_settings")
@nsApi.param("point_of_sale_id", "Point of Sale identifier")
class PointOfSaleUpdateSettings(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc("Updates the Point of Sale's settings")
    @errorHandler
    def post(self, point_of_sale_id):
        point_of_sale = PointOfSale.get_by_id(point_of_sale_id)

        if not point_of_sale:
            raise NotFound

        settings_json = request.get_json() if request.json else {}
        valid_settings = PointOfSaleSettingsFactory(
            pos_type=point_of_sale.type
        ).is_valid(settings_json)

        if not valid_settings:
            raise BadRequest

        point_of_sale.settings = settings_json
        point_of_sale.put()

        return point_of_sale.settings
