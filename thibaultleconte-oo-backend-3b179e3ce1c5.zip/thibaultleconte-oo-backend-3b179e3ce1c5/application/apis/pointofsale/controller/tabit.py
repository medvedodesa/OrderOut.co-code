# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 07/01/2020
#

from flask import request
from flask_restplus import Resource, Namespace
from ..model.PointOfSale import PointOfSale
from application.apis.account.model import Account
from application.apis.restaurant.model import Restaurant
from ..service.tabit.connect import connect_store_uuid_to_restaurant
from application.core.authentication.service import requires_auth_token
from application.core.exception import errorHandler
from application.core.webhook.service import save_webhook
from application.core.webhook.model import CoreWebhookService
from ..service.tabit.order import save_tabit_order_uuid
from application.apis.order.model.Order import Order
from application.core.exception import NotFound


nsApi = Namespace('POS-Tabit', description='Tabit related operations.')

pos_marshal = nsApi.model('PointOfSale', PointOfSale.schema())


@nsApi.route('/connect')
class PointOfSaleTabitConnect(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Point Of Sale to Tabit Location UUID')
    @nsApi.marshal_with(pos_marshal)
    @errorHandler
    def post(self):
        json_dict = request.get_json()
        _account_id = json_dict['account_id']
        _restaurant_id = json_dict['restaurant_id']
        _store_uuid = str(json_dict['tabit_store_uuid'])

        _account = Account.get_by_id(_account_id)
        if not _account: raise NotFound

        _restaurant = Restaurant.get_by_id(_restaurant_id)
        if not _restaurant: raise NotFound

        _pos = connect_store_uuid_to_restaurant(account_key=_account.key,
                                                restaurant_key=_restaurant.key,
                                                store_uuid=_store_uuid)
        return _pos

@nsApi.route('/callback/order/status')
class PointOfSaleTabitOrderStatusCallback(Resource):
    # method_decorators = [requires_auth_token] # TABIT DOES NOT SEND AUTHENTICATION

    @nsApi.doc('Order Status Callback after an order is created')
    @errorHandler
    def post(self):
        json_dict = request.get_json()

        import logging
        logging.info(json_dict)

        _order_id = json_dict.get('order_id', None) # OrderOut Order id
        _status = json_dict.get('status') # SUCCESS, SUCCESS_ISSUES, ERROR
        _order_uuid = json_dict.get('payload', {}).get('order', {}).get('_id')

        _wh = save_webhook(url=request.url, service=CoreWebhookService.TABIT, payload=json_dict)
        _wh.is_successful() if _status.upper() == 'SUCCESS' else _wh.failed()

        if _status.upper() in ['SUCCESS', 'SUCCESS_ISSUES']:
            _order = Order.get_by_id(_order_id)
            if not _order: raise NotFound
            _order = save_tabit_order_uuid(order_key=_order.key, tabit_order_uuid=_order_uuid)

        _response = {}
        return _response
