# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 07/01/2020
#
from application.core.parser.price import sanitize_price
from application.core.settings.app import get_config_for_key

def format_header(store_uuid):
    _integrator_token = get_config_for_key('TABIT_API_KEY_INTEGRATOR_TOKEN')
    return {'Content-Type': 'application/json', 'integrator-token': _integrator_token, 'organization-token': store_uuid}

def format_amount_for_tabit(amount):
    return int(sanitize_price(amount * 100))

def format_date_for_tabit(date_to_format, restaurant_zipcode, restaurant_key_id):
    _local_time = convert_utc_datetime_to_zipcode_timezone(date_to_format, restaurant_zipcode, restaurant_key_id)
    return str(_local_time.strftime("%Y-%m-%d %H:%M:%S"))
