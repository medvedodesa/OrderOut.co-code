# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 07/01/2020
#

from application.apis.ooexceptions import ConflictResourceAlreadyExistsError, Unauthorized
from ..common import createPointOfSale
from ..common import check_point_of_sale_already_connected
from ...model.PointOfSale import PointOfSaleType
from menu import get_menu


def connect_store_uuid_to_restaurant(account_key, restaurant_key, store_uuid):
    if check_point_of_sale_already_connected(restaurant_key=restaurant_key):
        raise ConflictResourceAlreadyExistsError

    _pos = createPointOfSale(type=PointOfSaleType.TABIT,
                             account_key=account_key,
                             restaurant_key=restaurant_key,
                             service_merchant_id=store_uuid)
    _task = get_menu(_pos.key)
    return _pos
