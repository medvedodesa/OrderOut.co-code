# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 07/01/2020
#

from application.apis.menu.service.menusync.creator import create_menu_sync
from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from application.apis.menu.service.menusync.fetch import fetch_menu_task_started, fetch_menu_task_finished
from application.apis.menu.service.menusync.process import process_menu_task_started
from application.core.error import report_error
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.apis.menu.model.MenuSync import MenuSync
from application.core.settings.app import get_config_for_key
from common import format_header

from application.apis.menu.service.crud.section import create_update_menu_section
from application.apis.menu.service.crud.category import create_update_menu_category
from application.apis.menu.service.creator import generate_item_dict, generate_modifier_group_dict, generate_modifier_dict, startTaskToCreateOrUpdateMenuItemsAndModifiers
from application.core.parser.string import sanitize_str


DEFAULT_TABIT_MENU_SECTION_NAME = 'Menu'
DEFAULT_TABIT_MENU_CATEGORY_NAME = 'Main'

def get_menu(pointofsale_key):
    _pos = pointofsale_key.get()
    _menuSync = create_menu_sync(restaurant_key=_pos.restaurant, service_key=_pos.key)
    _pos.menuSync = _menuSync.key
    _pos.put()
    _task = _startTaskToFetchMenuFromTabit(_menuSync.key)
    return _task

######
# Task
######

def _startTaskToFetchMenuFromTabit(menu_sync_key):
    _ms = menu_sync_key.get()
    _task = addTask(category=CoreTaskCategory.TABIT_MENU_FETCH, entity=_ms)
    _menuSync = fetch_menu_task_started(menuSync_key=menu_sync_key, task_key=_task.key)
    return _task

def processTaskToFetchMenuFromTabit(menu_sync_id):
    _task_result_json = {}
    _ms = MenuSync.get_by_id(menu_sync_id)
    if not _ms:
        _task_result_json['processTaskToFetchMenuFromTabit'] = {'message': 'MenuSync with id %s not found' % (str(menu_sync_id))}
    elif not _ms.service:
        _task_result_json['processTaskToFetchMenuFromTabit'] = {'message': 'MenuSync with id %s has no ds' % (str(menu_sync_id))}
    else:
        _url, _status_code, _result_json = __start_fetch_menu_request(_ms.service)
        _task_result_json['__start_fetch_menu_request'] = {'url': _url,
                                                           'status_code': _status_code,
                                                           'result_json': _result_json}
        if _status_code >= 200 and _status_code <= 299:
            _menu_items = __process_menu(_ms, _result_json)
            process_menu_task_started(menuSync_key=_ms.key, tasks_keys=_menu_items)
            _task_result_json['__parse_menu'] = {'message': "Point Of Sale has fetched %s menu items" % (str(len(_menu_items)))}
        else:
            report_error(code=_status_code, subject="GetTabitMenu-Error", message="Menu Sync %s returned %s" % (str(_ms.key.id()), str(_status_code)))
    return _task_result_json

############
# Fetch Menu
############

def __start_fetch_menu_request(pointofsale_key):
    _pos = pointofsale_key.get()
    _url = get_config_for_key('TABIT_API_URL_BASE') + "/menu"
    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.TABIT, method="GET", headers=format_header(_pos.service_merchant_id))
    if _status_code < 200 or _status_code > 299:
        fetch_menu_task_finished(menuSync_key=_pos.menuSync, success=False)
        return _url, _status_code, None
    fetch_menu_task_finished(menuSync_key=_pos.menuSync, success=True)
    return _url, _status_code, _result_json

##############
# Process Menu
##############
def __process_menu(menu_sync, raw_data):
    _items_tasks = []
    _section = create_update_menu_section(menu_sync_key=menu_sync.key, name=DEFAULT_TABIT_MENU_SECTION_NAME)
    return __parse_items(menu_sync, raw_data, _section.key)

def __parse_items(menu_sync, raw_categories, section_key):
    _items_tasks = []
    for _raw_category in raw_categories:
        # CATEGORY
        _raw_menu_category_name, _raw_menu_category_uuid = __get_category_name_and_uuid(_raw_category)
        _category = create_update_menu_category(menu_sync_key=menu_sync.key,
                                                section_key=section_key,
                                                name=_raw_menu_category_name,
                                                uuid=_raw_menu_category_uuid)
        # MENU ITEMS
        _list_of_raw_item_to_process = []
        if 'children' in _raw_category:
            for _raw_item in _raw_category.get('children', []):
                if _raw_item.get('type', '').lower() == 'menu':
                    for _raw_sub_item in _raw_item.get('children', []):
                        if _raw_sub_item.get('type', '').lower() == 'offer':
                            _list_of_raw_item_to_process.append(_raw_sub_item)
                elif _raw_item.get('type', '').lower() == 'offer':
                    _list_of_raw_item_to_process.append(_raw_item)

        for _raw_item in _list_of_raw_item_to_process:
            # MODIFIER GROUPS and MODIFIERS
            _modifier_groups = __parse_modifier_groups(_raw_item)
            # MENU ITEM
            _mi = generate_item_dict(name=_raw_item.get('name'),
                                    price=_raw_item.get('price'),
                                    modifier_groups=_modifier_groups,
                                    uuid=_raw_item.get('id'),
                                    category_id=_category.get_id())
            # Tasks
            _task = startTaskToCreateOrUpdateMenuItemsAndModifiers(menu_sync, _mi)
            _items_tasks.append(_task.key)

    return _items_tasks

def __get_category_name_and_uuid(raw_category):
    _raw_menu_category_name = sanitize_str(raw_category.get('name'))
    _raw_menu_category_uuid = sanitize_str(raw_category.get('type'))
    return _raw_menu_category_name, _raw_menu_category_uuid

def __parse_modifier_groups(raw_item):
    modifier_groups = []
    if 'groups' in raw_item:
        raw_modifierGroups = raw_item['groups']
        for raw_element in raw_modifierGroups:
            _group_name = raw_element.get('name')
            _group_uuid = raw_element.get('id')
            _modifiers = __parse_modifiers(raw_element)
            _group = generate_modifier_group_dict(name=_group_name,
                                                  modifiers=_modifiers,
                                                  uuid=_group_uuid,)
            modifier_groups.append(_group)
    return modifier_groups

def __parse_modifiers(raw_element):
    modifiers = []
    if 'members' in raw_element:
        raw_modifiers = raw_element['members']
        for _raw_element in raw_modifiers:
            if "groups" in _raw_element:
                for group in _raw_element["groups"]:
                    for member in group.get("members", []):
                        _mod = generate_modifier_dict(
                            name=member.get("name"),
                            price=member.get("price"),
                            uuid=member.get("id"),
                        )
                        modifiers.append(_mod)
            else:
                _mod = generate_modifier_dict(name=_raw_element.get('name'),
                                              price=_raw_element.get('price'),
                                              uuid=_raw_element.get('id'))
                modifiers.append(_mod)
    return modifiers
