# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 07/01/2019
#
import uuid

from common import format_header, format_amount_for_tabit
from application.core.settings.app import get_config_for_key
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.error import report_error, report_warning
import datetime
from application.core.parser.string import sanitize_str
from application.core.datetime.timezone import convert_utc_datetime_to_zipcode_timezone
from application.apis.order.model.Order import Order, OrderType
from application.apis.deliveryservice.model.DeliveryService import DeliveryServiceType


TABIT_UNRECOGNIZED_NAME = 'Unrecognized'
TABIT_UNRECOGNIZED_ID = -1

TABIT_DELIVERY_TYPE_DELIVERY = 'delivery'
TABIT_DELIVERY_TYPE_PICKUP = 'takeaway'

TEMPORARY_KEY_FROM_TABIT = "ubereats"
TEMPORARY_NAME_FROM_TABIT = "UberEATS"
TABIT_SOURCE_KEY_FOR_ORDEROUT = "OrderOut"


def push_order(order_key, point_of_sale_key, unmapped_order_itens=None):
    if not unmapped_order_itens:
        unmapped_order_itens = []

    _order = order_key.get()
    _pos = point_of_sale_key.get()
    _payload = __generate_order_payload(_order, unmapped_order_itens)
    _success_order_created = __create_order_on_tabit(_pos, _payload, _order)
    return True

def __create_order_on_tabit(pos, payload, order):
    # Related entities
    _related_entities_keys = [pos.account, pos.restaurant, pos.key, order.delivery_service, order.key]
    # Request
    _headers = format_header(pos.service_merchant_id)
    _url = get_config_for_key('TABIT_API_URL_BASE') + "/order"
    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.TABIT, method="POST", headers=_headers, data=payload, related_entities_keys=_related_entities_keys)
    if _status_code < 200 or _status_code > 299:
        report_error(code=500, message='__create_order_on_tabit return status code %s' % (str(_status_code)))
        return False

    return True

def __generate_order_payload(order, unmapped_order_itens):
    """
        documentation: https://inpact.github.io/tabit-middleware/webhooks.html#tag/Third-Party-API/paths/~1order/post
    """

    #extract required entity for later use
    _payload = {}
    _restaurant = order.restaurant.get()
    _pos = _restaurant.point_of_sale.get()
    _ds = order.delivery_service.get()

    #general info
    _payload["consumer_comment"] = order.store_instructions
    _payload["consumer_name"]    = order.customer_name
    _payload["id"] = order.get_id()
    _ds_order_uuid = order.delivery_service_short_uuid if order.delivery_service_short_uuid else order.delivery_service_uuid
    _payload["order_number"] =  _ds_order_uuid
    _payload['preorder'] = None
    _source_ds = {"key": _get_source_key(_ds.type.name), "name": _get_source_name(_ds.type.name), "order_number": _ds_order_uuid, "origin": True}
    _source_orderout = {"key": TABIT_SOURCE_KEY_FOR_ORDEROUT, "name": TABIT_SOURCE_KEY_FOR_ORDEROUT, "order_number": _ds_order_uuid, "origin": False}
    _payload["sources"] = [_source_ds, _source_orderout]

    # MAYBE WE NEED TO HANDLE THIS SITUATION, but as of August 18 2020 this is not a problem
    # if NOW, then send None
    # If there is a date, then format following the tabit documentation example https://inpact.github.io/tabit-middleware/webhooks.html#tag/Third-Party-API/paths/~1order/post
    ############################### in order to plugin the following code, I need to know in advance that what is the format of order.ready_by
    # from datetime import datetime
    # now = datetime.now()
    # date_time = now.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    # print(date_time)
    # print('2019-12-12T09:52:56.882000Z')
    #####################################

    _payload['pickup_eta'] = _get_eta(_ds.type.name, order.ready_by) #order.ready_by if order.ready_by.lower() != 'now' else None #as of August 18 2020, this logic is fine

    #delivery info
    _payload_delivery_info = {}
    _payload_delivery_info['type'] = TABIT_DELIVERY_TYPE_DELIVERY if order.type == OrderType.DELIVERY else TABIT_DELIVERY_TYPE_PICKUP
    _payload_delivery_info['phone'] = str(order.customer_phone)
    #delivery_address info
    _payload_delivery_address = {}
    _payload_delivery_address["city"] = order.delivery_city
    _payload_delivery_address["street"] = order.delivery_address
    # no need to pass below params now as only street is required and handle full address
    # _payload_delivery_address["house"] = ""
    # _payload_delivery_address["floor"] = None
    # _payload_delivery_address["entrance"] = None
    # _payload_delivery_address["apartment"] = None
    _payload_delivery_address["notes"] = order.delivery_instructions

    _payload_delivery_info['address'] = _payload_delivery_address
    _payload['delivery'] = _payload_delivery_info

    #payment info
    _payload_payment_info = {}
    if order.charge_customer_delivery_fee:
        _payload_payment_info["delivery"] = { "amount": format_amount_for_tabit(order.charge_customer_delivery_fee) , "currency":"USD"}
    if order.charge_tip:
        _payload_payment_info["tip"] = {"amount": format_amount_for_tabit(order.charge_tip), "currency":"USD"}
    if order.charge_tax:
        _payload_payment_info["taxes"] = {"amount": format_amount_for_tabit(order.charge_tax), "currency":"USD"}
    _payload["payment"] = _payload_payment_info

    #items info
    _payload["items"] = __format_item_for_tabit(order, unmapped_order_itens)

    #restaurant info
    _payload['restaurant'] = {'name': _restaurant.name}

    ##total price
    _payload_price = {}
    _payload_price["amount"] = format_amount_for_tabit(order.charge_total)
    _payload_price["currency"] = "USD"
    _payload["price"] = _payload_price

    return _payload

# Order UUID
############

def _get_source_name(name):
    if name.lower() == "ubereats":
        return "UberEATS"
    else:
        return name

def _get_source_key(name):
    key = name.lower()
    # key_map = {"ubereats":"ubereats","doordash":"doordash","grubhub":"grubhub"}
    # delivery_partner_name = name.lower()
    # key = key_map.get(delivery_partner_name,name)
    return key

def _get_eta(_ds_type, given_eta):
    if _ds_type == DeliveryServiceType.DOORDASH:
        time_part = given_eta.split("at")[1].strip()
        _d =  datetime.datetime.strptime(time_part,"%I:%M %p")
        today_date = datetime.datetime.now()
        today_date = today_date.replace(hour=_d.hour,minute=_d.minute,second=0,microsecond=0)
    elif _ds_type == DeliveryServiceType.UBEREATS:
        today_date = datetime.datetime.strptime(given_eta,"%m/%d/%y, %I:%M %p")
    elif _ds_type == DeliveryServiceType.GRUBHUB:
        today_date = datetime.datetime.strptime(given_eta,"%b %d, %Y, %I:%M %p")
    else:
        today_date = datetime.datetime.now()
    final_eta = today_date.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    return final_eta


def save_tabit_order_uuid(order_key, tabit_order_uuid):
    _order = order_key.get()
    _order.point_of_sale_uuid = tabit_order_uuid
    _order.put()
    return _order

# MENU ITEM
###########

def __format_item_for_tabit(order, unmapped_order_itens):
    _formatted_items = []
    for _order_item_key in order.order_items:
        _order_item = _order_item_key.get()
        if _order_item.menu_item:
            _ds_menu_item = _order_item.menu_item.get()
            _pos_menu_item = None
            if _ds_menu_item.mappedToMenuItem:
                _pos_menu_item = _ds_menu_item.mappedToMenuItem.get()
            else:
                _message = '400: Mapped Order Item in Tabit for Order Id %s not found' % (str(order.key.id()))
                report_warning(code=400, message=_message, data_dict={'order key': str(order.key.id())})
            # format payload
            _tabit_menu_item = __generate_tabit_menu_item(order_item=_order_item, ds_menu_item=_ds_menu_item, pos_menu_item=_pos_menu_item)
            _tabit_menu_item['options'] = __format_modifiers_for_tabit(order_key=order.key, order_item=_order_item)
            _formatted_items.append(_tabit_menu_item)
        else:
            _message = 'Incoming Order Id %s has a menu item not mapped' % (str(order.key.id()))
            report_warning(code=400, message=_message)

    for unmapped_order_item in unmapped_order_itens:
        _tabit_menu_item = __generate_tabit_menu_item_from_unmapped_order_item(unmapped_order_item)
        _tabit_menu_item["options"] = __format_unmapped_modifiers_for_tabit(unmapped_order_item["modifiers"])

    return _formatted_items


def __generate_tabit_menu_item_from_unmapped_order_item(unmapped_order_item):
    _tabit_menu_item = {}

    currency = "USD"

    _tabit_menu_item["base_price"] = {
        "amount": format_amount_for_tabit(unmapped_order_item["unit_price"]), "currency": currency,
    }

    _tabit_menu_item["price"] = {
        "amount": format_amount_for_tabit(unmapped_order_item["price"]), "currency": currency
    }

    _tabit_menu_item['count'] = int(unmapped_order_item["quantity"])
    _tabit_menu_item["note"] = unmapped_order_item["instruction"]
    _tabit_menu_item["id"] = str(uuid.uuid4())
    _tabit_menu_item["name"] = unmapped_order_item["name"]

    return _tabit_menu_item

def __generate_tabit_menu_item(order_item, ds_menu_item, pos_menu_item=None):
    # ORDER ITEM
    _tabit_menu_item = {}

    #order item base price dictionary
    _tabit_menu_item["base_price"] = {"amount": format_amount_for_tabit(order_item.unit_price), "currency": ds_menu_item.currency}
    _tabit_menu_item["price"] = {"amount": format_amount_for_tabit(order_item.price), "currency": ds_menu_item.currency}

    _tabit_menu_item['count'] = int(order_item.quantity)
    _tabit_menu_item["note"] = order_item.store_instructions
    if pos_menu_item:
        _tabit_menu_item["id"] = pos_menu_item.get_id()
        _tabit_menu_item["name"] = str(pos_menu_item.name)
        _tabit_menu_item["pos_id"] = str(pos_menu_item.uuid)
    else:
        _tabit_menu_item["id"] = order_item.get_id()
        _tabit_menu_item["name"] = str(ds_menu_item.name)

    return _tabit_menu_item

def __calculate_total_price_for_order_item_with_modifier(order_item):
    _total = order_item.price * order_item.quantity
    for _order_item_modifier_key in order_item.selected_modifier:
        _order_item_modifier = _order_item_modifier_key.get()
        _total += _order_item_modifier.price
    return _total

# MENU ITEM MODIFIERS
#####################


def __format_unmapped_modifiers_for_tabit(modifier_names):
    formatted_item_modifiers = []

    for modifier_name in modifier_names:
        tabit_menu_item_modifier = {
            "id": uuid.uuid4(),
            "count": 1,
            "price": {"amount": format_amount_for_tabit(0), "currency": "USD"},
            "value": modifier_name,
        }

        formatted_item_modifiers.append(tabit_menu_item_modifier)

    return formatted_item_modifiers



def __format_modifiers_for_tabit(order_key, order_item):
    # MODDIFIER
    _formatted_item_modifiers =[]
    # return _formatted_item_modifiers # as of now we are not implementing this section
    for _order_item_modifier_key in order_item.selected_modifier:
        _order_item_modifier = _order_item_modifier_key.get()
        if _order_item_modifier.menu_item_modifier:
            _ds_menu_item_modifier = _order_item_modifier.menu_item_modifier.get()
            _pos_menu_item_modifier = None
            import logging
            logging.info(order_key)
            if _ds_menu_item_modifier.mappedToMenuItemModifier:
                _pos_menu_item_modifier = _ds_menu_item_modifier.mappedToMenuItemModifier.get()
            else:
                _message = 'Mapped Order Item Modifier in Delivery Service in Tabit for Order Id %s not found' % (str(order_key.id()))
                report_warning(code=400, message=_message, data_dict={'order key': str(order_key.id())})
            # format payload
            _tabit_menu_item_modifier = __generate_tabit_menu_item_modifier(order_item_modifier=_order_item_modifier,
                                                                            ds_menu_item_modifier=_ds_menu_item_modifier,
                                                                            pos_menu_item_modifier=_pos_menu_item_modifier)
            _formatted_item_modifiers.append(_tabit_menu_item_modifier)
        else:
            _message = 'Mapped Order Item Modifier in Tabit for Order Id %s not found' % (str(order_key.id()))
            report_warning(code=400, message=_message, data_dict={'order key': str(order_key.id())})

    return _formatted_item_modifiers

def __generate_tabit_menu_item_modifier(order_item_modifier, ds_menu_item_modifier, pos_menu_item_modifier=None):
    # ORDER ITEM MODIFIERS
    _tabit_menu_item_modifier = {}
    _tabit_menu_item_modifier["count"] = 1
    _tabit_menu_item_modifier["price"] = {"amount": format_amount_for_tabit(order_item_modifier.price), "currency":"USD"}
    _tabit_menu_item_modifier["id"] = order_item_modifier.get_id()
    # This is for MenuItemModifier
    if pos_menu_item_modifier:
        _tabit_menu_item_modifier["value"] = str(pos_menu_item_modifier.name)
        _tabit_menu_item_modifier["value_pos_id"] = str(pos_menu_item_modifier.uuid)
        # This is for Modifier Group
        if len(pos_menu_item_modifier.groups) > 0:
            _pos_menu_item_modifier_group_key = pos_menu_item_modifier.groups[0]
            _pos_menu_item_modifier_group = _pos_menu_item_modifier_group_key.get()
            _tabit_menu_item_modifier["name"] = str(_pos_menu_item_modifier_group.name)
            _tabit_menu_item_modifier["pos_id"] = str(_pos_menu_item_modifier_group.uuid)
    else:
        _tabit_menu_item_modifier["value"] = str(ds_menu_item_modifier.name)
        # _tabit_menu_item_modifier["value_pos_id"] = None
        # This is for Modifier Group
        if len(ds_menu_item_modifier.groups) > 0:
            _ds_menu_item_modifier_group_key = ds_menu_item_modifier.groups[0]
            _ds_menu_item_modifier_group = _ds_menu_item_modifier_group_key.get()
            _tabit_menu_item_modifier["name"] = str(_ds_menu_item_modifier_group.name)
            # _tabit_menu_item_modifier["pos_id"] = None

    return _tabit_menu_item_modifier
