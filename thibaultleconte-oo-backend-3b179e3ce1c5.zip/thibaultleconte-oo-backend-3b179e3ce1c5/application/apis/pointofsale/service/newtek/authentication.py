# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 01/21/2019
#

from application.core.settings.app import get_config_for_key
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
import base64


def get_new_access_token(related_entities_keys):
    _client_id = get_config_for_key('NEWTEK_API_CLIENT_ID')
    _client_secret = get_config_for_key('NEWTEK_API_CLIENT_SECRET')
    _headers = __format_header_for_auth(_client_id, _client_secret)
    _payload = {'grant_type': 'client_credentials'}
    _url = get_config_for_key('NEWTEK_API_URL_BASE') + "/oauth/token"
    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.NEWTEK, method="POST", headers=_headers, data=_payload, related_entities_keys=related_entities_keys)
    if _status_code < 200 or _status_code > 299: return None, _status_code
    _access_token = _result_json.get('data').get('token').get('accessToken')
    return _access_token, _status_code

def refresh_access_token(pos_key, related_entities_keys):
    _access_token, _status_code = get_new_access_token(related_entities_keys)
    _pos = pos_key.get()
    _pos.access_token = _access_token
    _pos.put()
    return _access_token, _status_code

def __format_header_for_auth(client_id, client_secret):
    _authorization_encoded = base64.b64encode('%s:%s' % (str(client_id), str(client_secret)))
    return {'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': _authorization_encoded}
