# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 01/21/2019
#

def formatHeader(access_token):
    return {'Content-Type': 'application/json', 'Authorization': access_token}
