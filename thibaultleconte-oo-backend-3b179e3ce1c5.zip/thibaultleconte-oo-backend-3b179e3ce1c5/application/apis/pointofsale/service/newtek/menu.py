# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 01/21/2019
#

from application.apis.menu.service.menusync.creator import create_menu_sync
from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from application.apis.menu.service.menusync.fetch import fetch_menu_task_started, fetch_menu_task_finished
from application.apis.menu.service.menusync.process import process_menu_task_started
from application.core.error import report_error
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from authentication import refresh_access_token
from application.apis.menu.model.MenuSync import MenuSync
from application.core.settings.app import get_config_for_key
from common import formatHeader
from application.apis.menu.service.crud.section import create_update_menu_section
from application.apis.menu.service.crud.category import create_update_menu_category
from application.apis.menu.service.creator import generate_item_dict, generate_modifier_group_dict, generate_modifier_dict, startTaskToCreateOrUpdateMenuItemsAndModifiers
from application.core.parser.string import sanitize_str


DEFAULT_NEWTEK_MENU_SECTION_NAME = 'Menu'
DEFAULT_NEWTEK_MENU_CATEGORY_NAME = 'Main'

def get_menu(pointofsale_key):
    _pos = pointofsale_key.get()
    _menuSync = create_menu_sync(restaurant_key=_pos.restaurant, service_key=_pos.key)
    _pos.menuSync = _menuSync.key
    _pos.put()
    _task = _startTaskToFetchMenuFromNewTek(_menuSync.key)
    return _task

######
# Task
######

def _startTaskToFetchMenuFromNewTek(menu_sync_key):
    _ms = menu_sync_key.get()
    _task = addTask(category=CoreTaskCategory.NEWTEK_MENU_FETCH, entity=_ms)
    _menuSync = fetch_menu_task_started(menuSync_key=menu_sync_key, task_key=_task.key)
    return _task

def processTaskToFetchMenuFromNewTek(menu_sync_id):
    _task_result_json = {}
    _ms = MenuSync.get_by_id(menu_sync_id)
    if not _ms:
        _task_result_json['processTaskToFetchMenuFromNewTek'] = {'message': 'MenuSync with id %s not found' % (str(menu_sync_id))}
    elif not _ms.service:
        _task_result_json['processTaskToFetchMenuFromNewTek'] = {'message': 'MenuSync with id %s has no ds' % (str(menu_sync_id))}
    else:
        _pos = _ms.service.get()

        # Related entities
        _related_entities_keys = [_ms.key]
        _related_entities_keys.append(_ms.restaurant)
        _related_entities_keys.append(_pos.account)
        _related_entities_keys.append(_pos.key)
        # request

        _headers = formatHeader(_pos.access_token)
        _url, _status_code, _result_json = __start_fetch_menu_request(menusync_key=_ms.key, headers=_headers, service_merchant_id=_pos.service_merchant_id, related_entities_keys=_related_entities_keys)
        # refresh access token if unauthorized because it expired
        if _status_code == 401:
            _access_token, _status_code = refresh_access_token(_ms.service, related_entities_keys=_related_entities_keys)
            if _access_token:
                _headers = formatHeader(_access_token)
                _url, _status_code, _result_json = __start_fetch_menu_request(menusync_key=_ms.key, headers=_headers, service_merchant_id=_pos.service_merchant_id, related_entities_keys=_related_entities_keys)

        _task_result_json['__start_fetch_menu_request'] = {'url': _url,
                                                           'status_code': _status_code,
                                                           'result_json': _result_json}
        if _status_code >= 200 and _status_code <= 299:
            _menu_items = __process_menu_v2(_ms, _result_json)
            process_menu_task_started(menuSync_key=_ms.key, tasks_keys=_menu_items)
            _task_result_json['__parse_menu'] = {'message': "Point Of Sale has fetched %s menu items" % (str(_menu_items))}

            from application.apis.menu.service.stats import refresh_stats
            refresh_stats(menu_sync_key=_ms.key)
            from application.apis.menu.service.menusync.process import manage_menu_task
            manage_menu_task(menu_sync_key=_ms.key)

        else:
            report_error(code=_status_code, subject="GetNewTekMenu-Error", message="Menu Sync %s returned %s" % (str(_ms.key.id()), str(_status_code)))
    return _task_result_json

############
# Fetch Menu
############

def __start_fetch_menu_request(menusync_key, headers, service_merchant_id, related_entities_keys):
    _url = get_config_for_key('NEWTEK_API_URL_BASE') + "/api/menu/" + str(service_merchant_id)
    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.NEWTEK, method="GET", headers=headers, related_entities_keys=related_entities_keys)
    if _status_code < 200 or _status_code > 299:
        fetch_menu_task_finished(menuSync_key=menusync_key, success=False)
        return _url, _status_code, None
    fetch_menu_task_finished(menuSync_key=menusync_key, success=True)
    return _url, _status_code, _result_json

#################
# Process Menu V1
#################

def __process_menu_v1(menu_sync, raw_data):
    _items_tasks = []
    _section = create_update_menu_section(menu_sync_key=menu_sync.key, name=DEFAULT_NEWTEK_MENU_SECTION_NAME)
    if 'data' in raw_data:
        _raw_elements = raw_data.get('data')
        if 'groups' in _raw_elements:
            raw_categories = _raw_elements.get('groups')
            _items_tasks.extend(__parse_items(menu_sync, raw_categories, _section.key))
    return _items_tasks

def __parse_items(menu_sync, raw_categories, section_key):
    _items_tasks = []
    for _raw_category in raw_categories:
        # CATEGORY
        _raw_menu_category_name, _raw_menu_category_uuid = __get_category_name_and_uuid(_raw_category)
        _category = create_update_menu_category(menu_sync_key=menu_sync.key,
                                                section_key=section_key,
                                                name=_raw_menu_category_name,
                                                uuid=_raw_menu_category_uuid)
        # MENU ITEMS
        if 'items' in _raw_category:
            for _raw_item in _raw_category.get('items'):
                # Modifiers
                _modifier_groups = __parse_modifier_groups(_raw_item)
                # MENU ITEM
                _mi = generate_item_dict(name=_raw_item.get('name'),
                                         price=_raw_item.get('price'),
                                         modifier_groups=_modifier_groups,
                                         uuid=_raw_item.get('id'),
                                         is_available=__parse_status_available(_raw_item.get('status')),
                                         category_id=_category.get_id())
                # Tasks
                _task = startTaskToCreateOrUpdateMenuItemsAndModifiers(menu_sync, _mi)
                if _task: _items_tasks.append(_task.key)
    return _items_tasks

def __get_category_name_and_uuid(raw_category):
    _raw_menu_category_name = sanitize_str(raw_category.get('name'))
    _raw_menu_category_uuid = sanitize_str(raw_category.get('id'))
    return _raw_menu_category_name, _raw_menu_category_uuid

def __parse_modifier_groups(raw_item):
    modifier_groups = []
    if 'modifier_groups' in raw_item:
        raw_modifierGroups = raw_item['modifier_groups']
        for raw_element in raw_modifierGroups:
            _group_name = raw_element.get('name')
            _group_uuid = raw_element.get('id')
            _modifiers = __parse_modifiers(raw_element)
            _group = generate_modifier_group_dict(name=_group_name,
                                                  modifiers=_modifiers,
                                                  uuid=_group_uuid,)
            modifier_groups.append(_group)
    return modifier_groups

def __parse_modifiers(raw_element):
    modifiers = []
    if 'modifiers' in raw_element:
        raw_modifiers = raw_element['modifiers']
        for _raw_element in raw_modifiers:
            _mod = generate_modifier_dict(name=_raw_element.get('name'),
                                          price=_raw_element.get('price'),
                                          uuid=_raw_element.get('id'),
                                          is_available=__parse_status_available(_raw_element.get('status')))
            modifiers.append(_mod)
    return modifiers

def __parse_status_available(raw_status):
    if sanitize_str(raw_status) == 'active': return True
    return False

#################
# Process Menu V2
#################

from google.appengine.ext import ndb
from application.apis.menu.model.MenuSection import MenuSection
from application.apis.menu.model.MenuCategory import MenuCategory
from application.apis.menu.model.MenuItem import MenuItem
from application.apis.menu.model.MenuModifierGroup import MenuModifierGroup
from application.apis.menu.model.MenuItemModifier import MenuItemModifier
from application.apis.menu.service.availability import fetch_availability

def __process_menu_v2(menu_sync, raw_data):
    raw_categories = raw_data.get('data').get('groups')
    _raw_items = []
    for _raw_category in raw_categories:
        if 'items' in _raw_category:
            for _raw_item in _raw_category.get('items', []):
                _raw_items.append(_raw_item)
    
    # Menu Modifier Groups
    _modifier_groups_dict, _modifiers_dict = __create_modifier_groups_v2(menu_sync, _raw_items)

    # Menu Categories
    _categories_dict, _items_dict = __create_categories_v2(menu_sync, raw_categories)

    # Items for Newtek which means Menu Item and Modifiers all together
    _items_dict = __create_items_v2(menu_sync, _raw_items, _items_dict)

    # Modifiers for UberEats which means Menu Item and Modifiers all together
    _modifiers_dict = __create_modifiers_v2(menu_sync, _raw_items, _modifiers_dict)

    # Menu Sections
    _sections = __create_sections_v2(menu_sync, _categories_dict)

    # #####
    # # MAP
    # #####

    # MAP Menu Items to Categories
    _items_dict, categories_dict = __map_items_to_categories_v2(raw_categories, _items_dict, _categories_dict)

    # MAP Menu Items and Modifier Groups
    items_dict, modifier_groups_dict = _map_modifier_groups_to_items_v2(_raw_items, _items_dict, _modifier_groups_dict)

    # MAP Menu Modifiers and Modifier Groups
    _modifiers_dict, modifier_groups_dict = _map_modifiers_to_modifier_groups_v2(_raw_items, _modifiers_dict, _modifier_groups_dict)

    _total_items_and_modifiers = len(items_dict) + len(_modifiers_dict)
    return _total_items_and_modifiers

def __create_sections_v2(menu_sync, categories_dict):
    _categories_keys = []
    for _raw_category_id in categories_dict.keys():
        _category = categories_dict.get(sanitize_str(_raw_category_id))
        _categories_keys.append(_category.key)
    
    _section = MenuSection(menuSync=menu_sync.key,
                            name='Menu',
                            availability=fetch_availability('Menu', []),
                            position=1,
                            uuid=None,
                            description=None,
                            categories=_categories_keys)
    _sections = [_section]

    _ = ndb.put_multi(_sections)
    return _sections

def __create_categories_v2(menu_sync, raw_categories):
    _categories = []
    _categories_dict = {}
    _items_dict = {}

    for _raw_category in raw_categories:
        _raw_category_uuid = sanitize_str(_raw_category.get('id', None))
        _category = MenuCategory(menuSync=menu_sync.key,
                                 name=_raw_category.get("name", None),
                                 uuid=_raw_category_uuid)
        _categories.append(_category)

        _categories_dict[_raw_category_uuid] = _category

        # pre-create dict of items with uuid
        if 'items' in _raw_category:
            for _raw_item in _raw_category.get('items', []):
                _items_dict[sanitize_str(_raw_item.get('id'), lower_case=False)] = None

    _ = ndb.put_multi(_categories)

    return _categories_dict, _items_dict

def __create_items_v2(menu_sync, _raw_items, items_dict):
    _items = []
    for raw_item in _raw_items:
        _raw_item_uuid = sanitize_str(raw_item.get('id', None), lower_case=False)
        if _raw_item_uuid in items_dict and items_dict[_raw_item_uuid] == None:
            _item = MenuItem(menuSync=menu_sync.key,
                    name=raw_item.get("name", None),
                    uuid=_raw_item_uuid,
                    price=raw_item.get("price", None),
                    is_available=__parse_status_available(raw_item.get("status")))
            _items.append(_item)

            items_dict[_raw_item_uuid] = _item

    _ = ndb.put_multi(_items)
    
    return items_dict

def __create_modifier_groups_v2(menu_sync, _raw_items):
    _modifier_groups = []
    _modifier_groups_dict = {}
    _modifiers_dict = {}

    for raw_item in _raw_items:
        if 'modifier_groups' in raw_item:
            raw_modifierGroups = raw_item['modifier_groups']
            for _raw_modifier_group in raw_modifierGroups:
                _raw_modifier_group_uuid = sanitize_str(_raw_modifier_group.get('id', None), lower_case=False)

                if _raw_modifier_group_uuid not in _modifier_groups_dict:
                    _modifier_group = MenuModifierGroup(menuSync=menu_sync.key,
                                                        name=_raw_modifier_group.get('name', None),
                                                        max_permitted=_raw_modifier_group.get('max_permitted', 1),
                                                        min_permitted=_raw_modifier_group.get('min_permitted', 0),
                                                        uuid=_raw_modifier_group_uuid)
                    _modifier_groups.append(_modifier_group)

                    _modifier_groups_dict[_raw_modifier_group_uuid] = _modifier_group

                # pre-create dict of modifiers with uuid
                _modifier_options_raw = _raw_modifier_group.get('modifiers') if _raw_modifier_group.get('modifiers') is not None else []
                for _raw_modifier in _modifier_options_raw:
                    _modifiers_dict[sanitize_str(_raw_modifier.get('id'), lower_case=False)] = None

    _ = ndb.put_multi(_modifier_groups)

    return _modifier_groups_dict, _modifiers_dict

def __create_modifiers_v2(menu_sync, _raw_items, modifiers_dict):
    _modifiers = []
    for raw_item in _raw_items:
        if 'modifier_groups' in raw_item:
            raw_modifierGroups = raw_item['modifier_groups']
            
            for _raw_modifier_group in raw_modifierGroups:
                if 'modifiers' in _raw_modifier_group:
                    raw_modifiers = _raw_modifier_group['modifiers']
                    
                    for _raw_modifier in raw_modifiers:
                        _raw_modifier_uuid = sanitize_str(_raw_modifier.get('id', None), lower_case=False)
                        
                        if _raw_modifier_uuid in modifiers_dict and modifiers_dict[_raw_modifier_uuid] == None:
                            _modifier = MenuItemModifier(menuSync=menu_sync.key,
                                                        name=_raw_modifier.get('name', None),
                                                        uuid=_raw_modifier_uuid,
                                                        price=_raw_modifier.get('price', 0),
                                                        is_available=__parse_status_available(_raw_modifier.get('status')))
                            _modifiers.append(_modifier)

                            modifiers_dict[_raw_modifier_uuid] = _modifier

    _ = ndb.put_multi(_modifiers)

    return modifiers_dict

# #####
# # MAP
# #####

def __map_items_to_categories_v2(raw_categories, items_dict, categories_dict):
    _items = []

    for _raw_category in raw_categories:
        _raw_category_uuid = sanitize_str(_raw_category.get('id', None))
        _category = categories_dict.get(_raw_category_uuid)

        # pre-create dict of items with uuid
        if 'items' in _raw_category:
            for _raw_item in _raw_category.get('items', []):
                _raw_item_uuid = sanitize_str(_raw_item.get('id'), lower_case=False)
                _item = items_dict.get(_raw_item_uuid)
                _categories_keys = _item.categories if _item.categories else []
                if _category.key not in _categories_keys: _categories_keys.append(_category.key)
                _item.categories = _categories_keys
                _items.append(_item)

    _ = ndb.put_multi(_items)
    return items_dict, categories_dict

def _map_modifier_groups_to_items_v2(raw_items, items_dict, modifier_groups_dict):
    _items = []
    _modifier_groups = []

    for _raw_item in raw_items:
        _raw_item_uuid = sanitize_str(_raw_item.get('id', None), lower_case=False)

        if _raw_item_uuid in items_dict:
            _item = items_dict.get(_raw_item_uuid)
            _item_modifiers_groups_keys = _item.modifier_groups if _item.modifier_groups else []

            _raw_modifier_group_uuids = []
            if 'modifier_groups' in _raw_item:
                raw_modifierGroups = _raw_item['modifier_groups']
                for _raw_modifier_group in raw_modifierGroups:
                    _raw_modifier_group_uuid = sanitize_str(_raw_modifier_group.get('id', None), lower_case=False)
                    _modifier_group = modifier_groups_dict.get(_raw_modifier_group_uuid)

                    _modifier_group_items_keys = _modifier_group.items if _modifier_group.items else []
                    if _item.key not in _modifier_group_items_keys: _modifier_group_items_keys.append(_item.key)
                    _modifier_group.items = _modifier_group_items_keys
                    _modifier_groups.append(_modifier_group)

                    if _modifier_group.key not in _item_modifiers_groups_keys: _item_modifiers_groups_keys.append(_modifier_group.key)

                if _item_modifiers_groups_keys:
                    _item.modifier_groups = _item_modifiers_groups_keys
                    _items.append(_item)

    _ = ndb.put_multi(_items)
    _ = ndb.put_multi(_modifier_groups)
    return items_dict, modifier_groups_dict

def _map_modifiers_to_modifier_groups_v2(raw_items, modifiers_dict, modifier_groups_dict):
    _modifiers = []
    _modifier_groups = []

    for _raw_item in raw_items:
        if 'modifier_groups' in _raw_item:
            raw_modifier_groups = _raw_item['modifier_groups']
            for _raw_modifier_group in raw_modifier_groups:
                _raw_modifier_group_uuid = sanitize_str(_raw_modifier_group.get('id', None), lower_case=False)

                _modifier_group = modifier_groups_dict.get(_raw_modifier_group_uuid)
                _modifier_group_property_modifiers_keys = _modifier_group.modifiers if _modifier_group.modifiers else []

                _modifier_options_raw = _raw_modifier_group.get('modifiers') if _raw_modifier_group.get('modifiers') is not None else []
                for _raw_modifier in _modifier_options_raw:
                    _raw_modifier_uuid = sanitize_str(_raw_modifier.get('id', None), lower_case=False)
                    _modifier = modifiers_dict.get(_raw_modifier_uuid)

                    if _modifier is not None:
                        _modifier_property_groups_keys = _modifier.groups if _modifier.groups else []
                        if _modifier_group.key not in _modifier_property_groups_keys: _modifier_property_groups_keys.append(_modifier_group.key)
                        _modifier.groups = _modifier_property_groups_keys
                        _modifiers.append(_modifier)

                        if _modifier.key not in _modifier_group_property_modifiers_keys: _modifier_group_property_modifiers_keys.append(_modifier.key)

                if _modifier_group_property_modifiers_keys:
                    _modifier_group.modifiers = _modifier_group_property_modifiers_keys
                    _modifier_groups.append(_modifier_group)

    _ = ndb.put_multi(_modifiers)
    _ = ndb.put_multi(_modifier_groups)
    return modifiers_dict, modifier_groups_dict