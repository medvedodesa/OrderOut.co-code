# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 08/24/2020
#

from application.core.settings.app import get_config_for_key
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from common import formatHeader


def test_connection(point_of_sale_key):
    # related entities
    _related_entities_keys = [point_of_sale_key]
    _point_of_sale = point_of_sale_key.get()
    _related_entities_keys.append(_point_of_sale.account)
    _related_entities_keys.append(_point_of_sale.restaurant)
    # request
    _pos = point_of_sale_key.get()
    _headers = formatHeader(_pos.access_token)
    _url = get_config_for_key('NEWTEK_API_URL_BASE') + "/api/menu/" + str(_pos.service_merchant_id)
    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.NEWTEK, method="GET", headers=_headers, related_entities_keys=_related_entities_keys)
    if not _result_json and not _status_code: return False
    if _status_code < 200 or _status_code > 299: return False
    return True
