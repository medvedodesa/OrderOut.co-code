# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 01/21/2019
#

from ..common import check_point_of_sale_already_connected
from application.apis.ooexceptions import ConflictResourceAlreadyExistsError, Unauthorized
from ..common import createPointOfSale
from application.apis.pointofsale.model.PointOfSale import PointOfSaleType
from authentication import get_new_access_token
from menu import get_menu


def connect_newtek_store_uuid_to_restaurant(account_key, restaurant_key, newtek_store_uuid):
    if check_point_of_sale_already_connected(restaurant_key=restaurant_key):
        raise ConflictResourceAlreadyExistsError

    _related_entities_keys = [account_key, restaurant_key]

    _access_token, _status_code = get_new_access_token(related_entities_keys=_related_entities_keys)
    if not _access_token: raise Unauthorized

    _pos = createPointOfSale(type=PointOfSaleType.NEWTEK,
                             account_key=account_key,
                             restaurant_key=restaurant_key,
                             service_merchant_id=newtek_store_uuid,
                             access_token=_access_token)
    _task = get_menu(_pos.key)
    return _pos
