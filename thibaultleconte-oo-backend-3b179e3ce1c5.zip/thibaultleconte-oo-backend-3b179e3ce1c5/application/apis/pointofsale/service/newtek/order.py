# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 01/21/2019
#

from common import formatHeader
from application.core.settings.app import get_config_for_key
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.error import report_error, report_warning
from authentication import refresh_access_token
import datetime
from application.core.parser.string import sanitize_str
from application.core.datetime.timezone import convert_utc_datetime_to_zipcode_timezone

NEWTEK_UNRECOGNIZED_NAME = 'Unrecognized'
NEWTEK_UNRECOGNIZED_ID = -1


def push_order(order_key, point_of_sale_key):
    _order = order_key.get()
    _pos = point_of_sale_key.get()

    _payload = __generate_order_payload(_order)

    _order_uuid = __create_order_on_newtek(_pos, _payload, _order)

    _order = __save_newtek_order_uuid(_order, _order_uuid)

    return True

def __create_order_on_newtek(pos, payload, order):
    # Related entities
    _related_entities_keys = [pos.key]
    _related_entities_keys.append(pos.account)
    _related_entities_keys.append(pos.restaurant)
    _related_entities_keys.append(pos.menuSync)
    _related_entities_keys.append(order.delivery_service)
    _related_entities_keys.append(order.key)
    # request
    _headers = formatHeader(pos.access_token)
    _url = get_config_for_key('NEWTEK_API_URL_BASE') + "/api/order"
    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.NEWTEK, method="POST", headers=_headers, data=payload, related_entities_keys=_related_entities_keys)

    # refresh access token if unauthorized because it expired
    if _status_code == 401:
        _access_token, _status_code = refresh_access_token(pos.key, related_entities_keys=_related_entities_keys)
        if _access_token:
            _headers = formatHeader(_access_token)
            _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.NEWTEK, method="POST", headers=_headers, data=payload, related_entities_keys=_related_entities_keys)

    if _status_code < 200 or _status_code > 299:
        report_error(code=500, message='__create_order_on_newtek return status code %s' % (str(_status_code)))
        return None

    _order_uuid = None
    if 'data' in _result_json:
        _raw_elements = _result_json.get('data')
        if 'oid' in _raw_elements:
            _order_uuid = sanitize_str(_raw_elements.get('oid'))
    return _order_uuid

def __generate_order_payload(order):
    _payload = {}

    _restaurant = order.restaurant.get()
    _pos = _restaurant.point_of_sale.get()
    _ds = order.delivery_service.get()

    _ds_order_uuid = order.delivery_service_short_uuid if order.delivery_service_short_uuid else order.delivery_service_uuid

    # order
    _payload_order = {}
    # _payload_order['order_id'] = int(0) # str(order.key.id()) POSONCLOUD have security measusres against 16 digits
    _payload_order['store_id'] = _pos.service_merchant_id
    _payload_order['order_reference'] = _ds_order_uuid
    _payload_order['order_date'] = __format_date(order.api_created_at, _restaurant.zipcode, _restaurant.key.id())
    _payload_order['subtotal'] = float(order.charge_subtotal)
    _payload_order['tax'] = float(order.charge_tax)
    _payload_order['total'] = float(order.charge_total)
    _payload_order['discount'] = float(0.0) # Information not shared with us so we use a default value - Required field
    _payload_order['tip'] = float(order.charge_tip)
    _payload_order['order_type'] = str(order.type)
    _payload_order['order_status'] = str(order.status)
    _payload_order['notes'] = str(order.store_instructions)
    _payload_order['coupon_code'] = "" # Information not shared with us so we use a default value - Required field
    _payload['order'] = _payload_order

    # customer_info
    _payload_customer_info = {}
    _payload_customer_info['name'] = str(order.customer_name)
    _payload_customer_info['phone'] = str(order.customer_phone)
    _payload_customer_info['email'] = str(order.customer_email) if order.customer_email else ""
    _payload['customer_info'] = _payload_customer_info

    # items
    _payload_items = {}
    _payload['items'] = __format_item_for_newtek(order)

    # payment
    _payload_payment = {}
    _payload_payment['payment_reference_number'] = _ds_order_uuid
    _payload_payment['pay_date'] = __format_date(order.api_created_at, _restaurant.zipcode, _restaurant.key.id())
    _payload_payment['pay_type'] = str(_ds.type)
    _payload_payment['payment_method'] = str(order.charge_mode)
    _payload_payment['tax'] = float(order.charge_tax)
    _payload_payment['total'] = float(order.charge_total)
    _payload_payment['tip'] = float(order.charge_tip)
    _payload['payment'] = _payload_payment

    # delivery
    _payload_delivery = {}

    if order.ready_by and order.ready_by.lower() == "none": order.ready_by = None
    _order_ready_by = order.ready_by.capitalize() if order.ready_by else 'Now'

    _payload_delivery['time'] = str(_order_ready_by)
    _formatted_address = ""
    if order.delivery_address: _formatted_address += str(order.delivery_address)
    if order.delivery_city: _formatted_address += ", " + str(order.delivery_city)
    if order.delivery_state: _formatted_address += ", " + str(order.delivery_state)
    if order.delivery_zip: _formatted_address += ", " + str(order.delivery_zip)
    _payload_delivery['address'] = _formatted_address
    _payload_delivery['delivery_instructions'] = str(order.delivery_instructions)
    _payload_delivery['fees'] = float(order.charge_customer_delivery_fee)
    _payload_delivery['service_fee'] = float(order.charge_fee)
    _payload['delivery'] = _payload_delivery

    return _payload

def __save_newtek_order_uuid(order, newtek_order_uuid):
    order.point_of_sale_uuid = newtek_order_uuid
    order.put()
    return order

# MENU ITEM
###########

def __format_item_for_newtek(order):
    _formatted_items =[]
    for _order_item_key in order.order_items:
        _order_item = _order_item_key.get()
        if _order_item.menu_item:
            _ds_menu_item = _order_item.menu_item.get()
            if _ds_menu_item.mappedToMenuItem:
                _pos_menu_item = _ds_menu_item.mappedToMenuItem.get()
                if _pos_menu_item:
                    _newtek_menu_item = __generate_newtek_menu_item(order_item=_order_item, pos_menu_item=_pos_menu_item)
                    _newtek_menu_item['modifiers'] = __format_modifiers_for_newtek(order_key=order.key, order_item=_order_item)
                    _formatted_items.append(_newtek_menu_item)
                else:
                    _message = 'Order Item in NewTek for Order Id %s not found' % (str(order.key.id()))
                    report_error(code=500, message=_message)
            else:
                _newtek_menu_item = __generate_newtek_menu_item(order_item=_order_item)
                _newtek_menu_item['modifiers'] = __format_modifiers_for_newtek(order_key=order.key, order_item=_order_item)
                _formatted_items.append(_newtek_menu_item)
                _message = 'Mapped Order Item in NewTek for Order Id %s not found' % (str(order.key.id()))
                report_warning(code=400, message=_message, data_dict={'order key': str(order.key.id())})
        else:
            _message = 'Incoming Order Id %s has a menu item not mapped' % (str(order.key.id()))
            report_warning(code=400, message=_message)
    return _formatted_items

def __generate_newtek_menu_item(order_item, pos_menu_item=None):
    # ORDER ITEM
    _newtek_menu_item = {"price": float(order_item.unit_price),
                         "quantity": int(order_item.quantity),
                         "amount": float(order_item.price),
                         "item_notes": str(order_item.store_instructions),
                         "tip": 0}
    if pos_menu_item:
        _newtek_menu_item['description'] = str(pos_menu_item.name)
        _newtek_menu_item['id'] = str(pos_menu_item.uuid)
    else:
        _newtek_menu_item['description'] = NEWTEK_UNRECOGNIZED_NAME
        _newtek_menu_item['id'] = str(NEWTEK_UNRECOGNIZED_ID)
    return _newtek_menu_item

# MENU ITEM MODIFIERS
#####################

def __format_modifiers_for_newtek(order_key, order_item):
    # MODDIFIER
    _formatted_item_modifiers =[]
    for _order_item_modifier_key in order_item.selected_modifier:
        _order_item_modifier = _order_item_modifier_key.get()
        if _order_item_modifier.menu_item_modifier:
            _ds_menu_item_modifier = _order_item_modifier.menu_item_modifier.get()
            if _ds_menu_item_modifier.mappedToMenuItemModifier:
                _pos_menu_item_modifier = _ds_menu_item_modifier.mappedToMenuItemModifier.get()
                if _pos_menu_item_modifier:
                    _clover_menu_item_modifier = __generate_newtek_menu_item_modifier(order_item_modifier=_order_item_modifier,
                                                                                      pos_menu_item_modifier=_pos_menu_item_modifier)
                    _formatted_item_modifiers.append(_clover_menu_item_modifier)
                else:
                    _message = 'Order Item Modifier in NewTek for Order Id %s not found' % (str(order_key.id()))
                    report_error(code=500, message=_message, data_dict={'order key': str(order_key.id())})
            else:
                _clover_menu_item_modifier = __generate_newtek_menu_item_modifier(order_item_modifier=_order_item_modifier)
                _formatted_item_modifiers.append(_clover_menu_item_modifier)
                _message = 'Mapped Order Item Modifier in Delivery Service in NewTek for Order Id %s not found' % (str(order_key.id()))
                report_warning(code=400, message=_message, data_dict={'order key': str(order_key.id())})
        else:
            _message = 'Mapped Order Item Modifier in NewTek for Order Id %s not found' % (str(order_key.id()))
            report_warning(code=400, message=_message, data_dict={'order key': str(order_key.id())})

    return _formatted_item_modifiers

def __generate_newtek_menu_item_modifier(order_item_modifier, pos_menu_item_modifier=None):
    # ORDER ITEM MODIFIERS
    _newtek_menu_item_modifier = {"price": float(order_item_modifier.price),
                                  "quantity": 1,
                                  "amount": float(order_item_modifier.price),
                                  "notes": ""}
    if pos_menu_item_modifier:
        _newtek_menu_item_modifier['description'] = str(pos_menu_item_modifier.name)
        _newtek_menu_item_modifier['modifier_id'] = str(pos_menu_item_modifier.uuid)
    else:
        _newtek_menu_item_modifier['description'] = NEWTEK_UNRECOGNIZED_NAME
        _newtek_menu_item_modifier['modifier_id'] = NEWTEK_UNRECOGNIZED_ID
    return _newtek_menu_item_modifier

# HELPER

def __format_date(date_to_format, restaurant_zipcode, restaurant_key_id):
    _local_time = convert_utc_datetime_to_zipcode_timezone(date_to_format, restaurant_zipcode, restaurant_key_id)
    return str(_local_time.strftime("%Y-%m-%d %H:%M:%S"))
