# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/27/2019
#

from ..model.PointOfSale import PointOfSale, PointOfSaleType
from .clover.menu import get_menu as get_clover_menu
from .newtek.menu import get_menu as get_newtek_menu
from .tabit.menu import get_menu as get_tabit_menu
from .clover.connection import test_connection as test_clover_connection
from .newtek.connection import test_connection as test_newtek_connection
from .tabit.connection import test_connection as test_tabit_connection


def check_point_of_sale_already_connected(restaurant_key):
    _restaurant = restaurant_key.get()
    if _restaurant.point_of_sale:
        return True
    return False

def get_point_of_sale_for_restaurant(restaurant_key):
    _query = PointOfSale.query()
    _query = _query.filter(PointOfSale.restaurant == restaurant_key)
    _results = _query.fetch()
    return _results

def start_fetching_menu_for_point_of_sale(point_of_sale_key):
    _pos = point_of_sale_key.get()
    if _pos.type == PointOfSaleType.CLOVER:
        _task = get_clover_menu(_pos.key)
        return _task
    if _pos.type == PointOfSaleType.NEWTEK:
        _task = get_newtek_menu(_pos.key)
        return _task
    if _pos.type == PointOfSaleType.TABIT:
        _task = get_tabit_menu(_pos.key)
        return _task
    return False

def test_connection_for_point_of_sale(point_of_sale_key):
    _result = False
    _pos = point_of_sale_key.get()
    if _pos.type == PointOfSaleType.CLOVER:
        _result = test_clover_connection(_pos.key)
    if _pos.type == PointOfSaleType.NEWTEK:
        _result = test_newtek_connection(_pos.key)
    if _pos.type == PointOfSaleType.TABIT:
        _task = test_tabit_connection(_pos.key)
    return _result

def createPointOfSale(type, account_key, restaurant_key, service_merchant_id, access_token=None, service_employee_id=None, service_client_id=None):
    _pos = PointOfSale()
    _pos.type = type
    _pos.account = account_key
    _pos.restaurant = restaurant_key
    _pos.access_token = access_token
    _pos.service_merchant_id = service_merchant_id
    _pos.service_employee_id = service_employee_id
    _pos.service_client_id = service_client_id
    _pos.put()
    _restaurant = restaurant_key.get()
    _restaurant.point_of_sale = _pos.key
    _restaurant.put()
    return _pos

def disconnect(point_of_sale_key):
    _pos = point_of_sale_key.get()
    if _pos.restaurant:
        _restaurant = _pos.restaurant.get()
        _restaurant.point_of_sale = None
        _restaurant.put()
    _pos.delete()
    return True
