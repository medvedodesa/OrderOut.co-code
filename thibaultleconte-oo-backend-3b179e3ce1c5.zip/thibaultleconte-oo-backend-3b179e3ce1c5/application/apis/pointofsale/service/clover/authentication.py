# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/22/2019
#


from flask import current_app
from application.core.urlFetch.service import fetch_with_url_encoded_data, fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from .lead import fetch_by_merchant_id as fetch_clover_lead
from .lead import create as create_clover_lead
from .lead import update_clover_authentication
from application.core.exception import NotFound, BadRequest
from application.core.settings.app import get_config_for_key
from application.core.event.model import CoreEventCategory
from application.core.event.service import create_event
from ...model.PointOfSale import PointOfSale
import json
import logging


#####
# WEB
#####

def process_web_callback(clover_merchant_id, clover_employee_id, clover_client_id, clover_auth_code):
    _url = get_config_for_key('CLOVER_URL_AUTH_BASE')
    _url += "/oauth/token?client_id=" + get_config_for_key('CLOVER_APP_ID')
    _url += "&client_secret=" + get_config_for_key('CLOVER_APP_SECRET')
    _url += "&code=" + str(clover_auth_code)
    _result_json, _status_code, _request_key = fetch_with_url_encoded_data(url=_url, service=UrlFetchService.CLOVER, method="GET")

    if 'access_token' not in _result_json:
        _message = "access_token not in clover _result_json"
        _payload = {'clover_client_id': clover_client_id, 'result_json': _result_json, 'url': _url}
        create_event(category=CoreEventCategory.OAUTH,
                     name='CLOVER',
                     success=False,
                     message=_message,
                     payload=_payload)
        logging.error(_message)
        raise BadRequest
    _clover_access_token = _result_json['access_token']

    _clover_headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + _clover_access_token}
    _url = get_config_for_key('CLOVER_URL_API_BASE') + "merchants/" + clover_merchant_id + "?expand=owner,address"
    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.CLOVER, method="GET", headers=_clover_headers)

    _clover_lead = fetch_clover_lead(clover_merchant_id, clover_employee_id)
    if not _clover_lead:
        logging.info('Creating NEW Clover Lead for Clover Merchant ID %s' % (str(clover_merchant_id)))
        _clover_lead = create_clover_lead(clover_merchant_id,
                                          clover_employee_id,
                                          _clover_access_token,
                                          _result_json,
                                          clover_client_id,
                                          clover_auth_code)
    else:
        logging.info('Updating existing Clover Lead %s for Clover Merchant ID %s' % (str(_clover_lead.key.id()), str(clover_merchant_id)))
        _clover_lead = update_clover_authentication(clover_lead_key=_clover_lead.key,
                                                    clover_access_token=_clover_access_token,
                                                    clover_auth_code=clover_auth_code)
        _pos = PointOfSale.get_by_merchant_id(merchant_id=_clover_lead.merchant_id)
        if _pos:
            _pos = update_clover_access_token(point_of_sale_key=_pos.key, clover_lead_key=_clover_lead.key)

    # check if at least one delivery service is set to enabled. If not, it means the customer never finished the setup flow
    _clover_lead_delivery_services = json.loads(_clover_lead.delivery_services)
    _clover_lead_is_new = True
    for _ds in _clover_lead_delivery_services:
        if _ds.get('selected') == True:
            _clover_lead_is_new = False
            break

    return _clover_lead, _clover_lead_is_new


####################
# CLOVER ANDROID POS
####################

def process_pos_callback(clover_merchant_id, clover_access_token):

    # fetch merchant info
    _clover_headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + clover_access_token}
    _url = get_config_for_key('CLOVER_URL_API_BASE') + "merchants/" + clover_merchant_id + "?expand=owner,address"
    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.CLOVER, method="GET", headers=_clover_headers)
    _clover_employee_id = _result_json.get('owner',{}).get('id')

    if not _clover_employee_id: return None, None

    # create lead
    _clover_lead = fetch_clover_lead(clover_merchant_id, _clover_employee_id)
    if not _clover_lead:
        logging.info('Creating NEW Clover Lead')
        _clover_lead = create_clover_lead(clover_merchant_id,
                                          _clover_employee_id,
                                          clover_access_token,
                                          _result_json)
    else:
        logging.info('Updating existing Clover Lead')
        _clover_lead = update_clover_authentication(clover_lead_key=_clover_lead.key,
                                                    clover_access_token=clover_access_token)
        _pos = PointOfSale.get_by_merchant_id(merchant_id=_clover_lead.merchant_id)
        if _pos:
            _pos = update_clover_access_token(point_of_sale_key=_pos.key, clover_lead_key=_clover_lead.key)

    # check if at least one delivery service is set to enabled. If not, it means the customer never finished the setup flow
    _clover_lead_delivery_services = json.loads(_clover_lead.delivery_services)
    _clover_lead_is_new = True
    for _ds in _clover_lead_delivery_services:
        if _ds.get('selected') == True:
            _clover_lead_is_new = False
            break

    return _clover_lead, _clover_lead_is_new

##########################
# Clover Lead Access Token
##########################

def update_clover_access_token(point_of_sale_key, clover_lead_key):
    _pos = point_of_sale_key.get()
    _clover_lead = clover_lead_key.get()
    _pos.access_token = _clover_lead.access_token
    _pos.put()
    return _pos


##############
#create clover items
##############
from requests.auth import AuthBase
import requests

class CloverAuth(AuthBase):
    # Provided by clover: https://docs.clover.com/build/oauth-2-0/
    def __init__(self, api_key):
        self.api_key = api_key

    def __call__(self, request):
        request.headers.update(get_auth_headers(self.api_key))
        return request

def get_auth_headers(api_key):
    return {
        'Content-Type': 'Application/JSON',
        'Authorization': 'Bearer ' + api_key
    }
