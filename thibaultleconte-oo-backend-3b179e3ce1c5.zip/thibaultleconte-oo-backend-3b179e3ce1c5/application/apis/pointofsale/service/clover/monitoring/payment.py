# Work here Rajdeep
#
# check ..payment check_orderout_tender_type_is_valid()
#
# Thibault will give the logic and code to create a point_of_sale object with a valid access token from clover
