
# def generate_fake_point_of_sale():
#     _pos = PointOfSale()
#     _pos.access_token = 'xxx'
#     _pos.put()
#     return _pos.key
