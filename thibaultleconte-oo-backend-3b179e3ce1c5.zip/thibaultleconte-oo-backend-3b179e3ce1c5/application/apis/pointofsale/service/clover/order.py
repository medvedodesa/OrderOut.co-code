# -*- coding: utf-8 -*-
# !/usr/bin/env python
#
# thibault@orderout.co
#
# 04/11/2019
#

from application.core.error import report_error, report_warning
from application.core.parser.price import sanitize_price
from .fees.factories import FeeSenderFactory
from .order_charge.calculator import OrderChargeCalculator
from .payment import check_orderout_tender_type_is_valid, setup_orderout_tender_type, \
    check_orderout_order_type_is_valid, setup_orderout_order_type
from application.core.event.model import CoreEventCategory
from application.core.event.service import create_event
from .request import make_api_request, check_status_code_success
from application.apis.menu.service.mapping.clover.magicmapping import get_magic_mapping_section, \
    get_magic_mapping_category, create_item_in_clover_and_map
import logging

from .settings.factory import PointOfSaleSettingsFactory

MERCHANTS_CONTEXT = "merchants/"
ORDERS_CONTEXT = "/orders/"

CLOVER_UNRECOGNIZED_NAME = 'Unrecognized'
CLOVER_UNRECOGNIZED_ID = 'oo-1'


def push_order(order_key, point_of_sale_key):
    _order = order_key.get()
    _pos = point_of_sale_key.get()
    pos_settings = PointOfSaleSettingsFactory(
        pos_type=_pos.type
    ).create(_pos.settings)

    # TENDER
    _tender_is_valid = check_orderout_tender_type_is_valid(point_of_sale_key=_pos.key,
                                                           delivery_service_key=_order.delivery_service,
                                                           order_key=order_key)
    if not _tender_is_valid:
        _tender_is_created = setup_orderout_tender_type(point_of_sale_key=_pos.key,
                                                        delivery_service_key=_order.delivery_service,
                                                        order_key=order_key)
        if not _tender_is_created:
            return False

    # ORDER TYPE
    _order_type_is_valid = check_orderout_order_type_is_valid(point_of_sale_key=_pos.key,
                                                              delivery_service_key=_order.delivery_service,
                                                              order_key=order_key)
    if not _order_type_is_valid: setup_orderout_order_type(point_of_sale_key=_pos.key,
                                                           delivery_service_key=_order.delivery_service,
                                                           order_key=order_key)

    # GET TAX RATE ID
    _clover_tax_rate_formatted = __get_tax_rate_id_from_clover(_pos, order_key, pos_settings)

    # CLOVER CUSTOMER
    # WAITING FOR CLOVER PERMISSION
    _clover_customer_uuid = None
    # _clover_customer_uuid = __create_customer_in_clover(_pos, _order)
    # if _clover_customer_uuid:
    #     __create_address_for_customer_in_clover(_pos, _order, _clover_customer_uuid)
    #     __save_clover_customer_uuid(_order, _clover_customer_uuid)

    # CLOVER ORDER ID
    _clover_order_uuid = _order.point_of_sale_uuid
    if not _clover_order_uuid:
        _orders_notes = __format_notes_for_clover_order(_order)
        _clover_order_uuid = __create_order_on_clover(_pos, _orders_notes, _order.key, _clover_customer_uuid)
        logging.info('--> Clover: NEW ORDER UUID is %s' % str(_clover_order_uuid))
        if not _clover_order_uuid:
            report_error(code=500, message='Issue when creating order in clover')
            return False
        _order = __save_clover_order_uuid(_order, _clover_order_uuid)

    # MENU ITEMS & MODIFIERS
    _success = _save_items_and_modifiers_in_clover(_order, _pos, _clover_order_uuid, _clover_tax_rate_formatted)
    if not _success: return False

    FeeSenderFactory.instantiate_with_default_service_charge(
        order=_order, pos=_pos, pos_settings=pos_settings
    ).send_fees()

    # ORDER STATE OPEN
    total_charge = OrderChargeCalculator(pos_settings).calculate(_order)
    success = __update_clover_order_state(_pos, _clover_order_uuid, 'open', total_charge, _order.key)
    if not success:
        report_error(code=500, message='Issue when updating order state in clover')
        return False

    # RECORD PAYMENT
    if not _order.point_of_sale_payment_uuid:
        _clover_payment_uuid = __record_payment_with_tender(_order, _pos, _clover_tax_rate_formatted, pos_settings)
        _order = __save_clover_payment_uuid(_order, _clover_payment_uuid)

    return True


##########
# Customer
##########

def __create_customer_in_clover(pos, order):
    _payload = {'firstName': order.customer_name.capitalize()}
    _url = MERCHANTS_CONTEXT + pos.service_merchant_id + "/customers/"
    _result_json, _status_code = make_api_request(point_of_sale_key=pos.key,
                                                  url=_url,
                                                  method="POST",
                                                  friendly_request_name='create_customer_in_clover',
                                                  data=_payload,
                                                  order_key=order.key)
    if not check_status_code_success(_status_code): return False
    _clover_customer_uuid = _result_json.get('id')
    return _clover_customer_uuid


def __create_address_for_customer_in_clover(pos, order, clover_customer_uuid):
    _payload = {}
    if order.delivery_address: _payload['address1'] = order.delivery_address
    if order.delivery_city: _payload['city'] = order.delivery_city
    if order.delivery_zip: _payload['zip'] = order.delivery_zip
    if order.delivery_state: _payload['state'] = order.delivery_state
    if order.customer_phone: _payload['phoneNumber'] = order.customer_phone

    _url = MERCHANTS_CONTEXT + pos.service_merchant_id + "/customers/" + clover_customer_uuid + '/addresses'
    _result_json, _status_code = make_api_request(point_of_sale_key=pos.key,
                                                  url=_url,
                                                  method="POST",
                                                  friendly_request_name='create_address_for_customer_in_clover',
                                                  data=_payload,
                                                  order_key=order.key)
    if not check_status_code_success(_status_code): return None
    return clover_customer_uuid


def __save_clover_customer_uuid(order, clover_customer_uuid):
    order.point_of_sale_customer_uuid = clover_customer_uuid
    order.put()
    return order


###############
# Order & State
###############

def __create_order_on_clover(pos, orders_notes, order_key, clover_customer_uuid=None):
    _payload = {'note': orders_notes}
    if clover_customer_uuid: _payload['customers'] = [{'id': clover_customer_uuid}]

    _url = MERCHANTS_CONTEXT + pos.service_merchant_id + ORDERS_CONTEXT
    _result_json, _status_code = make_api_request(point_of_sale_key=pos.key,
                                                  url=_url,
                                                  method="POST",
                                                  friendly_request_name='create_order_on_clover',
                                                  data=_payload,
                                                  order_key=order_key)
    if not check_status_code_success(_status_code): return False
    _clover_order_uuid = _result_json.get('id')
    return _clover_order_uuid


def __format_notes_for_clover_order(order):
    _ds = order.delivery_service.get()
    _order_uuid = order.delivery_service_short_uuid if order.delivery_service_short_uuid else order.delivery_service_uuid
    _notes = '%s %s - %s - Ready by %s' % (str(_ds.type), str(_order_uuid), str(order.type), str(order.ready_by))
    if order.customer_name: _notes += ' - Customer: %s' % str(order.customer_name.capitalize())
    if order.charge_mode: _notes += ' - %s' % str(order.charge_mode)
    if order.store_instructions: _notes += ' - Restaurant instructions: %s' % (str(order.store_instructions))
    if order.delivery_instructions: _notes += ' - Delivery instructions: %s' % (str(order.delivery_instructions))
    return _notes


def __save_clover_order_uuid(order, clover_order_uuid):
    order.point_of_sale_uuid = clover_order_uuid
    order.put()
    return order


def __update_clover_order_state(pos, clover_order_uuid, state, order_total, order_key):
    _payload = {'state': state,
                'total': int(sanitize_price(order_total * 100))}  # , 'taxRemoved': True, 'isVat': False}

    _url = MERCHANTS_CONTEXT + pos.service_merchant_id + ORDERS_CONTEXT + clover_order_uuid
    _result_json, _status_code = make_api_request(point_of_sale_key=pos.key,
                                                  url=_url,
                                                  method="POST",
                                                  friendly_request_name='update_clover_order_state',
                                                  data=_payload,
                                                  order_key=order_key)
    if not check_status_code_success(_status_code): return False
    return True


#######
# TAXES
#######

def __get_tax_rate_id_from_clover(pos, order_key, pos_settings):
    if not pos_settings.send_taxes:
        return None

    _url = MERCHANTS_CONTEXT + pos.service_merchant_id + "/tax_rates"
    _result_json, _status_code = make_api_request(point_of_sale_key=pos.key,
                                                  url=_url,
                                                  method="GET",
                                                  friendly_request_name='get_tax_rate_from_clover',
                                                  order_key=order_key)
    if not check_status_code_success(_status_code): return None
    _raw_elements = _result_json.get('elements', [])
    for _element in _raw_elements:
        if _element.get('isDefault', False) == True:
            return __format_tax_rates_for_clover(_element)
    if len(_raw_elements) > 0:
        _first_element = _raw_elements[0]
        return __format_tax_rates_for_clover(_element)
    return None


def __format_tax_rates_for_clover(element):
    _result = {'id': str(element.get('id')), 'name': str(element.get('name')), 'rate': int(element.get('rate')),
               'isDefault': bool(element.get('isDefault'))}
    return _result


#########
# PAYMENT
#########

def __record_payment_with_tender(order, pos, clover_tax_rate_formatted, pos_settings):
    _ds = order.delivery_service.get()
    total_charge = OrderChargeCalculator(pos_settings).calculate(order)
    _payload = {
        "amount": int(sanitize_price(total_charge * 100)),
        "tender": {"id": _ds.point_of_sale_tender_id},
        "employee": {"id": pos.service_employee_id},
        "result": "SUCCESS",
    }

    if pos_settings.send_taxes:
        _payload["taxAmount"] = int(sanitize_price(order.charge_tax * 100))

    if pos_settings.send_tips:
        _payload["tipAmount"] = int(sanitize_price(order.charge_tip_to_send_to_the_pos * 100))

    if clover_tax_rate_formatted:
        clover_tax_rate_formatted['taxableAmount'] = int(sanitize_price(order.charge_subtotal * 100))
        clover_tax_rate_formatted['taxAmount'] = int(sanitize_price(order.charge_tax * 100))
        _payload["taxRates"] = [clover_tax_rate_formatted]

    _url = MERCHANTS_CONTEXT + pos.service_merchant_id + ORDERS_CONTEXT + order.point_of_sale_uuid + "/payments"
    _result_json, _status_code = make_api_request(point_of_sale_key=pos.key,
                                                  url=_url,
                                                  method="POST",
                                                  friendly_request_name='record_payment_with_tender',
                                                  data=_payload,
                                                  order_key=order.key)
    if not check_status_code_success(_status_code): return None
    _clover_payment_uuid = _result_json.get('id')
    return _clover_payment_uuid


def __save_clover_payment_uuid(order, clover_payment_uuid):
    order.point_of_sale_payment_uuid = clover_payment_uuid
    order.put()
    return order


##############
# MENU ITEM V2
##############

def _save_items_and_modifiers_in_clover(order, pos, clover_order_uuid, clover_tax_rate_formatted):
    try:
        for _order_item_key in order.order_items:
            _order_item = _order_item_key.get()
            if not _order_item.point_of_sale_uuid:
                for _ in range(_order_item.quantity):
                    # MENU ITEM
                    _clover_menu_item = _format_item_for_clover(_order_item, clover_tax_rate_formatted)
                    _result_json, _status_code = __send_item_to_clover(pos, clover_order_uuid, _clover_menu_item,
                                                                       order.key)
                    if not check_status_code_success(_status_code):
                        return False

                    _clover_line_item_uuid = _result_json.get('id')

                    if not _clover_line_item_uuid:
                        return False

                    __save_clover_line_item_uuid(_order_item, _clover_line_item_uuid)
        return True
    except MenuItemNotFoundError:
        logging.error("Order ({}) not sent due to missing Menu Item.".format(order.id))
        return False


def __get_mapped_menu_item(order_item, pos):
    if order_item.menu_item:
        _ds_menu_item = order_item.menu_item.get()
        if not _ds_menu_item:
            logging.info(order_item)
            return
        if _ds_menu_item.mappedToMenuItem:
            return _ds_menu_item.mappedToMenuItem.get()

        return __map_menu_item(_ds_menu_item, pos)


def __map_menu_item(ds_menu_item, pos):
    logging.info("New Clover Menu Item creation")
    _pos_section_key = get_magic_mapping_section(pos_menu_sync_key=pos.menuSync)
    _pos_category_key = get_magic_mapping_category(pos_menu_sync_key=pos.menuSync, pos_section_key=_pos_section_key)
    ds_menu_item, _pos_mi = create_item_in_clover_and_map(pos_key=pos.key, pos_menu_sync_key=pos.menuSync,
                                                    pos_category_key=_pos_category_key, ds_unmapped_item=ds_menu_item)
    if ds_menu_item:
        ds_menu_item.put()
    return _pos_mi


def _format_item_for_clover(order_item, clover_tax_rate_formatted):
    item_price = order_item.unit_price
    menu_item = order_item.menu_item.get()
    if not menu_item:
        logging.error("No menu item found for order item: {}".format(order_item))
        raise MenuItemNotFoundError()
    name = menu_item.name
    # _unit_price = menu_item.price

    # Testing possible solution to Unpaid Balance issues
    # Adds modifiers information to the line item itself
    modifiers_separator = ", "
    name_length = len(name) + len(" (...")
    max_length = 127
    modifiers_names_list = []
    modifiers_names_second_list = []
    for i, order_item_modifier_key in enumerate(order_item.selected_modifier, start=1):
        order_item_modifier = order_item_modifier_key.get()
        menu_item_modifier = order_item_modifier.menu_item_modifier.get()
        # _unit_price += menu_item_modifier.price
        menu_item_modifier_name = menu_item_modifier.name
        new_length = [name_length, len(menu_item_modifier_name)]
        if i > 1:
            new_length.append(len(modifiers_separator))
        if sum(new_length) <= max_length:
            name_length = sum(new_length)
            modifiers_names_list.append(menu_item_modifier_name)
        else:
            modifiers_names_second_list.append(menu_item_modifier_name)

    notes = []
    if modifiers_names_list:
        name += " ({modifiers_names}".format(
            modifiers_names=modifiers_separator.join(modifiers_names_list)
        )
        if modifiers_names_second_list:
            name += "..."
            notes.append("... {remaining_modifiers_names})".format(
                    remaining_modifiers_names=modifiers_separator.join(modifiers_names_second_list)
                )
            )
        else:
            name += ")"

    # _clover_menu_item = {'item': {'id': str(pos_menu_item.uuid).upper()},
    #                      'price': int(sanitize_price(_unit_price * 100)),
    #                      'priceWithModifiers': int(sanitize_price(_price * 100)),
    #                      'unitQty': int(0),
    #                      'name': str(pos_menu_item.name).capitalize()}
    if order_item.store_instructions:
        notes.append(str(order_item.store_instructions))
    _clover_menu_item = {
        "price": int(sanitize_price(item_price * 100)),
        "name": str(name).capitalize()
    }

    if notes:
        _clover_menu_item["note"] = ". ".join(notes)

    if clover_tax_rate_formatted: _clover_menu_item["taxRates"] = [clover_tax_rate_formatted]
    return _clover_menu_item


def __send_item_to_clover(pos, clover_order_uuid, item_clover_formatted, order_key):
    _url = MERCHANTS_CONTEXT + pos.service_merchant_id + ORDERS_CONTEXT + clover_order_uuid + "/line_items"
    _result_json, _status_code = make_api_request(point_of_sale_key=pos.key,
                                                  url=_url,
                                                  method="POST",
                                                  friendly_request_name='send_item_to_clover',
                                                  data=item_clover_formatted,
                                                  order_key=order_key)
    return _result_json, _status_code


def __clear_mapping_and_save_item_to_pos(order_item, pos, clover_tax_rate_formatted, clover_order_uuid, order_key):
    # Redo mapping
    _pos_menu_item = __get_mapped_menu_item(order_item, pos)
    # format item for clover
    _clover_menu_item = _format_item_for_clover(order_item, clover_tax_rate_formatted)
    # send item to clover
    _result_json, _status_code = __send_item_to_clover(pos, clover_order_uuid, _clover_menu_item, order_key)
    return _result_json, _status_code


def __save_clover_line_item_uuid(order_item, clover_line_item_uuid):
    order_item.point_of_sale_uuid = clover_line_item_uuid
    order_item.put()


def __get_mapped_menu_item_modifier(order, order_item_modifier):
    if order_item_modifier.menu_item_modifier:
        _ds_menu_item_modifier = order_item_modifier.menu_item_modifier.get()
        if _ds_menu_item_modifier.mappedToMenuItemModifier:
            return _ds_menu_item_modifier.mappedToMenuItemModifier.get()
    _message = 'Mapped Order Item Modifier %s for Order Menu Item %s in Clover for Order Id %s not found' % (
        str(order_item_modifier.key.id()), str(order_item_modifier.order_item.id()),
        str(order_item_modifier.order.id()))
    _parent_entities_keys = [order_item_modifier.key, order_item_modifier.order]
    _order = order_item_modifier.order.get()
    _parent_entities_keys.append(_order.account)
    _parent_entities_keys.append(_order.restaurant)
    _parent_entities_keys.append(_order.delivery_service)
    _parent_entities_keys.append(_order.point_of_sale)
    if order_item_modifier.order_item:
        _parent_entities_keys.append(order_item_modifier.order_item)
        _order_item = order_item_modifier.order_item.get()
        if _order_item.menu_item: _parent_entities_keys.append(_order_item.menu_item)
    if order_item_modifier.menu_item_modifier: _parent_entities_keys.append(order_item_modifier.menu_item_modifier)
    create_event(category=CoreEventCategory.MAPPING,
                 name='MISSING',
                 success=False,
                 message=_message,
                 entity_key=order_item_modifier.key,
                 parent_entities_keys=_parent_entities_keys)
    report_warning(code=500, message=_message, data_dict={'order key': str(order_item_modifier.order.id())})
    return None


def __send_item_modifier_to_clover(pos, clover_order_uuid, clover_item_uuid, item_modifier, order_key):
    _url = MERCHANTS_CONTEXT + pos.service_merchant_id + ORDERS_CONTEXT + clover_order_uuid + "/line_items/" + clover_item_uuid + '/modifications'
    _result_json, _status_code = make_api_request(point_of_sale_key=pos.key,
                                                  url=_url,
                                                  method="POST",
                                                  friendly_request_name='send_item_modifier_to_clover',
                                                  data=item_modifier,
                                                  order_key=order_key)
    return _result_json, _status_code


def __save_clover_modifier_uuid(order_item_modifier, clover_modifier_uuid):
    order_item_modifier.point_of_sale_uuid = clover_modifier_uuid
    order_item_modifier.put()


class MenuItemNotFoundError(Exception):
    pass
