# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/20/2019
#

from application.core.email.service import send_raw_email_to_admin
from application.core.webhook.service import save_webhook
from application.core.webhook.model import CoreWebhookService
import json

CLOVER_WEBHOOK_ACTION_TYPE_CREATE = 'CREATE'
CLOVER_WEBHOOK_OBJECT_TYPE_APP = 'A'


def processWebhookVerification(verification_code):
    send_raw_email_to_admin("[POS] Clover Webhook Create", "verification_code " + verification_code)
    return True

def processWebhookMessage(url, json_dict):
    _wh = save_webhook(url=url, service=CoreWebhookService.CLOVER, payload=json_dict)
    _wh.is_successful()
    _action_type, _object_type = get_webhook_action_type_object_type(json_dict)
    if _action_type == CLOVER_WEBHOOK_ACTION_TYPE_CREATE and _object_type == CLOVER_WEBHOOK_OBJECT_TYPE_APP:
        send_raw_email_to_admin("[POS] Clover Webhook New App Install", json.dumps(json_dict))
    return True

#######################
# Webhook Action Helper
#######################

def get_webhook_action_type_object_type(json_dict):
    for _merchant_id, _details in json_dict.get('merchants').items():
        for _detail in _details:
            _action_type = _detail.get('type')
            _object_type = _detail.get('objectId')[0]
            return _action_type, _object_type
    return None, None
