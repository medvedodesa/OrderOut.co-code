# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 07/26/2019
#

from ...model.CloverLead import CloverLead
from application.core.email.service import send_raw_email_to_admin
from application.core.slack.clover import post_clover_signup, post_clover_submit
from application.core.task.service import startDeferredTask
import json
from ..common import check_point_of_sale_already_connected
from application.apis.ooexceptions import ConflictResourceAlreadyExistsError
from ..common import createPointOfSale
from application.apis.pointofsale.model.PointOfSale import PointOfSaleType, PointOfSale
from .menu import get_menu
from application.apis.deliveryservice.service.common.fetch import generate_list_delivery_services_available
from application.core.avochato.text import send_text_message_for_new_clover_lead as send_avochato_text_message_for_new_clover_lead
from application.core.avochato.contact import update_contact as update_avochato_contact
from application.core.avochato.tag import AvochatoTag
from application.core.settings.app import get_config_for_key
from application.core.phonevalidator.search import check_phone_number_is_mobile
from application.core.zapier.push import push_clover_lead_to_zapier
from application.core.email.service import send_email_active_for_clover_lead
from application.core.intercom.contact import create_contact_lead
from application.core.intercom.tag import attach_clover_lead_tag_to_contact
from application.core.intercom.company import fetch_company_name, create_company, attach_contact_to_company
from application.core.databox.push import push_clover_lead


def fetch_by_merchant_id(clover_merchant_id, clover_employee_id):
    _clover_lead = None

    _pos = PointOfSale.get_by_merchant_id(merchant_id=clover_merchant_id, all_status=True)
    if _pos:
        if _pos.api_status == False:
            return None

    _clover_lead_query = CloverLead().query()
    _clover_lead_query = _clover_lead_query.filter(CloverLead.merchant_id == clover_merchant_id)
    _clover_lead_query = _clover_lead_query.filter(CloverLead.employee_id == clover_employee_id)
    _clover_lead_query = _clover_lead_query.order(-CloverLead.api_created_at)
    _clover_lead = _clover_lead_query.get()

    return _clover_lead


########
# Step 1
########

def create(clover_merchant_id, clover_employee_id, clover_access_token, raw_json, clover_client_id=None, clover_auth_code=None):
    _cloverLead = CloverLead(merchant_id=clover_merchant_id,
                             employee_id=clover_employee_id,
                             client_id=clover_client_id,
                             auth_code=clover_auth_code,
                             access_token=clover_access_token)
    _delivery_services_list = generate_list_delivery_services_available()
    _cloverLead.account_name = raw_json.get('name')
    _cloverLead.street_address_1 = raw_json.get('address').get('address1')
    _cloverLead.street_address_2 = raw_json.get('address').get('address2')
    _cloverLead.street_address_3 = raw_json.get('address').get('address3')
    _cloverLead.city = raw_json.get('address').get('city')
    _cloverLead.zipcode = raw_json.get('address').get('zip')
    _cloverLead.state = raw_json.get('address').get('state')
    _cloverLead.country = raw_json.get('address').get('country')
    _cloverLead.phone_number = raw_json.get('address').get('phoneNumber')
    _cloverLead.owner_name = raw_json.get('owner').get('name')
    _cloverLead.owner_email = raw_json.get('owner').get('email')
    _cloverLead.delivery_services = json.dumps(_delivery_services_list)
    _cloverLead.raw_data = json.dumps(raw_json)
    _cloverLead.put()
    startDeferredTask(__notify_team_lead_created, _cloverLead.key)
    return _cloverLead

########
# Step 2
########

def update_clover_authentication(clover_lead_key,
                                 clover_access_token,
                                 clover_auth_code=None):
     _clover_lead = clover_lead_key.get()
     if not _clover_lead: raise NotFound
     _clover_lead.access_token = clover_access_token
     _clover_lead.auth_code = clover_auth_code
     _clover_lead.put()     
     return _clover_lead

def update(clover_lead_key, raw_json):
    _clover_lead = clover_lead_key.get()
    if not _clover_lead: raise NotFound
    import logging
    logging.info(raw_json)
    _clover_lead.account_name = raw_json.get('account_name')
    _clover_lead.street_address_1 = raw_json.get('street_address_1')
    _clover_lead.street_address_2 = raw_json.get('street_address_2')
    _clover_lead.street_address_3 = raw_json.get('street_address_3')
    _clover_lead.city = raw_json.get('city')
    _clover_lead.zipcode = raw_json.get('zipcode')
    _clover_lead.state = raw_json.get('state')
    _clover_lead.country = raw_json.get('country')
    _clover_lead.phone_number = raw_json.get('phone_number')
    _clover_lead.owner_name = raw_json.get('owner_name')
    _clover_lead.owner_email = raw_json.get('owner_email')
    _delivery_services_list = raw_json.get('delivery_services')
    _clover_lead.delivery_services = json.dumps(_delivery_services_list)
    _clover_lead.raw_data = json.dumps(raw_json)
    _clover_lead.put()
    return _clover_lead

def notify_new_lead(clover_lead_key):
    startDeferredTask(__notify_team_lead_delivery_services, clover_lead_key)
    # startDeferredTask(__notify_restaurant_owner_for_onboarding, clover_lead_key)
    startDeferredTask(__push_clover_lead_to_zapier, clover_lead_key)
    # startDeferredTask(__notify_store_owner_by_email_to_activate_account, clover_lead_key)
    startDeferredTask(__push_clover_lead_to_intercom, clover_lead_key)
    # startDeferredTask(__push_clover_lead_to_databox, clover_lead_key)
    return

########
# Step 3
########

def link_restaurant_to_clover_lead(account_key, restaurant_key, clover_lead_key):
    if check_point_of_sale_already_connected(restaurant_key=restaurant_key):
        raise ConflictResourceAlreadyExistsError
    _clover_lead = clover_lead_key.get()
    _pos = createPointOfSale(type=PointOfSaleType.CLOVER,
                             account_key=account_key,
                             restaurant_key=restaurant_key,
                             service_merchant_id=_clover_lead.merchant_id,
                             access_token=_clover_lead.access_token,
                             service_employee_id=_clover_lead.employee_id,
                             service_client_id=_clover_lead.client_id)
    _task = get_menu(_pos.key)
    return _pos


########
# HELPER
########

def __notify_team_lead_created(clover_lead_key):
    _cloverLead = clover_lead_key.get()
    _subject = 'New Clover Lead from %s' % (str(_cloverLead.account_name))
    _body = 'Owner is %s %s\nCloverLead id: %s' % (str(_cloverLead.owner_name), str(_cloverLead.owner_email), str(_cloverLead.key.id()))
    # Email
    _result = send_raw_email_to_admin(subject=_subject, body=_body)
    # Slack
    # _result = post_clover_signup(owner_name=_cloverLead.owner_name,
    #                              owner_email=_cloverLead.owner_email,
    #                              phone_number=_cloverLead.phone_number,
    #                              account_name=_cloverLead.account_name,
    #                              clover_lead_id=str(_cloverLead.key.id()),
    #                              restaurant_address=_cloverLead.street_address_1,
    #                              restaurant_city=_cloverLead.city,
    #                              restaurant_state=_cloverLead.state,
    #                              restaurant_zip=_cloverLead.zipcode)
    return _result

# def __notify_restaurant_owner_for_onboarding(clover_lead_key):
#     _result = False
#     _cloverLead = clover_lead_key.get()
#     if not _cloverLead.phone_number: return _result
#     _is_mobile = check_phone_number_is_mobile(phone_number=_cloverLead.phone_number)
#     # if _is_mobile:
#     #     _result_json, _status_code = send_avochato_text_message_for_new_clover_lead(phone_number=_cloverLead.phone_number)
#     #     _result = True if _status_code >= 200 and _status_code <= 299 else False
#     #     if _result:
#     #         _result_json, _status_code = update_avochato_contact(phone_number=_cloverLead.phone_number,
#     #                                                              name=_cloverLead.owner_name,
#     #                                                              email=_cloverLead.owner_email,
#     #                                                              company=_cloverLead.account_name,
#     #                                                              street=_cloverLead.street_address_1,
#     #                                                              city=_cloverLead.city,
#     #                                                              zipcode=_cloverLead.zipcode,
#     #                                                              state=_cloverLead.state,
#     #                                                              country=_cloverLead.country,
#     #                                                              tag=AvochatoTag.CLOVER_LEAD)
#     #         _result = True if _status_code >= 200 and _status_code <= 299 else False
#     # else: # IT IS A LANDLINE
#     #     import logging
#     #     logging.warning("Landline so MAKE A PHONE CALL")
#     return _result

def __notify_team_lead_delivery_services(clover_lead_key):
    _cloverLead = clover_lead_key.get()
    _delivery_services_list = json.loads(_cloverLead.delivery_services)
    # Slack
    _result = post_clover_submit(owner_name=_cloverLead.owner_name,
                                 owner_email=_cloverLead.owner_email,
                                 phone_number=_cloverLead.phone_number,
                                 account_name=_cloverLead.account_name,
                                 clover_lead_id=str(_cloverLead.key.id()),
                                 restaurant_address=_cloverLead.street_address_1,
                                 restaurant_city=_cloverLead.city,
                                 restaurant_state=_cloverLead.state,
                                 restaurant_zip=_cloverLead.zipcode,
                                 delivery_services_list=_delivery_services_list)
    return

def __push_clover_lead_to_zapier(clover_lead_key):
    _cloverLead = clover_lead_key.get()
    _result_json, _status_code = push_clover_lead_to_zapier(owner_name=_cloverLead.owner_name,
                                                            owner_email=_cloverLead.owner_email,
                                                            phone_number=_cloverLead.phone_number,
                                                            account_name=_cloverLead.account_name,
                                                            clover_lead_id=str(_cloverLead.key.id()),
                                                            restaurant_address=_cloverLead.street_address_1,
                                                            restaurant_city=_cloverLead.city,
                                                            restaurant_state=_cloverLead.state,
                                                            restaurant_zip=_cloverLead.zipcode)
    return

# def __notify_store_owner_by_email_to_activate_account(clover_lead_key):
#     _cloverLead = clover_lead_key.get()
#     response = send_email_active_for_clover_lead(recipient_email=_cloverLead.owner_email)
#     return

def __push_clover_lead_to_intercom(clover_lead_key):
    _company_name = clover_lead_key.get().account_name
    _contact_intercom_uuid = create_contact_lead(clover_lead_key)
    _success = attach_clover_lead_tag_to_contact(_contact_intercom_uuid)
    _company_intercom_uuid = fetch_company_name(_company_name)
    if not _company_intercom_uuid: _company_intercom_uuid = create_company(_company_name)
    _success = attach_contact_to_company(_company_intercom_uuid, _contact_intercom_uuid)
    return

def __push_clover_lead_to_databox(clover_lead_key):
    _cloverLead = clover_lead_key.get()
    _result_json, _status_code = push_clover_lead(account_name=_cloverLead.account_name,
                                                  restaurant_city=_cloverLead.city,
                                                  restaurant_state=_cloverLead.state,
                                                  restaurant_zip=_cloverLead.zipcode)
    return

###################
# List & Pagination
###################

def fetch_clover_lead_offset_pagination_for_clover_merchant_id(clover_merchant_id, _page=1, _item_per_page=2):
    _query = CloverLead.query()
    if clover_merchant_id: _query = _query.filter(CloverLead.merchant_id == clover_merchant_id.upper())
    _objects, prev, _next, _count = CloverLead.list_with_offset_pagination(query=_query, page=_page, item_per_page=_item_per_page, keys_only=True, sort='desc')
    return _objects, prev, _next, _count
