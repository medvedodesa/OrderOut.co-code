# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/19/2020
#

from .common import formatHeader
from application.core.settings.app import get_config_for_key
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.error import report_and_abort, report_warning
from application.core.event.service import create_event, CoreEventCategory
from application.core.slack.alert_clover import post_to_alert_clover_unauthorized


def make_api_request(point_of_sale_key, url, method, friendly_request_name, data=None, order_key=None, warning_reporting=True, error_reporting=True):
    # Related entities
    _related_entities_keys = [point_of_sale_key]
    _point_of_sale = point_of_sale_key.get()
    _related_entities_keys.append(_point_of_sale.account)
    _related_entities_keys.append(_point_of_sale.restaurant)
    if order_key: _related_entities_keys.append(order_key)
    # clover request
    _clover_headers = formatHeader(point_of_sale_key.id())
    _url = get_config_for_key('CLOVER_URL_API_BASE') + url
    _result_json, _status_code, _request_key = fetch_with_json_data(url=_url, service=UrlFetchService.CLOVER, method=method, headers=_clover_headers, data=data, related_entities_keys=_related_entities_keys)
    if _status_code < 200 or _status_code > 299:
        # core event parent parent_entities
        _parent_entities_keys = _related_entities_keys
        _parent_entities_keys.append(_request_key)
        # message
        _message ='%s return status code %s' % (str(friendly_request_name), str(_status_code))
        _payload = {'sent_data': data, 'result_data': _result_json}
        if _status_code == 401:
            create_event(category=CoreEventCategory.UNAUTHORIZED,
                         name='CLOVER',
                         success=False,
                         message=_message,
                         payload=_payload,
                         parent_entities_keys=_parent_entities_keys)
            if warning_reporting: report_warning(code=_status_code, message=_message, subject="Clover Unauthorized Access", data_dict=_payload)
            __report_to_slack_error_401(account_key=_point_of_sale.account, restaurant_key=_point_of_sale.restaurant)
        elif _status_code == 400:
            create_event(category=CoreEventCategory.NOTFOUND,
                         name='CLOVER',
                         success=False,
                         message=_message,
                         payload=_payload,
                         parent_entities_keys=_parent_entities_keys)
            if warning_reporting: report_warning(code=_status_code, message=_message, subject="Clover referenced item does not exist", data_dict=_payload)
        else:
            _returned_message = _result_json.get('message', '')
            if 'Referenced' in _returned_message and 'does not exist' in _returned_message:
                create_event(category=CoreEventCategory.NOTFOUND,
                             name='CLOVER',
                             success=False,
                             message=_returned_message,
                             payload=_payload,
                             parent_entities_keys=_parent_entities_keys)
                # return None, None
            else:
                create_event(category=CoreEventCategory.UNKNOWN,
                             name='CLOVER',
                             success=False,
                             message=_returned_message,
                             payload=_payload,
                             parent_entities_keys=_parent_entities_keys)
                if error_reporting: report_and_abort(message=_message, code=_status_code)
        # return None, None
    return _result_json, _status_code

def __report_to_slack_error_401(account_key, restaurant_key):
    _account_name = account_key.get().name
    _restaurant_name = restaurant_key.get().name
    _restaurant_admin_url = "{}/restaurant/{}".format(get_config_for_key("ADMIN_BASE_URL"), str(restaurant_key.id()))
    post_to_alert_clover_unauthorized(account_name=_account_name,
                                      restaurant_name=_restaurant_name,
                                      restaurant_admin_url=_restaurant_admin_url)
    return

def test_connection(point_of_sale_key):
    return False

def check_status_code_success(status_code):
    if not status_code: return False
    if status_code >= 200 and status_code <= 299: return True
    return False


def get_entity_id(response_json, status_code):
    if not check_status_code_success(status_code):
        return None
    return response_json.get("id")
