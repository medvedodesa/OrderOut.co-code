import logging

from application.apis.pointofsale.service.clover.fees.fee_sender import FeeSender, VoidFeeSender
from application.apis.pointofsale.service.clover.request import make_api_request, get_entity_id
from application.core.points_of_sale.clover.service_charge_api import ServiceChargeApiClient


class FeeSenderFactory(object):
    @staticmethod
    def instantiate_with_default_service_charge(order, pos, pos_settings):
        if not pos_settings.send_fees:
            return VoidFeeSender()

        result_json, status_code = ServiceChargeApiClient(
            order_key=order.key, pos=pos, request_tool=make_api_request
        ).get_default_service_charge()

        default_service_charge_id = get_entity_id(result_json, status_code)

        if not default_service_charge_id:
            logging.warning(
                "Potential unpaid balance issue with order: {order_key}. No default service charge found.".format(
                    order_key=order.key
                )
            )

        return FeeSender(
            request_tool=make_api_request, order=order, pos=pos, service_charge_id=default_service_charge_id
        )
