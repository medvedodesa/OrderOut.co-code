import abc


class AbstractFeeSender(object):
    @abc.abstractmethod
    def send_fees(self):
        raise NotImplementedError


class FeeSender(AbstractFeeSender):

    MERCHANTS_CONTEXT = "merchants"
    ORDERS_CONTEXT = "orders"
    SERVICE_CHARGE_CONTEXT = "service_charge"

    def __init__(self, request_tool, order, pos, service_charge_id):
        self.request_tool = request_tool
        self.order = order
        self.pos = pos
        self.service_charge_id = service_charge_id

    @staticmethod
    def _equivalent_percentage_rate(subtotal, expected_absolute_value):
        if not subtotal:
            return 0
        equivalent_percentage = expected_absolute_value / subtotal
        equivalent_percentage_decimal = 1000000 * equivalent_percentage
        return round(equivalent_percentage_decimal)

    def _create_url(self):
        return "/".join(
            [
                self.MERCHANTS_CONTEXT,
                self.pos.service_merchant_id,
                self.ORDERS_CONTEXT,
                self.order.point_of_sale_uuid,
                self.SERVICE_CHARGE_CONTEXT,
            ]
        )

    def _create_fees(self):
        fees = {}
        if self.order.charge_customer_delivery_fee:
            fees["Customer Delivery Fee"] = self.order.charge_customer_delivery_fee
        if self.order.charge_fee:
            fees["Service Fee"] = self.order.charge_fee

        return fees

    def send_fees(self):
        if not self.service_charge_id:
            return

        fees = self._create_fees()
        if not fees:
            return

        name = " and ".join(fees.keys())
        equivalent_percentage = self._equivalent_percentage_rate(
            subtotal=self.order.charge_subtotal, expected_absolute_value=sum(fees.values())
        )

        payload = {
            "id": self.service_charge_id,
            "name": name,
            "enabled": True,
            "percentageDecimal": equivalent_percentage,
        }

        self.request_tool(
            point_of_sale_key=self.pos.key,
            url=self._create_url(),
            method="POST",
            friendly_request_name="update_clover_order_with_service_charge",
            data=payload,
            order_key=self.order.key,
        )


class VoidFeeSender(AbstractFeeSender):
    def send_fees(self):
        """
        Send no fees to POS
        """
        pass
