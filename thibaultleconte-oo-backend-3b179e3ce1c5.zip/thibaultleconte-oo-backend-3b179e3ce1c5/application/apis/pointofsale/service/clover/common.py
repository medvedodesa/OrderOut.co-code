# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/22/2019
#

from ...model.PointOfSale import PointOfSale


def formatHeader(point_of_sale_id):
    _pos = PointOfSale.get_by_id(point_of_sale_id)
    return {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + _pos.access_token}
