from application.apis.pointofsale.service.clover.request import make_api_request
from application.core.exception import BadGateway


def request_get_all_employees(pos):
    response, status_code = make_api_request(
        method="GET",
        url="merchants/{merchant_id}/employees".format(
            merchant_id=pos.service_merchant_id,
        ),
        point_of_sale_key=pos.key,
        friendly_request_name="get_clover_employees",
    )

    if status_code == 401:
        raise BadGateway("Clover", status_code)

    if status_code != 200:
        raise Exception("Unkown error getting employees from Clover")

    return response.get("elements")


def request_create_support_employee(pos, email):
    response, status_code = make_api_request(
        method="POST",
        url="merchants/{merchant_id}/employees".format(
            merchant_id=pos.service_merchant_id,
        ),
        data={
            "name": "OrderOut Support",
            "email": email,
            "inviteSent": "false",
            "pin": "123456",
            "role": "ADMIN",
        },
        point_of_sale_key=pos.key,
        friendly_request_name="post_clover_employees",
    )

    if status_code == 401:
        raise BadGateway("Clover", status_code)

    if status_code != 200:
        raise Exception("Unkown error creating employee in Clover")

    return response


def request_delete_support_employee(pos, employee_id):
    response, status_code = make_api_request(
        method="DELETE",
        url="merchants/{merchant_id}/employees/{employee_id}".format(
            merchant_id=pos.service_merchant_id,
            employee_id=employee_id,
        ),
        point_of_sale_key=pos.key,
        friendly_request_name="delete_clover_employees",
    )

    if status_code == 401:
        raise BadGateway("Clover", status_code)

    if status_code != 200:
        raise Exception("Unkown error deleting employee from Clover")
