from application.apis.pointofsale.service.clover.employee.employee_api import (
    request_get_all_employees,
    request_create_support_employee,
    request_delete_support_employee
)


SUPPORT_EMAIL = "support@orderout.co"


def create_or_update_clover_support_employee(pos):
    support_employee = _get_clover_support_employee(pos)

    if not support_employee:
        support_employee = request_create_support_employee(pos, SUPPORT_EMAIL)

    pos.support_employee_id = support_employee.get("id")
    pos.put()


def delete_clover_support_employee(pos):
    _delete_clover_support_employees(pos)

    pos.support_employee_id = None
    pos.put()


def _get_clover_support_employee(pos):
    all_employees = request_get_all_employees(pos)
    support_employee = filter(_by_order_out_email, all_employees)
    return support_employee[0] if len(support_employee) > 0 else None


def _by_order_out_email(employee):
    return employee.get("email") == SUPPORT_EMAIL


def _delete_clover_support_employees(pos):
    employee = _get_clover_support_employee(pos)
    while employee:
        request_delete_support_employee(pos, employee.get("id"))
        employee = _get_clover_support_employee(pos)
