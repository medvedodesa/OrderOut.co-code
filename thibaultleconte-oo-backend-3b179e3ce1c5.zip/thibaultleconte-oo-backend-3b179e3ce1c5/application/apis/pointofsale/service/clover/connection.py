# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 08/24/2020
#


from application.core.error import report_error
from application.core.parser.string import sanitize_str
from .request import make_api_request


def test_connection(point_of_sale_key):
    _pos = point_of_sale_key.get()
    _url = "merchants/" + _pos.service_merchant_id
    _result_json, _status_code = make_api_request(point_of_sale_key=point_of_sale_key,
                                                  url=_url,
                                                  method="GET",
                                                  friendly_request_name='test_connection_request',
                                                  warning_reporting=False)
    if not _result_json and not _status_code: return False
    if _status_code < 200 or _status_code > 299: return False
    return True
