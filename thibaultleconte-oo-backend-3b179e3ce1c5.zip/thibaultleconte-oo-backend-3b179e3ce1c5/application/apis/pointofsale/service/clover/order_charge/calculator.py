class OrderChargeCalculator(object):
    def __init__(self, pos_settings):
        self.pos_settings = pos_settings

    def calculate(self, order):
        total_charge = order.charge_subtotal

        if self.pos_settings.send_taxes:
            total_charge += order.charge_tax

        if self.pos_settings.send_fees:
            total_charge += order.charge_fee + order.charge_customer_delivery_fee

        return total_charge
