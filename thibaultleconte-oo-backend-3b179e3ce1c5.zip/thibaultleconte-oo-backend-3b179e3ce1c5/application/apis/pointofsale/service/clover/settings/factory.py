from application.apis.pointofsale.model.PointOfSale import PointOfSaleType
from application.apis.pointofsale.service.clover.settings.clover_settings import CloverSettings


class InvalidPointOfSaleSettings(Exception):
    pass


class CloverSettingsFactory(object):
    DEFAULT_CLOVER_SETTINGS = CloverSettings(
        send_taxes=False,
        send_tips=False,
        send_fees=False,
        send_items_as_revenue=True,
    )

    @classmethod
    def create(cls, settings_dict):
        if settings_dict is None:
            return cls.get_default_settings()

        try:
            return CloverSettings(**settings_dict)
        except Exception:
            raise InvalidPointOfSaleSettings()

    @classmethod
    def get_default_settings(cls):
        return cls.DEFAULT_CLOVER_SETTINGS


class PointOfSaleSettingsFactory(object):
    FACTORIES_BY_TYPE = {
        PointOfSaleType.CLOVER: CloverSettingsFactory,
    }

    def __init__(self, pos_type):
        self.factory = self.FACTORIES_BY_TYPE.get(pos_type)

    @property
    def default(self):
        if self.factory is None:
            return None

        return self.factory.get_default_settings()

    @property
    def default_as_dict(self):
        if self.default is None:
            return None

        return self.default.__dict__

    def create(self, settings_dict):
        if self.factory is None:
            raise NotImplementedError("No factory found for this POS type")

        return self.factory.create(settings_dict)

    def is_valid(self, settings_dict):
        try:
            self.create(settings_dict)
        except InvalidPointOfSaleSettings:
            return False

        return True
