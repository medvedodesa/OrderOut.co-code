class CloverSettings(object):
    def __init__(
            self,
            send_taxes,
            send_tips,
            send_fees,
            send_items_as_revenue,
    ):
        self.send_taxes = send_taxes
        self.send_tips = send_tips
        self.send_fees = send_fees
        self.send_items_as_revenue = send_items_as_revenue
