# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/22/2019
#

from flask import current_app

from application.core.parser.price import sanitize_price
from ...model.PointOfSale import PointOfSale
# from .common import formatHeader
from application.core.task.service import addTask
from application.core.task.model import CoreTaskCategory
from application.core.error import report_error
# from application.apis.menu.service.creator import create_menu_item, create_menu_item_modifier
from application.apis.menu.service.menusync.fetch import fetch_menu_task_started, fetch_menu_task_finished
from google.appengine.ext import ndb
from application.apis.menu.service.creator import generate_item_dict, generate_modifier_group_dict, generate_modifier_dict, startTaskToCreateOrUpdateMenuItemsAndModifiers
from application.apis.menu.service.menusync.creator import create_menu_sync
from application.apis.menu.model.MenuSync import MenuSync
# from application.core.urlFetch.service import fetch_with_json_data
# from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.apis.menu.service.menusync.process import process_menu_task_started
# from application.core.settings.app import get_config_for_key
from application.apis.menu.service.crud.section import create_update_menu_section
from application.apis.menu.service.crud.category import create_update_menu_category
from application.core.parser.string import sanitize_str
from .request import make_api_request
import logging

DEFAULT_CLOVER_MENU_SECTION_NAME = 'Menu'
DEFAULT_CLOVER_MENU_CATEGORY_NAME = 'Main'

def get_menu(pointofsale_key):
    _pos = pointofsale_key.get()
    _menuSync = create_menu_sync(restaurant_key=_pos.restaurant, service_key=_pos.key)
    _pos.menuSync = _menuSync.key
    _pos.put()
    _task = _startTaskToFetchMenuFromClover(_menuSync.key)
    return _task

######
# Task
######

def _startTaskToFetchMenuFromClover(menu_sync_key):
    _ms = menu_sync_key.get()
    _task = addTask(category=CoreTaskCategory.CLOVER_MENU, entity=_ms)
    _menuSync = fetch_menu_task_started(menuSync_key=menu_sync_key, task_key=_task.key)
    return _task

def processTaskToFetchMenuFromClover(menu_sync_id, limit = 1000):
    _task_result_json = {}
    _ms = MenuSync.get_by_id(menu_sync_id)
    if not _ms:
        _task_result_json['processTaskToFetchMenuFromClover'] = {'message': 'MenuSync with id %s not found' % (str(menu_sync_id))}
    elif not _ms.service:
        _task_result_json['processTaskToFetchMenuFromClover'] = {'message': 'MenuSync with id %s has no ds' % (str(menu_sync_id))}
    else:
        _pos = _ms.service.get()
        _task_result_json["requests"] = []
        _all_items_fetched = []
        _all_status_codes = []

        condition = True
        while condition:
            _task_request_result_json, _task_request_items_fetched, _status_code = _singleFetchMenuFromClover(
                ms=_ms,
                pos=_pos,
                limit=limit,
                offset=len(_all_items_fetched),
            )
            _all_items_fetched.extend(_task_request_items_fetched)
            _all_status_codes.append(_status_code)
            _task_result_json["requests"].append(_task_request_result_json)
            condition = len(_task_request_items_fetched) > 0 and len(_task_request_items_fetched) == limit

        _any_request_failed = [status_code for status_code in _all_status_codes if status_code < 200 or status_code > 299]
        if _any_request_failed:
            fetch_menu_task_finished(menuSync_key=_ms.key, success=False)
        else:
            fetch_menu_task_finished(menuSync_key=_ms.key, success=True)
            _menu_items = __process_menu(_ms, _all_items_fetched)
            process_menu_task_started(menuSync_key=_ms.key, tasks_keys=_menu_items)

    return _task_result_json

def _singleFetchMenuFromClover(ms, pos, limit, offset):
    _task_request_result_json = {}
    _raw_elements = []

    _url, _status_code, _result_json = __start_fetch_menu_request(
        pointofsale_key=pos.key,
        merchant_id=pos.service_merchant_id,
        limit=limit,
        offset=offset,
    )
    _task_request_result_json['__start_fetch_menu_request'] = {'url': _url,
                                                               'status_code': _status_code,
                                                               'result_json': _result_json}
    if _result_json and 200 <= _status_code <= 299 and _result_json.get("elements"):
        _raw_elements = _result_json["elements"]
        _task_request_result_json['__parse_menu'] = {
            'message': "Point Of Sale has fetched %s menu items" % (str(len(_raw_elements)))}
    else:
        report_error(code=_status_code, subject="GetUbereatsMenu-Error",
                     message="Menu Sync %s returned %s" % (str(ms.key.id()), str(_status_code)))

    return _task_request_result_json, _raw_elements, _status_code

############
# Fetch Menu
############

def __start_fetch_menu_request(pointofsale_key, merchant_id, limit, offset):
    _url = "merchants/{merchant_id}/items?expand=modifierGroups.modifiers%2Ccategories&limit={limit}&offset={offset}".format(
        merchant_id=merchant_id,
        limit=str(limit),
        offset=str(offset),
    )
    _result_json, _status_code = make_api_request(point_of_sale_key=pointofsale_key,
                                                  url=_url,
                                                  method="GET",
                                                  friendly_request_name='start_fetch_menu_request')
    return _url, _status_code, _result_json

##############
# Process Menu
##############

def __process_menu(menu_sync, all_items_fetched):
    _items_tasks = []
    _section = create_update_menu_section(menu_sync_key=menu_sync.key, name=DEFAULT_CLOVER_MENU_SECTION_NAME)
    _items_tasks.extend(__parse_items(menu_sync, all_items_fetched, _section.key))
    return _items_tasks

def __parse_items(menu_sync, raw_elements, section_key):
    _items_tasks = []
    for _raw_element in raw_elements:
        # CATEGORY
        _raw_categories = _raw_element.get('categories')
        _raw_menu_category_name, _raw_menu_category_uuid = __get_category_name_and_uuid(_raw_categories)
        _category = create_update_menu_category(menu_sync_key=menu_sync.key,
                                                section_key=section_key,
                                                name=_raw_menu_category_name,
                                                uuid=_raw_menu_category_uuid)
        # Modifiers
        _modifier_groups = __parse_modifier_groups(_raw_element)
        # Menu Item
        _mi = generate_item_dict(name=_raw_element.get('name'),
                                 price=_raw_element.get('price')/100.0,
                                 modifier_groups=_modifier_groups,
                                 uuid=_raw_element.get('id'),
                                 is_available= not bool(_raw_element.get('hidden')),
                                 category_id=_category.get_id())
        _task = startTaskToCreateOrUpdateMenuItemsAndModifiers(menu_sync, _mi)
        if _task: _items_tasks.append(_task.key)
    return _items_tasks

def __get_category_name_and_uuid(raw_categories):
    _raw_menu_category_name = DEFAULT_CLOVER_MENU_CATEGORY_NAME
    _raw_menu_category_uuid = None
    for _raw_element in raw_categories.get('elements'):
        _raw_menu_category_name = sanitize_str(_raw_element.get('name'))
        _raw_menu_category_uuid = sanitize_str(_raw_element.get('id'))
    return _raw_menu_category_name, _raw_menu_category_uuid

def __parse_modifier_groups(raw_item):
    modifier_groups = []
    if 'modifierGroups' in raw_item:
        raw_modifierGroups = raw_item['modifierGroups']
        if 'elements' in raw_modifierGroups:
            for raw_element in raw_modifierGroups['elements']:
                _group_name = raw_element.get('name')
                _group_uuid = raw_element.get('id')
                _modifiers = __parse_modifiers(raw_element)
                _group = generate_modifier_group_dict(name=_group_name,
                                                      modifiers=_modifiers,
                                                      uuid=_group_uuid,)
                modifier_groups.append(_group)
    return modifier_groups

def __parse_modifiers(raw_element):
    modifiers = []
    if 'modifiers' in raw_element:
        raw_modifiers = raw_element['modifiers']
        if 'elements' in raw_modifiers:
            for raw_element in raw_modifiers['elements']:
                _mod = generate_modifier_dict(name=raw_element.get('name'),
                                              price=raw_element.get('price')/100.0,
                                              uuid=raw_element.get('id'))
                modifiers.append(_mod)
    return modifiers


################
#Create menuitem
################

def add_item_to_clover(pointofsale_key, menu_item_name, menu_item_price):
    _payload = {}
    _payload["name"] = menu_item_name
    _payload["price"] = int(sanitize_price(menu_item_price * 100))
    _payload["hidden"] = True
    _pos = pointofsale_key.get()
    _url = "merchants/" + _pos.service_merchant_id + "/items"
    _result_json, _status_code = make_api_request(point_of_sale_key=pointofsale_key,
                                                  url=_url,
                                                  method="POST",
                                                  friendly_request_name='create_menu_item',
                                                  data=_payload)
    if _status_code < 200 or _status_code > 299: return None, None, None
    _name = _result_json.get("name")
    _uuid = _result_json.get("id")
    _price = _result_json.get("price")/100.0
    return _name, _uuid, _price


#########################
#Create menuitemmmodifier
#########################

def _parse_modifiergroups(data):
    modifier_groups = {}
    if "elements" in data:
        for group in data["elements"]:
            modifier_groups[group["name"].lower()] = group["id"]
    return modifier_groups

def get_modifier_groups(pointofsale_key):
    _pos = pointofsale_key.get()
    _url = "merchants/" + _pos.service_merchant_id  + "/modifier_groups"
    _result_json, _status_code = make_api_request(point_of_sale_key=pointofsale_key,
                                                  url=_url,
                                                  method="GET",
                                                  friendly_request_name='get_all_modifier_groups'
                                                  )
    if _status_code < 200 or _status_code > 299: return None, None, None
    return _parse_modifiergroups(_result_json)

def add_modifier_group_to_clover(pointofsale_key, modifier_group_name):
    _payload = {}
    _payload["name"] = modifier_group_name
    _payload["showByDefault"] = False
    _pos = pointofsale_key.get()
    _url = "merchants/" + _pos.service_merchant_id + "/modifier_groups/"
    _result_json, _status_code = make_api_request(point_of_sale_key=pointofsale_key,
                                                  url=_url,
                                                  method="POST",
                                                  friendly_request_name='create_menu_item_modifier_group',
                                                  data=_payload)
    logging.info("add_modifier_group_to_clover: '{}', result_json: '{}'".format(modifier_group_name, _result_json))
    if _status_code < 200 or _status_code > 299: return None
    _uuid = _result_json.get("id")
    return _uuid


def add_modifier_to_clover(pointofsale_key, modifier_group_uuid, name, price):
    logging.info("adding modifier to clover: modifier_group_uuid '{}', name: '{}'".format(
            modifier_group_uuid,
            name,
        )
    )

    if not modifier_group_uuid:
        return None, None, None

    _payload = {}
    _payload["name"] = name
    _payload["price"] = int(sanitize_price(price * 100))
    _pos = pointofsale_key.get()

    _url = "merchants/" + _pos.service_merchant_id + "/modifier_groups/" + modifier_group_uuid + "/modifiers"
    _result_json, _status_code = make_api_request(point_of_sale_key=pointofsale_key,
                                                  url=_url,
                                                  method="POST",
                                                  friendly_request_name='create_menu_item_modifier',
                                                  data=_payload)
    if _status_code < 200 or _status_code > 299: return None, None, None
    _name = _result_json.get("name")
    _uuid = _result_json.get("id")
    _price = _result_json.get("price")/100.0
    return _name, _uuid, _price
