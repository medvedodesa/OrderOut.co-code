# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 08/03/2019
#

# from application.core.urlFetch.service import fetch_with_json_data
# from application.core.urlFetch.UrlFetchRequest import UrlFetchService
# from .common import formatHeader
# from application.core.error import report_and_abort, report_error
# from application.core.settings.app import get_config_for_key

from .request import make_api_request, check_status_code_success


CLOVER_TYPE_LABEL_ORDEROUT = 'OrderOut'
CLOVER_DEFAULT_ORDER_TYPE = 'Dine-In'

#############
# TENDER TYPE
#############

def check_orderout_tender_type_is_valid(point_of_sale_key, delivery_service_key, order_key):
    _pos = point_of_sale_key.get()
    _ds = delivery_service_key.get()

    _url = "merchants/" + _pos.service_merchant_id + "/tenders"
    _result_json, _status_code = make_api_request(point_of_sale_key=point_of_sale_key,
                                                  url=_url,
                                                  method="GET",
                                                  friendly_request_name='check_orderout_tender_type_is_valid',
                                                  order_key=order_key)
    # if not _result_json and not _status_code: return False
    if not check_status_code_success(_status_code): return False

    _tender_name = __format_name(delivery_service_name=_ds.type)
    for _raw_tender_json in _result_json.get('elements'):
        _ds.point_of_sale_tender_id = __return_tender_id(raw_tender_json=_raw_tender_json, tender_name=_tender_name)
        if _ds.point_of_sale_tender_id:
            _ds.put()
            return True
    return False

def setup_orderout_tender_type(point_of_sale_key, delivery_service_key, order_key):
    _pos = point_of_sale_key.get()
    _ds = delivery_service_key.get()
    _tender_name = __format_name(delivery_service_name=_ds.type)
    _payload = {'enabled': True,
                'supportsTipping': False,
                'opensCashDrawer': False,
                'label': _tender_name,
                'editable': False,
                'visible': True}


    _url = "merchants/" + _pos.service_merchant_id + "/tenders"
    _result_json, _status_code = make_api_request(point_of_sale_key=point_of_sale_key,
                                                  url=_url,
                                                  method="POST",
                                                  friendly_request_name='setup_orderout_tender_type',
                                                  data=_payload,
                                                  order_key=order_key)
    # if not _result_json and not _status_code: return False
    if not check_status_code_success(_status_code): return False

    _ds.point_of_sale_tender_id = __return_tender_id(raw_tender_json=_result_json, tender_name=_tender_name)
    _ds.put()
    return True

############
# ORDER TYPE
############

def check_orderout_order_type_is_valid(point_of_sale_key, delivery_service_key, order_key):
    _pos = point_of_sale_key.get()
    _ds = delivery_service_key.get()

    _url = "merchants/" + _pos.service_merchant_id + "/order_types"
    _result_json, _status_code = make_api_request(point_of_sale_key=point_of_sale_key,
                                                  url=_url,
                                                  method="GET",
                                                  friendly_request_name='setup_orderout_tender_type',
                                                  order_key=order_key)
    # if not _result_json and not _status_code: return False
    if not check_status_code_success(_status_code): return False

    _order_type_name = __format_name(delivery_service_name=_ds.type)
    for _raw_order_type_json in _result_json.get('elements'):
        _ds.point_of_sale_order_type_id = __return_order_type_id(raw_order_type_json=_raw_order_type_json, order_type_name=_order_type_name)
        if _ds.point_of_sale_order_type_id:
            _ds.put()
            return True
    return False

def setup_orderout_order_type(point_of_sale_key, delivery_service_key, order_key):
    _ds = delivery_service_key.get()
    _order_type_name = __format_name(delivery_service_name=_ds.type)

    _result_json, _status_code = __create_orderout_order_type(point_of_sale_key=point_of_sale_key, order_type_name=_order_type_name, order_key=order_key)
    # if not _result_json and not _status_code: return False
    if not check_status_code_success(_status_code): return False
    _ds.point_of_sale_order_type_id = __return_order_type_id(raw_order_type_json=_result_json, order_type_name=_order_type_name)
    _ds.put()

    if _result_json.get('isDefault') == True:
        _result_json, _status_code = __create_orderout_order_type(point_of_sale_key=point_of_sale_key,
                                                                  order_type_name=CLOVER_DEFAULT_ORDER_TYPE,
                                                                  order_key=order_key,
                                                                  default=True,
                                                                  hidden=False)
    return True

def __create_orderout_order_type(point_of_sale_key, order_type_name, order_key, default=False, hidden=True):
    _pos = point_of_sale_key.get()
    _payload = {'isDefault': default,
                'isHidden': hidden,
                'isDeleted': False,
                'label': order_type_name,
                'filterCategories': False,
                'taxable': True}

    _url = "merchants/" + _pos.service_merchant_id + "/order_types"
    _result_json, _status_code = make_api_request(point_of_sale_key=point_of_sale_key,
                                                  url=_url,
                                                  method="POST",
                                                  friendly_request_name='create_orderout_order_type',
                                                  data=_payload,
                                                  order_key=order_key)

    return _result_json, _status_code

########
# Helper
########

def __format_name(delivery_service_name):
    return str(delivery_service_name).capitalize() + '-' + CLOVER_TYPE_LABEL_ORDEROUT

def __return_tender_id(raw_tender_json, tender_name):
    if raw_tender_json.get('label') == tender_name:
        return raw_tender_json.get('id')
    return None

def __return_order_type_id(raw_order_type_json, order_type_name):
    if raw_order_type_json.get('label') == order_type_name:
        return raw_order_type_json.get('id')
    return None
