import base64
import logging
import json
import time

from googleapiclient.discovery import build


def push_order(order_key):
    order_id = order_key.id()
    order = order_key.get()

    pos = order.point_of_sale.get()

    customer_id = pos.service_merchant_id

    logging.info("Pushing Aldelo order {}".format(order_id))

    data = json.dumps({"order_id": order_id, "customer_id": customer_id})

    body = {
        "messages": [
            {
                "data": base64.b64encode(data)
            }
        ]
    }

    service = build("pubsub", "v1")

    topic_path = "projects/orderout-backend/topics/aldelo-orders"

    service.projects().topics().publish(
        topic=topic_path,
        body=body
    ).execute()

    return True


def _get_messages():
    """Pull messages from a given subscription."""
    service = build("pubsub", "v1")

    subscription = "projects/orderout-backend/subscriptions/aldelo-external"
    body = {
        'returnImmediately': False,
        'maxMessages': 100,
    }

    try:
        resp = service.projects().subscriptions().pull(
            subscription=subscription,
            body=body,
        ).execute(
            num_retries=3,
        )
    except Exception as e:
        time.sleep(0.5)
        logging.exception("Pull Messages Exception {}".format(e))
        return

    received_messages = resp.get('receivedMessages')
    return received_messages


def pull_messages(customer_id):
    messages = []

    received_messages = _get_messages()
    if received_messages:
        for receivedMessage in received_messages:
            message = receivedMessage.get('message')
            if message:
                data = base64.b64decode(str(message.get('data')))
                data = json.loads(data)
                customer_id_from_order = data.get("customer_id")
                if customer_id_from_order == customer_id:
                    messages.append(data)

    return messages


def confirm_messages(customer_id, order_ids):
    ack_ids = []
    messages = []

    received_messages = _get_messages()
    if received_messages:
        for receivedMessage in received_messages:
            message = receivedMessage.get('message')
            if message:
                data = base64.b64decode(str(message.get('data')))
                data = json.loads(data)
                customer_id_from_order = data.get("customer_id")
                poll_order_id = data.get("order_id")
                if customer_id_from_order == customer_id and poll_order_id in order_ids:
                    ack_ids.append(receivedMessage.get('ackId'))
                    messages.append(data)

    if ack_ids:
        service = build("pubsub", "v1")
        subscription = "projects/orderout-backend/subscriptions/aldelo-external"

        ack_body = {'ackIds': ack_ids}
        service.projects().subscriptions().acknowledge(
            subscription=subscription,
            body=ack_body,
        ).execute(
            num_retries=3,
        )

    return messages
