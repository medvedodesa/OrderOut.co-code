# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 07/01/2020
#
from application.apis.menu.service.menusync.creator import create_menu_sync
from application.apis.ooexceptions import ConflictResourceAlreadyExistsError
from ..common import createPointOfSale
from ..common import check_point_of_sale_already_connected
from ...model.PointOfSale import PointOfSaleType


def connect_store_uuid_to_restaurant(account_key, restaurant_key, store_uuid):
    if check_point_of_sale_already_connected(restaurant_key=restaurant_key):
        raise ConflictResourceAlreadyExistsError

    _pos = createPointOfSale(type=PointOfSaleType.ALDELO,
                             account_key=account_key,
                             restaurant_key=restaurant_key,
                             service_merchant_id=store_uuid)

    _menuSync = create_menu_sync(restaurant_key=_pos.restaurant, service_key=_pos.key)
    _pos.menuSync = _menuSync.key
    _pos.put()

    return _pos
