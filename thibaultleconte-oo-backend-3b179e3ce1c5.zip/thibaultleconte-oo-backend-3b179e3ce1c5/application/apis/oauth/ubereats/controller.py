import logging
import json

from flask import request, redirect
from flask_restplus import Resource, Namespace
from google.appengine.api import memcache
from werkzeug.exceptions import Forbidden, BadRequest

from application.core.delivery_services.ubereats.factories import UberEatsApiClientFactory
from application.core.oauth.base import InvalidStateException
from application.core.oauth.factory import OAuthHandlerFactory
from application.core.settings.app import get_config_for_key

nsApi = Namespace("oauth-uber", description="Uber OAuth2 handler")


logger = logging.getLogger(__name__)


@nsApi.route("/<int:restaurant_id>/authorization_url")
class AuthorizationURL(Resource):

    def get(self, restaurant_id):
        uber_eats_oauth_handler = OAuthHandlerFactory("ubereats").create()

        mc_client = memcache.Client()
        mc_client.set(key=uber_eats_oauth_handler.state, value=restaurant_id, time=3600)

        return {"authorization_url": uber_eats_oauth_handler.authorization_url}


@nsApi.route("/redirect_handler")
class RedirectHandlerURL(Resource):

    def get(self):
        oauth_code = request.args.get("code")
        state = request.args.get("state")

        oauth_handler = OAuthHandlerFactory("ubereats").create()
        try:
            oauth_data = oauth_handler.handle_oauth_redirect(oauth_code, state)
        except InvalidStateException:
            raise Forbidden

        refresh_token = oauth_data.refresh_token
        restaurant_id = oauth_data.restaurant_id

        uber_eats_api = UberEatsApiClientFactory.instantiate_google_urlfetch_api_client(
            refresh_token=refresh_token
        )

        stores_data = uber_eats_api.list_stores()

        stores_data = stores_data.get("stores")
        if not stores_data:
            raise BadRequest

        mc_client = memcache.Client()
        mc_client.set(
            key="ubereats/{}".format(restaurant_id),
            value=json.dumps(stores_data),
            time=3600
        )

        mc_client.set(
            key="ubereats/{}/refresh_token".format(restaurant_id),
            value=refresh_token,
            time=3600,
        )

        onboarding_url = "{}/restaurant/{}/onboarding".format(get_config_for_key("DASHBOARD_BASE_URL"), restaurant_id)

        return redirect(onboarding_url)
