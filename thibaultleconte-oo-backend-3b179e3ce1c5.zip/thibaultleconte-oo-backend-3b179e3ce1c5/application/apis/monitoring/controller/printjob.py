# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/19/2020
#

from flask_restplus import Resource, Namespace
from application.apis.printer.model.Job import Job
from datetime import datetime, timedelta
from application.core.authentication.service import requires_auth_token


nsApi = Namespace('printjob', description='PrintJob related operations.')

@nsApi.route('/summary')
class MonitoringPrintJobSummary(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Monitoring PrintJobs Summary')
    @nsApi.response(200, 'OK')
    # @errorHandler
    def get(self):
        _timeline = []
        _timeline.append({'_1h': datetime.now() - timedelta(hours=1)})
        _timeline.append({'_6h': datetime.now() - timedelta(hours=6)})
        _timeline.append({'_12h': datetime.now() - timedelta(hours=12)})
        _timeline.append({'_1d': datetime.now() - timedelta(days=1)})
        _timeline.append({'_2d': datetime.now() - timedelta(days=2)})
        _timeline.append({'_7d': datetime.now() - timedelta(days=7)})
        _timeline.append({'_14d': datetime.now() - timedelta(days=14)})
        _timeline.append({'_30d': datetime.now() - timedelta(days=30)})

        _results = {}
        for _timelapse in _timeline:
            for _key, _value in _timelapse.items():
                _printjob_query = Job.query()
                _printjob_query = _printjob_query.filter(Job.api_created_at >= _value)
                _printjob_query = _printjob_query.order(-Job.api_created_at)

                _printjob_total = _printjob_query.count()
                _printjob_printed_success = _printjob_query.filter(Job.printed == True).count()
                _printjob_printed_failure = _printjob_query.filter(Job.printed == False).count()
                _printjob_printed_rate = round(float(_printjob_printed_success)/float(_printjob_total), 4) if _printjob_total > 0 else 0.0
                _printjob_printed_percent = round(float(_printjob_printed_rate)*100, 2)

                _stats = {'total': _printjob_total,
                          'printed': _printjob_printed_success,
                          'not-printed': _printjob_printed_failure,
                          'printed-rate': _printjob_printed_rate,
                          'printed-percent': _printjob_printed_percent}
                _results[_key] = _stats

        return _results
