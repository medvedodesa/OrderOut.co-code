# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 08/12/2020
#

from flask_restplus import Resource, Namespace
from application.core.authentication.service import requires_auth_token
from application.core.exception import errorHandler
from datetime import datetime, timedelta
from application.apis.restaurant.model import Restaurant
from application.apis.pointofsale.service.common import check_point_of_sale_already_connected
from application.apis.deliveryservice.service.common.fetch import get_delivery_services_for_restaurant
from flask_restplus import marshal
from google.appengine.api import memcache


nsApi = Namespace('onboarding', description='Onboaarding related operations.')

restaurant_marshal = nsApi.model('Restaurant', Restaurant.schema(with_point_of_sale=False, with_account=True))

MEMCACHE_ONBOARDING_STATS_KEY = 'mc_onboarding_stats'
MEMCACHE_ONBOARDING_RESTAURANTS_PENDING_KEY = 'mc_onboarding_restaurants_pending'
MEMCACHE_ONBOARDING_DURATION_SECONDS = 60

@nsApi.route('/stats')
class MonitoringOnboardingStats(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Monitoring Onboarding Stats')
    @nsApi.response(200, 'OK')
    # @errorHandler
    def get(self):
        mc_client = memcache.Client()
        _cached_results = mc_client.get(MEMCACHE_ONBOARDING_STATS_KEY)
        if _cached_results: return _cached_results

        _results = {}

        for _timelapse in _generate_date_range():
            for _key, _daterange in _timelapse.items():

                _startdate = _daterange.get('start')
                _enddate = _daterange.get('end')

                _restaurant_query = Restaurant.query()
                _restaurant_query = _restaurant_query.order(-Restaurant.api_created_at)

                _restaurant_query_period = _restaurant_query.filter(Restaurant.api_created_at < _startdate, Restaurant.api_created_at >= _enddate)

                _no_ds = _pending_ds = _no_live_ds = _live_1_ds = _not_counted = _no_pos = 0

                _restaurants_keys = _restaurant_query_period.fetch(keys_only=True)
                for _r_key in _restaurants_keys:

                    # Point of sale count
                    _no_pos += 0 if check_point_of_sale_already_connected(_r_key) == True else 1

                    # Delivery Service count
                    _counted = False
                    _ds_list = get_delivery_services_for_restaurant(restaurant_key=_r_key, keys_only=False)

                    if len(_ds_list) == 0:
                        _no_ds += 1
                        _counted = True
                    if _counted: continue

                    for _ds in _ds_list:
                        if not _ds.serviceLocationId:
                            _pending_ds += 1
                            _counted = True
                            break
                    if _counted: continue

                    for _ds in _ds_list:
                        if not _ds.integration_enabled:
                            _no_live_ds += 1
                            _counted = True
                            break
                    if _counted: continue

                    for _ds in _ds_list:
                        if _ds.integration_enabled:
                            _live_1_ds += 1
                            _counted = True
                            break
                    if _counted: continue

                    _not_counted += 1

                _startdate = _startdate.isoformat()
                _enddate = _enddate.isoformat()
                _stats = {'start': str(_startdate), 'end': str(_enddate), 'no_ds': _no_ds, 'pending_ds': _pending_ds, 'no_live_ds': _no_live_ds, 'live_1+_ds': _live_1_ds, 'not_counted': _not_counted, 'no_pos': _no_pos}
                _results[_key] = _stats

        _success = mc_client.set(MEMCACHE_ONBOARDING_STATS_KEY, _results, time=MEMCACHE_ONBOARDING_DURATION_SECONDS)
        return _results

@nsApi.route('/restaurant/pending')
class MonitoringOnboardingToDoList(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Monitoring Onboarding To Do List')
    @nsApi.response(200, 'OK')
    @errorHandler
    def get(self):
        mc_client = memcache.Client()
        _cached_results = mc_client.get(MEMCACHE_ONBOARDING_RESTAURANTS_PENDING_KEY)
        if _cached_results: return _cached_results

        _results = {}

        _restaurant_query = Restaurant.query()
        _restaurant_query = _restaurant_query.order(-Restaurant.api_created_at)

        _no_ds = []
        _pending_ds = []
        _no_live_ds = []
        _live_1_ds = []
        _no_pos = []

        _restaurants = _restaurant_query.fetch()
        for _restaurant in _restaurants:
            if not _restaurant.api_status:
                continue

            # Point of Sale
            if check_point_of_sale_already_connected(_restaurant.key) == False:
                _no_pos.append(marshal(_restaurant, restaurant_marshal))
                continue

            # Delivery Service
            _counted = False
            _ds_list = get_delivery_services_for_restaurant(restaurant_key=_restaurant.key, keys_only=False)

            if len(_ds_list) == 0:
                _no_ds.append(marshal(_restaurant, restaurant_marshal))
                continue

            for _ds in _ds_list:
                if not _ds.serviceLocationId:
                    _pending_ds.append(marshal(_restaurant, restaurant_marshal))
                    _counted = True
                    break
            if _counted: continue

            for _ds in _ds_list:
                if not _ds.integration_enabled:
                    _no_live_ds.append(marshal(_restaurant, restaurant_marshal))
                    _counted = True
                    break
            if _counted: continue

            for _ds in _ds_list:
                if _ds.integration_enabled:
                    _live_1_ds.append(marshal(_restaurant, restaurant_marshal))
                    _counted = True
                    break
            if _counted: continue

        _results = {'no_ds': _no_ds, 'pending_ds': _pending_ds, 'no_live_ds': _no_live_ds, 'live_1+_ds': _live_1_ds, 'no_pos': _no_pos}
        _success = mc_client.set(MEMCACHE_ONBOARDING_RESTAURANTS_PENDING_KEY, _results, time=MEMCACHE_ONBOARDING_DURATION_SECONDS)
        return _results

def _generate_date_range():
    _now = datetime.now()
    _timeline = []
    _timeline.append({'_last_7d': {'start': _now, 'end': _now - timedelta(days=7)}})
    _timeline.append({'_7_to_14d': {'start': _now - timedelta(days=7), 'end': _now - timedelta(days=14)}})
    _timeline.append({'_14_to_21d': {'start': _now - timedelta(days=14), 'end': _now - timedelta(days=21)}})
    _timeline.append({'_21_to_28d': {'start': _now - timedelta(days=21), 'end': _now - timedelta(days=28)}})
    _timeline.append({'_28_to_45d': {'start': _now - timedelta(days=28), 'end': _now - timedelta(days=45)}})
    _timeline.append({'_more_than_45d': {'start': _now - timedelta(days=45), 'end': _now - timedelta(days=1000)}})
    return _timeline
