# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/24/2020
#

from application.apis.pointofsale.model.CloverLead import CloverLead
from application.core.task.service import startDeferredTask
from application.core.email.service import send_admin_email
from application.core.settings.app import get_config_for_key
from flask_restplus import Resource, Namespace
from application.apis.restaurant.model import Restaurant
from application.apis.menu.model.MenuSync import MenuSync


nsApi = Namespace('menu', description='Menu related operations.')


@nsApi.route('/stats')
class MonitoringMenuStatistics(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Monitoring Menu Statistics')
    @nsApi.response(200, 'OK')
    # @nsApi.response(200, 'OK', orders_pagination_marshal)
    # @nsApi.marshal_with(orders_pagination_marshal)
    # @errorHandler
    def get(self):
        response = 200
        startDeferredTask(start_deferred_task_export_menu_stats_all_restaurants)
        return response

ACCOUNT_NAME = 'account_name'
REST_ID = 'restaurant_id'
REST_NAME = 'restaurant_name'
REST_CITY = 'restaurant_city'
REST_STATE = 'restaurant_state'
REST_ZIPCODE = 'restaurant_zipcode'
MENU_TYPE = 'menu_type'
MENU_CREATION_DATE = 'menu_creation_date'
MENU_SECTIONS = 'menu_sections'
MENU_CATEGORIES = 'menu_categories'
MENU_ITEMS = 'menu_items'
MENU_MODIFIER_GROUPS = 'menu_modifier_groups'
MENU_MODIFIERS = 'menu_modifiers'

def start_deferred_task_export_menu_stats_all_restaurants():
    _all_restaurants = Restaurant.query(all_status=True).fetch()
    _all_rows = []
    for _restaurant in _all_restaurants:
        _pos_key = _restaurant.point_of_sale
        _ds_keys = _restaurant.delivery_services

        _all_ms = []
        if _pos_key:
            _all_ms.append(_pos_key.get().menuSync.get())

        if _ds_keys:
            for _ds_key in _ds_keys:
                _all_ms.append(_ds_key.get().menuSync.get())

        for _ms in _all_ms:
            _export_row = {REST_ID: str(_restaurant.key.id()),
                           ACCOUNT_NAME: str(_restaurant.account.get().name),
                           REST_NAME: str(_restaurant.name),
                           REST_CITY: str(_restaurant.city),
                           REST_STATE: str(_restaurant.state),
                           REST_ZIPCODE: str(_restaurant.zipcode)}
            _export_row[MENU_TYPE] = str(_ms.service.get().type) if _ms.service else ""
            _export_row[MENU_CREATION_DATE] = str(_ms.api_created_at)

            from application.apis.menu.model.MenuSection import MenuSection
            _nb_sections = MenuSection.query().filter(MenuSection.menuSync == _ms.key).count()
            _export_row[MENU_SECTIONS] = str(_nb_sections)

            from application.apis.menu.model.MenuCategory import MenuCategory
            _nb_categories = MenuCategory.query().filter(MenuCategory.menuSync == _ms.key).count()
            _export_row[MENU_CATEGORIES] = str(_nb_categories)

            from application.apis.menu.model.MenuItem import MenuItem
            _nb_items = MenuItem.query().filter(MenuItem.menuSync == _ms.key).count()
            _export_row[MENU_ITEMS] = str(_nb_items)

            from application.apis.menu.model.MenuModifierGroup import MenuModifierGroup
            _nb_modifier_groups = MenuModifierGroup.query().filter(MenuModifierGroup.menuSync == _ms.key).count()
            _export_row[MENU_MODIFIER_GROUPS] = str(_nb_modifier_groups)

            from application.apis.menu.model.MenuItemModifier import MenuItemModifier
            _nb_modifiers = MenuItemModifier.query().filter(MenuItemModifier.menuSync == _ms.key).count()
            _export_row[MENU_MODIFIERS] = str(_nb_modifiers)

            _all_rows.append(_export_row)

    _schema = [ACCOUNT_NAME,
               REST_NAME,
               REST_ID,
               REST_CITY,
               REST_STATE,
               REST_ZIPCODE,
               MENU_TYPE,
               MENU_CREATION_DATE,
               MENU_SECTIONS,
               MENU_CATEGORIES,
               MENU_ITEMS,
               MENU_MODIFIER_GROUPS,
               MENU_MODIFIERS]
    result =''

    for _col in _schema:
        if _schema.index(_col) != 0:
            result += ","
        result += str(_col)
    result += "\n"

    for _row in _all_rows:
        for _col in _schema:
            if _schema.index(_col) != 0:
                result += ","
            result += str(_row[_col])
        result += "\n"
    send_admin_email(recipients=get_config_for_key('EMAIL_TO_ADMINS'), subject='All Restaurant menu Statistics', body=result)
    return
