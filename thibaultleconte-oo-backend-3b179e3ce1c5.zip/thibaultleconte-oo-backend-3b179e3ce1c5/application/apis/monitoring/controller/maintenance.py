# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/13/2019
#

from application.core.task.service import startDeferredTask
from application.core.email.service import send_admin_email
from application.core.settings.app import get_config_for_key

from flask_restplus import Resource, Namespace


nsApi = Namespace('maintenance', description='Maintenance related operations.')

@nsApi.route('/migration/integration')
class MaintenanceMigrationIntegration(Resource):
    def get(self):
        response = 200
        startDeferredTask(start_deferred_task_maintenance_migration_integration)
        return response

def start_deferred_task_maintenance_migration_integration():

    from application.apis.restaurant.model import Restaurant
    from application.apis.deliveryservice.service.common.fetch import get_delivery_services_for_restaurant
    import logging

    _all_restaurants_query = Restaurant.query().order(-Restaurant.api_created_at)
    _all_restaurants_total = _all_restaurants_query.count()
    _all_restaurants = _all_restaurants_query.fetch()
    _processed_restaurants = 0
    for _restaurant in _all_restaurants:
        _processed_restaurants += 1
        _all_delivery_services = get_delivery_services_for_restaurant(restaurant_key=_restaurant.key, keys_only=False)
        for _ds in _all_delivery_services:
            _ds.integration_enabled = _restaurant.pointOfSaleIntegrationEnabled
            _ds.put()
    logging.info("process %s/%s" % (str(_processed_restaurants), str(_all_restaurants_total)))
    return
