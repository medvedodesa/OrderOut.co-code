# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 11/23/2020
#

from application.core.settings.app import get_config_for_key
from flask_restplus import Resource, Namespace
from application.apis.deliveryservice.service.ubereats.authentication import reset_ubereats_access_token

nsApi = Namespace('ubereats-maintenancne', description='UberEats Maintenance related operations.')


@nsApi.route('/accesstoken/reset')
class MonitoringUberEatsResetAccessTokens(Resource):
    # method_decorators = [requires_auth_token]

    @nsApi.doc('Monitoring UberEats Reset Access Token')
    @nsApi.response(200, 'OK')
    def get(self):
        response = 200
        reset_ubereats_access_token()
        return response
