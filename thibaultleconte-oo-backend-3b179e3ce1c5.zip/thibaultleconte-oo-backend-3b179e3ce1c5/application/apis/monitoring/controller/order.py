# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 08/01/2019
#

from flask_restplus import Resource, Namespace
from application.core.exception import errorHandler
from application.core.authentication.service import requires_auth_token
from application.apis.statistics.service.order import query_nb_orders_total, query_nb_orders_today, query_nb_orders_last_days
from flask import current_app
from application.core.email.service import send_admin_email
from json import dumps as json_dumps
from application.core.settings.app import get_config_for_key


nsApi = Namespace('order', description='Order related operations.')

# order_marshal = nsApi.model('Order', Order.schema())


@nsApi.route('/summary')
class MonitoringOrderSummary(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Monitoring Orders Summary')
    @nsApi.response(200, 'OK')
    # @nsApi.response(200, 'OK', orders_pagination_marshal)
    # @nsApi.marshal_with(orders_pagination_marshal)
    # @errorHandler
    def get(self):

        # from application.core.intercom.contact import create_contact_lead
        # from application.core.intercom.tag import attach_clover_lead_tag_to_contact
        # from application.core.intercom.company import fetch_company_name, create_company, attach_contact_to_company
        # from application.apis.pointofsale.model.CloverLead import CloverLead
        #
        # _clover_lead_key = CloverLead.get_key('4603517746544640')
        #
        # _contact_intercom_uuid = create_contact_lead(_clover_lead_key)
        # _success = attach_clover_lead_tag_to_contact(_contact_intercom_uuid)
        # _company_intercom_uuid = fetch_company_name(_clover_lead_key.get().account_name)
        # if not _company_intercom_uuid: _company_intercom_uuid = create_company(_clover_lead_key.get().account_name)
        # _success = attach_contact_to_company(_company_intercom_uuid, _contact_intercom_uuid)
        # return _success

        # from application.core.phonevalidator.search import check_phone_number_is_mobile
        # from application.core.avochato.text import send_text_message_for_new_clover_lead as send_avochato_text_message_for_new_clover_lead
        # import logging
        # _phone_number = "6176531302"
        # _is_mobile = check_phone_number_is_mobile(phone_number=_phone_number)
        # if _is_mobile:
        #     _result_json, _status_code = send_avochato_text_message_for_new_clover_lead(phone_number=_phone_number)
        #     _result = True if _status_code >= 200 and _status_code <= 299 else False
        # return _result

        _order_today = query_nb_orders_today()
        _order_yesterday = query_nb_orders_last_days(since_nb_days=1)
        _order_last_7_days = query_nb_orders_last_days(since_nb_days=7)
        _orders_total = query_nb_orders_total()

        _result = {"orders today": _order_today,
                   "orders yesterday": _order_yesterday,
                   "orders last 7 days": _order_last_7_days,
                   "orders total": _orders_total}

        _subject = 'Orders Daily Summary'
        send_admin_email(get_config_for_key('EMAIL_TO_ADMINS'), _subject, json_dumps(_result))

        return _result
