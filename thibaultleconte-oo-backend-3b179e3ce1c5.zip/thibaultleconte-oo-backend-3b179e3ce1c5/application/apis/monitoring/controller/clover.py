# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/11/2020
#

from application.apis.pointofsale.model.CloverLead import CloverLead
from application.core.task.service import startDeferredTask
from application.core.email.service import send_admin_email
from application.core.settings.app import get_config_for_key

from flask_restplus import Resource, Namespace
from application.core.event.model import CoreEventCategory
from application.core.event.service import create_event
from application.core.authentication.service import requires_auth_token
from application.core.exception import errorHandler
from flask import request
from application.apis.pointofsale.model.PointOfSale import PointOfSale
from datetime import datetime, timedelta


nsApi = Namespace('clover', description='Clover related operations.')

@nsApi.route('/lead/stats')
class MonitoringLeadStats(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Monitoring Leads Stats')
    @nsApi.response(200, 'OK')
    @errorHandler
    def get(self):
        _timeline = []
        _timeline.append({'_1h': datetime.now() - timedelta(hours=1)})
        _timeline.append({'_6h': datetime.now() - timedelta(hours=6)})
        _timeline.append({'_12h': datetime.now() - timedelta(hours=12)})
        _timeline.append({'_1d': datetime.now() - timedelta(days=1)})
        _timeline.append({'_2d': datetime.now() - timedelta(days=2)})
        _timeline.append({'_7d': datetime.now() - timedelta(days=7)})
        _timeline.append({'_14d': datetime.now() - timedelta(days=14)})
        _timeline.append({'_30d': datetime.now() - timedelta(days=30)})

        _results = {}
        for _timelapse in _timeline:
            for _key, _value in _timelapse.items():
                _cloverlead_query = CloverLead.query()
                _cloverlead_query = _cloverlead_query.filter(CloverLead.api_created_at >= _value)
                _cloverlead_query = _cloverlead_query.order(-CloverLead.api_created_at)

                _cloverlead_total = _cloverlead_query.count()

                _stats = {'total': _cloverlead_total}
                _results[_key] = _stats

        return _results

@nsApi.route('/lead/all')
class MonitoringCloverGetAllLeads(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Get all Clover Leads')
    # @nsApi.response(200, 'OK', orders_pagination_marshal)
    # @nsApi.marshal_with(orders_pagination_marshal)
    # @errorHandler
    def get(self):
        response = 200
        startDeferredTask(start_deferred_task_export_clover_lead)
        return response

def start_deferred_task_export_clover_lead():
    _all_leads = CloverLead.query(all_status=True).fetch()
    result ='export\n'
    for _lead in _all_leads:
        result += "%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n" % (str(_lead.account_name), str(_lead.street_address_1), str(_lead.street_address_2), str(_lead.street_address_3), str(_lead.city), str(_lead.zipcode), str(_lead.state), str(_lead.phone_number), str(_lead.owner_name), str(_lead.owner_email), str(_lead.api_created_at))
    send_admin_email(recipients=get_config_for_key('EMAIL_TO_ADMINS'), subject='Clover Lead Export', body=result)
    return

@nsApi.route('/app/<string:merchant_id>/reporting')
class MonitoringCloverPostAppReporting(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Reports an error or exception')
    # @nsApi.response(200, 'OK', orders_pagination_marshal)
    # @nsApi.marshal_with(orders_pagination_marshal)
    @errorHandler
    def post(self, merchant_id):
        response = 200
        json_dict = request.get_json()
        _event_name = json_dict.get('event_name', '')
        _event_message = json_dict.get('event_message', '')
        _event_payload = json_dict.get('event_payload', {})
        _pos = PointOfSale.get_by_merchant_id(merchant_id)
        _parent_entities_keys = []
        if _pos: _parent_entities_keys = [_pos.account, _pos.restaurant]
        create_event(category=CoreEventCategory.CLOVER_APP,
                     name=_event_name,
                     success=False,
                     message=_event_message,
                     payload=_event_payload,
                     entity_key=_pos.key,
                     parent_entities_keys=_parent_entities_keys)
        return response
