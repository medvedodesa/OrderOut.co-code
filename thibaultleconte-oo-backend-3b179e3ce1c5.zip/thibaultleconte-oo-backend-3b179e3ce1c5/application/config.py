# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

from application.secret_keys import CSRF_SECRET_KEY, SESSION_KEY


class _Config(object):
    COMPANY = "OrderOut"
    PROJECT_NAME = "Backend"
    URL_WEBSITE = "https://www.orderout.co"
    URL_LOGO = ""
    CONTACT_EMAIL = "contact@orderout.co"
    ADMIN_EMAIL = "thibault@orderout.co"
    AUTHOR = ""
    DESCRIPTION = ""
    KEYWORDS = ""
    ORDEROUT_SUPPORT_PHONENUMBER = "305-871-9551"

    SECRET_KEY = CSRF_SECRET_KEY
    CSRF_SESSION_KEY = SESSION_KEY

    RESTPLUS_VALIDATE = True
    SWAGGER_UI_DOC_EXPANSION = "none"  # 'none' 'list' 'full'

    GCLOUD_PROJECT_NAME = "orderout-backend"
    GCLOUD_TASK_DEFAULT_QUEUE = "default"
    GCLOUD_TASK_DEFAULT_LOCATION = "us-east1"

    AUTH0_DOMAIN = "orderout.auth0.com"
    AUTH0_API_AUDIENCE = "https://auth0.orderout.co/api"
    AUTH0_USERINFO_URL = "https://orderout.auth0.com/userinfo"
    AUTH0_ROLE_URL = "https://auth.orderout.co/roles"
    AUTH0_ROLE_ADMIN = "admin"

    SENDGRID_API_KEY = (
        "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"
    )

    EMAIL_TO_ADMINS = ["thibault@orderout.co"]
    EMAIL_ADMIN_SENDER = "thibault+backend_bot@orderout.co"
    EMAIL_TO_ONBOARDING = ["thibault@orderout.co", "melissa@orderout.co", "bryan@orderout.co"]
    EMAIL_TO_SUPPORT_MANAGER = ["thibault@orderout.co", "melissa@orderout.co", "bryan@orderout.co"]
    EMAIL_SUPPORT_SENDER = "support@orderout.co"

    EMAIL_THRESHOLD_ONBOARDING_FOLLOWUP = [20, 50, 100]  # After this nb of orders, we send an email reminder to our onboarding team to reach out to the restaurant manager

    APIFY_TOKEN = "kpXKZHuKxzmY5Hg6L2oscjD2J"
    GRUBHUB_HEADER_HACK_API_ACCESS_TOKEN = "hM9Ef6VZmF9iqKRYgHiBSQyrlX5aP8EzMtu9Q4zJx5eMuDYqCG1gyI5f5EvuOxXQ"

    PARSEUR_INCOMING_EMAIL_PREFIX_GRUBHUB_OLD = "orderout+"
    PARSEUR_INCOMING_EMAIL_PREFIX_GRUBHUB = "oogh+"
    PARSEUR_INCOMING_EMAIL_PREFIX_DOORDASH = "oodd+"
    PARSEUR_INCOMING_EMAIL_PREFIX_CHOWNOW = "oocn+"
    PARSEUR_INCOMING_EMAIL_DOMAIN = "@in.parseur.com"

    PRINTER_PULLING_INTERVAL_SECONDS = 5
    PRINTER_PAIRING_CODE_EXPIRATION_SECONDS = 60 * 60 * 48
    PRINTER_TURNED_OFF_TRIGGER_SECONDS = 60 * 60 * 72
    PRINTER_JOB_EXPIRATION_MINUTES = 15

    ORDEROUT_CPUTIL_CONVERT_URL = "https://oo-cputil.appspot.com/cputil/convert"
    ORDEROUT_CPUTIL_CONVERT_PLATFORM = "linux64"

    GCLOUD_PROJECT = "orderout-backend"
    GCLOUD_BIGQUERY_TABLE_ORDER = "oo_order"

    SLACK_BACKEND_CLOVER_WEBHOOK_URL = (
        "https://hooks.slack.com/services/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"
    )
    SLACK_BACKEND_ONBOARDING_WEBHOOK_URL = (
        "https://hooks.slack.com/services/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"
    )
    SLACK_BACKEND_ONBOARDING_FIRST_ORDER_WEBHOOK_URL = (
        "https://hooks.slack.com/services/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"
    )
    SLACK_BACKEND_ONBOARDING_FOLLOWUP_WEBHOOK_URL = (
        "https://hooks.slack.com/services/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"
    )
    SLACK_BACKEND_SUPPORT_WEBHOOK_URL = (
        "https://hooks.slack.com/services/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"
    )
    SLACK_BACKEND_ALERT_CLOVER_UNAUTHORIZED_WEBHOOK_URL = (
        "https://hooks.slack.com/services/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"
    )
    SLACK_BACKEND_ALERT_UBEREATS_MENU = (
        "https://hooks.slack.com/services/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"
    )

    UBEREATS_LOCATION_ID_BISCAYNE_BAKERY = "b14adac4-9138-454a-aa72-b299a8732f84"

    DATABOX_APP_TOKEN = "6ahnl5fjqikg84kgo4sk4044wckw84k4"
    DATABOX_BACKEND_PUSH_URL = "https://push.databox.com"

    AVOCHATO_API_URL_BASE = "https://www.avochato.com/v1/"
    AVOCHATO_API_AUTH_ID = "LV9ab57AeR"
    AVOCHATO_API_AUTH_SECRET = "88d0686191594a30"

    PHONE_VALIDATOR_API_URL_BASE = "https://www.phonevalidator.com/api/phonesearch"
    PHONE_VALIDATOR_API_KEY = "9493b8ef-4cd9-46ef-94fe-184693b3d72f"

    TWILIO_API_URL_BASE = "https://api.twilio.com/2010-04-01"
    TWILIO_API_KEY_ACCOUNT_SID = "ACaacc8c42bbaf19603a493790cbb46cef"
    TWILIO_API_KEY_SECRET = "9641a1986de2c91830e9ed6bb90ba347"
    TWILIO_FROM_PHONE_NUMBER = "+17864225476"

    INTERCOM_API_ACCESS_TOKEN = (
        "dG9rOjE0ZGRjOTU1XzY1MmVfNGJhMV9hMzc2XzVhNGM3NjQ3OTEyNToxOjA="
    )

    GRUBHUB_CLIENT_ID = "QhYEEP59t2QhjFCMvYhsvdN655YPsNCWzggzM8VoA3FNUhSQbSrixtNhLfCK8RVf"
    GRUBHUB_BASE_URL = "https://api-gtm.grubhub.com"

    TABIT_API_URL_BASE = "https://us-middleware.tabit.cloud" # DEV "https://us-middleware.tabit-int.com"
    TABIT_API_KEY_INTEGRATOR_TOKEN = "f2c6abb491ae446395f16cd24524529b" # DEV "30c2c95938bd49078c4588bb6c47fc2b"

    HAPPYFOX_BASIC_AUTH = "Basic YTU2YjhjMjVkMjJiNDg0ZDhmZjk0ZmIyYzAxNDZkOTI6YjM2OTJmZGRjMDgzNDM4ZGEzOTI1ZjExM2QzYjk0NGM="
    HAPPYFOX_CREATE_TICKET_URL = "https://orderout.happyfox.com/api/1.1/json/tickets/"
    HAPPYFOX_GET_ALL_CATEGORY_CUSTOM_FIELDS = "https://orderout.happyfox.com/api/1.1/json/ticket_custom_fields/"
    HAPPYFOX_CATEGORY_ONBOARDING_UUID = 3 # Support:2 Onboarding:3 Test:4
    HAPPYFOX_CUSTOM_FIELD_RESTAURANT_NAME_UUID = 1
    HAPPYFOX_CUSTOM_FIELD_DASHBOARD_URL_UUID = 2

    ACCOUNT_INDEX = "AccountIndex"
    RESTAURANT_INDEX = "RestaurantIndex"

    INFRASTRUCTURE_ADMIN_BASE_URL = 'http://localhost:8080/infrastructure/admin'
    INFRASTRUCTURE_ADMIN_AUTH0_CLIENT_ID = 'gTeUYt1VXftKZIC4XXJM8h3IDoeqODhS'
    INFRASTRUCTURE_ADMIN_AUTH0_CLIENT_SECRET = 'IVelq24RK426wWtowQJoY0DNQg9K13WN3JTABezqJxiaJyYip1cpAwssGTx_pnyR'
    INFRASTRUCTURE_ADMIN_AUTH0_BASE_URL = 'https://orderout.auth0.com'
    INFRASTRUCTURE_ADMIN_AUTH0_ACCESS_TOKEN_URL = '/oauth/token'
    INFRASTRUCTURE_ADMIN_AUTH0_AUTHORIZE_URL = '/authorize'
    INFRASTRUCTURE_ADMIN_AUTH0_CALLBACK_URL = '/callback/auth'

    MAP_SLACK_CHANNEL_HOOKS = {
        "order-alerts": "https://hooks.slack.com/services/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",
        "alerts-doordash-credentials": "https://hooks.slack.com/services/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",
        "alerts-grubhub-credentials": "https://hooks.slack.com/services/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",
    }

    DOORDASH_BASE_AUTH_URL = "https://identity.doordash.com/api/v1/auth/token"
    DOORDASH_BASE_MERCHANT_URL = "https://merchant-mobile-bff.doordash.com"
    DOORDASH_AUTH_HOST = "identity.doordash.com"
    DOORDASH_MERCHANT_HOST = "merchant-mobile-bff.doordash.com"
    DOORDASH_AUTHORIZATION_CODE = "Ft98fOkQwIcAAAAAAAAAANmMvfQvWUg8AAAAAAAAAACimJeZMkWvEwAAAAAAAAAA"
    DOORDASH_DEVICE_ID = "ff92a17f34b208be"
    DOORDASH_CORRELATION_ID = "8d6ffa36-1861-4871-8065-7583c4f1a505"
    DOORDASH_NEW_RELIC_ID = "XAUEWF5SGwEJV1ZRDgEE"

    DATASTORE_MAX_LENGTH = 1048487

class Development(_Config):
    ENV_NAME = "Development"
    DEBUG = True
    CSRF_ENABLED = True
    PROJECT_URL = "https://orderout-tibo.ngrok.io"
    # SERVER_NAME = 'localhost:8080'
    # SERVER_NAME = 'orderout-tibo.ngrok.io'
    # PREFERRED_URL_SCHEME = 'http'

    GCLOUD_BIGQUERY_DATASET_NAME = "oo_dev"

    CLOVER_APP_ID = "6GCRBMM7MG4H8"
    CLOVER_APP_SECRET = "6fc45e47-b1fb-1901-485a-0f20717569e8"
    CLOVER_URL_AUTH_BASE = "https://sandbox.dev.clover.com"
    CLOVER_URL_API_BASE = "https://apisandbox.dev.clover.com/v3/"

    # UBEREATS_CLIENT_ID = 'AEmoijb5J0poyoevtPPv5P5DObjlVkWf'
    # UBEREATS_CLIENT_SECRET = 'iOiMPWhgfNzPe0Ugx7u0JX57hyEH6D72UJVvpdZ5'
    # UBEREATS_SCOPE = 'eats.store eats.order'
    # UBEREATS_TOKEN_URL = 'https://login.uber.com/oauth/v2/token'

    UBEREATS_CLIENT_ID = "bavgddiwJnRtOr4n7hbpNegKnzam2Fu9"
    UBEREATS_CLIENT_SECRET = "JBirYXBAY5XSrneYClupeJFdt8BdwwNlBIMHZqoy"
    UBEREATS_SCOPE = (
        "eats.store eats.order eats.store.orders.read eats.store.status.write"
    )
    UBEREATS_TOKEN_URL = "https://login.uber.com/oauth/v2/token"
    UBEREATS_REDIRECT_URI = "https://orderout-gabriel.ngrok.io/api/oauth/ubereats/redirect_handler"
    UBEREATS_AUTHORIZATION_BASE_URL = "https://login.uber.com/oauth/v2/authorize"

    POSTMATES_BASE_URL = "https://api-v2-stage.postmates.com"
    POSTMATES_DEVELOPER_ID = "dev_aDqiJ4QgQiSkVSxxYea65g"
    POSTMATES_ACCOUNT_ID = "act_vV2vBWwUR9G06peyUjfy2w"
    POSTMATES_BASIC_AUTH_USERNAME = "f5e9b106-0ddb-4658-8305-be2f28373d4e"
    POSTMATES_BASIC_AUTH_PASSWORD = ""

    NEWTEK_API_URL_BASE = "https://orderout-staging.posoncloud.com"
    NEWTEK_API_CLIENT_ID = "79jq8QKvoJA0nCec7e"
    NEWTEK_API_CLIENT_SECRET = "b14m6bZ3wdd3m6UnYl"

    INFRASTRUCTURE_ADMIN_BASE_URL = 'http://localhost:8080/infrastructure/admin'

    ADMIN_BASE_URL = "http://localhost:4200"
    DASHBOARD_BASE_URL = "http://localhost:4200"


class Testing(_Config):
    ENV_NAME = "Testing"
    TESTING = True
    DEBUG = True
    CSRF_ENABLED = True
    PROJECT_URL = "https://orderout-tibo.ngrok.io"
    # SERVER_NAME = 'localhost:8080'
    # PREFERRED_URL_SCHEME = 'http'

    GCLOUD_BIGQUERY_DATASET_NAME = "oo_dev"

    CLOVER_APP_ID = "6GCRBMM7MG4H8"
    CLOVER_APP_SECRET = "6fc45e47-b1fb-1901-485a-0f20717569e8"
    CLOVER_URL_AUTH_BASE = "https://sandbox.dev.clover.com"
    CLOVER_URL_API_BASE = "https://apisandbox.dev.clover.com/v3/"

    UBEREATS_CLIENT_ID = "bavgddiwJnRtOr4n7hbpNegKnzam2Fu9"
    UBEREATS_CLIENT_SECRET = "JBirYXBAY5XSrneYClupeJFdt8BdwwNlBIMHZqoy"
    UBEREATS_SCOPE = (
        "eats.store eats.order eats.store.orders.read eats.store.status.write"
    )
    UBEREATS_TOKEN_URL = "https://login.uber.com/oauth/v2/token"
    UBEREATS_REDIRECT_URI = "https://api.orderout.co/api/oauth/ubereats/redirect_handler"
    UBEREATS_AUTHORIZATION_BASE_URL = "https://login.uber.com/oauth/v2/authorize"

    NEWTEK_API_URL_BASE = "https://orderout-staging.posoncloud.com"
    NEWTEK_API_CLIENT_ID = "79jq8QKvoJA0nCec7e"
    NEWTEK_API_CLIENT_SECRET = "b14m6bZ3wdd3m6UnYl"

    POSTMATES_BASE_URL = "https://api-v2-stage.postmates.com"
    POSTMATES_DEVELOPER_ID = "dev_aDqiJ4QgQiSkVSxxYea65g"
    POSTMATES_ACCOUNT_ID = "act_vV2vBWwUR9G06peyUjfy2w"
    POSTMATES_PLACE_ID = "plc_X22MSGw3RdKUXi6M3BdvYg"
    POSTMATES_BASIC_AUTH_USERNAME = "f5e9b106-0ddb-4658-8305-be2f28373d4e"
    POSTMATES_BASIC_AUTH_PASSWORD = ""

    INFRASTRUCTURE_ADMIN_BASE_URL = 'http://localhost:8080/infrastructure/admin'

    ADMIN_BASE_URL = "http://localhost:4200"
    DASHBOARD_BASE_URL = "http://localhost:4200"


class Production(_Config):
    ENV_NAME = "Production"
    DEBUG = False
    CSRF_ENABLED = True
    PROJECT_URL = "https://api.orderout.co"
    # SERVER_NAME = 'orderout-backend.appspot.com'
    # PREFERRED_URL_SCHEME = 'https'

    GCLOUD_BIGQUERY_DATASET_NAME = "oo_prod"

    CLOVER_APP_ID = "NWHCH32XVYV40"
    CLOVER_APP_SECRET = "28cb6a4f-97db-75b1-0ce0-9d7ffb4f665b"
    CLOVER_URL_AUTH_BASE = "https://www.clover.com"
    CLOVER_URL_API_BASE = "https://api.clover.com/v3/"

    UBEREATS_CLIENT_ID = "bavgddiwJnRtOr4n7hbpNegKnzam2Fu9"
    UBEREATS_CLIENT_SECRET = "JBirYXBAY5XSrneYClupeJFdt8BdwwNlBIMHZqoy"
    UBEREATS_SCOPE = (
        "eats.store eats.order eats.store.orders.read eats.store.status.write"
    )
    UBEREATS_TOKEN_URL = "https://login.uber.com/oauth/v2/token"
    UBEREATS_REDIRECT_URI = "https://api.orderout.co/api/oauth/ubereats/redirect_handler"
    UBEREATS_AUTHORIZATION_BASE_URL = "https://login.uber.com/oauth/v2/authorize"

    NEWTEK_API_URL_BASE = 'https://orderout.posoncloud.com'
    NEWTEK_API_CLIENT_ID = '79jq8QKvoJA0nCec7e'
    NEWTEK_API_CLIENT_SECRET = 'b14m6bZ3wdd3m6UnYl'

    POSTMATES_BASE_URL = "https://api-v2.postmates.com"
    POSTMATES_DEVELOPER_ID = "dev_T6RJl3QlSAiygt6P9U_lAw"
    POSTMATES_ACCOUNT_ID = "act_vV2vBWwUR9G06peyUjfy2w"
    POSTMATES_BASIC_AUTH_USERNAME = "4ed178ed-abaa-4dcd-adee-f52296936798"
    POSTMATES_BASIC_AUTH_PASSWORD = ""

    INFRASTRUCTURE_ADMIN_BASE_URL = 'https://api.orderout.co/infrastructure/admin'

    ADMIN_BASE_URL = "https://admin.orderout.co"
    DASHBOARD_BASE_URL = "https://dashboard.orderout.co"
