import json
import logging

from flask import request, Response
from flask_restplus import Resource, Namespace
from werkzeug.exceptions import Unauthorized, BadRequest

from application.apis.deliveryservice.model.DeliveryService import (
    DeliveryService, DeliveryServiceType
)
from application.apis.deliveryservice.service.ubereats.menu.fetch import startTaskToFetchMenu
from application.apis.deliveryservice.service.ubereats.menu.push import processTaskToPushMenuToUberEats
from application.apis.menu.model.MenuSection import MenuSection
from application.apis.menu.model.MenuSync import MenuSync
from application.apis.menu.service.fetch.section import fetch_all_sections
from application.apis.restaurant.model import Restaurant
from application.core.authentication.service import requires_logged_in_user
from application.core.exception import errorHandler
from application.core.marshal import pagination_schema

nsApi = Namespace("menu", description="Menu public related operations.")

menu_marshal = nsApi.model("Menu", MenuSync.schema())
menu_section_marshal = nsApi.model("MenuSection", MenuSection.schema(True))
menus_pagination_marshal = nsApi.model(
    "MenusPagination", pagination_schema(menu_marshal)
)


@nsApi.route("restaurant/<int:restaurant_id>/menu")
@nsApi.param("restaurant_id", "Restaurant identifier")
class RestaurantMenu(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc("List Restaurant's Menus")
    @nsApi.response(200, "OK", menus_pagination_marshal)
    @nsApi.marshal_with(menu_marshal)
    def get(self, restaurant_id, user=None):
        restaurant = Restaurant.get_by_id(restaurant_id)

        if not restaurant:
            raise Unauthorized

        if user and user.key not in restaurant.users:
            raise Unauthorized

        query = MenuSync.query()
        query = query.filter(MenuSync.restaurant == restaurant.key)
        return query.fetch()

    @nsApi.doc("Create Restaurant's Menus")
    @nsApi.response(200, "OK", menus_pagination_marshal)
    @nsApi.marshal_with(menu_marshal)
    def post(self, restaurant_id, user=None):
        json_dict = request.get_json() if request.json else {}
        restaurant = Restaurant.get_by_id(restaurant_id)

        if not restaurant:
            raise Unauthorized

        if user and user.key not in restaurant.users:
            raise Unauthorized

        menu = MenuSync.create(restaurant.key)
        menu.name = json_dict.get("name")
        menu.description = json_dict.get("description")
        menu.author = user.key
        menu.put()
        return menu


@nsApi.route("restaurant/<int:restaurant_id>/menu/delete")
@nsApi.param("restaurant_id", "Restaurant identifier")
class RestaurantMenuBatchDelete(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc("Delete Restaurant's Menus")
    def post(self, restaurant_id, user=None):
        json_dict = request.get_json() if request.json else {}
        restaurant = Restaurant.get_by_id(restaurant_id)

        if not restaurant:
            raise Unauthorized

        if user and user.key not in restaurant.users:
            raise Unauthorized

        deleted = []
        error = []

        for menu_id in json_dict.get("ids"):
            menu = MenuSync.get_by_id(menu_id)
            if menu and menu.restaurant == restaurant.key:
                menu.delete()
                deleted.append(menu_id)
            else:
                error.append({
                    "id": menu_id,
                    "reason": "Unauthorized",
                })

        return {
            "deleted": deleted,
            "error": error,
        }


@nsApi.route("delivery_service/<int:delivery_service_id>/menu")
@nsApi.param("restaurant_id", "Restaurant identifier")
class DeliveryServiceMenu(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc("Fetch menus from delivery service")
    @nsApi.response(200, "OK", menus_pagination_marshal)
    @nsApi.marshal_with(menu_marshal)
    @errorHandler
    def get(self, delivery_service_id, user=None):
        ds = DeliveryService.get_by_id(delivery_service_id)

        if not ds:
            raise Unauthorized

        restaurant = ds.restaurant

        if not restaurant:
            raise Unauthorized

        restaurant = restaurant.get()

        if user and user.key not in restaurant.users:
            raise Unauthorized

        menu_sync = ds.menuSync.get()
        if not menu_sync:
            raise BadRequest

        return menu_sync


@nsApi.route("menu/<int:menu_id>")
@nsApi.param("menu_id", "Menu identifier")
class Menu(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc("Get Menu")
    @nsApi.response(200, "OK", menus_pagination_marshal)
    @nsApi.marshal_with(menu_marshal)
    def get(self, menu_id, user=None):
        menu = MenuSync.get_by_id(menu_id)

        if not menu:
            raise Unauthorized

        restaurant = Restaurant.get_by_id(menu.restaurant.id())

        if not restaurant:
            raise Unauthorized

        if user and user.key not in restaurant.users:
            raise Unauthorized

        return menu

    @nsApi.doc("Delete Menu")
    def delete(self, menu_id, user=None):
        menu = MenuSync.get_by_id(menu_id)

        if not menu:
            raise Unauthorized

        restaurant = Restaurant.get_by_id(menu.restaurant.id())

        if not restaurant:
            raise Unauthorized

        if user and user.key not in restaurant.users:
            raise Unauthorized

        menu.delete()

        return {"success": True}


@nsApi.route("menu/<int:menu_id>/copy")
@nsApi.param("menu_id", "Menu identifier")
class MenuCopy(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc("Duplicate Menu")
    @nsApi.response(200, "OK", menus_pagination_marshal)
    @nsApi.marshal_with(menu_marshal)
    def post(self, menu_id, user=None):
        json_dict = request.get_json() if request.json else {}
        menu = MenuSync.get_by_id(menu_id)

        if not menu:
            raise Unauthorized

        restaurant = Restaurant.get_by_id(menu.restaurant.id())

        if not restaurant:
            raise Unauthorized

        if user and user.key not in restaurant.users:
            raise Unauthorized

        new_menu = MenuSync.create(restaurant.key)
        new_menu.name = json_dict.get("name", menu.name)
        new_menu.description = json_dict.get("description", menu.description)
        new_menu.author = user.key
        new_menu.put()
        return new_menu


@nsApi.route("delivery_service/<int:delivery_service_id>/menu_fetch", methods=["POST"])
@nsApi.param("delivery_service_id", "Delivery Service identifier")
class DeliveryServiceMenuFetch(Resource):
    method_decorators = [requires_logged_in_user]

    @errorHandler
    def post(self, delivery_service_id, user=None):
        ds = DeliveryService.get_by_id(delivery_service_id)

        if not ds:
            raise Unauthorized

        restaurant = ds.restaurant

        if not restaurant:
            raise Unauthorized

        restaurant = restaurant.get()

        if user and user.key not in restaurant.users:
            raise Unauthorized

        if ds.type == DeliveryServiceType.UBEREATS:
            json_dict = request.get_json()
            startTaskToFetchMenu(
                deliveryservice_key=ds.key,
                name=json_dict.get("name"),
                description=json_dict.get("description"),
                author=user.key,
            )

        return {"success": True}


@nsApi.route("menu/<int:menu_id>/activate")
@nsApi.param("menu_id", "Menu identifier")
class MenuActivate(Resource):
    method_decorators = [requires_logged_in_user]

    @errorHandler
    def post(self, menu_id, user=None):
        json_dict = request.get_json()
        test_on_biscayne_bakery = json_dict.get('testOnBiscayneBakery', True)

        menu = MenuSync.get_by_id(menu_id)

        if not menu:
            raise Unauthorized

        restaurant = Restaurant.get_by_id(menu.restaurant.id())

        if not restaurant:
            raise Unauthorized

        if user and user.key not in restaurant.users:
            raise Unauthorized

        ds = menu.service
        if not ds:
            msg = "Menu not linked with a delivery service"
            logging.info(msg)
            return Response(msg, status=400)

        ds = ds.get()

        if ds.type == DeliveryServiceType.UBEREATS:
            status_code, result_json = processTaskToPushMenuToUberEats(deliveryservice_id=ds.key.id(),
                                                                       test_on_biscayne_bakery=test_on_biscayne_bakery)
            if 200 <= status_code <= 299:
                msg = "Pushing Delivery Service menu started"
                logging.info(msg)
                return Response(msg, status=200)
            else:
                msg = json.dumps(result_json)
                logging.info(msg)
                return Response(msg, status=502)

        msg = "Delivery Service menu push not supported"
        logging.info(msg)
        return Response(msg, status=400)
