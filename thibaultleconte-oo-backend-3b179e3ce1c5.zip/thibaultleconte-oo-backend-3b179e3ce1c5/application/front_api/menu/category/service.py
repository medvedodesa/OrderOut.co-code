from werkzeug.exceptions import BadRequest

from application.apis.menu.model.MenuCategory import MenuCategory
from application.apis.menu.model.MenuSection import MenuSection


def get_all_categories(menu_key):
    query = MenuCategory.query()
    query = query.filter(MenuCategory.menuSync == menu_key)
    query = query.filter(MenuCategory.enabled == True)
    query = query.order(MenuCategory.position)
    return query.fetch()


def create_category(menu_key, section_key, json_dict):
    if "name" not in json_dict:
        raise BadRequest

    category = MenuCategory()
    category.menuSync = menu_key
    category.section = section_key
    category.name = json_dict.get("name")
    if "position" in json_dict:
        category.position = json_dict.get("position")
    if "enabled" in json_dict:
        category.enabled = json_dict.get("enabled")
    category.put()

    section = MenuSection.get_by_id(section_key.id())
    section.categories.append(category.key)
    section.put()

    return category


def update_category(category_id, json_dict):
    category = MenuCategory.get_by_id(category_id)
    if "name" in json_dict:
        category.name = json_dict.get("name")
    if "position" in json_dict:
        category.position = json_dict.get("position")
    if "enabled" in json_dict:
        category.enabled = json_dict.get("enabled")
    category.put()
    return category


def delete_category(category_id):
    category = MenuCategory.get_by_id(category_id)
    category.delete()
    return {"success": True}
