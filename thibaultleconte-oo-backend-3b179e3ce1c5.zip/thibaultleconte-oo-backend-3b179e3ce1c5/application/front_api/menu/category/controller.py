from flask import request
from flask_restplus import Resource, Namespace
from werkzeug.exceptions import Unauthorized, BadRequest

from application.apis.menu.model.MenuCategory import MenuCategory
from application.apis.menu.model.MenuSection import MenuSection
from application.apis.restaurant.model import Restaurant
from application.core.authentication.service import requires_logged_in_user
from application.front_api.menu.category.service import get_all_categories, create_category, update_category, delete_category

nsApi = Namespace("menu_category", description="Menu Category public related operations.")

menu_category_marshal = nsApi.model("MenuCategory", MenuCategory.schema(False))


@nsApi.route("section/<int:section_id>/category")
@nsApi.param("section_id", "Menu Section identifier")
class SectionIdCategory(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc("Get Menu Categories")
    @nsApi.response(200, "OK", menu_category_marshal)
    @nsApi.marshal_with(menu_category_marshal)
    def get(self, section_id, user=None):
        section = MenuSection.get_by_id(section_id)
        check_section_permissions(section, user)

        return get_all_categories(section.menuSync)


    @nsApi.doc("Create Menu Category")
    @nsApi.response(200, "OK", menu_category_marshal)
    @nsApi.marshal_with(menu_category_marshal)
    def post(self, section_id, user=None):
        json_dict = request.get_json()
        if not json_dict:
            raise BadRequest

        section = MenuSection.get_by_id(section_id)
        check_section_permissions(section, user)

        return create_category(section.menuSync, section.key, json_dict)


@nsApi.route("category/<int:category_id>")
@nsApi.param("category_id", "Category identifier")
class CategoryId(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc("Get Menu Category")
    @nsApi.response(200, "OK", menu_category_marshal)
    @nsApi.marshal_with(menu_category_marshal)
    def get(self, category_id, user=None):
        category = MenuCategory.get_by_id(category_id)
        check_category_permissions(category, user)

        return category


    @nsApi.doc("Update Menu Category")
    @nsApi.response(200, "OK", menu_category_marshal)
    @nsApi.marshal_with(menu_category_marshal)
    def put(self, category_id, user=None):
        json_dict = request.get_json()
        if not json_dict:
            raise BadRequest

        category = MenuCategory.get_by_id(category_id)
        check_category_permissions(category, user)

        return update_category(category_id, json_dict)


    @nsApi.doc("Delete Menu Category")
    @nsApi.response(200, "OK")
    def delete(self, category_id, user=None):
        category = MenuCategory.get_by_id(category_id)
        check_category_permissions(category, user)

        return delete_category(category_id)


def check_menu_permissions(menu, user):
    if not menu:
        raise Unauthorized

    restaurant = Restaurant.get_by_id(menu.restaurant.id())
    if not restaurant:
        raise Unauthorized
    if user and user.key not in restaurant.users:
        raise Unauthorized

def check_section_permissions(section, user):
    if not section:
        raise Unauthorized

    menu = section.menuSync.get()
    check_menu_permissions(menu, user)

def check_category_permissions(category, user):
    if not category:
        raise Unauthorized

    menu = category.menuSync.get()
    check_menu_permissions(menu, user)
