from werkzeug.exceptions import BadRequest, Unauthorized

from application.apis.menu.model.MenuSection import MenuSection


DAYS_OF_WEEK = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]

def get_all_sections(menu_key):
    query = MenuSection.query()
    query = query.filter(MenuSection.menuSync == menu_key)
    query = query.filter(MenuSection.enabled == True)
    query = query.order(MenuSection.position)
    return query.fetch()


def create_section(menu_key, json_dict):
    if "name" not in json_dict:
        raise BadRequest

    section = MenuSection()
    section.menuSync = menu_key
    section.name = json_dict.get("name")
    if "description" in json_dict:
        section.description = json_dict.get("description")
    if "position" in json_dict:
        section.position = json_dict.get("position")
    if "enabled" in json_dict:
        section.enabled = json_dict.get("enabled")
    section.put()
    return section


def update_section(section_id, json_dict):
    section = MenuSection.get_by_id(section_id)
    if "name" in json_dict:
        section.name = json_dict.get("name")
    if "description" in json_dict:
        section.description = json_dict.get("description")
    if "position" in json_dict:
        section.position = json_dict.get("position")
    if "enabled" in json_dict:
        section.enabled = json_dict.get("enabled")
    section.put()
    return section


def delete_section(section_id):
    section = MenuSection.get_by_id(section_id)
    section.delete()
    return {"success": True}


def update_section_availability(section_id, json_dict):
    if "availability" not in json_dict:
        raise BadRequest

    section = MenuSection.get_by_id(section_id)
    availability = json_dict.get("availability")

    for day in availability:
        if day.get("day_of_week") not in DAYS_OF_WEEK:
            raise BadRequest
        if "time_periods" not in day:
            raise BadRequest

        for time_period in day.get("time_periods"):
            if "start_time" not in time_period:
                raise BadRequest
            if "end_time" not in time_period:
                raise BadRequest

    section.availability = availability
    section.put()
    return section


def update_sections_positions(menu, json_dict):
    if "positions" not in json_dict:
        raise BadRequest
    positions = json_dict.get("positions")

    for position in positions:
        if "id" not in position or "position" not in position:
            raise BadRequest

        section = MenuSection.get_by_id(position.get("id"))
        if section.menuSync != menu.key:
            raise Unauthorized

        section.position = position.get("position")
        section.put()

    return {"success": True}
