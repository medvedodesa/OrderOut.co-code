from flask import request
from flask_restplus import Resource, Namespace
from werkzeug.exceptions import Unauthorized, BadRequest

from application.apis.menu.model.MenuSection import MenuSection
from application.apis.menu.model.MenuSync import MenuSync
from application.apis.restaurant.model import Restaurant
from application.core.authentication.service import requires_logged_in_user
from application.front_api.menu.section.service import get_all_sections, create_section, update_section, delete_section, \
    update_section_availability, update_sections_positions

nsApi = Namespace("menu_section", description="Menu Section public related operations.")

menu_section_marshal = nsApi.model("MenuSection", MenuSection.schema(False))
menu_section_expanded_marshal = nsApi.model("MenuSection", MenuSection.schema(True))


@nsApi.route("menu/<int:menu_id>/section")
@nsApi.param("menu_id", "Menu identifier")
class MenuIdSection(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc("Get Menu Sections")
    @nsApi.response(200, "OK", menu_section_expanded_marshal)
    @nsApi.marshal_with(menu_section_expanded_marshal)
    def get(self, menu_id, user=None):
        menu = MenuSync.get_by_id(menu_id)
        check_menu_permissions(menu, user)

        return get_all_sections(menu.key)


    @nsApi.doc("Create Menu Section")
    @nsApi.response(200, "OK", menu_section_marshal)
    @nsApi.marshal_with(menu_section_marshal)
    def post(self, menu_id, user=None):
        json_dict = request.get_json()
        if not json_dict:
            raise BadRequest

        menu = MenuSync.get_by_id(menu_id)
        check_menu_permissions(menu, user)

        return create_section(menu.key, json_dict)


@nsApi.route("menu/<int:menu_id>/section/update_positions")
@nsApi.param("menu_id", "Menu identifier")
class MenuIdSectionPositions(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc("Update positions")
    @nsApi.response(200, "OK")
    def post(self, menu_id, user=None):
        json_dict = request.get_json()
        if not json_dict:
            raise BadRequest

        menu = MenuSync.get_by_id(menu_id)
        check_menu_permissions(menu, user)

        return update_sections_positions(menu, json_dict)


@nsApi.route("section/<int:section_id>")
@nsApi.param("section_id", "Section identifier")
class SectionId(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc("Get Menu Section")
    @nsApi.response(200, "OK", menu_section_marshal)
    @nsApi.marshal_with(menu_section_marshal)
    def get(self, section_id, user=None):
        section = MenuSection.get_by_id(section_id)
        check_section_permissions(section, user)

        return section


    @nsApi.doc("Update Menu Section")
    @nsApi.response(200, "OK", menu_section_marshal)
    @nsApi.marshal_with(menu_section_marshal)
    def put(self, section_id, user=None):
        json_dict = request.get_json()
        if not json_dict:
            raise BadRequest

        section = MenuSection.get_by_id(section_id)
        check_section_permissions(section, user)

        return update_section(section_id, json_dict)


    @nsApi.doc("Delete Menu Section")
    @nsApi.response(200, "OK")
    def delete(self, section_id, user=None):
        section = MenuSection.get_by_id(section_id)
        check_section_permissions(section, user)

        return delete_section(section_id)


@nsApi.route("section/<int:section_id>/update_availability")
@nsApi.param("section_id", "Section identifier")
class SectionIdAvailability(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc("Update Menu Section time availability")
    @nsApi.response(200, "OK", menu_section_marshal)
    @nsApi.marshal_with(menu_section_marshal)
    def post(self, section_id, user=None):
        json_dict = request.get_json()
        if not json_dict:
            raise BadRequest

        section = MenuSection.get_by_id(section_id)
        check_section_permissions(section, user)

        return update_section_availability(section_id, json_dict)


def check_menu_permissions(menu, user):
    if not menu:
        raise Unauthorized

    restaurant = Restaurant.get_by_id(menu.restaurant.id())
    if not restaurant:
        raise Unauthorized
    if user and user.key not in restaurant.users:
        raise Unauthorized

def check_section_permissions(section, user):
    if not section:
        raise Unauthorized

    menu = section.menuSync.get()
    check_menu_permissions(menu, user)
