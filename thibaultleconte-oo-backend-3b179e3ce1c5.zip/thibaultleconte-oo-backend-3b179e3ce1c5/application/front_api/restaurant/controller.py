from flask import request
from flask_restplus import Resource, Namespace
from werkzeug.exceptions import NotFound, BadRequest, Unauthorized

from application.apis.ooexceptions import ResourceDoesNotExist
from application.apis.restaurant.model import Restaurant
from application.apis.restaurant.service import get_by_id_and_populate
from application.apis.user.model.User import User, UserRole, ROLE_MAPPING
from application.core.exception import ConflictResourceAlreadyExistsError
from application.core.marshal import create_schema, pagination_schema
from application.core.authentication.service import requires_logged_in_manager
from application.core.authentication.service import requires_logged_in_user


nsApi = Namespace("restaurant", description="Restaurant public related operations.")

restaurant_marshal = nsApi.model("Restaurant", Restaurant.schema())
restaurants_pagination_marshal = nsApi.model(
    "RestaurantsPagination", pagination_schema(restaurant_marshal)
)

user_marshal = nsApi.model('User', User.schema())
users_create_marshal = nsApi.model('UsersCreate', create_schema(user_marshal))


@nsApi.route("restaurant")
class RestaurantRoot(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc("Get a Restaurant")
    @nsApi.response(200, "OK", restaurant_marshal)
    @nsApi.response(409, "Conflict with other resource")
    @nsApi.response(404, "Not found")
    @nsApi.marshal_with(restaurant_marshal)
    def get(self, user=None):
        if not user:
            return []

        return user.get_restaurants()


@nsApi.route("restaurant/<int:restaurant_id>")
@nsApi.param("restaurant_id", "Restaurant identifier")
class RestaurantPutDelete(Resource):

    method_decorators = [requires_logged_in_manager]

    @nsApi.doc("Edit a Restaurant's User")
    @nsApi.response(200, "OK", restaurant_marshal)
    @nsApi.marshal_with(restaurant_marshal)
    @nsApi.response(404, "Not found")
    @nsApi.response(400, "Bad Request")
    def put(self, restaurant_id, user=None):
        json_dict = request.get_json()
        try:
            return get_by_id_and_populate(restaurant_id, json_dict)
        except ResourceDoesNotExist:
            nsApi.abort(404, 'Not found')
        except NotFound:
            nsApi.abort(404, 'Not found')
        except ConflictResourceAlreadyExistsError:
            nsApi.abort(409, 'Resource already exists')
        except Exception as e:
            import logging
            logging.error(e)
            nsApi.abort(400, 'Bad request')


@nsApi.route("restaurant/<int:restaurant_id>/user")
@nsApi.param("restaurant_id", "Restaurant identifier")
class RestaurantUserGetPost(Resource):
    method_decorators = [requires_logged_in_manager]

    @nsApi.doc("List Restaurant's Users")
    @nsApi.response(200, "OK", user_marshal)
    @nsApi.marshal_with(user_marshal)
    def get(self, restaurant_id, user=None):
        _restaurant = Restaurant.get_by_id(restaurant_id)

        if not _restaurant:
            raise Unauthorized

        if user and user.key not in _restaurant.users:
            raise Unauthorized

        users = User.query().filter(User.restaurants == _restaurant.key).fetch()
        return users

    @nsApi.doc("Create a Restaurant's User")
    @nsApi.response(200, "OK", user_marshal)
    @nsApi.response(409, "Conflict with other resource")
    @nsApi.response(400, "Bad Request")
    @nsApi.expect(users_create_marshal, validate=True)
    @nsApi.marshal_with(user_marshal)
    def post(self, restaurant_id, user=None):
        json_dict = request.get_json()
        email = json_dict.pop("email", None)
        role = json_dict.pop("role", "")
        role = role.lower()

        if role:
            if role not in ROLE_MAPPING:
                raise BadRequest

            role = ROLE_MAPPING[role]

        if not email:
            raise BadRequest

        _restaurant = Restaurant.get_by_id(restaurant_id)

        if not _restaurant:
            raise Unauthorized

        if user and user.key not in _restaurant.users:
            raise Unauthorized

        new_user = User.get_by_email(email)
        if not new_user:
            new_user = User.create_and_populate(email, json_dict, role=role)

        _restaurant.add_user(new_user.key)
        return new_user


@nsApi.route("restaurant/<int:restaurant_id>/user/<int:user_id>")
@nsApi.param("restaurant_id", "Restaurant identifier")
@nsApi.param("user_id", "User identifier")
class RestaurantUserDelete(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc("Delete a Restaurant's User")
    @nsApi.response(200, "OK")
    @nsApi.response(404, "Not found")
    @nsApi.response(400, "Bad Request")
    def delete(self, restaurant_id, user_id, user=None):
        if not user.is_manager:
            raise Unauthorized

        try:
            restaurant = Restaurant.get_by_id(restaurant_id)
            if not restaurant:
                raise Unauthorized

            if user and user.key not in restaurant.users:
                raise Unauthorized

            if user.role == UserRole.OWNER:
                raise BadRequest

            _user = User.get_by_id(user_id)
            restaurant.remove_user(_user.key)

        except ResourceDoesNotExist:
            nsApi.abort(404, "Not found")
        except NotFound:
            nsApi.abort(404, "Not found")
        except Exception as e:
            import logging

            logging.error(e)
            nsApi.abort(400, "Bad request")
        return {}

    @nsApi.doc("Edit a Restaurant's User")
    @nsApi.response(200, "OK", user_marshal)
    @nsApi.marshal_with(user_marshal)
    @nsApi.response(404, "Not found")
    @nsApi.response(400, "Bad Request")
    def put(self, restaurant_id, user_id, user=None):
        if user.id != user_id and not user.is_manager:
            raise Unauthorized

        try:
            json_dict = request.get_json()

            role = json_dict.pop("role", "")
            role = role.lower()
            json_dict["email"] = user.email

            if role:
                if role not in ROLE_MAPPING:
                    raise BadRequest

                role = ROLE_MAPPING[role]
                json_dict["role"] = role

            restaurant = Restaurant.get_by_id(restaurant_id)
            if not restaurant:
                raise Unauthorized

            if user and user.key not in restaurant.users:
                raise Unauthorized

            _user = User.get_by_id_and_populate(user_id, json_dict)
            return _user

        except ResourceDoesNotExist:
            nsApi.abort(404, "Not found")
        except NotFound:
            nsApi.abort(404, "Not found")
        except Exception as e:
            import logging

            logging.error(e)
            nsApi.abort(400, "Bad request")
