from flask_restplus import Resource, Namespace

from application.apis.user.model.User import User
from application.core.authentication.service import requires_logged_in_user


nsApi = Namespace("user", description="User public related operations.")

user_marshal = nsApi.model('User', User.schema())


@nsApi.route("user")
class UserRoot(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc("Get a User")
    @nsApi.response(200, "OK", user_marshal)
    @nsApi.response(409, "Conflict with other resource")
    @nsApi.response(404, "Not found")
    @nsApi.marshal_with(user_marshal)
    def get(self, user=None):
        if user:
            return user

        return {}
