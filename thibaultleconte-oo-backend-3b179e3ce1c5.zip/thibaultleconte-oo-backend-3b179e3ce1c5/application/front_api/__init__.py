from flask import Blueprint
from flask_restplus import Api

from application.front_api.restaurant.controller import nsApi as nsRestaurant
from application.front_api.user.controller import nsApi as nsUser
from application.front_api.reports.order.controller import nsApi as nsOrderReport
from application.front_api.order.controller import nsApi as nsOrder
from application.front_api.account.controller import nsApi as nsAccount
from application.front_api.menu.controller import nsApi as nsMenu
from application.front_api.menu.section.controller import nsApi as nsMenuSection
from application.front_api.menu.category.controller import nsApi as nsMenuCategory


blueprint = Blueprint("front_api", __name__)

api_description = "OrderOut Front API."

api = Api(
    blueprint, title="OrderOut Front API", version="1.0", description=api_description, doc="/doc"
)

api.add_namespace(nsUser, path="/")
api.add_namespace(nsRestaurant, path="/")
api.add_namespace(nsAccount, path="/")
api.add_namespace(nsOrderReport, path="/report")
api.add_namespace(nsOrder, path="/order")
api.add_namespace(nsMenu, path="/")
api.add_namespace(nsMenuSection, path="/")
api.add_namespace(nsMenuCategory, path="/")
