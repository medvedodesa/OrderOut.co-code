import logging

from flask import request
from flask_restplus import Resource, Namespace, reqparse
from werkzeug.exceptions import Forbidden

from application.apis.order.functions import list_orders
from application.apis.order.model.Order import Order
from application.apis.order.model.order_issue import OrderIssue
from application.apis.order.service.cancel import order_is_canceled
from application.apis.order.service.push import push_canceled_order_to_printers
from application.core.marshal import pagination_schema
from application.core.authentication.service import requires_logged_in_user
from application.core.exception import errorHandler
from application.core.zapier.push import push_order_report_to_zapier

nsApi = Namespace('order', description='Order related operations.')

order_marshal = nsApi.model('Order', Order.schema())
orders_pagination_marshal_response = nsApi.model('OrdersPaginationResponse', pagination_schema(order_marshal))


@nsApi.route('/list')
class OrderList(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc('List Orders')
    @nsApi.response(200, 'OK', orders_pagination_marshal_response)
    @errorHandler
    def get(self, user):
        parser = reqparse.RequestParser()
        parser.add_argument('page', default=1, type=int)
        parser.add_argument('item_per_page', default=25, type=int)
        parser.add_argument('sort_order', default='desc', type=str)
        parser.add_argument('delivery_service_type', default='', type=str)
        parser.add_argument('account_id', default=None, type=int)
        parser.add_argument('restaurant_id', default=None, type=int)
        parser.add_argument('from_timestamp', default=None, type=str)
        parser.add_argument('to_timestamp', default=None, type=str)
        args = parser.parse_args()

        restaurant_ids = []
        restaurants = user.restaurants
        for r in restaurants:
            if r:
                restaurant_id = r.id()
                restaurant_ids.append(restaurant_id)

        # _limit = args.get('pageSize')
        _sort = args.get('sort_order')
        _page = args.get('page', 1)
        _item_per_page = min(args.get('item_per_page'), 100)
        _account_id = args.get('account_id')
        _restaurant_id = args.get('restaurant_id')
        _from_timestamp = args.get('from_timestamp')
        _to_timestamp = args.get('to_timestamp')
        _delivery_service_type = args.get('delivery_service_type')

        if _restaurant_id not in restaurant_ids:
            raise Forbidden

        __marshalled_result = list_orders(
            account_id=_account_id,
            restaurant_id=_restaurant_id,
            from_timestamp=_from_timestamp,
            to_timestamp=_to_timestamp,
            delivery_service_type=_delivery_service_type,
            page=_page,
            item_per_page=_item_per_page,
            sort=_sort,
        )
        return __marshalled_result

@nsApi.route('/<int:order_id>')
@nsApi.param('order_id', 'Order identifier')
class OrderGet(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc('Get an Order')
    @nsApi.response(200, 'OK', order_marshal)
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(404, 'Not found')
    @nsApi.marshal_with(order_marshal)
    @errorHandler
    def get(self, order_id, user=None):
        order = Order.get_by_id(order_id)

        restaurants = user.get_restaurants()
        restaurant_ids = []
        for r in restaurants:
            if r:
                restaurant_id = r.id
                restaurant_ids.append(restaurant_id)

        if order.restaurant.id() not in restaurant_ids:
            raise Forbidden

        return order

@nsApi.route('/<int:order_id>/cancel')
@nsApi.param('order_id', 'Order identifier')
class OrderPutCancel(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc('Cancel an Order')
    @nsApi.response(200, 'OK')
    @nsApi.response(409, 'Conflict with other ressource')
    @nsApi.response(404, 'Not found')
    @errorHandler
    def put(self, order_id, user=None):
        success = True
        try:
            _order = Order.get_by_id(order_id)

            restaurants = user.get_restaurants()
            restaurant_ids = []
            for r in restaurants:
                if r:
                    restaurant_id = r.id
                    restaurant_ids.append(restaurant_id)

            if _order.restaurant.id() not in restaurant_ids:
                raise Forbidden

            _order = order_is_canceled(_order.key)
            _order = push_canceled_order_to_printers(_order.key)
        except Exception as e:
            logging.exception("Exception on canceling order: {}".format(e))
            success = False

        if success:
            return {'status': 'success'}
        return {'status': 'error'}

@nsApi.route('/<int:order_id>/report_issue')
class ReportOrderIssue(Resource):
    method_decorators = [requires_logged_in_user]

    def post(self, order_id, user=None):
        order = Order.get_by_id(order_id)
        if not order:
            raise Forbidden

        order_key = order.key

        restaurants = user.get_restaurants()
        restaurant_ids = []
        for r in restaurants:
            if r:
                restaurant_id = r.id
                restaurant_ids.append(restaurant_id)

        if order.restaurant.id() not in restaurant_ids:
            raise Forbidden

        payload = request.get_json()
        message = payload.get("message")

        order_issue = OrderIssue(order=order_key, message=message).put()

        push_order_report_to_zapier(
            order_issue_key=order_issue,
            order_issue_message=message,
            user=user,
            order=order,
        )

        return {"status": "success"}
