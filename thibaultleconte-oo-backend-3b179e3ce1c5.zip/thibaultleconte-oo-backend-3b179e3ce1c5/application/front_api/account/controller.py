from flask_restplus import Resource, Namespace

from application.apis.account.model import Account
from application.core.authentication.service import requires_logged_in_user


nsApi = Namespace("Account", description="Account public related operations.")

account_marshall = nsApi.model("Account", Account.schema())


@nsApi.route("account")
class AccountRoot(Resource):
    method_decorators = [requires_logged_in_user]

    @nsApi.doc("Get an Account")
    @nsApi.response(200, "OK", account_marshall)
    @nsApi.response(409, "Conflict with other resource")
    @nsApi.response(404, "Not found")
    @nsApi.marshal_with(account_marshall)
    def get(self, user=None):
        if not user:
            return {}

        return user.account
