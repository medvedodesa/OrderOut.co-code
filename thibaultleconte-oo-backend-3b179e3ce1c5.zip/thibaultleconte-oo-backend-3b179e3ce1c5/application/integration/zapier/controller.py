import logging

from flask import Response, request
from flask_restplus import Resource, Namespace

from application.core.authentication.service import requires_short_auth_token

nsApi = Namespace('integration-zapier', description='Zapier Integration related operations.')


@nsApi.route('/user')
class ZapierIntegrationUser(Resource):
    method_decorators = [requires_short_auth_token]

    def get(self, user):
        logging.info("Zapier Integration - Get user - {}".format(user.email))

        return {
            "userName": "{} {}".format(user.firstname, user.lastname)
        }


@nsApi.route('/restaurants')
class ZapierIntegrationRestaurants(Resource):
    method_decorators = [requires_short_auth_token]

    def get(self, user):
        logging.info("Zapier Integration - Restaurants - {}".format(user.email))

        restaurants = []
        for restaurant_key in user.restaurants:
            restaurants.append({
                "id": restaurant_key.id(),
                "name": restaurant_key.get().name
            })

        return sorted(restaurants, key=lambda restaurant: restaurant["name"])


@nsApi.route('/new-order/subscribe')
class ZapierIntegrationNewOrderSubscribe(Resource):
    method_decorators = [requires_short_auth_token]

    def post(self, user):
        hook_url = request.get_json().get("hookUrl")

        logging.info("Zapier Integration - New Order - Subscribe - {}".format(user.email))
        logging.info("Zapier Integration - New Order - Hook URL - {}".format(hook_url))

        return Response({
            "id": "subscribe_id"
        }, status=200)


@nsApi.route('/new-order/unsubscribe')
class ZapierIntegrationNewOrderUnsubscribe(Resource):
    method_decorators = [requires_short_auth_token]

    def delete(self, user):
        subscribe_id = request.get_json().get("subscribeId")

        logging.info("Zapier Integration - New Order - Unsubscribe - {}".format(user.email))
        logging.info("Zapier Integration - New Order - Subscribe ID - {}".format(subscribe_id))

        return Response("", status=200)
