from flask import Blueprint
from flask_restplus import Api

from application.integration.zapier.controller import nsApi as nsZapier


blueprint = Blueprint("integration", __name__)

api_description = "OrderOut Integration API."

api = Api(
    blueprint, title="OrderOut Integration API", version="1.0", description=api_description, doc="/doc"
)

api.add_namespace(nsZapier, path="/zapier")
