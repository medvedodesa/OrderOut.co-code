from functools import wraps
from flask import current_app, Flask, Blueprint, render_template, request, redirect, url_for, jsonify, session
from authlib.flask.client import OAuth
from six.moves.urllib.parse import urlencode


auth0 = None
AUTH0_CALLBACK_URL = '/callback/auth'

class RegisterBlueprint(Blueprint):
    def register(self, app, options, first_registration=False):
        global auth0

        appAuth = Flask(__name__)
        oauth = OAuth(appAuth)

        config = app.config
        client_id = config.get('INFRASTRUCTURE_ADMIN_AUTH0_CLIENT_ID')
        client_secret = config.get('INFRASTRUCTURE_ADMIN_AUTH0_CLIENT_SECRET')
        api_base_url = config.get('INFRASTRUCTURE_ADMIN_AUTH0_BASE_URL')
        access_token_url = str(api_base_url) + str(config.get('INFRASTRUCTURE_ADMIN_AUTH0_ACCESS_TOKEN_URL'))
        authorize_url = str(api_base_url) + str(config.get('INFRASTRUCTURE_ADMIN_AUTH0_AUTHORIZE_URL'))

        auth0 = oauth.register(
            'auth0',
            client_id=client_id,
            client_secret=client_secret,
            api_base_url=api_base_url,
            access_token_url=access_token_url,
            authorize_url=authorize_url,
            client_kwargs={
                'scope': 'openid profile email',
            },
        )

        super(RegisterBlueprint, self).register(app, options, first_registration)

blueprint = RegisterBlueprint('admin', __name__, template_folder='templates')


# Here we're using the callback route.
@blueprint.route(AUTH0_CALLBACK_URL)
def callback_auth():

    code = request.args.get('code')
    state = request.args.get('state')
    error = request.args.get('error')
    if code and state:
        # Handles response from token endpoint
        auth0.authorize_access_token()
        resp = auth0.get('userinfo')
        userinfo = resp.json()

        # Store the user information in flask session.
        session['jwt_payload'] = userinfo
        session['profile'] = {
            'user_id': userinfo['sub'],
            'name': userinfo['name'],
            'picture': userinfo['picture'],
            'email': userinfo['email']
        }
        return redirect(url_for('admin-common.homepage'))
    elif error:
        return redirect(url_for('admin-common.forbidden'))
    else:
        return redirect(url_for('admin-common.login'))

@blueprint.route('/loginCallback')
def loginCallback():
    return auth0.authorize_redirect(redirect_uri= current_app.config.get('INFRASTRUCTURE_ADMIN_BASE_URL') + AUTH0_CALLBACK_URL)

@blueprint.route('/logout')
def logout():
    # Clear session stored data
    session.clear()
    # Redirect user to logout endpoint
    params = {'returnTo': url_for('admin-common.login', _external=True), 'client_id': current_app.config.get('INFRASTRUCTURE_ADMIN_AUTH0_CLIENT_ID')}
    return redirect(auth0.api_base_url + '/v2/logout?' + urlencode(params))

def requires_auth(f):
  @wraps(f)
  def decorated(*args, **kwargs):
    if 'profile' not in session:
      # Redirect to Login page here
      return redirect(url_for('admin-common.login'))
    return f(*args, **kwargs)

  return decorated

def not_requires_auth(f):
  @wraps(f)
  def decorated(*args, **kwargs):
    if 'profile' in session:
      # Redirect to Home page here
      return redirect(url_for('admin-common.homepage'))
    return f(*args, **kwargs)

  return decorated