# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#
from google.appengine.ext import ndb
from application.apis.order.model.Order import Order
from application.apis.order.model.OrderItemModifier import OrderItemModifier
from application.apis.order.model.OrderItem import OrderItem
from application.apis.deliveryservice.model.DeliveryService import DeliveryService
from application.apis.menu.model.MenuSync import MenuSync
from application.apis.menu.model.MenuItemModifier import MenuItemModifier
from application.apis.menu.model.MenuItem import MenuItem
from application.apis.restaurant.model import Restaurant
from application.apis.account.model import Account
from application.core.task.model import CoreTask, CoreTaskCategory
from application.apis.pointofsale.model.PointOfSale import PointOfSale
from application.apis.user.model.User import User

def get_entity_by_kind(kind):
	if kind == "order":
		return Order
	if kind == "restaurant":
		return Restaurant
	if kind == "account":
		return Account
	if kind == "deliveryservice":
		return DeliveryService
	if kind == "menusync":
		return MenuSync
	if kind == "task":
		return CoreTask
	if kind == "pointofsale":
		return PointOfSale
	if kind == "orderitemmodifier":
		return OrderItemModifier
	if kind == "orderitem":
		return OrderItem
	if kind == "menuitemmodifier":
		return MenuItemModifier
	if kind == "menuitem":
		return MenuItem
	if kind == "user":
		return User
