# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

from application.core.json import  json_string_to_float
# ### custom template filter ###
def json_beautify(text):
    return json_string_to_float(text)

def set_viewer(entity, key):
    import google
    url = 'infrastructure/admin/viewer'
    core_entities_map = {'coretask': 'task', 'urlfetchrequest': 'urlfetch', 'corewebhook': 'webhook', 'coreevent': 'event'}
    if isinstance(entity, google.appengine.ext.ndb.key.Key):
        kind = entity.kind().lower()
        if kind in core_entities_map:
            kind = core_entities_map.get(kind)
            url = 'infrastructure/admin'

        viewer_link = "<a target='_blank' href='/{}/{}/{}'>{}</a>".\
                        format(url, kind,entity.id(), key+' - '+str(entity.id()))
        return viewer_link
    return entity

def is_list(value):
    return isinstance(value, list)
filters = {"json_beautify":json_beautify, "set_viewer":set_viewer, "is_list": is_list}