# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

from application.admin.auth import blueprint as admin_blueprint
from application.admin.views.common import blueprint as admin_common_blueprint
from application.admin.views.event import blueprint as admin_event_blueprint
from application.admin.views.request import blueprint as admin_request_blueprint
from application.admin.views.task import blueprint as admin_task_blueprint
from application.admin.views.webhook import blueprint as admin_webhook_blueprint
from application.admin.views.objviewer import blueprint as admin_objviewer_blueprint