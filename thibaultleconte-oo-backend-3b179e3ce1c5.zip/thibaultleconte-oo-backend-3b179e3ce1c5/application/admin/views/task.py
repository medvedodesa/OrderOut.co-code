# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 10/29/2020
#


from flask import Blueprint, render_template, request
from application.core.task.model import CoreTask, CoreTaskCategory
from application.admin.auth import requires_auth
from application.admin.constants import PAGINATION_DEFAULT_SIZE, PAGINATION_MAX_SIZE


blueprint = Blueprint('admin-task', __name__, static_folder='static', template_folder='templates')

@blueprint.route("/list")
@requires_auth
def lists():
    _item_per_page = min(request.args.get('item_per_page', default=PAGINATION_DEFAULT_SIZE, type=int), PAGINATION_MAX_SIZE)
    _page = request.args.get('page', default=1, type=int)
    _raw_filter = request.args.get('filter', default='', type=str)
    _query = CoreTask.query()
    if _raw_filter:
        _filter_service = CoreTaskCategory(str(_raw_filter))
        _query = _query.filter(CoreTask.category == _filter_service)
    _objects, prev, _next, _count = CoreTask.list_with_offset_pagination(query=_query, page=_page, item_per_page=_item_per_page)
    _filter = {'name': 'Category', 'choices': list(map(str, CoreTaskCategory))}
    _filters = [_filter]
    return render_template('admin/task/list.html', filters=_filters, raw_filter=_raw_filter, objects=_objects, prev=prev, next=_next, page=_page, item_per_page=_item_per_page)


@blueprint.route("/<int:task_id>")
@requires_auth
def details(task_id):
    _obj = CoreTask.get_by_id(task_id)
    return render_template('admin/task/details.html', object=_obj)
