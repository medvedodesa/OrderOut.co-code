# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 10/29/2020
#


from flask import Blueprint, render_template, request
from application.core.event.model import CoreEvent, CoreEventCategory
from application.admin.auth import requires_auth
from application.admin.constants import PAGINATION_DEFAULT_SIZE, PAGINATION_MAX_SIZE


blueprint = Blueprint('admin-event', __name__, static_folder='static', template_folder='templates')

@blueprint.route("/list")
@requires_auth
def lists():
    _item_per_page = min(request.args.get('item_per_page', default=PAGINATION_DEFAULT_SIZE, type=int), PAGINATION_MAX_SIZE)
    _page = request.args.get('page', default=1, type=int)
    _raw_filter = request.args.get('filter', default=None, type=str)
    _query = CoreEvent.query()
    if _raw_filter:
        _filter_service = CoreEventCategory(str(_raw_filter))
        _query = _query.filter(CoreEvent.category == _filter_service)
    _objects, prev, _next, _count = CoreEvent.list_with_offset_pagination(query=_query, page=_page, item_per_page=_item_per_page)
    _filter = {'name': 'Category', 'choices': map(str, CoreEventCategory)}
    _filters = [_filter]
    return render_template('admin/event/list.html', filters=_filters, objects=_objects, prev=prev, next=_next, page=_page, item_per_page=_item_per_page)

@blueprint.route("/<int:event_id>")
@requires_auth
def details(event_id):
    # _obj = CoreTask.get_by_id(event_id)
    _obj = CoreEvent.get_by_id(event_id)
    return render_template('admin/event/details.html', object=_obj)
