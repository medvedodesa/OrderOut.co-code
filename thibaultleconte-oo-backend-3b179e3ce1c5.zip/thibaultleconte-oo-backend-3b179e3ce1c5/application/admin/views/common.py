# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 10/29/2020
#


from flask import Blueprint, render_template
from application.admin.auth import requires_auth, not_requires_auth


blueprint = Blueprint('admin-common', __name__, static_folder='static', template_folder='templates')

@blueprint.route("/")
@not_requires_auth
def login():
    return render_template('admin/login.html')

@blueprint.route("/home")
@requires_auth
def homepage():
    return render_template('admin/homepage.html')

@blueprint.route("/forbidden")
@not_requires_auth
def forbidden():
    return render_template('admin/403.html')

@blueprint.app_errorhandler(404)
def pageNotFound(e):
    return render_template('admin/404.html'), 404