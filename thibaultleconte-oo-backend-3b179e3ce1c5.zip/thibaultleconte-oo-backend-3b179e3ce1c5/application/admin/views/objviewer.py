# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 10/29/2020
#


from flask import Blueprint, render_template
from collections import OrderedDict
from application.core.json import is_json
from application.admin.auth import requires_auth
from application.admin.utils import get_entity_by_kind

blueprint = Blueprint('admin-objviewer', __name__, static_folder='static', template_folder='templates')

@blueprint.route("/<string:entity_kind>/<int:entity_id>")
@requires_auth
def entityDetails(entity_kind, entity_id):
    import google
    entity = get_entity_by_kind(entity_kind)
    _obj = entity.get_by_id(entity_id)
    final_dict = {}
    final_dict["entity_kind"] = entity_kind
    final_dict["entity_id"] = entity_id
    if _obj is not None:
        for k,v in _obj.to_dict().items():


            if is_json(v):
                if "json_data" in final_dict:
                    final_dict["json_data"][format_string(k)] = v
                else:
                    final_dict["json_data"] = {format_string(k): v}
                continue
            if v is None:
                final_dict[format_string(k)] = v

            if isinstance(v, (str,unicode,float,int,google.appengine.ext.ndb.key.Key)):
                if len(str(v)) > 100:
                    continue
                final_dict[format_string(k)] = set_default(v)
    final_dict = OrderedDict(sorted(final_dict.items()))
    return render_template('admin/viewer.html', object=final_dict)

def format_string(string):
    string = string.replace('_', ' ')
    return string.capitalize()


def set_default(data):
    if data is None or data == 'None':
        return "null"
    elif len(str(data)) == 0:
        return '""'
    else:
        return data
