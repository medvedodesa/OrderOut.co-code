# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

from flask import Blueprint, render_template, redirect

blueprint = Blueprint('website', __name__, static_folder='static/website', template_folder='templates/website')

@blueprint.route("/")
def homepage():
    return render_template('homepage.html')

# DEMO
######

@blueprint.route("/demo")
def demo():
    return render_template('demo/main.html')

@blueprint.route("/demo/ubereats")
def demoUberEats():
    return render_template('demo/ubereats.html')

@blueprint.route("/demo/order")
def demoUberEatsOrder():
    from application.apis.restaurant.model import Restaurant
    from application.apis.order.service.fetch import get_last_order_key_for_restaurant
    from application.apis.printer.service.common.printjob import publish_order_print_job_for_restaurant
    _restaurant_id = '4956123002044416' # Biscayne Bakery in api.orderout.co
    _restaurant = Restaurant.get_by_id(_restaurant_id)
    _last_order_key = get_last_order_key_for_restaurant(_restaurant.key)
    _jobs = publish_order_print_job_for_restaurant(_restaurant.key,
                                                   _last_order_key,
                                                   testing=True)
    return redirect('/demo')
