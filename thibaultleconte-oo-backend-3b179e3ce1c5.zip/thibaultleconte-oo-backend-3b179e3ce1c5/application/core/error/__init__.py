# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

from flask import abort
from application.core.email.service import send_raw_email_to_admin
import json


def report_url_fetch(error_url_fetch):
    from application import app
    with app.app_context():
        if error_url_fetch.status_code == 500:
            app.logger.error("New Error with UrlFetchRequest ID: %s" % (str(error_url_fetch.key.id())))
            app.logger.error("Url: %s" % (str(error_url_fetch.url)))
            app.logger.error(error_url_fetch.data_response)
        else:
            app.logger.warning("New Warning with UrlFetchRequest ID: %s" % (str(error_url_fetch.key.id())))
            app.logger.warning("Url: %s" % (str(error_url_fetch.url)))
            app.logger.warning(error_url_fetch.data_response)

def report_and_abort(message, code=500):
    report_error(code, message)
    abort(code, message)

def report_error(code, message, subject="Backend Error", data_dict=None, email_notify=False):
    from application import app
    with app.app_context():
        app.logger.error("--- ERROR REPORTING - BEGINNING ---")
        body = message
        if data_dict: body += " - " + json.dumps(data_dict)
        app.logger.error(body)
        if email_notify: send_raw_email_to_admin(subject=subject, body=body)
        app.logger.error("--- ERROR REPORTING - END ---")

def report_warning(code, message, subject="Backend Warning", data_dict=None, email_notify=False):
    from application import app
    with app.app_context():
        app.logger.warning("--- WARNING REPORTING - BEGINNING ---")
        body = message
        if data_dict: body += " - " + json.dumps(data_dict)
        app.logger.warning(body)
        if email_notify: send_raw_email_to_admin(subject=subject, body=body)
        app.logger.warning("--- WARNING REPORTING - END ---")
