import base64

from application.core.settings.app import get_config_for_key
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.urlFetch.service import fetch_with_url_encoded_data


def send_sms(phone_numbers, message):
    method = 'POST'
    url = _get_url()
    service = UrlFetchService.TWILIO
    headers = {
        'Authorization': 'Basic %s' % str(_get_auth_header()),
    }

    for phone_number in phone_numbers:
        payload = {
            'From': str(get_config_for_key('TWILIO_FROM_PHONE_NUMBER')),
            'To': str(phone_number),
            'Body': str(message)
        }
        result_json, status_code, request_key = fetch_with_url_encoded_data(method, url, service, headers, payload)
        if 200 <= status_code <= 299:
            pass

    return True

def _get_url():
    twilio_api_url_base = str(get_config_for_key('TWILIO_API_URL_BASE'))
    twilio_api_key_account_sid = str(get_config_for_key('TWILIO_API_KEY_ACCOUNT_SID'))
    return '%s/Accounts/%s/Messages.json' % (twilio_api_url_base, twilio_api_key_account_sid)

def _get_auth_header():
    twilio_api_key_account_sid = str(get_config_for_key('TWILIO_API_KEY_ACCOUNT_SID'))
    twilio_api_key_secret = str(get_config_for_key('TWILIO_API_KEY_SECRET'))
    return base64.b64encode('%s:%s' % (twilio_api_key_account_sid, twilio_api_key_secret))
