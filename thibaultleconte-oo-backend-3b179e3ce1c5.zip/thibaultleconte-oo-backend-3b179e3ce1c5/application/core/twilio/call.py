# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 01/17/2020
#

from application.core.urlFetch.service import fetch_with_url_encoded_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.settings.app import get_config_for_key
import base64


def trigger_call_for_clover_onboarding(phone_number):
    _auth = base64.b64encode('%s:%s' % (str(get_config_for_key('TWILIO_API_KEY_ACCOUNT_SID')), str(get_config_for_key('TWILIO_API_KEY_SECRET'))))
    _headers = {'Authorization': 'Basic %s' % (str(_auth))}
    _payload = {'Url':'https://handler.twilio.com/twiml/EH5ac8bddf222d8c5aaf363cb9b6f3758d',
                'To': str(phone_number),
                'From': str(get_config_for_key('TWILIO_FROM_PHONE_NUMBER'))}
    _url = '%s/Accounts/%s/Calls.json' % (str(get_config_for_key('TWILIO_API_URL_BASE')), str(get_config_for_key('TWILIO_API_KEY_ACCOUNT_SID')))
    _result_json, _status_code, _request_key = fetch_with_url_encoded_data("POST", _url, UrlFetchService.TWILIO, headers=_headers, data=_payload)
    if _status_code >= 200 and _status_code <= 299:
        return _result_json, _status_code
    return _result_json, _status_code
