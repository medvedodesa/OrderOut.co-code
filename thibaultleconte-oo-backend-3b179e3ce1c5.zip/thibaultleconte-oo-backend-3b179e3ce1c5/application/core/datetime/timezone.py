# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 06/03/2020
#

from datetime import timedelta
from .zipcodedb import zipcodes as zipcode_dict


def convert_utc_datetime_to_zipcode_timezone(datetime_utc, zipcode, restaurant_key_id):
    # local_datetime = __with_hack_for_newtek(datetime_utc, zipcode, restaurant_key_id)
    local_datetime = __with_database_copy_from_rajdeep_no_outside_library(datetime_utc, zipcode, restaurant_key_id)
    return local_datetime

def __with_hack_for_newtek(datetime_utc, zipcode, restaurant_key_id):
    _list_of_ids_to_hack = ['6077764721442816']
    hours_to_use = 0
    if str(restaurant_key_id) in _list_of_ids_to_hack:
        hours_to_use = -4
        local_datetime = datetime_utc + timedelta(hours = hours_to_use)
    else:
        local_datetime = datetime_utc

    return local_datetime

def __with_database_copy_from_rajdeep_no_outside_library(datetime_utc, zipcode, restaurant_key_id):
    zipcode_detail = zipcode_dict.get(str(zipcode))

    _list_of_ids_to_hack = ['6077764721442816']
    if str(restaurant_key_id) in _list_of_ids_to_hack: zipcode_detail = {'timezone': -5, 'dst': 1}

    if not zipcode_detail: return datetime_utc
    local_datetime = None
    daylings_savings = zipcode_detail.get("dst")

    timezone = zipcode_detail.get("timezone")
    hours_to_use = timezone + daylings_savings
    local_datetime = datetime_utc + timedelta(hours = hours_to_use)
    return local_datetime
