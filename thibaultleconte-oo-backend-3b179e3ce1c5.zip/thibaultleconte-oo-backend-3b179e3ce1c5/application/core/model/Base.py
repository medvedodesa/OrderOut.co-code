
# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

from google.appengine.ext import ndb
from google.appengine.api import memcache
from time import strftime
from flask_restplus import fields
from application.core.exception import StatusConflict, NotFound
from application.core.error import report_error

MEMCACHE_KEY_PREFIX = '_MC_KEY_'
TASK_NAME_SUFFIX = 'TASK_'

##########
# MEMCACHE
##########


def get_mc_key_for_entity_key(entity_key, marshalled=True):
    _name = entity_key.kind().upper()
    _key_id = str(entity_key.id())
    _mc_key = MEMCACHE_KEY_PREFIX + _name + '_' + _key_id
    if marshalled: _mc_key += '_marshalled'
    return _mc_key


def _set_object_to_cache(entity, cache_key):
    mc_client = memcache.Client()
    _success = mc_client.set(cache_key, entity)
    if not _success:
        report_error(500, 'Base - Memcache add failed for object %s with mc_key %s ' % (super(Base, entity)._class_name().upper(), cache_key))
        return None
    return _success


############
# BASE CLASS
############

class Base(ndb.Model):
    api_created_at = ndb.DateTimeProperty(required=True, auto_now_add=True)
    # temporary code
    api_updated_at = ndb.DateTimeProperty()#required=True, auto_now=True)
    api_status = ndb.BooleanProperty(required=True, default=True)

    ###########
    # Name & ID
    ###########
    @property
    def id(self):
        return self.get_id()

    def get_name(self):
        return str(self.__class__ + '_' + str(self.key.id()))

    def get_id(self):
        return int(self.key.id())

    def get_kind(self):
        return str(self.key.kind())

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = {}
        schema['id'] = fields.Integer(readOnly=True, attribute=lambda obj: obj.key.id(), description="Identifier")
        schema['api_created_at'] = fields.DateTime(readOnly=True, description="Creation date and time")
        return schema

    ########
    # CREATE
    ########

    def put(self, **kwargs):
        key = super(Base, self).put(**kwargs)

        # Object caching
        mc_key = self.__class__.get_mc_key_for_entity(key_id=key.id())
        if self.api_status:
            _success = self.__set_to_cache(mc_key)
        else:
            _success = self.__delete_from_cache(mc_key)

        # Marchal Caching - Clean cache for list endpoints caching
        mc_key_marshalled = self.__class__.get_mc_key_for_entity(key_id=key.id(), marshalled=True)
        _success = self.__delete_from_cache(mc_key_marshalled)

        return key

    ######
    # READ
    ######

    @classmethod
    def get_key(cls, key):
        if not key: return None
        return ndb.Key(cls.__name__, int(key))

    @classmethod
    def get_by_id(cls, entity_id, status=True, ignore_status=False):
        mc_key = cls.get_mc_key_for_entity(key_id=entity_id)
        entity = cls.__get_from_cache(mc_key)
        if entity:
            if not ignore_status:
                if entity.api_status != status:
                    return None
        else:
            try:
                entity = cls.get_key(entity_id).get()
            except Exception:
                return None

            if entity:
                if not ignore_status:
                    if entity.api_status != status:
                        return None
                _set_object_to_cache(entity, mc_key)
            else:
                return None

        return entity

    ########
    # UPDATE
    ########

    def populate(self, **kwargs):
        super(Base, self).populate(**kwargs)
        # Object Caching
        mc_key = self.__class__.get_mc_key_for_entity(key_id=self.key.id())
        _success = self.__set_to_cache(mc_key)
        # Marchal Caching
        mc_key_marshalled = self.__class__.get_mc_key_for_entity(key_id=self.key.id(), marshalled=True)
        _success = self.__delete_from_cache(mc_key_marshalled)
        return self

    ########
    # DELETE
    ########
    @classmethod
    def delete_by_id(cls, id):
        _obj = super(Base, cls).get_by_id(id)
        if not _obj: raise NotFound
        _obj.delete()
        return _obj

    def delete(self, async=False):
        mc_key = self.get_mc_key_for_entity(key_id=self.key.id())
        self.api_status = False
        _result = self.put_async() if async == True else self.put()
        return _result

    ###########
    # NDB QUERY
    ###########

    # Query for active (not-deleted) models only
    @classmethod
    def query(cls, ancestor=None, status=True, all_status=False, *args):
        if ancestor: return super(Base, cls).query(ancestor=ancestor, *args)
        if all_status: return super(Base, cls).query(*args)
        return super(Base, cls).query(cls.api_status == status, *args)



    ###################
    # List & Pagination
    ###################

    @classmethod
    def list_with_pagination(cls, query=None, _prev_cursor=None, _next_cursor=None, limit=25, sort='desc', keys_only=True):
        if not query: query = super(cls, cls).query()
        query = query.order(cls.api_created_at) if sort == 'asc' else query.order(-cls.api_created_at)
        if not _prev_cursor and not _next_cursor:
            objects, next_cursor, more = query.fetch_page(page_size=limit, keys_only=keys_only)
            _prev_cursor = None
            if next_cursor == _next_cursor:
                more = False
            _next_cursor = next_cursor.urlsafe() if next_cursor else None
        elif _next_cursor:
            cursor = ndb.Cursor(urlsafe=_next_cursor)
            objects, next_cursor, more = query.fetch_page(page_size=limit, start_cursor=cursor, keys_only=keys_only)
            if next_cursor == _next_cursor:
                more = False

            _prev_cursor = _next_cursor
            if next_cursor:
                _next_cursor = next_cursor.urlsafe()
        elif _prev_cursor:
            cursor = ndb.Cursor(urlsafe=_prev_cursor)
            objects, next_cursor, more = query.fetch_page(page_size=limit, start_cursor=cursor, keys_only=keys_only)
            if next_cursor == _next_cursor:
                more = False

            objects.reverse()
            _next_cursor = _prev_cursor
            if next_cursor:
                _prev_cursor = next_cursor.urlsafe()

        # Count total elements for page size
        _count = query.count(limit=1000, start_cursor=None, end_cursor=None, deadline=30)

        return objects, _prev_cursor, _next_cursor, more, _count

    @classmethod
    def list_with_offset_pagination(cls, query, item_per_page=25, page=1, sort='desc', order_by_key=False, keys_only=False):
        """Pagination through query offset"""
        if not query: query = super(cls, cls).query()

        if sort == 'asc':
            query = query.order(cls.api_created_at, cls.key) if order_by_key else query.order(cls.api_created_at)
        else:
            query = query.order(-cls.api_created_at, cls.key) if order_by_key else query.order(-cls.api_created_at)

        _count = query.count()

        if page < 0: page = 1
        offset = (int(page) - 1) * item_per_page

        objects, next_cursor, more = query.fetch_page(item_per_page, keys_only=keys_only, offset=offset)
        prev = True if offset else False
        next_ = True if more else False
        return objects, prev, next_, _count


    ##########
    # MEMCACHE
    ##########

    @classmethod
    def get_mc_key_for_entity(cls, key_id, marshalled=False):
        # _name = super(Base, cls)._class_name().upper()
        # _key_id = str(key_id)
        # return MEMCACHE_KEY_PREFIX + _name + '_FROM_ID_' + _key_id
        return get_mc_key_for_entity_key(entity_key=cls.get_key(key_id), marshalled=marshalled)

    @classmethod
    def get_entity_from_key_id(cls, key_id):
        mc_key = cls.get_mc_key_for_entity(key_id=key_id)
        entity = cls.__get_from_cache(mc_key)
        if not entity:
            entity = cls.get_by_id(key_id)
            if entity:
                entity.put()
        return entity

    @classmethod
    def __get_from_cache(cls, cache_key):
        try:
            mc_client = memcache.Client()
            entity = mc_client.get(cache_key)
            return entity
        except Exception:
            return None

    def __set_to_cache(self, cache_key):
        return _set_object_to_cache(self, cache_key)

    @classmethod
    def __delete_from_cache(cls, cache_key):
        mc_client = memcache.Client()
        _success = mc_client.delete(cache_key)
        return _success

    ######
    # TASK
    ######

    def get_task_name(self, extra=None):
        _name = TASK_NAME_SUFFIX + self.__class__.__name__.upper() + '_' + str(self.key.id())
        if extra:
            _name += "_" + extra
        _name += '_' + strftime("%Y_%m_%d_%H_%M_%S")
        from random import randint
        _name += "_" + str(randint(0, 999999))
        return _name
