class ServiceChargeApiClient(object):

    MERCHANTS_CONTEXT = "merchants"
    DEFAULT_SERVICE_CHARGE_CONTEXT = "default_service_charge"
    FRIENDLY_REQUEST_NAME = "get_default_service_charge_from_clover"

    def __init__(self, order_key, pos, request_tool):
        self.request_tool = request_tool
        self.order_key = order_key
        self.pos = pos

    def _create_url(self):
        return "/".join([self.MERCHANTS_CONTEXT, self.pos.service_merchant_id, self.DEFAULT_SERVICE_CHARGE_CONTEXT])

    def get_default_service_charge(self):
        result_json, status_code = self.request_tool(
            point_of_sale_key=self.pos.key,
            url=self._create_url(),
            method="GET",
            friendly_request_name=self.FRIENDLY_REQUEST_NAME,
            order_key=self.order_key,
        )
        return result_json, status_code
