# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

from collections import namedtuple
import json
def convert_json_dict_to_object(json_dict):
    result = namedtuple('ObjectJson', json_dict.keys())(*json_dict.values())
    return result


def as_float(obj):
    """Checks each dict passed to this function if it contains the key "value"
    Args:
        obj (dict): The object to decode

    Returns:
        dict: The new dictionary with changes if necessary
    """
    if "value" in obj:
        obj["value"] = float(obj["value"])
    return obj

def json_string_to_float(json_data):
    '''
        Converts json to dict and converts dicts values to floats
    '''
    if isinstance(json_data, dict):
        return json_data

    if json_data and json_data.startswith('"'):
        json_data = json.loads(json_data.replace('\"', '"'))
    l = json.loads(json.dumps(json_data), object_hook=as_float)
    return l


def is_json(text):
    try:
        a_json = json.loads(text)
        if "{" in a_json:
            return True
        return True
    except:
        return False