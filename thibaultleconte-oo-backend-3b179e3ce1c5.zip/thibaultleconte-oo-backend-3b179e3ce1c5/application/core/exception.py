from functools import wraps
from flask_restplus import abort
import logging

class BaseException(Exception):
    def __init__(self):
        Exception.__init__(self)
        self.status_code = 400
        self.message = "Unknown"

    def json(self):
        return {"status_code": self.status_code,
                "message": self.message}

class BadRequest(BaseException):
    def __init__(self):
        self.status_code = 400
        self.message = "BadRequest"

class Unauthorized(BaseException):
    def __init__(self):
        self.status_code = 401
        self.message = "Unauthorized"

class NotFound(BaseException):
    def __init__(self):
        self.status_code = 404
        self.message = "Not Found"

class InternalServerError(BaseException):
    def __init__(self):
        self.status_code = 500
        self.message = "Internal Server Error"


class ConflictResourceAlreadyExistsError(BaseException):
    def __init__(self):
        self.status_code = 409
        self.message = "Resource already exists"

class IncorrectPassword(BaseException):
    def __init__(self):
        self.status_code = 400
        self.message = "Incorrect password"

class AccountDoesNotExist(BaseException):
    def __init__(self):
        self.status_code = 404
        self.message = "Account does not exist"

class PointOfSaleDoesNotExist(BaseException):
    def __init__(self):
        self.status_code = 404
        self.message = "Point Of Sale does not exist"

class OrderDoesNotExist(BaseException):
    def __init__(self):
        self.status_code = 404
        self.message = "Order does not exist"

class NameNotChanged(BaseException):
    def __init__(self):
        self.status_code = 404
        self.message = "Name already exists"

class StatusConflict(BaseException):
    def __init__(self):
        self.status_code = 404
        self.message = "There was an issue with the status of the entity"

class BadGateway(BaseException):
    def __init__(self, service, service_response_code):
        self.status_code = 502
        self.message = "{} responded with a {} code".format(service, service_response_code)




def errorHandler(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except BadRequest:
            abort(400, "Bad Request")
        except Unauthorized:
            abort(404, "Tibo UnauthorizedError")
        except NotFound:
            abort(404, "Not found")
        except InternalServerError:
            abort(500, "Internal Server Error")
        except ConflictResourceAlreadyExistsError:
            abort(409, "The ID you are trying to create a resource with already exists")
        except IncorrectPassword:
            abort(409, "Incorrect password")
        except AccountDoesNotExist:
            abort(404, "The account_id entered does not belong to an account")
        except PointOfSaleDoesNotExist:
            abort(404, "Point Of Sale does not exist")
        except OrderDoesNotExist:
            abort(404, "Order does not exist")
        except NameNotChanged:
            abort(404, "Name already exists")
        except StatusConflict:
            abort(404, "There was a conflict with the status of the account you are trying to reach")
        except AssertionError:
            abort(400, "AssertionError")

        except BaseException as e:
            abort(e.status_code, e.message)
        except Exception as e:
            logging.error(e)
            abort(400, "this doesnt work")

    return wrapper
