from datetime import datetime

DAYS_OF_WEEK = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']


def validate_hour_minute_format(value):
    time_format = "%H:%M"
    try:
        datetime.strptime(value, time_format)
        return True
    except ValueError:
        return False
