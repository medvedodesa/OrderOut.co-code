# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/17/2020
#
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.settings.app import get_config_for_key



def post_message_to_happyfox(data):
	_url = get_config_for_key('HAPPYFOX_CREATE_TICKET_URL')
	_headers = {"Authorization": get_config_for_key('HAPPYFOX_BASIC_AUTH'), 'Content-Type': 'application/json'}
	_result_json, _status_code, _request_key = fetch_with_json_data("POST", _url, UrlFetchService.HAPPYFOX, headers=_headers, data=data)
	return _result_json, _status_code
