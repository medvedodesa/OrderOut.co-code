# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 08/03/2020
#

from .core import post_message_to_happyfox
from application.core.settings.app import get_config_for_key
import json

def create_ticket_for_onboarding(owner_email, owner_name, owner_phone, account_name, restaurant_name, subscription_plan_name, dashboard_url):
	_happyfox_category_uuid = get_config_for_key('HAPPYFOX_CATEGORY_ONBOARDING_UUID')
	_happyfox_restaurant_name_uuid = get_config_for_key('HAPPYFOX_CUSTOM_FIELD_RESTAURANT_NAME_UUID')
	_happyfox_dashboard_url_uuid = get_config_for_key('HAPPYFOX_CUSTOM_FIELD_DASHBOARD_URL_UUID')
	data = {}
	data["email"] = owner_email
	data["name"] = owner_name
	data["phone"] = owner_phone
	data["category"] = _happyfox_category_uuid
	data["priority"] = 1 #1 Medium 2 Critical 3 High 4 Low
	data["text"] = "Subscription: " + subscription_plan_name
	data["subject"] = account_name + " - " + restaurant_name
	data["c-cf-{}".format(_happyfox_restaurant_name_uuid)] = account_name + " - " + restaurant_name
	data["c-cf-{}".format(_happyfox_dashboard_url_uuid)] = dashboard_url
	_result_json, _status_code = post_message_to_happyfox(data)
	return _result_json, _status_code
