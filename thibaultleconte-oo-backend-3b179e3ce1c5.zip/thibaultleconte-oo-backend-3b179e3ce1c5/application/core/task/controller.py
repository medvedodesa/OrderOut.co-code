# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

from flask_restplus import Namespace, Resource

from application.apis.deliveryservice.model.DeliveryService import DeliveryServiceType
from .model import CoreTask, CoreTaskCategory
from .service import addTask
import json
from application.core.error import report_error


nsApi = Namespace("task", description="Task related operations for Asynchronous")


@nsApi.route("/list")
class CoreTaskList(Resource):
    @nsApi.doc("List tasks")
    # @nsApi.marshal_list_with(cat)
    def get(self):
        return 200


@nsApi.route("/<int:task_id>/run")
@nsApi.param("task_id", "Task identifier")
class CoreTaskRun(Resource):
    @nsApi.doc("Start processing task with id")
    def post(self, task_id):
        _task_result_json = {}
        _task = CoreTask.get_by_id(task_id)

        if _task.category == CoreTaskCategory.CORE_MENU_ITEM:
            from application.apis.menu.service.creator import (
                processTaskToCreateOrUpdateMenuItemsAndModifiers,
            )

            _menu_item_dict = json.loads(_task.parameters) if _task.parameters else None
            _task_result_json = processTaskToCreateOrUpdateMenuItemsAndModifiers(
                _task.entity, _menu_item_dict, _task.key
            )
        elif _task.category == CoreTaskCategory.CORE_MENU_PROCESS_DONE:
            from application.apis.menu.service.menusync.process import (
                processTaskAfterMenuHasBeenProcessed,
            )

            _task_result_json = processTaskAfterMenuHasBeenProcessed(_task.entity.id())
        elif _task.category == CoreTaskCategory.CLOVER_MENU:
            from application.apis.pointofsale.service.clover.menu import (
                processTaskToFetchMenuFromClover,
            )

            _task_result_json = processTaskToFetchMenuFromClover(_task.entity.id())
        elif _task.category == CoreTaskCategory.NEWTEK_MENU_FETCH:
            from application.apis.pointofsale.service.newtek.menu import (
                processTaskToFetchMenuFromNewTek,
            )

            _task_result_json = processTaskToFetchMenuFromNewTek(_task.entity.id())
        elif _task.category == CoreTaskCategory.TABIT_MENU_FETCH:
            from application.apis.pointofsale.service.tabit.menu import (
                processTaskToFetchMenuFromTabit,
            )

            _task_result_json = processTaskToFetchMenuFromTabit(_task.entity.id())
        # elif _task.category == CoreTaskCategory.SQUARE_MENU:
        #     from application.apis.pointofsale.service.square.menu import processTaskToFetchMenuItemFromClover
        #     _data_dict = json.loads(_task.parameters)
        #     _task_result_json = processTaskToFetchMenuItemFromClover(_task.entity.id(), data_dict=_data_dict)
        elif _task.category == CoreTaskCategory.UBEREATS_MENU_FETCH:
            from application.apis.deliveryservice.service.ubereats.menu.fetch import (
                processTaskToFetchMenuFromUberEats,
            )

            _task_result_json = processTaskToFetchMenuFromUberEats(_task.entity.id())
        elif _task.category == CoreTaskCategory.UBEREATS_MENU_PUSH:
            from application.apis.deliveryservice.service.ubereats.menu.push import (
                processTaskToPushMenuToUberEats,
            )

            _data_dict = json.loads(_task.parameters) if _task.parameters else None
            _test_on_biscayne_bakery = (
                _data_dict.get("test_on_biscayne_bakery") if _data_dict else True
            )
            _task_status_code, _task_result_json = processTaskToPushMenuToUberEats(
                _task.entity.id(), _test_on_biscayne_bakery
            )
        elif _task.category == CoreTaskCategory.UBEREATS_ORDER_ACCEPT:
            from application.apis.deliveryservice.service.ubereats.pointofsale import (
                process_task_to_accept_order,
            )

            _order_parameters_dict = (
                json.loads(_task.parameters) if _task.parameters else None
            )
            _task_result_json = process_task_to_accept_order(
                _task.entity.id(), _order_parameters_dict
            )
        elif _task.category == CoreTaskCategory.UBEREATS_ORDER_DENY:
            from application.apis.deliveryservice.service.ubereats.pointofsale import (
                process_task_to_deny_order,
            )

            _task_result_json = process_task_to_deny_order(_task.entity.id())
        elif _task.category == CoreTaskCategory.UBEREATS_ORDER_DETAILS:
            from application.apis.deliveryservice.service.ubereats.order import (
                process_task_to_fetch_order_details,
            )

            _order_parameters_dict = (
                json.loads(_task.parameters) if _task.parameters else None
            )
            _task_result_json = process_task_to_fetch_order_details(
                _task.entity.id(), _order_parameters_dict
            )
        elif _task.category == CoreTaskCategory.GRUBHUB_MENU_FETCH:
            from application.apis.deliveryservice.service.grubhub.menu.fetch import (
                processTaskToFetchMenuFromGrubhub,
            )

            _task_result_json = processTaskToFetchMenuFromGrubhub(_task.entity.id())
        elif _task.category == CoreTaskCategory.GRUBHUB_MENU_PROCESS:
            from application.apis.deliveryservice.service.grubhub.menu.process import (
                processTaskToProcessMenuFromGrubhub,
            )

            _task_result_json = processTaskToProcessMenuFromGrubhub(_task.entity.id())
        elif _task.category == CoreTaskCategory.GRUBHUB_ORDER_PROCESS:
            from application.apis.deliveryservice.service.grubhub.order import (
                processTaskToProcessOrderFromGrubhub,
            )

            _order_parameters_dict = (
                json.loads(_task.parameters) if _task.parameters else None
            )
            _task_result_json = processTaskToProcessOrderFromGrubhub(
                _task.entity.id(), _order_parameters_dict
            )
        elif _task.category == CoreTaskCategory.DOORDASH_MENU_FETCH:
            from application.apis.deliveryservice.service.doordash.menu.fetch import (
                processTaskToFetchMenuFromDoorDash,
            )

            _task_result_json = processTaskToFetchMenuFromDoorDash(_task.entity.id())
        elif _task.category == CoreTaskCategory.DOORDASH_MENU_PROCESS:
            from application.apis.deliveryservice.service.doordash.menu.process import (
                processTaskToProcessMenuFromDoorDash,
            )

            _task_result_json = processTaskToProcessMenuFromDoorDash(_task.entity.id())
        elif _task.category == CoreTaskCategory.DOORDASH_ORDER_PROCESS:
            from application.apis.deliveryservice.service.doordash.order import (
                processTaskToProcessOrderFromDoorDash,
            )

            _order_parameters_dict = (
                json.loads(_task.parameters) if _task.parameters else None
            )
            _task_result_json = processTaskToProcessOrderFromDoorDash(
                _task.entity.id(), _order_parameters_dict
            )
        elif _task.category == CoreTaskCategory.WIX_MENU_FETCH:
            from application.apis.deliveryservice.service.wix.menu.fetch import (
                processTaskToFetchMenuFromWix,
            )

            _task_result_json = processTaskToFetchMenuFromWix(_task.entity.id())
        elif _task.category == CoreTaskCategory.WIX_ORDER_PROCESS:
            from application.apis.deliveryservice.service.wix.order import (
                processTaskToProcessOrderDetailsFromWix,
            )

            _order_parameters_dict = (
                json.loads(_task.parameters) if _task.parameters else None
            )
            _task_result_json = processTaskToProcessOrderDetailsFromWix(
                _task.entity.id(), _order_parameters_dict
            )
        elif _task.category == CoreTaskCategory.CHOWNOW_MENU_FETCH:
            from application.apis.deliveryservice.service.chownow.menu.fetch import (
                processTaskToFetchMenuFromChownow,
            )

            _task_result_json = processTaskToFetchMenuFromChownow(_task.entity.id())

        elif _task.category == CoreTaskCategory.CHOWNOW_MENU_PROCESS:
            from application.apis.deliveryservice.service.chownow.menu.process import processTaskToProcessMenuFromChownow
            _task_result_json = processTaskToProcessMenuFromChownow(_task.entity.id())
        elif _task.category == CoreTaskCategory.CHOWNOW_ORDER_PROCESS:
            from application.apis.deliveryservice.service.chownow.order import processTaskToProcessOrderFromChownow
            _order_parameters_dict = json.loads(_task.parameters) if _task.parameters else None
            _task_result_json = processTaskToProcessOrderFromChownow(_task.entity.id(), _order_parameters_dict)

        elif _task.category == CoreTaskCategory.POSTMATES_MENU_COPY:
            from application.apis.deliveryservice.service.postmates.menu.copy import (
                process_menu_copy,
            )

            menu_item_dict = json.loads(_task.parameters)

            from_delivery_service_type = DeliveryServiceType(
                str(menu_item_dict["from_delivery_service_type"])
            )
            _task_result_json = process_menu_copy(_task.entity.id(), from_delivery_service_type)
        elif _task.category == CoreTaskCategory.POSTMATES_MENU_PUSH:
            from application.apis.deliveryservice.service.postmates.menu.push import (
                process_task_to_push_menu_to_postmates
            )
            data_dict = json.loads(_task.parameters) if _task.parameters else None
            test_on_biscayne_bakery = (
                data_dict.get("test_on_biscayne_bakery") if data_dict else True
            )
            _task_result_json = process_task_to_push_menu_to_postmates(_task.entity.id(), test_on_biscayne_bakery)
        elif _task.category == CoreTaskCategory.POSTMATES_ORDER_ACCEPT:
            from application.apis.deliveryservice.service.postmates.webhook import (
                process_task_to_accept_postmates_order
            )
            process_task_to_accept_postmates_order(order_id=_task.entity.id())

        else:
            message = 'Error with Task %s' % str(task_id)
            report_error(code=500, message=message)

        _task.executed(data=_task_result_json)

        return {}

@nsApi.route('/<int:task_id>/rerun')
@nsApi.param('task_id', 'Task identifier')
class CoreTaskReRun(Resource):
    @nsApi.doc('Start processing task with id')
    def post(self, task_id):

        _task_result_json = {}
        _task = CoreTask.get_by_id(task_id)

        _category = _task.category
        # _url = _task.url
        _entity = _task.entity.get()
        _data_dict = json.loads(_task.parameters) if _task.parameters else None
        _countdown = _task.countdown


        if _task: _core_event.parent_entities_keys = [_entity.key]
        _core_event.put()



        task = addTask(category = _category, entity = _entity,\
                     data_dict = _data_dict )
        return {"status": str(True)}
