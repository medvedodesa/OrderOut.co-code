# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

from flask import request
from google.appengine.api import taskqueue

from .model import CoreTask
from google.appengine.ext import deferred
import json
import datetime


def addTask(category, entity, url=None, data_dict=None, countdown=0, scheduled_at=None):
    scheduled_at = datetime.datetime.utcnow() if not scheduled_at else scheduled_at
    _task = CoreTask(category=category,
                     entity=entity.key,
                     name=entity.get_task_name(extra=str(category)),
                     countdown=countdown,
                     scheduled_at=scheduled_at)
    _task.parameters = json.dumps(data_dict) if data_dict else None
    _task.put()

    queue = taskqueue.Queue(name=_task.queue_name)

    from .. import api # TO-DO: Find a way to not have this import here - Currently we have to to avoid circular import -> THAT'S SUCKS AND UGLY
    from application import app
    with app.app_context(), app.test_request_context():
        from .controller import CoreTaskRun
        _url = api.url_for(CoreTaskRun, task_id=_task.key.id())

    t = taskqueue.Task(url=_url, name=_task.name, countdown=_task.countdown, headers=__generate_task_headers())

    rpc = queue.add_async(t)
    t = rpc.get_result()  # TO-CHECK: Do we need this line?
    return _task

##########
# DEFERRED
##########

def startDeferredTask(fct_name, *args, **kwargs):
    import logging
    kwargs["_headers"] = __generate_task_headers()
    _task = deferred.defer(fct_name, *args, **kwargs)
    logging.info("task {}".format(_task.__dict__))
    return True

########
# HELPER
########

def __generate_task_headers():
    # MUST DO THAT WHEN STARTING A TASK FORM A WEBHOOK - because flask http_host does not use localhost:8080 but the ngrok.io url
    _gae_task_header = {}
    from application import app
    with app.app_context(), app.test_request_context():
        if 'ngrok.io' in request.url_root:
            _gae_task_header['host'] = 'localhost:8080'
    return _gae_task_header
