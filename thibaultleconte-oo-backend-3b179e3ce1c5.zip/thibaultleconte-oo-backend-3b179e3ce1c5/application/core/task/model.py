# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#
from google.appengine.api.taskqueue import taskqueue

from application.core.model.Base import Base
from google.appengine.ext import ndb
from protorpc import messages
from datetime import datetime
from google.appengine.ext.ndb import msgprop
from flask_restplus import fields, marshal
import json


class CoreTaskCategory(messages.Enum):
    UNKNOWN = 0
    CORE_MENU_ITEM = 1
    CORE_MENU_PROCESS_DONE = 2
    CLOVER_MENU = 3
    SQUARE_MENU = 4
    UBEREATS_MENU_FETCH = 5
    GRUBHUB_MENU_FETCH = 6
    GRUBHUB_MENU_PROCESS = 7
    GRUBHUB_ORDER_PROCESS = 8
    DOORDASH_MENU_FETCH = 9
    DOORDASH_MENU_PROCESS = 10
    DOORDASH_ORDER_PROCESS = 11
    UBEREATS_ORDER_ACCEPT = 12
    UBEREATS_ORDER_DENY = 13
    UBEREATS_ORDER_DETAILS = 14
    WIX_MENU_FETCH = 15
    WIX_ORDER_PROCESS = 16
    CHOWNOW_MENU_FETCH = 17
    CHOWNOW_MENU_PROCESS = 18
    UBEREATS_MENU_PUSH = 19
    NEWTEK_MENU_FETCH = 20
    CHOWNOW_ORDER_PROCESS = 21
    POSTMATES_MENU_COPY = 22
    POSTMATES_MENU_PUSH = 23
    POSTMATES_ORDER_ACCEPT = 24
    TABIT_MENU_FETCH = 25


class CoreTask(Base):
    category = msgprop.EnumProperty(CoreTaskCategory, required=True)
    entity = ndb.KeyProperty(required=True)
    name = ndb.StringProperty(required=True)
    # url_to_call = ndb.StringProperty(required=True)
    queue_name = ndb.StringProperty(default="default")
    countdown = ndb.IntegerProperty(default=0)
    scheduled_at = ndb.DateTimeProperty(required=True, auto_now_add=True)
    executed_at = ndb.DateTimeProperty(default=None)
    parameters = ndb.JsonProperty(default=None, compressed=True)
    result_data = ndb.JsonProperty(default=None, compressed=True)

    def executed(self, data=None):
        self.executed_at = datetime.utcnow()
        if data:
            self.result_data = json.dumps(data)
        self.put()

    def cancel(self):
        self.scheduled_at = None
        self.put()
        q = taskqueue.Queue(self.queue_name)
        q.delete_tasks(taskqueue.Task(name=self.name))

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema["category"] = fields.String()
        schema["name"] = fields.String()
        schema["scheduled_at"] = fields.DateTime(
            readOnly=True, description="Task schedule date and time"
        )
        schema["executed_at"] = fields.DateTime(
            readOnly=True, description="Task execution date and time"
        )
        return schema


class CoreTaskSchemaFieldFromKeyFormatter(fields.Raw):
    def format(self, value):
        if value:
            return marshal(value.get(), CoreTask.schema())
        return None


class CoreTaskSchemaFieldListOfKeysFormatter(fields.Raw):
    def format(self, value):
        result = []
        for v in value:
            result.append(marshal(v.get(), CoreTask.schema()))
        return result
