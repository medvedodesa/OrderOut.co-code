# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/22/2019
#

from flask import request, g
from flask_restplus import Resource, Namespace, reqparse
from .UrlFetchRequest import UrlFetchRequest, UrlFetchService
from application.core.marshal import pagination_schema
from .service import fetch_with_json_data
from application.core.authentication.service import requires_auth_token
from google.appengine.ext import ndb
from application.core.marshal import oo_marshal_list

nsApi = Namespace('url fetch request', description='UrlFetchRequest related operations.')

urlfetchrequest_marshal = nsApi.model('UrlFetchRequest', UrlFetchRequest.schema())
urlfetchrequests_pagination_marshal = nsApi.model('UrlFetchRequestsPagination', pagination_schema(urlfetchrequest_marshal))

PAGINATION_MAX_SIZE = 100

@nsApi.route('/list')
class UrlFetchRequestList(Resource):

    @nsApi.doc('List UrlFetchRequests')
    @nsApi.response(200, 'OK', urlfetchrequests_pagination_marshal)
    @nsApi.marshal_with(urlfetchrequests_pagination_marshal)
    def get(self):
        _cursor = request.args.get('cursor', default=None, type=str)
        _objects, _previous_cursor, _next_cursor, _more, _count = UrlFetchRequest.list_with_pagination(_next_cursor=_cursor, keys_only=False)
        return {'data': _objects,
                'previous_cursor': _previous_cursor.urlsafe() if _previous_cursor else None,
                'next_cursor': _next_cursor.urlsafe() if _next_cursor else None,
                'more': _more}

@nsApi.route('/rerun')
class UrlFetchRequestRerun(Resource):

    @nsApi.doc('url to rerun UrlFetchRequest')
    @nsApi.response(200, 'OK')
    # @nsApi.response(409, 'Conflict with other ressource')
    # @nsApi.response(404, 'Not found')
    # @nsApi.expect(marshal_connect, validate=True)
    # @nsApi.marshal_with(restaurant_marshal)
    def post(self):
        import logging
        urlfetch_service_dict = {"UNKNOWN":UrlFetchService.UNKNOWN,"AUTH0":UrlFetchService.AUTH0,"CLOVER":UrlFetchService.CLOVER,"APIFY":UrlFetchService.APIFY,\
                                "ORDEROUT_TEST":UrlFetchService.ORDEROUT_TEST,"ORDEROUT_SOCKET":UrlFetchService.ORDEROUT_SOCKET,\
                                "UBEREATS":UrlFetchService.UBEREATS,"DOORDASH":UrlFetchService.DOORDASH,"GRUBHUB":UrlFetchService.GRUBHUB,"ORDEROUT_CPUTIL":UrlFetchService.ORDEROUT_CPUTIL,\
                                "SLACK":UrlFetchService.SLACK,"WIX":UrlFetchService.WIX,"AVOCHATO":UrlFetchService.AVOCHATO,"PHONE_VALIDATOR":UrlFetchService.PHONE_VALIDATOR,\
                                "TWILIO":UrlFetchService.TWILIO,"ZAPIER":UrlFetchService.ZAPIER,"NEWTEK":UrlFetchService.NEWTEK, "TABIT": UrlFetchService.TABIT}
        json_dict = request.get_json()
        # _service = urlfetch_service_dict.get(json_dict["service"])
        _service = UrlFetchService(json_dict["service"])
        _method = json_dict["method"]
        _url = json_dict["url"]
        _data = json_dict["data"]
        logging.info("service:{},method:{},url:{},data:{}".format(_service,_method,_url,_data))
        fetch_with_json_data( method=_method,url=_url, service=_service,data=_data)
        return {"status": str(True)}

@nsApi.route('/search')
@nsApi.param('entity_name', 'Event Entity Name')
@nsApi.param('entity_id', 'Event Entity ID')
class CoreUrlFetchSearch(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Search for urlfetch request with entity name and id')
    def get(self):

        parser = reqparse.RequestParser()
        parser.add_argument('page', default=1, type=int)
        parser.add_argument('item_per_page', default=25, type=int)
        parser.add_argument('entity_name', default=None, type=str)
        parser.add_argument('entity_id', default=None, type=int)
        args = parser.parse_args()

        _page = args.get('page')
        _item_per_page = min(args.get('item_per_page'), PAGINATION_MAX_SIZE)
        _entity_name = args.get('entity_name')
        _entity_id = args.get('entity_id')

        if not _entity_name or not _entity_id: nsApi.abort(404)

        _entity_key = ndb.Key(_entity_name, int(_entity_id))

        # Need to find a mechanism to link entities to request

        _query = UrlFetchRequest.query()
        _query =_query.filter(UrlFetchRequest.related_entities_keys == _entity_key)

        _objects, _prev, _next, _count = UrlFetchRequest.list_with_offset_pagination(query=_query, page=_page, item_per_page=_item_per_page, order_by_key=True, keys_only=True)

        __marshalled_result = {'data': oo_marshal_list(_objects, urlfetchrequest_marshal),
                               'prev': _prev,
                               'next': _next,
                               'page': _page,
                               'count': _count,
                               'item_per_page': _item_per_page}

        return __marshalled_result
