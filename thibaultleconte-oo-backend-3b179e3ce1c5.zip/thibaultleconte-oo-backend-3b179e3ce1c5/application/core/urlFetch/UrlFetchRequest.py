#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

from google.appengine.ext import ndb
from google.appengine.ext.ndb import msgprop
from application.core.model.Base import Base
from protorpc import messages
from flask_restplus import fields
from google.appengine.api import urlfetch


class UrlFetchService(messages.Enum):
    UNKNOWN = 0
    AUTH0 = 1
    CLOVER = 2
    APIFY = 3
    ORDEROUT_TEST = 4
    ORDEROUT_SOCKET = 5
    UBEREATS = 6
    DOORDASH = 7
    GRUBHUB = 8
    ORDEROUT_CPUTIL = 9
    SLACK = 10
    WIX = 11
    AVOCHATO = 12
    PHONE_VALIDATOR = 13
    TWILIO = 14
    ZAPIER = 15
    NEWTEK = 16
    POSTMATES = 17
    INTERCOM = 18
    CHOWNOW = 19
    DATABOX = 20
    TABIT = 21
    HAPPYFOX = 22

class UrlFetchRequest(Base):
    url = ndb.StringProperty(default=None)
    method = ndb.StringProperty(required=True)
    service = msgprop.EnumProperty(UrlFetchService, required=True)
    payload = ndb.JsonProperty(default=None)
    user_key = ndb.KeyProperty(default=None)
    related_entities_keys = ndb.KeyProperty(repeated=True)
    status_code = ndb.IntegerProperty(default=0)
    name = ndb.StringProperty(default=None)
    message = ndb.StringProperty(default=None)
    data_response = ndb.JsonProperty(default=None, compressed=True)
    success = ndb.BooleanProperty(default=False)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema['url'] = fields.String()
        schema['method'] = fields.String()
        schema['service'] = fields.Integer(required=True)
        schema['user'] = fields.Integer()
        schema['status_code'] = fields.Integer()
        schema['name'] = fields.String()
        schema['message'] = fields.String()
        schema['payload'] = fields.Raw()
        schema['data_response'] = fields.Raw()
        schema['success'] = fields.Boolean()
        return schema
