# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

import urllib
from google.appengine.api import urlfetch, urlfetch_errors
import json
import logging
from .UrlFetchRequest import UrlFetchRequest
from flask import g
from application.core.error import report_error
import sys

__ENABLE_URL_FETCH_LOG_SUCCESS = True

def fetch_with_url_encoded_data(method, url, service, headers=None, data=None, related_entities_keys=[]):
    form_data = urllib.urlencode(data) if data else None
    result_json, status_code, request_key = __process_fetcher(method=method,
                                                              url=url,
                                                              service=service,
                                                              headers=headers,
                                                              data=form_data,
                                                              related_entities_keys=related_entities_keys)
    return result_json, status_code, request_key

def fetch_with_json_data(method, url, service, headers=None, data=None, related_entities_keys=[]):
    data_json = json.dumps(data)
    result_json, status_code, request_key = __process_fetcher(method=method,
                                                              url=url,
                                                              service=service,
                                                              headers=headers,
                                                              data=data_json,
                                                              related_entities_keys=related_entities_keys)
    return result_json, status_code, request_key

def __process_fetcher(method, url, service, headers=None, data=None, related_entities_keys=[]):
    headers = {} if not headers else headers
    raw_response, status_code = __run_fetcher(method=method,
                                              url=url,
                                              service=service,
                                              headers=headers,
                                              data=data)
    result_json = {}
    if raw_response:
        if raw_response.content:
            try:
                result_json = json.loads(raw_response.content)
            except ValueError:
                result_json = {'response': raw_response.content}
        else:
            result_json = {}
    if status_code >= 200 and status_code <= 299:
        _request_key = save_success(service=service, method=method, url=url, payload=data, status_code=status_code, result_json=result_json, related_entities_keys=related_entities_keys, success=True)
    else:
        _request_key = save_error(url=url, method=method, service=service, payload=data, status_code=status_code, result_json=result_json, related_entities_keys=related_entities_keys)
    return result_json, status_code, _request_key


def __run_fetcher(method, url, service, headers, data=None):
    # TODO: set the validate_certificate parameter to true for HTTPS
    try:
        raw_response = urlfetch.fetch(url=url,
                                      method=method,
                                      payload=data,
                                      headers=headers,
                                      deadline=50)

        # validate_certificate=True
        return raw_response, raw_response.status_code
    except urlfetch_errors.DeadlineExceededError:
        status_code = 500
        name=str(urlfetch_errors.DeadlineExceededError.__name__)
        logging.error("UrlFetcher DeadlineExceeded for %s" % (str(url)))
        return None, 200
    except Exception as e:
        status_code = 500
        name=str(e.__class__.__name__)
        message=str(e)
        logging.error("UrlFetcher Exception %s for %s" % (str(e), str(url)))
        return None, status_code

#########
# Logging
#########

def save_success(service, method, url, status_code, result_json, user_key=None, related_entities_keys=[], payload=None, success=True):
    if not __ENABLE_URL_FETCH_LOG_SUCCESS: return
    data_payload = json.dumps(payload) if payload else None
    data_response = json.dumps(result_json) if result_json else None
    _obj = UrlFetchRequest(service=service,
                           method=method,
                           url=url,
                           user_key=user_key,
                           related_entities_keys=related_entities_keys,
                           status_code=status_code,
                           payload=data_payload,
                           data_response=data_response,
                           success=success)
    _obj.put()
    return _obj.key

def save_error(service, method, url=None, status_code=-1, name=None, message=None, result_json=None, user_key=None, related_entities_keys=[], payload=None, success=False):
    data_payload = json.dumps(payload) if payload else None
    data_response = json.dumps(result_json) if result_json else None
    data_payload_size = int(sys.getsizeof(data_payload))
    if data_payload_size > 900000:
        _message = 'Error with URLFetch data_payload_size'
        data_dict = {'service': str(service),
                     'method': method,
                     'url': url,
                     'status_code': status_code,
                     'name': name,
                     'message': message,
                     'result_json': result_json,
                     'payload': data_payload,
                     'data_payload_size': data_payload_size}
        report_error(500, subject='Error with URLFetch', message=_message, data_dict=data_dict)
        data_payload = {'original_payload_size': data_payload_size}
    error = UrlFetchRequest(service=service,
                            method=method,
                            url=url,
                            user_key=user_key,
                            related_entities_keys=related_entities_keys,
                            status_code=status_code,
                            payload=data_payload,
                            name=name,
                            message=message,
                            data_response=data_response,
                            success=success)
    error.put()
    from application.core.error import report_url_fetch
    report_url_fetch(error)
    return error.key
