# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/28/2019
#

from google.appengine.ext import ndb
from google.appengine.ext.ndb import msgprop
from application.core.model.Base import Base
from protorpc import messages
from flask_restplus import fields


class CoreWebhookService(messages.Enum):
    UNKNOWN = 0
    AUTH0 = 1
    CLOVER = 2
    APIFY = 3
    PARSEUR = 4
    UBEREATS = 5
    WIX = 6
    ZAPIER = 7
    POSTMATES = 8
    TYPEFORM = 9
    MENU_UPDATE_NOTIFY = 10
    TABIT = 11

class CoreWebhook(Base):
    url = ndb.StringProperty(default=None)
    service = msgprop.EnumProperty(CoreWebhookService, required=True)
    payload = ndb.JsonProperty(default=None, compressed=True)
    success = ndb.BooleanProperty(default=False)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema['url'] = fields.String()
        schema['service'] = fields.Integer(required=True)
        schema['payload'] = fields.Raw()
        schema['success'] = fields.Boolean()
        return schema

    #######
    # LOGIC
    #######

    def is_successful(self):
        self.success = True
        self.put()

    def failed(self):
        self.success = False
        self.put()
