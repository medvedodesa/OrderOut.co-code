# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

from .model import CoreWebhook
import json

def save_webhook(url, service, payload=None):
    _obj = CoreWebhook()
    _obj.url = url
    _obj.service = service
    if payload:
        _obj.payload = json.dumps(payload)
    _obj.put()
    return _obj
