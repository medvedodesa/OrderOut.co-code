# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/11/2019
#

from flask_restplus import fields

def create_schema(data_object_schema):
    return {'entity': fields.Nested(data_object_schema),
            'parent_id': fields.Integer}

def pagination_schema(data_object_schema):
    return {'data': fields.List(fields.Nested(data_object_schema)),
            'next_cursor': fields.String,
            'prev_cursor': fields.String,
            'more': fields.Boolean,
            'count': fields.Integer}

class SchemaFieldKeyFormatter(fields.Raw):
    def format(self, value):
        if value:
            return value.id()
        return None

class SchemaFieldListOfKeysFormatter(fields.Raw):
    def format(self, value):
        result = []
        for v in value:
            result.append(v.id())
        return result

# List of keys

from google.appengine.api import memcache
from application.core.model.Base import get_mc_key_for_entity_key
from flask_restplus import marshal

def oo_marshal_list(data, fields):
    _result = []
    for _element_key in data:
        if not _element_key: continue
        mc_key = get_mc_key_for_entity_key(_element_key, marshalled=True)
        mc_client = memcache.Client()
        __marshalled_element = mc_client.get(mc_key)
        if not __marshalled_element:
            _element = _element_key.get()
            __marshalled_element = marshal(_element, fields)
            mc_client.set(mc_key, __marshalled_element)
        _result.append(__marshalled_element)
    return _result
