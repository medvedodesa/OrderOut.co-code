# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 01/17/2020
#


from application.core.settings.app import get_config_for_key
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.error import report_and_abort


def __format_phone_number(phone_number):
    _result = phone_number.replace(' ', '')
    _result = _result.replace('-', '')
    _result = _result.replace('+', '')
    _result = _result.replace('(', '')
    _result = _result.replace(')', '')
    return _result

def __search_phone_number(phone_number):
    _phone_number = __format_phone_number(phone_number)
    _url = "%s?apikey=%s&phone=%s&type=basic" % (str(get_config_for_key('PHONE_VALIDATOR_API_URL_BASE')), str(get_config_for_key('PHONE_VALIDATOR_API_KEY')), str(_phone_number))
    _result_json, _status_code, _request_key = fetch_with_json_data("GET", _url, UrlFetchService.PHONE_VALIDATOR)
    if _status_code < 200 or _status_code > 299:
        report_and_abort(message='search_phone_number via phone_validator return status code %s' % (str(_status_code)), code=_status_code)
        return _result_json, _status_code
    return _result_json, _status_code

def process_phone_validator_response(result_json):
    _raw_phonebasic = result_json.get('PhoneBasic')
    if _raw_phonebasic:
        _error_code = 200 if _raw_phonebasic.get('ErrorCode') == "" else _raw_phonebasic.get('ErrorCode', 0)
        if _error_code >= 200 and _error_code <= 299:
            _raw_line_type = _raw_phonebasic.get('LineType', '')
            if _raw_line_type and _raw_line_type.lower() == 'cell phone':
                return True
    return False


def check_phone_number_is_mobile(phone_number):
    _result_json, _status_code = __search_phone_number(phone_number)
    _result = False
    if _status_code >= 200 or _status_code <= 299:
        _result = process_phone_validator_response(_result_json)
    return _result
