# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/04/2019
#

from google.appengine.ext import ndb
from google.appengine.ext.ndb import msgprop
from protorpc import messages
from application.core.model.Base import Base
from json import loads as json_loads
from flask_restplus import fields
from application.core.settings.app import get_config_for_key
from application.apis.user.model.User import UserSchemaFieldFromKeyFormatter

class CoreEventCategory(messages.Enum):
    UNKNOWN = 0
    MAPPING = 1
    OAUTH = 2
    PARSEUR = 3
    UUID = 4
    UNAUTHORIZED = 5
    CLOVER_APP = 6
    NOTFOUND = 7
    MISSING_DATA = 8
    DS_DISCONNECT = 9
    DS_CONNECT = 10
    DS_ENABLE = 11
    DS_DISABLE = 12
    UNKNOWN_MENU_ITEM = 13
    UNKNOWN_MENU_MODIFIER = 14
    ORDER_RELEASE = 15
    DS_CREDENTIALS = 16

# UUID: everythin related to other service uuid (not matched in oo-backend, missing uuid, ...)

class CoreEvent(Base):
    category = msgprop.EnumProperty(CoreEventCategory, required=True)
    name = ndb.StringProperty(required=True)
    success = ndb.BooleanProperty(default=True)
    message = ndb.StringProperty()
    payload = ndb.JsonProperty(default=None)
    user_key = ndb.KeyProperty(default=None)
    trigger_event_key = ndb.KeyProperty(default=None)
    entity = ndb.KeyProperty(default=None) # hide from read
    parent_entities_keys = ndb.KeyProperty(repeated=True)

    #########
    # MARSHAL
    #########

    @classmethod
    def schema(cls):
        schema = super(cls, cls).schema()
        schema['category'] = fields.String(required=True, description="Category")
        schema['name'] = fields.String(required=True, description="Name")
        schema['success'] = fields.Boolean(default=True, description="Did it work?")
        schema['message'] = fields.String(required=False, description="Message")
        schema['user'] = UserSchemaFieldFromKeyFormatter(attribute='user_key', description='User')
        schema['payload'] = fields.Raw(description="payload")
        schema['admin_url'] = CoreEventSchemaFieldForAdminUrl(attribute=lambda obj: obj.key.id(), description='Admin Url')
        return schema

    ##########
    # POPULATE
    ##########

    def populate(self, data):
        data['category'] = CoreEventCategory(data['category'])
        return super(cls, self).populate(**data)

class CoreEventSchemaFieldForAdminUrl(fields.Raw):
    def format(self, value):
        if value: return get_config_for_key('INFRASTRUCTURE_ADMIN_BASE_URL') + '/event/' + str(value)
        return None
