# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/04/2019
#

from flask import request
from flask_restplus import Resource, Namespace, reqparse
from service import create_event, list_events, get_event
from model import CoreEvent
from google.appengine.ext import ndb
from application.core.marshal import pagination_schema
from application.core.authentication.service import requires_auth_token
from application.core.marshal import oo_marshal_list


nsApi = Namespace('event', description='Event & Logs related operations')

event_marshal = nsApi.model('Event', CoreEvent.schema())
accounts_pagination_marshal = nsApi.model('EventsPagination', pagination_schema(event_marshal))

PAGINATION_MAX_SIZE = 100


@nsApi.route('/list')
class CoreEventList(Resource):
    @nsApi.doc('List events')
    @nsApi.response(200, 'OK', [event_marshal])
    @nsApi.marshal_list_with(event_marshal)
    def get(self):
        return list_events()

@nsApi.route('/<string:category>/<string:name>')
@nsApi.param('category', 'Event category')
@nsApi.param('name', 'Event name')
class CoreEventCreate(Resource):
    @nsApi.doc('Create an event')
    @nsApi.response(200, 'OK', event_marshal)
    @nsApi.response(400, 'Bad Request')
    @nsApi.expect(event_marshal, validate=True)
    @nsApi.marshal_with(event_marshal)
    def post(self, category, name):
        json_dict = request.get_json()
        _event = create_event(json_dict)
        if _event: return _event
        nsApi.abort(400)

@nsApi.route('/<int:id>')
@nsApi.param('id', 'Event identifier')
class CoreEventGet(Resource):
    @nsApi.doc('Get event with id')
    @nsApi.response(200, 'OK', event_marshal)
    @nsApi.response(404, 'Not found')
    @nsApi.marshal_with(event_marshal)
    def get(self, id):
        _event = get_event(id)
        if _event: return _event
        nsApi.abort(404)

@nsApi.route('/search')
@nsApi.param('entity_name', 'Event Entity Name')
@nsApi.param('entity_id', 'Event Entity ID')
class CoreEventSearch(Resource):
    method_decorators = [requires_auth_token]

    @nsApi.doc('Search for event with entity name and id')
    @nsApi.response(200, 'OK', accounts_pagination_marshal)
    # @nsApi.marshal_list_with(event_marshal)
    def get(self):

        parser = reqparse.RequestParser()
        parser.add_argument('page', default=1, type=int)
        parser.add_argument('item_per_page', default=25, type=int)
        parser.add_argument('entity_name', default=None, type=str)
        parser.add_argument('entity_id', default=None, type=int)
        args = parser.parse_args()

        _page = args.get('page')
        _item_per_page = min(args.get('item_per_page'), PAGINATION_MAX_SIZE)
        _entity_name = args.get('entity_name')
        _entity_id = args.get('entity_id')

        if not _entity_name or not _entity_id: nsApi.abort(404)

        _entity_key = ndb.Key(_entity_name, int(_entity_id))

        _query = CoreEvent.query()
        _query =_query.filter(ndb.OR(CoreEvent.entity == _entity_key, CoreEvent.parent_entities_keys == _entity_key))

        _objects, _prev, _next, _count = CoreEvent.list_with_offset_pagination(query=_query, page=_page, item_per_page=_item_per_page, order_by_key=True, keys_only=True)

        __marshalled_result = {'data': oo_marshal_list(_objects, event_marshal),
                               'prev': _prev,
                               'next': _next,
                               'page': _page,
                               'count': _count,
                               'item_per_page': _item_per_page}

        return __marshalled_result
