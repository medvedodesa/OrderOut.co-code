# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/04/2019
#

from model import CoreEvent, CoreEventCategory

def create_event(json_dict):
    _core_event = CoreEvent()
    _core_event.populate(json_dict)
    _core_event.put()
    return _core_event

def create_event(category, name, success, message=None, payload=None, user_key=None, entity_key=None, parent_entities_keys=None):
    if not parent_entities_keys:
        parent_entities_keys = []
    _core_event = CoreEvent()
    _core_event.category = category
    _core_event.name = name
    _core_event.success = success
    _core_event.message = message
    _core_event.payload = payload
    _core_event.user_key = user_key
    _core_event.entity = entity_key
    _core_event.parent_entities_keys = parent_entities_keys
    _core_event.put()
    return _core_event

def list_events():
    _events = CoreEvent.query().fetch()
    return _events

def get_event(event_id):
    _event = CoreEvent.get_by_id(event_id)
    return _event
