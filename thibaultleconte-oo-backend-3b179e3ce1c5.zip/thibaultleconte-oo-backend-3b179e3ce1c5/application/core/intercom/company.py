# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/01/2020
#

from .core import send_to_intercom


def fetch_company_name(company_name):
    _url = 'https://api.intercom.io/companies?company_id=%s' % (company_name)
    _result_json, _status_code = send_to_intercom(method="GET", url=_url)
    if _status_code >= 200 and _status_code <= 299:
        return _result_json.get('id')
    return None

def create_company(company_name):
    _data = {'name': str(company_name), 'company_id': str(company_name)}
    _url = 'https://api.intercom.io/companies'
    _result_json, _status_code = send_to_intercom(method="POST", url=_url, data=_data)
    return _result_json.get('id')

def attach_contact_to_company(company_intercom_uuid, contact_intercom_uuid):
    _data = {'id': str(company_intercom_uuid)}
    _url = 'https://api.intercom.io/contacts/%s/companies' % (str(contact_intercom_uuid))
    _result_json, _status_code = send_to_intercom(method="POST", url=_url, data=_data)
    return True
