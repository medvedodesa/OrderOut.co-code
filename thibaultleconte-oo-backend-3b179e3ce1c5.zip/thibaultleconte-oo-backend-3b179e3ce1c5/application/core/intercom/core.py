# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/31/2020
#

from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.settings.app import get_config_for_key


##############
# POST MESSAGE
##############

def send_to_intercom(method, url, data=None):
    from application import app
    with app.app_context():
        _access_token = get_config_for_key('INTERCOM_API_ACCESS_TOKEN')
    _headers = {'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + _access_token}
    _result_json, _status_code, _request_key = fetch_with_json_data(method, url, UrlFetchService.INTERCOM, headers=_headers, data=data)
    if _status_code >= 200 and _status_code <= 299:
        return _result_json, _status_code
    return _result_json, _status_code
