# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/01/2020
#

from .core import send_to_intercom


def create_contact_lead(clover_lead_key):
    _clover_lead = clover_lead_key.get()

    _data_location = {'type': 'location',
                      'country': str(_clover_lead.country),
                      'region': str(_clover_lead.state),
                      'city': str(_clover_lead.city)}

    _data = {'role': 'lead',
             'external_id': str(clover_lead_key.id()),
             'email': str(_clover_lead.owner_email),
             'phone': str(_clover_lead.phone_number),
             'name': str(_clover_lead.owner_name),
             'company': str(_clover_lead.account_name),
             'location': _data_location}
    _url = 'https://api.intercom.io/contacts'
    _result_json, _status_code = send_to_intercom(method="POST", url=_url, data=_data)
    return _result_json.get('id')
