# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/31/2020
#

from .core import send_to_intercom


def list_all_tags():
    _url = 'https://api.intercom.io/tags'
    return send_to_intercom(method="GET", url=_url)

def attach_clover_lead_tag_to_contact(contact_intercom_uuid):
    _clover_lead_intercom_uuid = '3895102' # CLOVER_LEAD
    _data = {'id': str(_clover_lead_intercom_uuid)}
    _url = 'https://api.intercom.io/contacts/%s/tags' % (str(contact_intercom_uuid))
    _result_json, _status_code = send_to_intercom(method="POST", url=_url, data=_data)
    return True
