# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 08/01/2019
#

from flask import current_app
from application.core.settings.app import get_config_for_key


def get_project_name():
    from application import app
    with app.app_context(): _project_name = get_config_for_key('GCLOUD_PROJECT')
    return _project_name

def get_database_name():
    from application import app
    with app.app_context(): _dataset_name = get_config_for_key('GCLOUD_BIGQUERY_DATASET_NAME')
    return _dataset_name
