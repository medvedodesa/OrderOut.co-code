# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 07/10/2019
#

from flask import current_app
from google.cloud import bigquery
from application.core.error import report_error
from .helper import get_project_name, get_database_name

def store_one_row(table_name, row):
    rows_to_insert = [row]
    return store_many_rows(table_name, rows_to_insert)

def store_many_rows(table_name, rows):
    if not rows: return False
    bigquery_client = bigquery.Client(project=get_project_name())
    dataset_ref = bigquery_client.dataset(get_database_name())
    table_ref = dataset_ref.table(table_name)
    table = bigquery_client.get_table(table_ref)
    errors = bigquery_client.insert_rows(table, rows)
    if errors:
        _subject = 'GCloud BigQuery Store Insert Error'
        _message = 'Row insert for table %s failed' % (str(object=table_name))
        report_error(code=500, message=_message, subject=_subject, data_dict=errors)
        return False
    return True
