# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 07/11/2019
#

from google.cloud import bigquery
from .helper import get_project_name
import logging


def fetch(query):
    _client = bigquery.Client(project=get_project_name())
    _query_job = _client.query(query, location="US")
    for row in _query_job:
        return row[0]
    return 0
