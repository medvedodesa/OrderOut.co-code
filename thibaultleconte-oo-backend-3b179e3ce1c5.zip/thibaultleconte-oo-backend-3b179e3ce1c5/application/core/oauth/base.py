import logging
import os
import uuid
from base64 import urlsafe_b64encode
from google.appengine.api import memcache
from urllib import urlencode


class InvalidStateException(Exception):
    pass


class OAuthData:
    def __init__(self, oauth_code, restaurant_id, refresh_token):
        self.oauth_code = oauth_code
        self.restaurant_id = restaurant_id
        self.refresh_token = refresh_token


class BaseOAuth:
    def __init__(self, base_url, scope, client_id, redirect_uri):
        self.base_url = base_url
        self.scope = scope
        self.client_id = client_id
        self.redirect_uri = redirect_uri
        self._state = None

    def generate_refresh_token(self, oauth_code):
        raise NotImplementedError

    @property
    def state(self):
        if not self._state:
            self._state = urlsafe_b64encode(os.urandom(24) + uuid.uuid4().bytes).decode("utf-8")
        return self._state

    @property
    def authorization_url(self):
        args = {
            "scope": self.scope,
            "client_id": self.client_id,
            "state": self.state,
            "redirect_uri": self.redirect_uri,
            "response_type": "code",
        }
        authorization_url = "{}?{}".format(self.base_url, urlencode(args))
        return authorization_url

    def handle_oauth_redirect(self, oauth_code, state):
        logging.info("handle oauth redirect")
        mc_client = memcache.Client()
        restaurant_id = mc_client.get(key=state)
        if not restaurant_id:
            raise InvalidStateException

        refresh_token = self.generate_refresh_token(oauth_code=oauth_code)
        logging.info("refresh token: {}".format(refresh_token))
        return OAuthData(oauth_code=oauth_code, restaurant_id=restaurant_id, refresh_token=refresh_token)
