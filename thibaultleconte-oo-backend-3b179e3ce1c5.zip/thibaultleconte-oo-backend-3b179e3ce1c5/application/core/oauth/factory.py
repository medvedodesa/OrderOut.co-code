from application.core.oauth.ubereats import UberEatsOAuthHandler, UberEatsOAuthClient
from application.core.settings.app import get_config_for_key


class OAuthHandlerFactory(object):
    def __init__(self, delivery_service):
        self.delivery_service = delivery_service

    def create(self):
        if self.delivery_service == "ubereats":

            base_url = get_config_for_key("UBEREATS_AUTHORIZATION_BASE_URL")
            client_id = get_config_for_key("UBEREATS_CLIENT_ID")
            client_secret = get_config_for_key("UBEREATS_CLIENT_SECRET")
            redirect_uri = get_config_for_key("UBEREATS_REDIRECT_URI")

            return UberEatsOAuthHandler(
                base_url=base_url,
                scope="offline_access eats.pos_provisioning",
                client_id=client_id,
                client_secret=client_secret,
                redirect_uri=redirect_uri,
            )

    def create_oauth_client(self, refresh_token):
        if self.delivery_service == "ubereats":

            client_id = get_config_for_key("UBEREATS_CLIENT_ID")
            client_secret = get_config_for_key("UBEREATS_CLIENT_SECRET")

            return UberEatsOAuthClient(
                client_id=client_id,
                client_secret=client_secret,
                refresh_token=refresh_token,
            )
