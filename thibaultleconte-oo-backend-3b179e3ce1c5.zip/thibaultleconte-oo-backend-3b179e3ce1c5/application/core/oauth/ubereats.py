import logging
import requests
from werkzeug.exceptions import Forbidden, InternalServerError

from application.core.oauth.base import BaseOAuth
from functools import wraps


URL = "https://login.uber.com/oauth/v2/token"


logger = logging.getLogger(__name__)


class UberEatsOAuthHandler(BaseOAuth):
    def __init__(self, base_url, scope, client_id, client_secret, redirect_uri):
        BaseOAuth.__init__(self, base_url, scope, client_id, redirect_uri)
        self.client_secret = client_secret

    def generate_refresh_token(self, oauth_code):
        payload = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "grant_type": "authorization_code",
            "code": oauth_code,
            "redirect_uri": self.redirect_uri,
        }
        logging.info("generate refresh token {}".format(payload))
        response = requests.post(URL, data=payload)
        logging.info("status_code: {}".format(response.status_code))
        if response.status_code == 200:
            logging.info("response: {}".format(response.json()))
            response = response.json()
            refresh_token = response.get("refresh_token")
            return refresh_token


class UberEatsOAuthClient:
    def __init__(self, client_id, client_secret, refresh_token):
        self.client_id = client_id
        self.client_secret = client_secret
        self.refresh_token = refresh_token

        self._access_token = None

    @property
    def access_token(self):
        if not self._access_token:
            self._access_token = self.get_access_token()

        return self._access_token

    def refresh_access_token(self):
        self._access_token = None
        return self.access_token

    def get_access_token(self):
        payload = {
            "client_secret": (None, self.client_secret),
            "client_id": (None, self.client_id),
            "grant_type": (None, "refresh_token"),
            "refresh_token": (None, self.refresh_token),
        }

        response = requests.post(URL, files=payload)
        if response.status_code == 200:
            response = response.json()
            access_token = response.get("access_token")
            return access_token

    def handle_call(self, func, get_all_args=True):
        @wraps(func)
        def wrapper(*args, **kwargs):
            authorization_value = "Bearer {}".format(self.access_token)

            kwargs["headers"]["Authorization"] = authorization_value
            response, status_code, request_key = func(*args, **kwargs)

            details = response.get("code", "")
            if status_code in (401, 403) and "expired" in details or "unauthorized" in details:
                kwargs["headers"]["Authorization"] = self.refresh_access_token()
                response, status_code, request_key = func(*args, **kwargs)

            if status_code == 403:
                raise Forbidden

            elif 199 > status_code > 299:
                raise InternalServerError

            if get_all_args:
                return response, status_code, request_key

            return response

        return wrapper
