from google.appengine.api import search

from application.apis.restaurant.model import Restaurant
from application.core.settings.app import get_config_for_key


def get_accounts_ids_by_account_or_restaurant_name(name):
    index = search.Index(get_config_for_key("ACCOUNT_INDEX"))
    account_results = index.search("name = {}".format(name)).results

    accounts_ids = []

    for result in account_results:
        account_id = result.doc_id
        accounts_ids.append(account_id)

    index = search.Index(get_config_for_key("RESTAURANT_INDEX"))
    restaurant_results = index.search("name = {}".format(name)).results

    for result in restaurant_results:
        restaurant_id = result.doc_id
        restaurant = Restaurant.get_by_id(restaurant_id)
        if restaurant:
            account = restaurant.account.get()
            accounts_ids.append(account.id)

    return accounts_ids
