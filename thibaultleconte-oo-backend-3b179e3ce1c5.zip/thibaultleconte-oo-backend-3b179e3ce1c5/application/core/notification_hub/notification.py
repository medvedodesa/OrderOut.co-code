class Notification(object):
    @property
    def subject(self):
        raise NotImplementedError

    @property
    def message(self):
        raise NotImplementedError

    @property
    def summary(self):
        raise NotImplementedError
