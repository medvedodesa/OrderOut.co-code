from application.core.notification_hub.slack_notification import SlackNotification
from application.core.settings.app import get_config_for_key


class InvalidCredentialsNotification(SlackNotification):
    def __init__(self, restaurant_id, ds_id, ds_type):
        super(InvalidCredentialsNotification, self).__init__()
        self.restaurant_id = restaurant_id
        self.ds_id = ds_id
        self.ds_type = ds_type

    @property
    def subject(self):
        return ""

    @property
    def message(self):
        return ""

    @property
    def summary(self):
        return "Invalid {ds_type} credentials for restaurant {restaurant_id}.".format(
            restaurant_id=self.restaurant_id,
            ds_type=self.ds_type,
        )

    @property
    def slack_links(self):
        return [{
            "title": "Restaurant",
            "url": "{base_url}/restaurant/{restaurant_id}".format(
                base_url=get_config_for_key("ADMIN_BASE_URL"),
                restaurant_id=str(self.restaurant_id),
            )
        },{
            "title": "Delivery Service",
            "url": "{base_url}/restaurant/{restaurant_id}/ds/{ds_id}".format(
                base_url=get_config_for_key("ADMIN_BASE_URL"),
                restaurant_id=str(self.restaurant_id),
                ds_id=str(self.ds_id),
            )
        }]