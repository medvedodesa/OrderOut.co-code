from application.core.notification_hub.notifications.order_failed import OrderFailedNotification


class OrderFailedNotificationWithItems(OrderFailedNotification):
    def __init__(
        self,
        order_id,
        ds_type,
        restaurant_name,
        order_confirmation_code,
        order_reference,
        order_datetime,
        order_type,
        dropoff_datetime,
        dropoff_name,
        dropoff_phone,
        dropoff_instructions,
        order_items,
        payment_mode,
        subtotal,
        tax,
        grand_total,
    ):
        super(OrderFailedNotificationWithItems, self).__init__(order_id, ds_type)
        self.restaurant_name = restaurant_name
        self.order_confirmation_code = order_confirmation_code
        self.order_reference = order_reference
        self.order_datetime = order_datetime
        self.order_type = order_type
        self.dropoff_datetime = dropoff_datetime
        self.dropoff_name = dropoff_name
        self.dropoff_phone = dropoff_phone
        self.dropoff_instructions = dropoff_instructions
        self.order_items = order_items
        self.payment_mode = payment_mode
        self.subtotal = subtotal
        self.tax = tax
        self.grand_total = grand_total

    @property
    def message(self):
        return """
        {restaurant_name}
        
        Confirmation code: {order_confirmation_code}
        Order: {order_reference}
        Order placed on: {order_datetime}
        
        {order_type}
        Ready for driver by {dropoff_datetime}
        Deliver to: {dropoff_name}
        Phone: {dropoff_phone}
        
        Instructions: {dropoff_instructions}
        
        Items: {items}
        
        Subtotal: {subtotal}
        Tax: {tax}
        TOTAL: {grand_total}
        
        Payment: {payment_mode}
        """.format(
            restaurant_name=self.restaurant_name,
            order_confirmation_code=self.order_confirmation_code,
            order_reference=self.order_reference,
            order_datetime=self.order_datetime,
            order_type=self.order_type,
            dropoff_datetime=self.dropoff_datetime,
            dropoff_name=self.dropoff_name,
            dropoff_phone=self.dropoff_phone,
            dropoff_instructions=self.dropoff_instructions,
            items=self.get_items(),
            payment_mode=self.payment_mode,
            subtotal=self.subtotal,
            tax=self.tax,
            grand_total=self.grand_total,
        )

    def get_items(self):
        items_str = ""
        for item in self.order_items:
            if item.get("quantity"):
                items_str += """
                
                 * Quantity: {quantity}
                   Price: {price}
                   Description: {description}""".format(
                    quantity=item["quantity"],
                    price=item["price"],
                    description=item["description"],
                )
            else:
                for detail in item["description"].split("\n"):
                    items_str += """
                    {detail}""".format(
                        detail=detail
                    )
        return items_str
