from application.core.notification_hub.slack_notification import SlackNotification


class OrderFailedNotification(SlackNotification):
    def __init__(self, order_id, ds_type):
        super(OrderFailedNotification, self).__init__()
        self.order_id = order_id
        self.ds_type = ds_type

    @property
    def subject(self):
        return "Your {ds_type} order: {order_id} has failed".format(
            order_id=self.order_id,
            ds_type=self.ds_type,
        )

    @property
    def message(self):
        raise NotImplementedError

    @property
    def summary(self):
        return "Your {ds_type} order: {order_id} has failed. Please, check your e-mail for details.".format(
            order_id=self.order_id,
            ds_type=self.ds_type,
        )
