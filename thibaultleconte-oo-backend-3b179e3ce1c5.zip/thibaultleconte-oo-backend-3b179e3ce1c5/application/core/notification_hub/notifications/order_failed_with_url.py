from application.core.notification_hub.notifications.order_failed import OrderFailedNotification


class OrderFailedNotificationWithUrl(OrderFailedNotification):
    def __init__(self, order_id, ds_type, order_info_url):
        super(OrderFailedNotificationWithUrl, self).__init__(order_id, ds_type)
        self.order_info_url = order_info_url

    @property
    def message(self):
        return """
        Order URL: {order_info_url}
        """.format(
            order_info_url=self.order_info_url,
        )
