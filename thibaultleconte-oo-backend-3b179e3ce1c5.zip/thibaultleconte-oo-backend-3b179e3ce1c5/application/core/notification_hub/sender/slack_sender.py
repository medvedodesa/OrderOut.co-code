import requests

from application.core.notification_hub.sender.notification_sender_base import NotificationSenderBase


class SlackSender(NotificationSenderBase):
    TYPE = "Slack"

    def __init__(self, recipients):
        NotificationSenderBase.__init__(self, recipients, sender_type=self.TYPE)

    def send_notification(self, notification):
        headers = {
            "content-type": "application/json",
        }
        for recipient in self.recipients:
            requests.post(
                url=recipient,
                json=self._get_formatted_message(notification),
                headers=headers,
            )

    @classmethod
    def _get_formatted_message(cls, notification):
        message = {
            "text": notification.message,
        }
        fields = []
        for link in notification.slack_links:
            fields.append({
                "type": "mrkdwn",
                "text": "*{}*\n{}".format(link.get("title"), link.get("url")),
            })
        if fields:
            message["blocks"] = [{
                "type": "section",
                "text": {"type": "mrkdwn", "text": notification.message}
            }, {
                "type": "section",
                "fields": fields,
            }]
        return message