import collections


class NotificationSenderBase(object):
    def __init__(self, recipients, sender_type):
        self.recipients = recipients
        self.sender_type = sender_type

    def send_notification(self, notification):
        raise NotImplementedError


class NotificationsSenderGroupBase(object):
    def __init__(self, notification_services):
        self.notification_services = notification_services

    def dispatch(self, notification):
        for notification_service in self.notification_services:
            notification_service.send_notification(notification=notification)


class NotificationsSenderGroup(NotificationsSenderGroupBase):
    def __init__(self, notification_services):
        super(NotificationsSenderGroup, self).__init__(notification_services)


class MonitoredNotificationsSenderGroup(NotificationsSenderGroupBase):
    def __init__(self, notification_services, slack_service):
        super(MonitoredNotificationsSenderGroup, self).__init__(notification_services)
        self.slack_service = slack_service

    def create_monitoring_notification(self, original_notification):
        message_list = []

        message_list.append("Message Summary: '{}'".format(original_notification.summary))

        if self.notification_services:
            for notification_service in self.notification_services:
                message_list.append(
                    "{} sent to: {}".format(
                        notification_service.sender_type, notification_service.recipients
                    )
                )
        else:
            message_list.append("has not been sent to anyone")

        message = "\n".join(message_list)

        NotificationLike = collections.namedtuple("Notification", "message,slack_links")
        notification = NotificationLike(
            message=message,
            slack_links=original_notification.slack_links if hasattr(original_notification, "slack_links") else []
        )
        return notification

    def dispatch(self, notification):
        super(MonitoredNotificationsSenderGroup, self).dispatch(notification)

        slack_message = self.create_monitoring_notification(notification)
        self.slack_service.send_notification(slack_message)
