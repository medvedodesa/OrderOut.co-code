from application.core.notification_hub.sender.notification_sender_base import NotificationSenderBase
from application.core.twilio.sms import send_sms


class SmsSender(NotificationSenderBase):
    TYPE = "SMS"

    def __init__(self, recipients):
        NotificationSenderBase.__init__(self, recipients, sender_type=self.TYPE)

    def send_notification(self, notification):
        return send_sms(self.recipients, notification.summary)
