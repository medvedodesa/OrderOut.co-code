from application.core.email.service import send_support_email
from application.core.notification_hub.sender.notification_sender_base import NotificationSenderBase


class EmailSender(NotificationSenderBase):
    TYPE = "Email"

    def __init__(self, recipients):
        NotificationSenderBase.__init__(self, recipients, sender_type=self.TYPE)

    def send_notification(self, notification):
        return send_support_email(self.recipients, notification.subject, notification.message)
