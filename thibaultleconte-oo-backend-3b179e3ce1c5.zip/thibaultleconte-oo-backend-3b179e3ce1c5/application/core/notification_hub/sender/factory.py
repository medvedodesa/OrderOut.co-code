from application.core.notification_hub.sender.notification_sender_base import (
    MonitoredNotificationsSenderGroup,
    NotificationsSenderGroup,
)
from application.core.notification_hub.sender.slack_sender import SlackSender
from application.core.notification_hub.sender.sms_sender import SmsSender
from application.core.notification_hub.sender.email_sender import EmailSender
from application.core.settings.app import get_config_for_key


class NotificationSenderGroupFactory(object):
    def __init__(self, restaurant):
        self.restaurant = restaurant

    def create(self, monitored_channel=None):
        phone_recipients = []
        email_recipients = []

        notification_services = []

        users = self.restaurant.users or []

        for user_key in users:
            user = user_key.get()

            phone_number = user.phone
            email = user.email

            if user.receives_notification:
                if phone_number:
                    phone_recipients.append(phone_number)

                if email:
                    email_recipients.append(email)

        if phone_recipients:
            sms_sender = SmsSender(recipients=phone_recipients)
            notification_services.append(sms_sender)

        if email_recipients:
            email_sender = EmailSender(recipients=email_recipients)
            notification_services.append(email_sender)

        if monitored_channel:
            channel_url = get_config_for_key("MAP_SLACK_CHANNEL_HOOKS")[monitored_channel]

            slack_service = SlackSender(recipients=[channel_url])

            return MonitoredNotificationsSenderGroup(
                notification_services, slack_service=slack_service
            )
        else:
            return NotificationsSenderGroup(notification_services)


class NotificationSlackSenderFactory(object):

    def create(self, monitored_channel):
        channel_url = get_config_for_key("MAP_SLACK_CHANNEL_HOOKS")[monitored_channel]

        slack_service = SlackSender(recipients=[channel_url])

        return MonitoredNotificationsSenderGroup(
            [], slack_service=slack_service
        )
