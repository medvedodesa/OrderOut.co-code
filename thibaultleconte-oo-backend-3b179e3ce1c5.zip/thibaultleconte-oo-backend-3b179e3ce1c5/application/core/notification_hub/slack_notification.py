from application.core.notification_hub.notification import Notification


class SlackNotification(Notification):
    @property
    def subject(self):
        raise NotImplementedError

    @property
    def message(self):
        raise NotImplementedError

    @property
    def summary(self):
        raise NotImplementedError

    @property
    def slack_links(self):
        return []
