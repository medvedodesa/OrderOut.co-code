# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

from flask_restplus import Api
from flask import Blueprint
from authentication.controller import nsApi as nsAuth
from event.controller import nsApi as nsEvent
from task.controller import nsApi as nsTask
from urlFetch.controller import nsApi as nsUrlFetch


blueprint = Blueprint('core', __name__)

api_description = "These are all the elements and tools that are available for generic usage across the backend platform."
api_description += "<br/>There is no proper business logic related to OrderOut."

api = Api(blueprint,
          title = 'Core API',
          version = '1.0',
          description = api_description,
          doc = '/doc')

api.add_namespace(nsAuth, path='/auth')
api.add_namespace(nsEvent, path='/event')
api.add_namespace(nsTask, path='/task')
api.add_namespace(nsUrlFetch, path='/urlfetch')
