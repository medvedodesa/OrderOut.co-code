import json

import requests

from application.core.delivery_services.grubhub.grubhub_api import GrubHubApiClient
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.urlFetch.service import fetch_with_json_data
from application.core.settings.app import get_config_for_key


class GrubHubApiClientFactory(object):
    @classmethod
    def instantiate_google_urlfetch_api_client(cls, username, password):
        def wrap_fetch_with_json_data():
            def wrap(*args, **kwargs):
                kwargs.update({"service": UrlFetchService.GRUBHUB})
                return fetch_with_json_data(*args, **kwargs)[0]

            return wrap

        api_base_url = get_config_for_key("GRUBHUB_BASE_URL")
        client_id = get_config_for_key("GRUBHUB_CLIENT_ID")

        return GrubHubApiClient(
            api_base_url=api_base_url,
            client_id=client_id,
            username=username,
            password=password,
            fetch_tool=wrap_fetch_with_json_data(),
        )

    @classmethod
    def instantiate_api_client(cls, username, password):
        def wrap_requests():
            def wrap(*args, **kwargs):
                method = kwargs.pop("method").lower()
                kwargs["data"] = json.dumps(kwargs["data"])
                return getattr(requests, method)(*args, **kwargs).json()

            return wrap

        api_base_url = get_config_for_key("GRUBHUB_BASE_URL")
        client_id = get_config_for_key("GRUBHUB_CLIENT_ID")

        return GrubHubApiClient(
            api_base_url=api_base_url,
            client_id=client_id,
            username=username,
            password=password,
            fetch_tool=wrap_requests(),
        )
