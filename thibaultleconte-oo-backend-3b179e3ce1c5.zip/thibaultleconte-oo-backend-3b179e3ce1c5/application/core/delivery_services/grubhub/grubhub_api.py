import logging
from application.core.settings.app import get_config_for_key


class UnauthorizedException(Exception):
    pass


class GrubHubApiClient(object):
    def __init__(self, api_base_url, client_id, username, password, fetch_tool):
        self.api_base_url = api_base_url
        self.client_id = client_id
        self.username = username
        self.password = password
        self.fetch_tool = fetch_tool
        self.access_token = None
        self.merchant_ids = []

    def _call_service(self, method, endpoint, data=None, params=None):
        url = "{}{}".format(self.api_base_url, endpoint)

        headers = {
            "accept": "application/json",
            "accept-encoding": "gzip, deflate, br",
            "accept-language": "en-US,en;q=0.9",
            "authority": "api-gtm.grubhub.com",
            "cache-control": "no-cache",
            "content-type": "application/json",
            "origin": "https://restaurant.grubhub.com",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-site",
            "x-px-access-token": get_config_for_key('GRUBHUB_HEADER_HACK_API_ACCESS_TOKEN'),
        }

        if self.access_token:
            headers["authorization"] = "Bearer {}".format(self.access_token)

        try:
            response = self.fetch_tool(
                url=url, method=method, data=data, headers=headers,
            )
        except Exception as e:
            logging.exception("Exception on calling grubhub api: {}".format(e))
            return None

        return response

    def authenticate(self):
        logging.info("grubhub api authenticate")
        if not self.username or not self.password:
            logging.info("username or password missing")
            raise UnauthorizedException

        payload = {
            "brand": "GRUBHUB",
            "client_id": self.client_id,
            "email": self.username,
            "password": self.password,
        }

        logging.info("username: {}".format(self.username))

        endpoint = "/auth"
        response = self._call_service("POST", endpoint, data=payload)
        if response:
            logging.info("authenticate response: {}".format(response))
            access_token = response.get("session_handle", {}).get("access_token")
            merchant_ids = []
            for claim in response.get("claims", []):
                if claim["claim"] == "merchant":
                    merchant_ids.append(claim["claim_id"])

            self.access_token = access_token
            self.merchant_ids = merchant_ids

            if not self.access_token or not self.merchant_ids:
                raise UnauthorizedException

            return {
                "access_token": access_token,
                "merchant_ids": merchant_ids,
            }

    def get_active_orders(self):
        logging.info("get active orders")
        if not self.access_token or not self.merchant_ids:
            self.authenticate()
        logging.info("merchant ids: {}".format(self.merchant_ids))
        merchant_ids = ",".join(self.merchant_ids)
        endpoint = "/merchant/{}/orders/complete".format(merchant_ids)
        response = self._call_service("GET", endpoint)
        logging.info("response: {}".format(response))
        active_orders = response.get("in_house", {}).get("orders", [])
        unconfirmed_orders = response.get("unconfirmed", {}).get("orders", [])
        active_orders.extend(unconfirmed_orders)
        return active_orders

    def get_active_order(self, order_id):
        logging.info("get activer order {}".format(order_id))
        orders = self.get_active_orders()
        for order in orders:
            logging.info("order: {}".format(order))
            if order.get("order_number") == order_id:
                logging.info("order found")
                logging.info(order)
                return order
