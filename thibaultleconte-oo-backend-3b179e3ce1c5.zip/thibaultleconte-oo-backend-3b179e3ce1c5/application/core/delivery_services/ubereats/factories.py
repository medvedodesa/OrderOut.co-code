import json

import requests

from application.core.delivery_services.ubereats.ubereats_api import UberEatsApiClient
from application.core.oauth.factory import OAuthHandlerFactory
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.urlFetch.service import fetch_with_json_data


class UberEatsApiClientFactory(object):
    @classmethod
    def instantiate_google_urlfetch_api_client(cls, refresh_token):
        def wrap_fetch_with_json_data():
            def wrap(*args, **kwargs):
                kwargs.update({"service": UrlFetchService.UBEREATS})
                return fetch_with_json_data(*args, **kwargs)

            return wrap

        return UberEatsApiClient(
            fetch_tool=wrap_fetch_with_json_data(),
            uber_eats_oauth_client=OAuthHandlerFactory("ubereats").create_oauth_client(
                refresh_token
            ),
        )

    @classmethod
    def instantiate_api_client(cls, refresh_token):
        def wrap_requests():
            def wrap(*args, **kwargs):
                method = kwargs.pop("method").lower()
                kwargs["data"] = json.dumps(kwargs["data"])
                response = getattr(requests, method)(*args, **kwargs)
                response_data = response.json()
                status_code = response.status_code
                request_key = None

                return response_data, status_code, request_key

            return wrap

        return UberEatsApiClient(
            fetch_tool=wrap_requests(),
            uber_eats_oauth_client=OAuthHandlerFactory("ubereats").create_oauth_client(
                refresh_token
            ),
        )
