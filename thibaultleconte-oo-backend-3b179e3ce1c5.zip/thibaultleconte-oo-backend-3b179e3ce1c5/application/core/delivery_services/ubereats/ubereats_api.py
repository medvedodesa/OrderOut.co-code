import json
import logging

BASE_URL = "https://api.uber.com"


class UberEatsApiClient(object):
    def __init__(self, fetch_tool, uber_eats_oauth_client):
        self.fetch_tool = fetch_tool
        self.uber_eats_oauth_client = uber_eats_oauth_client

    def _call_service(self, method, endpoint, data=None, get_all_args=False):
        logging.info(
            "Calling Uber Eats API Client: {} {} - data: {}".format(method, endpoint, data)
        )
        url = "{}{}".format(BASE_URL, endpoint)

        headers = {"Content-Type": "application/json"}

        wrapped_request = self.uber_eats_oauth_client.handle_call(
            self.fetch_tool, get_all_args=get_all_args
        )

        if get_all_args:
            response, status_code, request_key = wrapped_request(
                url=url,
                method=method,
                data=data,
                headers=headers,
            )
            return response, status_code, request_key

        else:
            response = wrapped_request(
                url=url,
                method=method,
                data=data,
                headers=headers,
            )
            return response

    def list_stores(self):
        endpoint = "/v1/eats/stores"
        return self._call_service("GET", endpoint)

    def update_integration(self, store_id, active=False, get_all_args=False):
        endpoint = "/v1/eats/stores/{store_id}/pos_data".format(store_id=store_id)
        payload = {
            "pos_integration_enabled": active,
        }
        return self._call_service("POST", endpoint, payload, get_all_args=get_all_args)

    def get_menu(self, store_id, get_all_args=False):
        endpoint = "/v2/eats/stores/{store_id}/menus".format(store_id=store_id)
        return self._call_service("GET", endpoint, get_all_args=get_all_args)