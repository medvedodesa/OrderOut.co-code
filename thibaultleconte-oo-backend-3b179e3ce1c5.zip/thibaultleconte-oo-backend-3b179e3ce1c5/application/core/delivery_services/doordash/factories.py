import json
import logging

import requests

from application.core.delivery_services.doordash.doordash_api import DoorDashApiClient
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.urlFetch.service import fetch_with_json_data
from application.core.settings.app import get_config_for_key


class DoorDashApiClientFactory(object):

    @classmethod
    def instantiate_google_urlfetch_api_client(cls, email, password):
        def wrap_fetch_with_json_data():
            def wrap(*args, **kwargs):
                kwargs.update({"service": UrlFetchService.DOORDASH})
                return fetch_with_json_data(*args, **kwargs)[0]
            return wrap

        base_auth_url = get_config_for_key("DOORDASH_BASE_AUTH_URL")
        base_merchant_url = get_config_for_key("DOORDASH_BASE_MERCHANT_URL")
        auth_host = get_config_for_key("DOORDASH_AUTH_HOST")
        merchant_host = get_config_for_key("DOORDASH_MERCHANT_HOST")
        authorization_code = get_config_for_key("DOORDASH_AUTHORIZATION_CODE")
        device_id = get_config_for_key("DOORDASH_DEVICE_ID")
        correlation_id = get_config_for_key("DOORDASH_CORRELATION_ID")
        new_relic_id = get_config_for_key("DOORDASH_NEW_RELIC_ID")

        return DoorDashApiClient(
            fetch_tool=wrap_fetch_with_json_data(),
            base_auth_url=base_auth_url,
            base_merchant_url=base_merchant_url,
            auth_host=auth_host,
            merchant_host=merchant_host,
            authorization_code=authorization_code,
            device_id=device_id,
            correlation_id=correlation_id,
            new_relic_id=new_relic_id,
            email=email,
            password=password,
        )

    @classmethod
    def instantiate_api_client(cls, email, password):
        def wrap_requests():
            def wrap(*args, **kwargs):
                method = kwargs.pop("method").lower()
                kwargs["data"] = json.dumps(kwargs["data"])
                response = getattr(requests, method)(*args, **kwargs)
                return response.json()
            return wrap

        base_auth_url = get_config_for_key("DOORDASH_BASE_AUTH_URL")
        base_merchant_url = get_config_for_key("DOORDASH_BASE_MERCHANT_URL")
        auth_host = get_config_for_key("DOORDASH_AUTH_HOST")
        merchant_host = get_config_for_key("DOORDASH_MERCHANT_HOST")
        authorization_code = get_config_for_key("DOORDASH_AUTHORIZATION_CODE")
        device_id = get_config_for_key("DOORDASH_DEVICE_ID")
        correlation_id = get_config_for_key("DOORDASH_CORRELATION_ID")
        new_relic_id = get_config_for_key("DOORDASH_NEW_RELIC_ID")

        return DoorDashApiClient(
            fetch_tool=wrap_requests(),
            base_auth_url=base_auth_url,
            base_merchant_url=base_merchant_url,
            auth_host=auth_host,
            merchant_host=merchant_host,
            authorization_code=authorization_code,
            device_id=device_id,
            correlation_id=correlation_id,
            new_relic_id=new_relic_id,
            email=email,
            password=password,
        )
