import json
import logging

from application.core.exception import Unauthorized


INVALID_CREDENTIALS_CODE = 3
RISK_BLOCK_LOGIN_CODE = 7


class DoorDashApiClient(object):

    def __init__(self, fetch_tool, base_auth_url, base_merchant_url, auth_host, merchant_host,
                 authorization_code, device_id, correlation_id, new_relic_id, email, password):
        self._fetch_tool = fetch_tool
        self._base_auth_url = base_auth_url
        self._base_merchant_url = base_merchant_url
        self._auth_host = auth_host
        self._merchant_host = merchant_host
        self._authorization_code = authorization_code
        self._device_id = device_id
        self._correlation_id = correlation_id
        self._new_relic_id = new_relic_id
        self._email = email
        self._password = password
        self._access_token = None

    @property
    def access_token(self):
        if not self._access_token:
            self._access_token = self.authenticate()
        return self._access_token

    def _call_service(self, method, url, headers, data=None):
        logging.info("DoorDashApiClient._call_service: {} {} - headers: {} - data: {}".format(
            method, url, headers, data
        ))

        try:
            base_headers = {
                "User-Agent": "DoordashMerchant/2.64.2 (Android 8.0.0; unknown Google Pixel)",
                "Content-Type": "application/json; charset=UTF-8",
                "Accept": "application/json",
                "Accept-Language": "en-US",
                "Version-Name": "2.64.2",
                "X-NewRelic-ID": self._new_relic_id,
            }
            base_headers.update(headers)
            return self._fetch_tool(
                url=url,
                method=method,
                data=data,
                headers=base_headers,
            )
        except Exception as e:
            logging.exception("Error calling DoorDash API: {}".format(e))
            return None

    def authenticate(self):
        logging.info("DoorDashApiClient.authenticate")

        response = self._call_service(
            method="POST",
            url=self._base_auth_url,
            headers={
                "Authorization": self._authorization_code,
                "X-Device-Id": self._device_id,
                "X-Correlation-Id": self._correlation_id,
                "Host": self._auth_host,
            },
            data={
                "credentials": {
                    "email": self._email,
                    "password": self._password,
                }
            }
        )
        logging.info("DoorDashApiClient.authenticate: {}".format(response))
        if response and "token" in response:
            return response["token"].get("token")
        raise DoorDashUnauthorized(response.get("code"))

    def get_store(self, merchant_id):
        logging.info("DoorDashApiClient.get_store")

        response = self._call_service(
            method="GET",
            url="{}{}{}".format(self._base_merchant_url, "/v1/store/", merchant_id),
            headers={
                "Host": self._merchant_host,
                "Authorization": "JWT {}".format(self.access_token),
            },
        )
        if response and "store" in response:
            return response["store"]
        return None

    def get_active_orders(self, store_id):
        logging.info("DoorDashApiClient.get_active_orders")

        response = self._call_service(
            method="GET",
            url="{}{}{}".format(self._base_merchant_url, "/v1/active_orders/", store_id),
            headers={
                "Host": self._merchant_host,
                "Authorization": "JWT {}".format(self.access_token),
            },
        )
        return response

    def get_order(self, order_id):
        logging.info("DoorDashApiClient.get_order")

        response = self._call_service(
            method="GET",
            url="{}{}{}".format(self._base_merchant_url, "/v2/order_detail/", order_id),
            headers={
                "Host": self._merchant_host,
                "Authorization": "JWT {}".format(self.access_token),
            },
        )
        if response and "payload" in response:
            return json.loads(response["payload"])
        return None


class DoorDashUnauthorized(Unauthorized):
    def __init__(self, doordash_code):
        super(DoorDashUnauthorized, self).__init__()
        self.doordash_code = doordash_code
