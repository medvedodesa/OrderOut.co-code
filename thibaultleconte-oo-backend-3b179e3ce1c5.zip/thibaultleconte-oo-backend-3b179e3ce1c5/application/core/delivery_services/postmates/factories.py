from application.core.delivery_services.postmates.postmates_api import (
    PostmatesApiClient,
)
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.urlFetch.service import fetch_with_json_data
from application.core.settings.app import get_config_for_key, get_test_config_for_key

class PostmatesApiClientFactory(object):

    @classmethod
    def instantiate_google_urlfetch_api_client(cls, testing=False):
        def wrap_fetch_with_json_data():
            def wrap(*args, **kwargs):
                kwargs.update(
                    {"service": UrlFetchService.POSTMATES}
                )
                return fetch_with_json_data(*args, **kwargs)

            return wrap

        get_config = get_config_for_key
        if testing:
            get_config = get_test_config_for_key

        api_base_url = get_config("POSTMATES_BASE_URL")
        developer_id = get_config("POSTMATES_DEVELOPER_ID")
        username = get_config("POSTMATES_BASIC_AUTH_USERNAME")
        password = get_config("POSTMATES_BASIC_AUTH_PASSWORD")

        return PostmatesApiClient(
            api_base_url=api_base_url,
            developer_id=developer_id,
            username=username,
            password=password,
            fetch_tool=wrap_fetch_with_json_data(),
        )
