import base64
import logging
from datetime import datetime, timedelta


class PostmatesApiClient(object):
    def __init__(self, api_base_url, developer_id, username, password, fetch_tool):
        self.api_base_url = api_base_url
        self.developer_id = developer_id
        self.username = username
        self.password = password
        self.fetch_tool = fetch_tool

    def _call_service(self, method, endpoint, data=None):
        url = "{}{}".format(self.api_base_url, endpoint)

        authorization_value = "Basic {}".format(
            base64.b64encode("{}:{}".format(self.username, self.password))
        )

        headers = {"Content-Type": "application/json"}
        if authorization_value:
            headers["Authorization"] = authorization_value

        response, status_code, request_key = self.fetch_tool(
            url=url, method=method, data=data, headers=headers
        )
        return response

    def update_catalog(self, place_id, account_id, payload=None):
        if not payload:
            payload = {}

        payload.pop("place_id", None)
        payload.pop("location_id", None)

        payload.update({"location_id": place_id})

        endpoint = "/developers/{}/accounts/{}/locations/{}/catalog/jobs".format(
            self.developer_id, account_id, place_id
        )
        return self._call_service("POST", endpoint, data=payload)

    def update_order(self, order_id, external_order_id, event_id, success=True):
        logging.info(
            "Postmates update order: order_id {}, external_order_id {}".format(
                order_id, external_order_id
            )
        )
        if not external_order_id:
            external_order_id = "orderout-{}".format(order_id)

        payload = {
            "kind": "event.order_updated",
            "order_id": order_id,
            "id": event_id,
            "data": {
                "kind": "order",
                "order_id": order_id,
                "external_order_id": external_order_id,
            },
            "created": "{}Z".format(datetime.utcnow().isoformat()),
        }

        if success:
            status = "submitted"
            payload["data"]["pickup_time"] = "{}Z".format(
                (datetime.utcnow() + timedelta(minutes=25)).isoformat()
            )
        else:
            status = "failed"
            payload["data"]["errors"] = [
                {
                    "code": "unknown_error",
                    "message": "an unknown error has occurred",
                }
            ]

        payload["status"] = status

        logging.info("Postmates update order: payload {}".format(payload))

        endpoint = "/orders/{}/update_event".format(order_id)
        return self._call_service("POST", endpoint, data=payload)
