# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 01/14/2020
#


from .core import post_mesage_to_avochato
from application.core.settings.app import get_config_for_key
from application.core.error import report_and_abort


def __format_payload_to_send_message(phone_number, message):
    payload = {'phone': phone_number,
               'message': message}
    return payload

def __send_text_message(phone_number, message):
    _payload = __format_payload_to_send_message(phone_number, message)
    _url = get_config_for_key('AVOCHATO_API_URL_BASE') + "messages"
    _result_json, _status_code = post_mesage_to_avochato(url=_url, data=_payload)
    if _status_code < 200 or _status_code > 299:
        report_and_abort(message='send_text_message via avochato return status code %s' % (str(_status_code)), code=_status_code)
    return _result_json, _status_code

def send_text_message_for_new_clover_lead(phone_number):
    _result_json, _status_code = __send_text_message(phone_number=phone_number, message="$campaign_follow_up_texts")
    return _result_json, _status_code
