# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 01/17/2020
#


from .core import post_mesage_to_avochato
from application.core.settings.app import get_config_for_key
from application.core.error import report_and_abort
from protorpc import messages


class AvochatoTag(messages.Enum):
    UNKNOWN = 0
    CLOVER_LEAD = 1
    PAYING = 2

def __format_payload_to_add_tag(tag):
    payload = {'tag': str(tag)}
    return payload

def __add_tag(avochato_contact_uuid, tag):
    _payload = __format_payload_to_add_tag(tag)
    _url = get_config_for_key('AVOCHATO_API_URL_BASE') + "contacts/" + str(avochato_contact_uuid) + "/tags"
    _result_json, _status_code = post_mesage_to_avochato(url=_url, data=_payload)
    if _status_code < 200 or _status_code > 299:
        report_and_abort(message='add_tag via avochato return status code %s' % (str(_status_code)), code=_status_code)
        return _result_json, _status_code
    return _result_json, _status_code
