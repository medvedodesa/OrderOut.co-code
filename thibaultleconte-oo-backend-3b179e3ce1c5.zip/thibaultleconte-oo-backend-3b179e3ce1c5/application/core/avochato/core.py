# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 01/14/2020
#

from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.settings.app import get_config_for_key


##############
# POST MESSAGE
##############

def post_mesage_to_avochato(url, data):
    _headers = {'Content-type': 'application/json'}
    if not data: data = {}
    data['auth_id'] = get_config_for_key('AVOCHATO_API_AUTH_ID')
    data['auth_secret'] = get_config_for_key('AVOCHATO_API_AUTH_SECRET')
    _result_json, _status_code, _request_key = fetch_with_json_data("POST", url, UrlFetchService.AVOCHATO, headers=_headers, data=data)
    # if _status_code >= 200 and _status_code <= 299:
    #     return _result_json, _status_code
    return _result_json, _status_code
