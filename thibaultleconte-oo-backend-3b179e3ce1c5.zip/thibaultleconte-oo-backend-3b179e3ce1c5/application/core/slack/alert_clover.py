# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/22/2021
#

from flask import current_app
from .core import format_slack_field, post_mesage_to_slack
from application.core.settings.app import get_config_for_key


def post_to_alert_clover_unauthorized(account_name, restaurant_name, restaurant_admin_url):
    _formatted_title = "*%s* - *%s* got a Clover 401 Unauthorized response!" % (str(account_name.capitalize()), str(restaurant_name.capitalize()))
    _blocks = [{ "type": "section", "text": { "type": "mrkdwn", "text": _formatted_title } },
               { "type": "section",
                 "fields": [format_slack_field("Restaurant", restaurant_admin_url)]
               }
        ]
    _data = {"blocks": _blocks, "text": _formatted_title}
    return __post_to_channel(_data)


########
# HELPER
########

def __post_to_channel(data):
    from application import app
    with app.app_context():
        _url = get_config_for_key('SLACK_BACKEND_ALERT_CLOVER_UNAUTHORIZED_WEBHOOK_URL')
    return post_mesage_to_slack(url=_url, data=data)
