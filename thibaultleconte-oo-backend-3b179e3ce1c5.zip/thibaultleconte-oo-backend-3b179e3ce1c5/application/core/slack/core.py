# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 08/01/2019
#

from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService


########
# FORMAT
########

def format_slack_field(field_name, field_value):
    if not field_value: field_value = "UNSET"
    _result = { "type": "mrkdwn",
                "text": "*%s*\n%s" % (str(field_name), str(field_value))}
    return _result


##############
# POST MESSAGE
##############

def post_mesage_to_slack(url, data):
    _headers = {'Content-type': 'application/json'}
    _result_json, _status_code, _request_key = fetch_with_json_data("POST", url, UrlFetchService.SLACK, headers=_headers, data=data)
    if _status_code >= 200 and _status_code <= 299:
        return True
    return False
