# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 08/01/2019
#

from flask import current_app
from .core import format_slack_field, post_mesage_to_slack
from application.core.settings.app import get_config_for_key


def post_to_onboarding_first_order_for_new_delivery_service(account_name, restaurant_name, delivery_service_name, restaurant_admin_url, order_admin_url):
    _formatted_title = "*%s* - *%s* got their 1st order on %s!" % (str(account_name.capitalize()), str(restaurant_name.capitalize()), str(delivery_service_name))
    _blocks = [{ "type": "section", "text": { "type": "mrkdwn", "text": _formatted_title } },
               { "type": "section",
                 "fields": [format_slack_field("Restaurant", restaurant_admin_url),
                            format_slack_field("Order", order_admin_url)]
               }
        ]
    _data = {"blocks": _blocks, "text": _formatted_title}
    return __post_to_channel(_data)


########
# HELPER
########

def __post_to_channel(data):
    from application import app
    with app.app_context():
        _url = get_config_for_key('SLACK_BACKEND_ONBOARDING_FIRST_ORDER_WEBHOOK_URL')
    return post_mesage_to_slack(url=_url, data=data)
