# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/22/2021
#

from flask import current_app
from .core import format_slack_field, post_mesage_to_slack
from application.core.settings.app import get_config_for_key


def post_to_alert_ubereats_menu_for_missing_external_id(account_name, restaurant_name, restaurant_admin_url, order_admin_url, raw_item_name, exception_message):
    _formatted_title = "*%s* - *%s* got an issue with their UberEats Menu when processing an order! UberEats Menu must be re-pushed." % (str(account_name.capitalize()), str(restaurant_name.capitalize()))
    _blocks = [{ "type": "section", "text": { "type": "mrkdwn", "text": _formatted_title } },
               { "type": "section",
                 "fields": [format_slack_field("Order Item", raw_item_name),
                            format_slack_field("Error", exception_message),
                            format_slack_field("Restaurant", restaurant_admin_url),
                            format_slack_field("Order", order_admin_url)]
               }
        ]
    _data = {"blocks": _blocks, "text": _formatted_title}
    return __post_to_channel(_data)


########
# HELPER
########

def __post_to_channel(data):
    from application import app
    with app.app_context():
        _url = get_config_for_key('SLACK_BACKEND_ALERT_UBEREATS_MENU')
    return post_mesage_to_slack(url=_url, data=data)
