# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 08/01/2019
#

from flask import current_app
from .core import format_slack_field, post_mesage_to_slack
from application.core.settings.app import get_config_for_key


def post_to_self_onboarding_for_new_delivery_service(account_name, restaurant_name, delivery_service_name, delivery_service_public_menu_url, delivery_service_username, restaurant_dashboard_url, restaurant_onboarding_url):
    from application import app
    with app.app_context():
        _environment = get_config_for_key('ENV_NAME').capitalize()
    _formatted_title = "*%s* - *%s* added %s!" % (str(account_name.capitalize()), str(restaurant_name.capitalize()), str(delivery_service_name))
    _blocks = [{ "type": "section", "text": { "type": "mrkdwn", "text": _formatted_title } },
               { "type": "section",
                 "fields": [format_slack_field("Menu URL", delivery_service_public_menu_url),
                            format_slack_field("Username", delivery_service_username),
                            format_slack_field("Admin URL", restaurant_dashboard_url),
                            format_slack_field("Onboarding URL", restaurant_onboarding_url)]
               }
        ]
    _data = {"blocks": _blocks, "text": _formatted_title}
    return __post_to_channel(_data)


########
# HELPER
########

def __format_delivery_services(delivery_services_list):
    _result = ''
    for _ds_dict in delivery_services_list:
        _ds_name = _ds_dict.get('name')
        _ds_selected = _ds_dict.get('selected')
        if _ds_selected: _result += _ds_name + ' '
    return _result

def __post_to_channel(data):
    from application import app
    with app.app_context():
        _url = get_config_for_key('SLACK_BACKEND_ONBOARDING_WEBHOOK_URL')
    return post_mesage_to_slack(url=_url, data=data)
