# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 08/01/2019
#

from flask import current_app
from .core import format_slack_field, post_mesage_to_slack
from application.core.settings.app import get_config_for_key


# def post_new_clover_signup(owner_name, owner_email, account_name, clover_lead_id, restaurant_address, restaurant_city, restaurant_state, restaurant_zip):
#     _formatted_title = ":tada: *%s* from *%s* in *%s* signed up on Clover!" % (str(owner_name.capitalize()), str(account_name.capitalize()), str(restaurant_city))
#     _blocks = [{ "type": "section", "text": { "type": "mrkdwn", "text": _formatted_title } },
#                { "type": "section",
#                  "fields": [format_slack_field("Account", account_name.capitalize()),
#                             format_slack_field("Address", "%s, %s, %s, %s" % (str(restaurant_address), str(restaurant_city), str(restaurant_state), str(restaurant_zip))),
#                             format_slack_field("Email", owner_email),
#                             format_slack_field("Clover Lead ID", clover_lead_id)]
#                }
#         ]
#     _data = {"blocks": _blocks, "text": _formatted_title}
#
#     return __post_to_channel(_data)


########
# HELPER
########

def __post_to_channel(data):
    from application import app
    with app.app_context():
        _url = get_config_for_key('SLACK_BACKEND_SUPPORT_WEBHOOK_URL')
    return post_mesage_to_slack(url=_url, data=data)
