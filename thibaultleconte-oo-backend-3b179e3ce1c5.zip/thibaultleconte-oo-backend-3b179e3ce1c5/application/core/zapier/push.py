#!/usr/bin/env python
#
# thibault@orderout.co
#
# 01/21/2020
#
import logging

from application.core.settings.app import get_config_for_key
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService


def push_clover_lead_to_zapier(owner_name, owner_email, phone_number, account_name, clover_lead_id, restaurant_address, restaurant_city, restaurant_zip, restaurant_state):
    # _url = 'https://hooks.zapier.com/hooks/catch/6133540/ohkqs1q/' # existing but unknow zapier account
    _url = 'https://hooks.zapier.com/hooks/catch/6133540/o5prhce/'
    _headers = {'Content-type': 'application/json'}

    _payload = {'owner_name': owner_name,
                'owner_email': owner_email,
                'phone_number': phone_number,
                'account_name': account_name,
                'clover_lead_id': clover_lead_id,
                'address': restaurant_address,
                'city': restaurant_city,
                'zipcode': restaurant_zip,
                'state': restaurant_state}

    _result_json, _status_code, _request_key = fetch_with_json_data("POST", _url, UrlFetchService.ZAPIER, headers=_headers, data=_payload)
    if _status_code >= 200 and _status_code <= 299:
        return _result_json, _status_code
    return _result_json, _status_code


def push_order_report_to_zapier(order_issue_key, order_issue_message, user, order):
    restaurant = order.restaurant.get()

    result_json, status_code, request_key = fetch_with_json_data(
        method="POST",
        url="https://hooks.zapier.com/hooks/catch/6133540/bbq4ng1",
        service=UrlFetchService.ZAPIER,
        headers={
            "Content-type": "application/json",
        },
        data={
            "order_issue_id": order_issue_key.id(),
            "order_issue_message": order_issue_message,
            "order_id": order.key.id(),
            "order_url": "{base_url}/order/{order_id}".format(
                base_url=get_config_for_key("ADMIN_BASE_URL"),
                order_id=order.key.id(),
            ),
            "restaurant_id": restaurant.key.id(),
            "restaurant_name": restaurant.name,
            "restaurant_url": "{base_url}/restaurant/{restaurant_id}".format(
                base_url=get_config_for_key("ADMIN_BASE_URL"),
                restaurant_id=restaurant.key.id(),
            ),
            "user_name": "{} {}".format(user.firstname, user.lastname),
            "user_email": user.email,
            "user_phone": user.phone,
        }
    )

    if status_code < 200 or status_code > 299:
        logging.warn("Failed to send order report to zapier: {}", result_json)