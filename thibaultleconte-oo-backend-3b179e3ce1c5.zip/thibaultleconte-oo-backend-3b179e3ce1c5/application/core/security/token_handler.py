from itsdangerous import TimedJSONWebSignatureSerializer as Serializer, SignatureExpired

from application.core.settings.app import get_config_for_key


def get_token(token_id, expires_in=300):
    secret_key = get_config_for_key("SECRET_KEY")
    s = Serializer(secret_key, expires_in=expires_in)
    token = s.dumps({"id": token_id})
    return token


def read_token(token):
    secret_key = get_config_for_key("SECRET_KEY")
    s = Serializer(secret_key)
    try:
        return s.loads(token)
    except SignatureExpired:
        return None
