# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/17/2020
#
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.settings.app import get_config_for_key
from base64 import b64encode


def __format_headers():
	databox_app_token = get_config_for_key("DATABOX_APP_TOKEN").encode('ascii')
	authstr = 'Basic ' + b64encode(b':'.join((databox_app_token, b"")).strip())
	_headers = {'Content-type': 'application/json',
				'Accept':'application/vnd.databox.v2+json',
				'Authorization': authstr}
	return _headers


def process_kpi(**args):
		key = args.get('key', None)
		if key is None:
			raise Exception('Missing "key"')

		value = args.get('value', None)
		if value is None:
			raise Exception('Missing "value"')

		item = {('$%s' % args['key']): args['value']}

		date = args.get('date', None)
		if date is not None:
			item['date'] = date

		unit = args.get('unit', None)
		if unit is not None:
			item['unit'] = unit

		attributes = args.get('attributes', None)
		if attributes is not None:
			item.update(attributes)

		return item


def get_json_content(key, value, date=None, attributes=None, unit=None):
	data = {'data':[process_kpi(
					key=key,
					value=value,
					date=date,
					unit=unit,
					attributes=attributes
			)]}
	return data

##############
# POST MESSAGE
##############

def post_message_to_databox(event_name, value=1, attributes={}, unit=None):
	data = get_json_content(event_name, value, attributes=attributes, unit=unit)
	_headers = __format_headers()
	_url = get_config_for_key('DATABOX_BACKEND_PUSH_URL')
	_result_json, _status_code, _request_key = fetch_with_json_data("POST", _url, UrlFetchService.DATABOX, headers=_headers, data=data)
	return _result_json, _status_code
