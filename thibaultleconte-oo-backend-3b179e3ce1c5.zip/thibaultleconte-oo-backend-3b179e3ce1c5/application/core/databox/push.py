# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 04/17/2020
#
from json import dumps as json_dumps
from application.core.urlFetch.service import fetch_with_json_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.core.settings.app import get_config_for_key
from .core import post_message_to_databox
# from databox import Client
import json

# CLOVER LEAD


def push_clover_lead(account_name, restaurant_city, restaurant_state, restaurant_zip):
	_event = 'leads'
	_attributes = {'channel': 'clover'}
	_result_json, _status_code = post_message_to_databox(event_name=_event, attributes=_attributes)
	return _result_json, _status_code

# CHARGEBEE SUBSCRIPTION

def __format_subscription_name(raw_subscription_name):
	import logging
	logging.info(raw_subscription_name)
	_value = raw_subscription_name.replace('orderout-','')
	return _value

def push_chargebee_subscription(amount, subscription_name):
	_event = 'sales'
	_attributes = {'subscription': __format_subscription_name(subscription_name)}
	_result_json, _status_code = post_message_to_databox(event_name=_event, value=amount, attributes=_attributes)
	return _result_json, _status_code
