# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/29/2019
#

import re


def sanitize_str(raw_string, lower_case=True):
    if not raw_string: return None
    _process_string = raw_string
    if not isinstance(_process_string, str): _process_string = str(_process_string)
    _process_string = _process_string.encode('utf-8')
    _process_string = _process_string.replace(u'\xc2\xa0', ' ')
    _process_string = re.sub(u"\u2013", "-", _process_string)
    _process_string = re.sub("\xe2\x80\x93", "-", _process_string)
    # _process_string = _process_string.replace('*', '')
    if _process_string.startswith('* '): _process_string = _process_string[2:]
    _process_string = ' '.join(_process_string.split())
    if lower_case: _process_string = _process_string.lower()
    _process_string = str(_process_string)
    return _process_string


def remove_non_alphanumeric_chars(raw_string):
    pattern = re.compile('[\W_]+')
    return pattern.sub('', raw_string)
