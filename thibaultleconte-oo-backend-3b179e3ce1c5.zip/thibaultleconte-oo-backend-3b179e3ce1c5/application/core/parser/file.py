# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/02/2019
#

import csv

def parse_csv_file(filename):
    result = []
    with open(filename, 'rb') as csv_file:
        content = csv.DictReader(csv_file)
        for row in content:
            result.append(row)
    return result
