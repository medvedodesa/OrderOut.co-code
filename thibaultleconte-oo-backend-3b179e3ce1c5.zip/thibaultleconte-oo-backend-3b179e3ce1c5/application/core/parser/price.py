# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 05/29/2019
#

from math import ceil
import logging


def sanitize_price(raw_string):
    if not raw_string: return float(0.00)
    _process_string = raw_string
    if not isinstance(_process_string, str): _process_string = str(_process_string)
    _process_string = _process_string.replace(u'\xc2\xa0', ' ')
    _process_string = _process_string.lower().replace('usd', '')
    _process_string = _process_string.lower().replace('us', '')
    _process_string = _process_string.replace('$', '')
    _process_string = _process_string.replace(',', '.')
    _process_string = _process_string.replace(':', '.')
    _process_string = _process_string.replace(' ', '')
    try:
        _process_string = '{:.2f}'.format(float(_process_string))
    except Exception as e:
        import logging
        logging.error(e)
        _process_string = 0.00
    return round(float(_process_string), 2)

def sanitize_ubereats_price(raw_string):
    price = sanitize_price(raw_string)
    return (price / 100)
