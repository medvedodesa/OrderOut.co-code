# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 10/16/2019
#

def get_config_for_key(key):
    from flask import current_app
    from application import app
    with app.app_context():
        value = current_app.config.get(key)
    return value


def get_test_config_for_key(key):
    from application.config import Testing

    value = getattr(Testing, key)
    return value
