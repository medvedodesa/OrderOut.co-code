# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/20/2019
#

from flask import current_app
import sendgrid
from sendgrid.helpers.mail import Email, Substitution, Mail, Personalization, Content
from application.core.settings.app import get_config_for_key


# ADMIN
#######

def send_raw_email_to_admin(subject, body):
    recipients = []
    from application import app
    with app.app_context():
        to_emails = get_config_for_key('EMAIL_TO_ADMINS')
    for to_email in to_emails:
        recipients.append(to_email)
    return send_admin_email(recipients, subject, body)

def send_admin_email(recipients, subject, body):
    from application import app
    with app.app_context():
        sender_email = get_config_for_key("EMAIL_ADMIN_SENDER")
    success = __send_raw_email(recipients, sender_email, subject, body, admin_prefix=True)
    return success

# ONBOARDING
#########

def send_email_to_onboarding_team(subject, body, subject_prefix="[ONBOARDING] - "):
    subject = subject_prefix + subject
    recipients = []
    from application import app
    with app.app_context():
        to_emails = get_config_for_key('EMAIL_TO_ONBOARDING')
        sender_email = get_config_for_key("ADMIN_EMAIL")
    for to_email in to_emails:
        recipients.append(to_email)
    success = __send_raw_email(recipients, sender_email, subject, body)
    return success

def send_email_active_for_clover_lead(recipient_email):
    _template_id = "d-0286f4a120204ca687f06c70a399aac1"
    _apikey = get_config_for_key('SENDGRID_API_KEY')
    _sender_email = get_config_for_key('EMAIL_SUPPORT_SENDER')

    data = {"personalizations": [{"to": [{"email": recipient_email}]}],
            "from": {"email": _sender_email},
            "template_id": _template_id}

    sg = sendgrid.SendGridAPIClient(apikey=_apikey)
    response = sg.client.mail.send.post(request_body=data)
    return response.status_code

def send_email_new_subscription_for_clover_no_printer(recipient_email, account_name):
    _template_id = "d-77a251129a3349ad9f0ac82f13f811c4"
    _apikey = get_config_for_key('SENDGRID_API_KEY')
    _sender_email = get_config_for_key('EMAIL_SUPPORT_SENDER')

    dynamic_template_data = {'restaurantname': str(account_name)}

    data = {"personalizations": [{"to": [{"email": recipient_email}], "dynamic_template_data": dynamic_template_data}],
            "from": {"email": _sender_email},
            "template_id": _template_id}

    sg = sendgrid.SendGridAPIClient(apikey=_apikey)
    response = sg.client.mail.send.post(request_body=data)
    return response.status_code

def send_email_new_subscription_for_clover_with_printer(recipient_email, account_name):
    _template_id = "d-16a4272225ec4003b4593602d59216f6"
    _apikey = get_config_for_key('SENDGRID_API_KEY')
    _sender_email = get_config_for_key('EMAIL_SUPPORT_SENDER')

    dynamic_template_data = {'restaurantname': str(account_name)}

    data = {"personalizations": [{"to": [{"email": recipient_email}], "dynamic_template_data": dynamic_template_data}],
            "from": {"email": _sender_email},
            "template_id": _template_id}

    sg = sendgrid.SendGridAPIClient(apikey=_apikey)
    response = sg.client.mail.send.post(request_body=data)
    return response.status_code

# Manual onboarding

def send_email_from_dashboard_with_instructions_to_setup_doordash_grubhub(recipient_email, account_name, doordash_email=None, grubhub_email=None, chownow_email=None):
    _template_id = "d-03eecdbcfd884f91a03b2c0579a1b0f0"
    _apikey = get_config_for_key('SENDGRID_API_KEY')
    _sender_email = get_config_for_key('EMAIL_SUPPORT_SENDER')

    dynamic_template_data = {'restaurantname': str(account_name), 'doordashemail': doordash_email, 'grubhubemail': grubhub_email, 'chownowemail': chownow_email}
    # if doordash_email: dynamic_template_data['doordash_email'] = str(doordash_email)
    # if grubhub_email: dynamic_template_data['grubhub_email'] = str(grubhub_email)

    _recipients = [{"email": recipient_email}]
    for _email in get_config_for_key('EMAIL_TO_ONBOARDING'): _recipients.append({"email": _email})
    data = {"personalizations": [{"to": _recipients, "dynamic_template_data": dynamic_template_data}],
            "from": {"email": _sender_email},
            "template_id": _template_id}

    sg = sendgrid.SendGridAPIClient(apikey=_apikey)
    response = sg.client.mail.send.post(request_body=data)
    return response.status_code

# SUPPORT
#########

def send_support_email(recipients, subject, body):
    from application import app
    with app.app_context():
        sender_email = get_config_for_key("EMAIL_SUPPORT_SENDER")
    success = __send_raw_email(recipients, sender_email, subject, body)
    return success


# RAW
#####

def __send_raw_email(recipients, sender, subject, body, admin_prefix=False):
    from application import app
    with app.app_context():
        _apikey = get_config_for_key('SENDGRID_API_KEY')
        _environment_name = get_config_for_key('ENV_NAME')
    sg = sendgrid.SendGridAPIClient(apikey=_apikey)
    personalization = Personalization()
    for to_email in recipients:
        personalization.add_to(Email(to_email))
    mail = Mail()
    mail.from_email = Email(sender)
    _subject_prefix = ''
    if admin_prefix: _subject_prefix = '[ADMIN-{environment}] - '.format(environment=_environment_name.upper())
    mail.subject = _subject_prefix + subject
    mail.add_personalization(personalization)
    mail.add_content(Content('text/plain', body))
    # mail.add_content(Content('text/html', body))
    response = sg.client.mail.send.post(request_body=mail.get())
    return True
