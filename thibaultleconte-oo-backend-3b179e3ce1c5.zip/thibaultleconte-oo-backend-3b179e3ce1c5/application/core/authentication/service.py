# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/15/2019
#

from flask import request, _request_ctx_stack
from flask import current_app as app
from jose import jwt
from functools import wraps

from werkzeug.exceptions import Unauthorized

from application.core.urlFetch.service import fetch_with_url_encoded_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from google.appengine.api import memcache
from application.core.settings.app import get_config_for_key
import logging


__CORE_AUTHENTICATION_CAHING_DURATION_SECONDS = 300

# https://www.random.org/strings/?num=1&len=20&digits=on&upperalpha=on&loweralpha=on&unique=on&format=html&rnd=new
__UNIT_TEST_API_KEY = "007"
__DASHBOARD_ONBOARDING_API_KEY = "d8WjBw1uFu1dZvIAi8sY"
__GECKOBOARD_API_KEY = "OSJH21JlpnPE9ZjDjdA9"
__APTITO_IOS_APP_API_KEY = "hlGPFhogadLoJvnKTQOs"
__PAX_APP_API_KEY = "4gRR0sqRVzBru8vj2oEO"
__ZAPIER_WEBHOOK_API_KEY = "maavW8puXb6hA5NGB9MW"
__TYPEFORM_WEBHOOK_API_KEY = "ZK8BLOUlECJgnSgOMViD"
__CLOVER_APP_API_KEY = "R8bZo49f6yye4WLhVSrR"
__TABIT_TEST_ORDER_API_KEY = "8mjOYJrzr7VTg9eZYpKt"
__ALDELO_API_KEY = "LWGB5xF2JxWtrK8gj6h0"

############
# Decorators
############


def _get_auth_token(mc_key):
    # AUTH TOKEN
    mc_client = memcache.Client()
    token = __get_token_from_auth_header()
    url = "https://" + get_config_for_key("AUTH0_DOMAIN") + "/.well-known/jwks.json"


    result_json = mc_client.get(mc_key)
    _log_verified_from_memcache = True
    if not result_json:
        result_json, _satus_code, _request_key = fetch_with_url_encoded_data(url=url,
                                                                             service=UrlFetchService.AUTH0,
                                                                             method="GET")
        if __CORE_AUTHENTICATION_CAHING_DURATION_SECONDS > 0:
            mc_client.set(key=mc_key, value=result_json,
                          time=__CORE_AUTHENTICATION_CAHING_DURATION_SECONDS)
        _log_verified_from_memcache = False

    try:
        unverified_header = jwt.get_unverified_header(token)
    except jwt.JWTError as e:
        logging.error(e)
        raise Unauthorized  # ({"code": "invalid_header", "description": "Invalid header. Use an RS256 signed JWT Access Token"}, 401)

    if unverified_header["alg"] == "HS256":
        raise Unauthorized  # ({"code": "invalid_header", "description": "Invalid header. Use an RS256 signed JWT Access Token"}, 401)
    rsa_key = {}
    for key in result_json.get("keys", []):
        if key["kid"] == unverified_header["kid"]:
            rsa_key = {
                "kty": key["kty"],
                "kid": key["kid"],
                "use": key["use"],
                "n": key["n"],
                "e": key["e"]
            }
    if rsa_key:
        try:
            payload = jwt.decode(token,
                                 rsa_key,
                                 algorithms=unverified_header["alg"],
                                 audience=get_config_for_key("AUTH0_API_AUDIENCE"),
                                 issuer="https://" + get_config_for_key("AUTH0_DOMAIN") + "/")
        except jwt.ExpiredSignatureError:
            mc_client.delete(mc_key)
            raise Unauthorized  # ({"code": "token_expired", "description": "token is expired"}, 401)
        except jwt.JWTClaimsError:
            mc_client.delete(mc_key)
            raise Unauthorized  # ({"code": "invalid_claims", "description": "incorrect claims, please check the audience and issuer"}, 401)
        except Exception as e:
            mc_client.delete(mc_key)
            logging.error(e)
            raise Unauthorized  # ({"code": "invalid_header", "description": "Unable to parse authentication token."}, 401)
        # Auth0 User Roles
        try:
            unverified_claims = jwt.get_unverified_claims(token)
        except jwt.JWTError as e:
            logging.error(e)
            raise Unauthorized  # ({"code": "invalid_claims", "description": "Invalid claims. Error when getting unverified claims from JWT Token"}, 401)

        _roles = __get_roles(unverified_claims)

        user = __update_and_save_user(
            access_token=token,
            provider_payload=payload,
            is_admin=__is_roles_admin(_roles),
        )
        _request_ctx_stack.top.current_user = user

        return rsa_key, user


def requires_auth_token(func):
    """Determines if the access token is valid """
    @wraps(func)
    def wrapper(*args, **kwargs):

        # API KEY
        api_key = __get_api_key_from_auth_header()
        if api_key:
            is_valid = __check_api_key_valid(api_key)
            if not is_valid:
                raise Unauthorized # ({"code": "invalid api_key", "description": "API Key is not valid"}, 401)
            else:
                return func(*args, **kwargs)

        # AUTH TOKEN
        mc_client = memcache.Client()
        mc_key = "core_authentation_" + get_config_for_key(
            "AUTH0_DOMAIN").lower() + "requires_auth_token"

        rsa_key, user = _get_auth_token(mc_key)
        if rsa_key:
            # logging.info('[AUTH] - %s Authenticated from %s' % (str(_request_ctx_stack.top.current_user.key.id()), _log_verified_from_memcache))
            if not _request_ctx_stack.top.current_user.is_admin:
                # raise Unauthorized # ({"code": "missing_permission", "description": "Permissions to access required."}, 401)
                logging.error(_request_ctx_stack.top.current_user)
                raise Unauthorized

            return func(*args, **kwargs)
        mc_client.delete(mc_key)
        raise Unauthorized # ({"code": "invalid_header", "description": "Unable to find appropriate key"}, 401)
    return wrapper


def requires_logged_in_user(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        # AUTH TOKEN
        mc_client = memcache.Client()
        mc_key = "core_authentation_" + get_config_for_key(
            "AUTH0_DOMAIN").lower() + "requires_auth_token"

        rsa_key, user = _get_auth_token(mc_key)
        if rsa_key:
            kwargs["user"] = user
            return func(*args, **kwargs)

        mc_client.delete(mc_key)
        raise Unauthorized

    return wrapper


def requires_logged_in_manager(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        # AUTH TOKEN
        mc_client = memcache.Client()
        mc_key = "core_authentation_" + get_config_for_key(
            "AUTH0_DOMAIN").lower() + "requires_auth_token"

        rsa_key, user = _get_auth_token(mc_key)
        if rsa_key and user.is_manager:
            kwargs["user"] = user
            return func(*args, **kwargs)

        mc_client.delete(mc_key)
        raise Unauthorized

    return wrapper


def requires_short_auth_token(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        short_token = __get_token_from_auth_header()
        result_json, status_code, request_key = fetch_with_url_encoded_data(
            "GET",
            get_config_for_key("AUTH0_USERINFO_URL"),
            UrlFetchService.AUTH0,
            headers={
                "Authorization": "Bearer {}".format(short_token)
            },
        )
        user = User.get_by_provider_uuid(result_json.get("sub"))
        if not user:
            raise Unauthorized

        kwargs["user"] = user
        return func(*args, **kwargs)

    return wrapper


###############
# API KEY LOGIC
###############

def __check_api_key_valid(api_key):
    _valid_api_keys = [__UNIT_TEST_API_KEY, __DASHBOARD_ONBOARDING_API_KEY, __GECKOBOARD_API_KEY, __APTITO_IOS_APP_API_KEY, __PAX_APP_API_KEY, __ZAPIER_WEBHOOK_API_KEY, __TYPEFORM_WEBHOOK_API_KEY, __CLOVER_APP_API_KEY, __TABIT_TEST_ORDER_API_KEY, __ALDELO_API_KEY]
    return api_key in _valid_api_keys

#############
# AUTH0 Logic
#############

def __get_api_key_from_auth_header():
    """Obtains the access token from the Authorization Header """
    api_key = None
    if request.headers:
        api_key = request.headers.get("api-key", None)
        if api_key: return api_key
    if request.authorization:
        api_key = request.authorization.get("username", None)
        if api_key: return api_key
    return api_key

def __get_token_from_auth_header():
    """Obtains the access token from the Authorization Header """
    auth = request.headers.get("Authorization", None)
    if not auth:
        raise Unauthorized # ({"code": "authorization_header_missing", "description": "Authorization header is expected"}, 401)

    parts = auth.split()

    if parts[0].lower() != "bearer":
        raise Unauthorized # ({"code": "invalid_header", "description": "Authorization header must start with Bearer"}, 401)
    elif len(parts) == 1:
        raise Unauthorized # ({"code": "invalid_header", "description": "Token not found"}, 401)
    elif len(parts) > 2:
        raise Unauthorized # ({"code": "invalid_header", "description": "Authorization header must be Bearer token"}, 401)

    token = parts[1]
    return token

#############
# ROLES Logic
#############

def __get_roles(unverified_clains):
    _roles = unverified_clains.get(get_config_for_key('AUTH0_ROLE_URL'), [])
    return _roles

def __is_roles_admin(roles):
    if get_config_for_key('AUTH0_ROLE_ADMIN') in roles: return True
    return False

#############
# CREATE USER
#############

from application.apis.user.model.User import User, UserRole
from application.core.urlFetch.service import fetch_with_url_encoded_data
from application.core.urlFetch.UrlFetchRequest import UrlFetchService
from application.apis.ooexceptions import ConflictResourceAlreadyExistsError
from application.core.email.service import send_raw_email_to_admin
import json

def __update_and_save_user(access_token, provider_payload, is_admin=False):
    _auth0_userinfo_url = get_config_for_key("AUTH0_USERINFO_URL")
    _auth0_headers = {'Authorization': 'Bearer %s' % str(access_token)}
    _result_json, _status_code, _request_key = fetch_with_url_encoded_data(
        "GET",
        _auth0_userinfo_url,
        UrlFetchService.AUTH0,
        headers=_auth0_headers,
    )
    _email = _result_json['email'] if 'email' in _result_json else ''
    _provider_uuid = provider_payload['sub']
    _user = User.get_by_provider_uuid(_provider_uuid)
    if not _user:
        _user = User.get_by_email(_email)

    if not _user:
        if _status_code != 200: send_raw_email_to_admin(subject='[Auth0] - User Creation - UserInfo %s' % (str(_status_code)), body=json.dumps(_result_json))

        if User.exists_with_email(_email): raise ConflictResourceAlreadyExistsError
        _lastname = _result_json['family_name'] if 'family_name' in _result_json else ''
        _firstname = _result_json['given_name'] if 'given_name' in _result_json else ''
        _user = User.create(provider_uuid=_provider_uuid,
                            provider_payload=provider_payload,
                            email=_email,
                            firstname=_firstname,
                            lastname=_lastname,
                            is_admin=is_admin)
        send_raw_email_to_admin(subject='[Auth0] - %s Created - %s' % (str(_user.__class__.__name__), str(_email)), body=json.dumps(_result_json))
    else:
        _user.update_role(is_admin)
    return _user
