# -*- coding: utf-8 -*-
#!/usr/bin/env python
#
# thibault@orderout.co
#
# 03/15/2019
#

from flask import request
from flask_restplus import Namespace, Resource
# from flask_cors import cross_origin
from .service import requires_auth_token

nsApi = Namespace('auth', description='User Authentication')

@nsApi.route('/not-authenticated')
# @cross_origin(headers=["Content-Type", "Authorization"])
class CoreAuthGetNotAuthenticated(Resource):
    @nsApi.doc('Test user can access not authenticated page')
    @nsApi.response(200, 'OK')
    def get(self):
        return {}

@nsApi.route('/authenticated')
# @cross_origin(headers=["Content-Type", "Authorization"])
class CoreAuthGetAuthenticated(Resource):
    method_decorators = [requires_auth_token]
    @nsApi.doc('Test user can access authenticated page')
    @nsApi.response(200, 'OK')
    def get(self):
        return {}
