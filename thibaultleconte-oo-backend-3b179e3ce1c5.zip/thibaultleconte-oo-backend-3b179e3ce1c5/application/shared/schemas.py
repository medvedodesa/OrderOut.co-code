from marshmallow import Schema
from google.appengine.ext import ndb


class BaseNDBSchema(Schema):
    def get_attribute(self, key, obj, default):
        try:
            attrs = getattr(obj, key)
            if attrs:
                if not isinstance(attrs, (list, tuple)):
                    attrs = [attrs]

                items = []
                breaked = False

                for attr in attrs:
                    if not isinstance(attr, ndb.Key):
                        breaked = True
                        break

                    obj = attr.get()
                    if obj:
                        items.append(obj)

                if not breaked:
                    return items

        except Exception as e:
            pass

        return super(BaseNDBSchema, self).get_attribute(key, obj, default)


class BaseSchema(Schema):
    def __init__(self, overwrite=False, *args, **kwargs):
        self.overwrite = overwrite
        super(BaseSchema, self).__init__(*args, **kwargs)
