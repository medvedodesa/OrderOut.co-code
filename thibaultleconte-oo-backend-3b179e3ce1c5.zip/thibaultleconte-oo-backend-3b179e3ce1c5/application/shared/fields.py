from marshmallow import missing
from marshmallow.fields import String as MarshmallowString
from marshmallow.fields import Float as MarshmallowFloat
from marshmallow.fields import Nested as MarshmallowNested


class String(MarshmallowString):
    def __init__(self, stylize=None, none_if_empty=False, **kwargs):
        super(String, self).__init__(**kwargs)
        self.stylize = stylize
        self.none_if_empty = none_if_empty

    def _serialize(self, value, attr, obj):
        if value is None:
            return ""

        ret = super(String, self)._serialize(value, attr, obj)
        if callable(self.stylize):
            return self.stylize(ret)
        else:
            return ret

    def _deserialize(self, value, attr, data):
        ret = super(String, self)._deserialize(value, attr, data)
        ret = ret.strip()

        return None if self.none_if_empty and ret == "" else ret


class PositiveFloat(MarshmallowFloat):
    def _serialize(self, value, attr, obj):
        if value is None or value < 0.0:
            return 0.0

        return super(PositiveFloat, self)._serialize(value, attr, obj)


class SkipMissingNested(MarshmallowNested):
    def _serialize(self, nested_obj, attr, obj):
        result = super(SkipMissingNested, self)._serialize(nested_obj, attr, obj)
        return result or missing
