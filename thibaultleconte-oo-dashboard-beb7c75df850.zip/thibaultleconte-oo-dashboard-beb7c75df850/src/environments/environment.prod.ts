export const environment = {
    production: true,

    core_backend_url: 'https://api.orderout.co/',
    backend_url: 'https://api.orderout.co/api/',
    front_api_url: 'https://api.orderout.co/front-api/',
    auth: {
        "domain": "orderout.auth0.com",
        "clientId": "z32u4XqYQ6h3Y94xBIbaUI4CzY7MRgy4",
        "audience": "https://auth0.orderout.co/api",
        "scope": "openid profile email",
        "redirectUri": window.location.origin + '/dashboard',
    },
    INTERCOM_APP_ID: 'l68tvb4l',
    DASHBOARD_ONBOARDING_API_KEY: 'd8WjBw1uFu1dZvIAi8sY'
};
