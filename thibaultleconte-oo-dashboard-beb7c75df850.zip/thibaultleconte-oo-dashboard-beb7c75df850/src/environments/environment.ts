// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
    production: false,

    core_backend_url: 'http://localhost:8080/',
    backend_url: 'http://localhost:8080/api/',
    front_api_url: 'http://localhost:8080/front-api/',
    auth: {
        "domain": "orderout.auth0.com",
        "clientId": "z32u4XqYQ6h3Y94xBIbaUI4CzY7MRgy4",
        "audience": "https://auth0.orderout.co/api",
        "scope": "openid profile email",
        "redirectUri": window.location.origin + '/dashboard',
    },
    INTERCOM_APP_ID: 'l68tvb4l',
    DASHBOARD_ONBOARDING_API_KEY: 'd8WjBw1uFu1dZvIAi8sY'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
