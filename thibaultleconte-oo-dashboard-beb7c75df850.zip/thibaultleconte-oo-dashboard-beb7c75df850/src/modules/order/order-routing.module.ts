/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SBRouteData } from '@modules/navigation/models';

/* Module */
import { OrderModule } from './order.module';

/* Containers */
import * as orderContainers from './containers';

/* Guards */
import * as orderGuards from './guards';

/* Routes */
export const ROUTES: Routes = [
    {
        path: '',
        canActivate: [],
        component: orderContainers.OrderComponent,
        children: [
            {
                path: '',
                data: {
                    title: 'Dashboard - Order Report',
                    breadcrumbs: [
                        {
                            text: 'Dashboard',
                            active: true,
                        },
                    ],
                } as SBRouteData,
                component: orderContainers.OrderListComponent,
                children: [
                    {
                        path: ':orderId',
                        data: {
                            title: 'Dashboard - Order Report Detail',
                            breadcrumbs: [
                                {
                                    text: 'Dashboard',
                                    active: true,
                                },
                            ],
                        } as SBRouteData,
                        component: orderContainers.OrderEntrydetailsComponent
                    }
                ]
            }
        ],
    },
];

@NgModule({
    imports: [OrderModule, RouterModule.forChild(ROUTES)],
    exports: [RouterModule],
})
export class OrderRoutingModule { }
