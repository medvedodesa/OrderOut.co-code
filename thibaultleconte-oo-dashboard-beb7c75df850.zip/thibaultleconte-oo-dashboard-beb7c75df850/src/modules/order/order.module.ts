/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgBootstrapFormValidationModule } from 'ng-bootstrap-form-validation';

/* Modules */
import { AppCommonModule } from '@common/app-common.module';
import { NavigationModule } from '@modules/navigation/navigation.module';

/* Components */
import * as orderComponents from './components';

/* Containers */
import * as orderContainers from './containers';

/* Guards */
import * as orderGuards from './guards';

/* Services */
import * as orderServices from './services';

/* Helpers */
import * as orderHelpers from "./helpers";

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        ReactiveFormsModule,
        FormsModule,
        HttpClientModule,
        AppCommonModule,
        NavigationModule,
        NgBootstrapFormValidationModule,
    ],
    providers: [...orderServices.services, ...orderGuards.guards, ...orderHelpers.helpers],
    declarations: [...orderContainers.containers, ...orderComponents.components],
    exports: [...orderContainers.containers, ...orderComponents.components],
    entryComponents: [
        orderContainers.OrderEntrydetailsComponent,
    ]
})
export class OrderModule { }
