import { Account } from "@common/models/account";
import { Restaurant } from "@common/models/restaurant";
import { DeliveryService } from "@common/models/ds";
import { PointOfSale } from "@common/models/pos";
import { MenuItem, MenuItemModifier } from '@common/models/menu';

export interface Order {
    id: number;
    account: Account;
    restaurant: Restaurant;
    status: string;
    type: string;
    order_items: OrderItem[];
    customer_name: string;
    customer_phone: string;
    point_of_sale: PointOfSale;
    point_of_sale_uuid: string;
    delivery_service: DeliveryService;
    delivery_service_uuid: string;
    delivery_service_short_uuid: string;
    charge_customer_delivery_fee: number;
    charge_tax: number;
    charge_subtotal: number;
    charge_fee: number;
    charge_total: number;
    charge_mode: string;
    store_instructions: string;
    delivery_instructions: string;
    delivery_address: string;
    delivery_city: string;
    delivery_state: string;
    delivery_zip: number;
    charge_tip: number;
    ready_by: string;
    api_created_at: Date;
    api_updated_at: Date;
}

export interface OrdersList {
    count: number;
    item_per_page: number;
    next: boolean;
    prev: boolean;
    page: number;
    data: Order[];
    delivery_services_available: any;
    next_cursor: String;
    prev_cursor: String;
}

export interface OrderItem {
    id: number;
    menu_item: MenuItem;
    modifiers: [OrderItemModifier];
    quantity: number;
    unit_price: number;
    price: number;
    store_instructions: string;
    api_created_at: Date;
}

export interface OrderItemModifier {
    id: number;
    modifier: MenuItemModifier;
    price: number;
    api_created_at: Date;
}

export interface filters {
    page?: number;
    item_per_page?: number;
    sort_order?: String;
}

export interface OrderOptions extends filters {
    account_id?: number;
    restaurant_id?: number;
    from_timestamp?: number;
    to_timestamp?: number;
    delivery_service_type?: String;
}