import { OrderComponent } from './order/order.component';
import { OrderListComponent } from './order-list/order-list.component';
import { OrderDetailsComponent } from './order-details/order-details.component';
import { OrderEntrydetailsComponent } from './order-entrydetails/order-entrydetails.component';
import { OrderReportIssueComponent } from './order-report-issue/order-report-issue.component';

export const containers = [OrderComponent, OrderListComponent, OrderDetailsComponent, OrderEntrydetailsComponent, OrderReportIssueComponent];

export * from './order/order.component';
export * from './order-list/order-list.component';
export * from './order-details/order-details.component';
export * from './order-entrydetails/order-entrydetails.component';
export * from './order-report-issue/order-report-issue.component';
