import { Component, OnInit } from '@angular/core';
import { TitleCasePipe } from '@angular/common';
import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";

import { UtilityService, ExportFileService } from '@common/services';
import { Order } from '@modules/order/models';
import { OrderService } from '@modules/order/services';
import { OrderHelper } from '@modules/order/helpers';

@Component({
    selector: 'sbpro-order-details',
    templateUrl: './order-details.component.html',
    styleUrls: ['order-details.component.scss'],
})
export class OrderDetailsComponent implements OnInit {

    public order: Order;
    public orderId: number;
    public showLoader: boolean = false;

    constructor(
        public modal: NgbActiveModal,
        private orderService: OrderService,
        public orderHelper: OrderHelper,
        private utilityService: UtilityService,
        private efService: ExportFileService
    ) { }


    ngOnInit() {
        if (!this.order && this.orderId) {
            this.getOrder(this.orderId);
        }
    }

    getOrder(orderId: number) {
        this.showLoader = true;
        this.orderService.getOrder(orderId).subscribe(order => {
            this.order = order;
            this.showLoader = false;
        });
    }

    exportCSV() {
        let order = [{
            'name': 'Order Date',
            'value': this.utilityService.getFormatDate(this.order.api_created_at)
        },
        {
            'name': 'Order Id',
            'value': this.order.id
        },
        {
            'name': 'Account Id',
            'value': this.order.account && this.order.account.id
        },
        {
            'name': 'Account Name',
            'value': this.order.account && this.order.account.name
        },
        {
            'name': 'Restaurant Id',
            'value': this.order.restaurant && this.order.restaurant.id
        },
        {
            'name': 'Restaurant Name',
            'value': this.order.restaurant && this.order.restaurant.name
        },
        {
            'name': 'Delivery Service UUID',
            'value': this.order.delivery_service_short_uuid || this.order.delivery_service_uuid
        },
        {
            'name': 'Delivery Service',
            'value': this.order.delivery_service && this.order.delivery_service.type
        },
        {
            'name': 'Dollar Amount',
            'value': this.utilityService.getFormatAmount(this.order.charge_total),
        },
        {
            'name': 'Order Item Quantity',
            'value': this.orderHelper.getOrderItemQty(this.order.order_items)
        },
        {
            'name': 'Order Status',
            'value': this.order.status
        },
        {
            'name': 'Order Type',
            'value': this.order.type
        },
        {
            'name': 'Customer Name',
            'value': new TitleCasePipe().transform(this.order.customer_name)
        }] as any;

        order.push({
            'name': 'Order Items',
            'value': '',
            'iname': 'Item Name',
            'qty': 'Quantity',
            'uprice': 'Unit Price',
            'price': 'Price',
            'modifiers': 'Modifiers',
            'inst': 'Store Instructions'
        });

        this.order.order_items.forEach(item => {
            order.push({
                'name': '',
                'value': '',
                'iname': item.menu_item && item.menu_item.name,
                'qty': item.quantity,
                'uprice': this.utilityService.getFormatAmount(item.unit_price),
                'price': this.utilityService.getFormatAmount(item.price),
                'modifiers': this.getItemModifiers(item),
                'inst': item.store_instructions
            });
        });

        const titleList = ['Order Entity Name', 'Order Entity Value', '', '', '', '', '', ''];
        const headList = ['name', 'value', 'iname', 'qty', 'uprice', 'price', 'modifiers', 'inst'];
        const fname = '-' + this.order.id + '-order-details';
        this.efService.downloadFile(order, [titleList, headList], fname);
    }

    getItemModifiers(item) {
        let modifiers = [] as any;
        if (item.modifiers && item.modifiers.length > 0) {
            item.modifiers.forEach(mod => {
                mod.modifier && mod.modifier.name ? modifiers.push(mod.modifier.name) : '';
            });
        }
        return modifiers.join(',');
    }

}
