import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";

import { Order } from '@modules/order/models';
import { OrderDetailsComponent } from '@modules/order/containers/order-details/order-details.component';

@Component({
    selector: 'sbpro-order-entrydetails',
    template: '',
    styleUrls: ['order-entrydetails.component.scss'],
})
export class OrderEntrydetailsComponent implements OnInit {
    public order: Order;

    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        public modal: NgbModal
    ) {
        const state = this.router.getCurrentNavigation()?.extras.state
        state && state.order ? this.order = state.order : '';
    }

    ngOnInit() {
        const modalRef = this.showDialog();
        if (!this.order) {
            this.activatedRoute.paramMap.subscribe(
                (params: ParamMap) => {
                    const orderid = params.get('orderId')
                    if (orderid) {
                        modalRef.componentInstance.orderId = +orderid;
                    }
                }
            )
        } else {
            modalRef.componentInstance.order = this.order;
        }
    }

    showDialog() {
        const modalRef = this.modal.open(
            OrderDetailsComponent,
            {
                centered: true,
                scrollable: true,
                size: 'xl',
                backdrop: 'static',
                keyboard: false
            }
        );
        modalRef.result.then(
            result => {
            }, reason => {
                this.router.navigate(['orders']);
            });
        return modalRef;
    }
}
