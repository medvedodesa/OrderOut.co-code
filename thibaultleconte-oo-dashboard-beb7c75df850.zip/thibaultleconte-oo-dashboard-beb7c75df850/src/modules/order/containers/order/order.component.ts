import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'sbpro-order',
    templateUrl: './order.component.html',
    styleUrls: ['order.component.scss'],
})
export class OrderComponent implements OnInit {
    constructor() {}
    ngOnInit() {}
}
