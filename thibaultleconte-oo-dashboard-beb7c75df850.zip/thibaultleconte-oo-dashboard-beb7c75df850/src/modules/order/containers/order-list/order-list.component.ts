import { Component, OnInit, OnDestroy, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { Subject, Subscription } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

import { Restaurant } from '@common/models/restaurant';
import { Order, OrdersList, OrderOptions } from '@modules/order/models';
import { OrderService } from '@modules/order/services';
import { OrderHelper } from '@modules/order/helpers';
import { AppHelper } from '@common/helpers';

import { SpinnerService, UtilityService, ExportFileService } from '@common/services';

@Component({
    selector: 'sbpro-order-list',
    templateUrl: './order-list.component.html',
    styleUrls: ['order-list.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class OrderListComponent implements OnInit, OnDestroy {

    public title: string = 'Delivery Service Order Report';
    public ordersList$ = new Subject<OrdersList>();
    public total$ = new Subject<number>();

    public filtersForm: FormGroup;

    public currentRestaurant: Restaurant;
    public availableDSList;

    public orders: Order[];
    public orderOptions: OrderOptions = {};

    public subscriptions: Subscription = new Subscription();

    constructor(
        private router: Router,
        private orderService: OrderService,
        public orderHelper: OrderHelper,
        public appHelper: AppHelper,
        private spinnerService: SpinnerService,
        private utilityService: UtilityService,
        private efService: ExportFileService
    ) { }

    ngOnInit() {
        this.getRestaurants();
    }

    ngOnDestroy() {
        this.subscriptions.unsubscribe();
    }

    get page() {
        return this.orderOptions.page || 1;
    }
    set page(page: number) {
        this._set({ page });
    }
    get pageSize() {
        return this.orderOptions.item_per_page || 25;
    }
    set pageSize(item_per_page: number) {
        this._set({ item_per_page });
    }
    private _set(obj) {
        Object.assign(this.orderOptions, obj);
        this.getOrders();
    }

    getOrders() {
        this.spinnerService.show();
        this.subscriptions.add(this.orderService.getOrders(this.orderOptions)
            .subscribe(orders => {
                this.spinnerService.hide();
                this.availableDSList = orders.delivery_services_available;
                this.orders = orders.data;
                this.total$.next(orders.count);
                this.ordersList$.next(orders);
            }));
    }

    getRestaurants() {
        this.subscriptions.add(this.appHelper.currentRestaurant$.subscribe(restaurant => {
            this.currentRestaurant = restaurant;
            this.orderOptions.restaurant_id = restaurant.id;
            this.loadForm();
            this.getOrders();
        }));
    }

    getOrderItemQty(orderItems) {
        return this.orderHelper.getOrderItemQty(orderItems);
    }

    showOrderDetails(order: Order) {
        this.router.navigate(['orders', order.id], { state: { order: order } });
    }

    loadForm() {
        this.filtersForm = new FormGroup({
            restaurant: new FormControl(this.currentRestaurant.id),
            ds: new FormControl(''),
            date: new FormControl('')
        });

        this.onValueChanges();
    }

    onValueChanges() {
        let prevData = {
            restaurant: this.currentRestaurant.id,
            ds: "",
            date: ""
        };
        this.subscriptions.add(this.filtersForm.valueChanges
            .pipe(
                debounceTime(1000),
                distinctUntilChanged()
            )
            .subscribe((form) => {
                if (JSON.stringify(form) != JSON.stringify(prevData)) {
                    prevData = form;
                    const obj = {
                        restaurant_id: form.restaurant,
                        delivery_service_type: form.ds && form.ds.join(","),
                        from_timestamp: form.date && form.date.from_format,
                        to_timestamp: form.date && form.date.to_format
                    }
                    this._set(obj);
                }
            }));
    }

    exportCSV() {
        const newOrders = this.orders.map(order => {
            let obj: any = {};

            obj.api_created_at = this.utilityService.getFormatDate(order.api_created_at);
            obj.id = order.id;
            obj.accountId = order.account && order.account.id;
            obj.accountName = order.account && order.account.name;
            obj.restaurantId = order.restaurant && order.restaurant.id;
            obj.restaurantName = order.restaurant && order.restaurant.name;
            obj.uuid = order.delivery_service_short_uuid ? order.delivery_service_short_uuid.toString() : order.delivery_service_uuid;
            obj.type = order.delivery_service && order.delivery_service.type;
            obj.charge_total = this.utilityService.getFormatAmount(order.charge_total);
            obj.order_qty = this.orderHelper.getOrderItemQty(order.order_items);

            return obj;
        });
        const titleList = ['Order Date', 'Order Id', 'Account Id', 'Account Name',
            'Restaurant Id', 'Restaurant Name', 'Delivery Service UUID',
            'Delivery Service', 'Dollar Amount', 'Order Item Quantity'];
        const headList = ['api_created_at', 'id', 'accountId', 'accountName',
            'restaurantId', 'restaurantName', 'uuid', 'type', 'charge_total', 'order_qty'];
        this.efService.downloadFile(newOrders, [titleList, headList], '-orders_list');
    }

}
