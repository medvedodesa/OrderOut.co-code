import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Order } from '@modules/order/models';
import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";
import { FormControl, FormGroup, Validators } from "@angular/forms";

import { ToastMessageData, ToastMessageOptions } from '@common/models';
import { ToastService } from '@common/services/toast.service';

import { SpinnerService } from "@common/services/spinner.service";
import { OrderService } from "../../services";

@Component({
    selector: 'sbpro-order-report-issue',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './order-report-issue.component.html',
    styleUrls: ['order-report-issue.component.scss'],
})
export class OrderReportIssueComponent implements OnInit {
    public order: Order;
    public reportIssueFormGroup: FormGroup;
    public showLoader: boolean = false;
    constructor(
        public modal: NgbActiveModal,
        private toastService: ToastService,
        private spinnerService: SpinnerService,
        private orderService: OrderService
    ) { }
    ngOnInit() {
        const inputRegExp: RegExp = new RegExp(/^(?!\s)([A-Za-z0-9 ,.'-?:!$%]+)$/im);
        this.reportIssueFormGroup = new FormGroup({
            reportIssue: new FormControl("", [Validators.pattern(inputRegExp)]),
        });
    }

    onSubmit() {
        this.showLoader = true;
        let value = this.reportIssueFormGroup.value;
        this.orderService.reportIssue(this.order.id, value && value.reportIssue && value.reportIssue.trim())
            .subscribe((result) => {
                if (result.status === 'success') {
                    this.toastService.showSuccess({
                        header: 'Order Report Issue',
                        body: 'Your Order Report issue submitted successfully.'
                    });
                } else {
                    this.toastService.showError({
                        body: 'Something went wrong!',
                    });
                }
                this.showLoader = false;
                this.modal.close();
            });
    }
}
