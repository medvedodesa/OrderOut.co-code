import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

import { environment as env } from "environments/environment";
import { ApiService } from "@common/services/api.service";
import { UtilityService } from "@common/services";
import { Order, OrdersList, OrderOptions } from '../models/order.model';
import { delay } from 'rxjs/operators';

@Injectable()
export class OrderService {
    ordersUrl = env.front_api_url + 'order/list';
    orderUrl = env.front_api_url + 'order';

    constructor(private api: ApiService, private us: UtilityService) { }

    getOrders(options: OrderOptions): Observable<OrdersList> {

        options = this.us.pickBy(options);

        return this.api.get(this.ordersUrl, options);
    }

    getOrder(orderId: number): Observable<Order> {
        const url = `${this.orderUrl}/${orderId}`;
        return this.api.get(url);
    }

    reportIssue(orderId: number, message: string): Observable<any> {
        const url = `${this.orderUrl}/${orderId}/report_issue`;
        const params = {
            message: message
        };
        return this.api.post(url, params);
    }

}

