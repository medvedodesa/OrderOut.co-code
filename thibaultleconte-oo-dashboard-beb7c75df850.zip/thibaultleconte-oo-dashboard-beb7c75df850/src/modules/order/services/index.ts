import { OrderService } from './order.service';

export const services = [OrderService];

export * from './order.service';
