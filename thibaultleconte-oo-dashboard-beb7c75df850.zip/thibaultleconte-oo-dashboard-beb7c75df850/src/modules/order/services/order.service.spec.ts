import { TestBed } from '@angular/core/testing';

import { OrderService } from './order.service';

describe('OrderService', () => {
    let orderService: OrderService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [OrderService],
        });
        orderService = TestBed.get(OrderService);
    });

    describe('getOrder$', () => {
        it('should return Observable<Order>', () => {
            orderService.getOrder$().subscribe(response => {
                expect(response).toEqual({});
            });
        });
    });
});
