import { Injectable } from '@angular/core';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";

import { Order } from '../models';
import { OrderReportIssueComponent } from '@modules/order/containers/order-report-issue/order-report-issue.component';

@Injectable()
export class OrderHelper {

    constructor(
        public modal: NgbModal
    ) { }

    showReportIssueDg(order: Order) {
        const modalRef = this.modal.open(
            OrderReportIssueComponent,
            {
                centered: true,
                scrollable: true,
                size: 'lg'
            }
        );
        modalRef.componentInstance.order = order;
    }

    getOrderItemQty(orderItems) {
        let totalQty = 0;
        orderItems && orderItems.forEach(item => {
            totalQty += parseInt(item.quantity);
        });
        return totalQty;
    }
}