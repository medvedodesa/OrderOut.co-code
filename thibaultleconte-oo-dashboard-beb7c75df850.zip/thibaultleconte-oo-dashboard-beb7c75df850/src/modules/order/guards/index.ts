import { OrderGuard } from './order.guard';

export const guards = [OrderGuard];

export * from './order.guard';
