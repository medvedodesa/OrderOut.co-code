import { TestBed } from '@angular/core/testing';

import { OrderGuard } from './order.guard';

describe('_Template Module Guards', () => {
    let orderGuard: OrderGuard;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [],
            providers: [OrderGuard],
        });
        orderGuard = TestBed.get(OrderGuard);
    });

    describe('canActivate', () => {
        it('should return an Observable<boolean>', () => {
            orderGuard.canActivate().subscribe(response => {
                expect(response).toEqual(true);
            });
        });
    });

});
