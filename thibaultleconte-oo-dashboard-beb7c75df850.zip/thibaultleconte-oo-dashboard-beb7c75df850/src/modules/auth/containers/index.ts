import { Auth0LoginComponent } from './auth0-login/auth0-login.component';

export const containers = [Auth0LoginComponent];

export * from './auth0-login/auth0-login.component';
