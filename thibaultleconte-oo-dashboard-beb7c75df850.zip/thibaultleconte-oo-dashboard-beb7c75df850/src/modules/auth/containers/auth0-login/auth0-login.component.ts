import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { AuthService } from '@auth0/auth0-angular';

@Component({
    selector: 'sbpro-auth0-login',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './auth0-login.component.html',
    styleUrls: ['auth0-login.component.scss'],
})
export class Auth0LoginComponent implements OnInit {

    constructor(public auth: AuthService) {}

    ngOnInit() {}

    loginWithRedirect(): void {
        this.auth.loginWithRedirect({
            redirect_uri: window.location.origin + '/dashboard'
        });
    }
}
