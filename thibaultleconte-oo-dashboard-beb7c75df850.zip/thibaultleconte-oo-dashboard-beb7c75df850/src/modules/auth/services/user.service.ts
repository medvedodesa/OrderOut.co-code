import { Injectable, Inject } from '@angular/core';
import { Observable, ReplaySubject } from 'rxjs';
import { AuthService } from '@auth0/auth0-angular';
import { DOCUMENT } from '@angular/common';
import { Intercom } from "ng-intercom";

import { environment as env } from '../../../environments/environment';
import { User } from '../models';

const userSubject: ReplaySubject<User> = new ReplaySubject(1);

@Injectable()
export class UserService {
    constructor(public auth: AuthService, @Inject(DOCUMENT) private doc: Document, private intercom: Intercom) {
        this.auth.isAuthenticated$.subscribe((isLogged => {
            if (isLogged) {
                this.auth.user$.subscribe((profile) => {
                    if (profile) {
                        this.user = {
                            id: profile.sub!,
                            firstName: profile.given_name,
                            lastName: profile.family_name,
                            email: profile.email!,
                            image: profile.picture,
                            name: this.getUserName(profile)
                        };
                    }
                });
            }
        }));
    }

    set user(user: User) {
        userSubject.next(user);
    }

    get user$(): Observable<User> {
        return userSubject.asObservable();
    }

    getUserName(profile) {
        const familyName = profile.family_name ? profile.given_name + ' ' + profile.family_name : profile.given_name;
        return profile.given_name ? familyName : profile.nickname;
    }

    logout(): void {
        if (this.intercom) {
            this.intercom.shutdown();
        }
        this.auth.logout({
            returnTo: this.doc.location.origin,
            client_id: env.auth.clientId,
            //federated: true
        });
    }
}
