export interface User {
    id: string;
    firstName: string | undefined;
    lastName: string | undefined;
    name: string | undefined;
    email: string;
    image: string | undefined;
}
