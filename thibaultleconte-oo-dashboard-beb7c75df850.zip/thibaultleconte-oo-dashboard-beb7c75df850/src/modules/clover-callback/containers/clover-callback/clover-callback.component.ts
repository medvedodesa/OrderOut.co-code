import {
  Component,
  OnInit,
  ElementRef,
  ChangeDetectorRef,
} from "@angular/core";
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  Validators,
  FormControl,
  FormArray,
} from "@angular/forms";
import { ActivatedRoute } from "@angular/router";

import { CloverCallbackService } from "modules/clover-callback/services/clover-callback.service";
import { SpinnerService } from "@common/services/spinner.service";

@Component({
  selector: "sbpro-clover-callback",
  templateUrl: "./clover-callback.component.html",
  styleUrls: ["clover-callback.component.scss"],
})
export class CloverCallbackComponent implements OnInit {
  step: "account" | "restaurant" | "contact" | "ds" = "account";

  public userInfo: any;
  public csFormGroup: FormGroup;

  public showError: boolean = false;
  public isLeadCreated: boolean = false;

  // Delivery selection input value
  public ds_val: boolean;

  /** Returns a FormArray with the name 'formArray'. */
  get formArray(): AbstractControl | null {
    return this.csFormGroup.get("formArray");
  }

  constructor(
    private _elementRef: ElementRef,
    private route: ActivatedRoute,
    private cloverCallbackService: CloverCallbackService,
    private spinnerService: SpinnerService,
    private fb: FormBuilder,
    private changeDetectorRef: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.route.queryParams.subscribe((params) => {
      if (params.step) {
        this.step = params.step;
        this.changeDetectorRef.detectChanges();
      }
    });

    const cloverAuthCallbackMerchantId =
      this.route.snapshot.queryParamMap.get("merchant_id") || "";
    const cloverAuthCallbackEmployeeId =
      this.route.snapshot.queryParamMap.get("employee_id") || "";
    const cloverAuthCallbackClientId =
      this.route.snapshot.queryParamMap.get("client_id") || "";
    const cloverAuthCallbackCode =
      this.route.snapshot.queryParamMap.get("code") || "";

    this.spinnerService.show();
    this.cloverCallbackService
      .processCloverCallback(
        cloverAuthCallbackMerchantId,
        cloverAuthCallbackEmployeeId,
        cloverAuthCallbackClientId,
        cloverAuthCallbackCode
      )
      .subscribe((result: any) => {
        this.spinnerService.hide();
        if (result.is_new) {
          this.userInfo = result;
          this.createForm();
        } else {
          this.isLeadCreated = true;
        }
      });
  }

  createForm() {
    let zipcode = new FormControl(this.userInfo.zipcode, {
      validators: Validators.compose([
        Validators.required,
        Validators.pattern(/^\d{5}(?:[-\s]\d{4})?|[A-Z]\d[A-Z]\d[A-Z]\d$/im),
      ]),
    });

    let owner_email = new FormControl(this.userInfo.owner_email, {
      validators: Validators.compose([Validators.required, Validators.email]),
    });

    let phone_number = new FormControl(this.userInfo.phone_number, {
      validators: Validators.compose([
        Validators.required,
        Validators.pattern(
          /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im
        ),
      ]),
    });

    // To initialize FormGroup
    this.csFormGroup = this.fb.group({
      formArray: this.fb.array([
        this.fb.group({
          account_name: [this.userInfo.account_name, Validators.required],
        }),
        this.fb.group({
          street_address_1: [
            this.userInfo.street_address_1,
            Validators.required,
          ],
          street_address_2: [this.userInfo.street_address_2],
          street_address_3: [this.userInfo.street_address_3],
          city: [this.userInfo.city, Validators.required],
          state: [this.userInfo.state, Validators.required],
          zipcode: zipcode,
        }),
        this.fb.group({
          owner_email: owner_email,
          phone_number: phone_number,
        }),
        this.fb.group({
          ds_validate: [false, Validators.required],
        }),
      ]),
    });
  }

  hasError(controlName: any, scopeFormArray: FormArray, errorName: string) {
    return scopeFormArray.controls[controlName].hasError(errorName);
  }

  onSubmit() {
    this.spinnerService.show();
    let value = this.csFormGroup.value.formArray;
    let updateValue = Object.assign({}, value[0], value[1], value[2]);
    Object.assign(this.userInfo, updateValue);
    this.cloverCallbackService
      .saveCloverLead(this.userInfo.id, this.userInfo)
      .subscribe((result) => {
        this.spinnerService.hide();
        this.isLeadCreated = true;
      });
  }

  updateServices(id: string) {
    this.userInfo.delivery_services.forEach((service) => {
      if (service.id === id) {
        service.selected = !service.selected;
      }
    });

    this.updateCheckboxDsValidate();
  }

  setCheckboxDsValidate() {
    let selectedServices = this.getSelectedServices();
    if (selectedServices.length !== 0) {
      this.ds_val = true;
    } else {
      this.ds_val = false;
    }
  }

  updateCheckboxDsValidate() {
    let dsValidate = this._elementRef.nativeElement.querySelector(
      "#ds_validate"
    );
    let selectedServices = this.getSelectedServices();
    if (selectedServices.length !== 0) {
      this.showError = false;
      if (dsValidate.checked === false) {
        dsValidate.click();
      }
    } else {
      this.showError = true;
      if (dsValidate.checked === true) {
        dsValidate.click();
      }
    }
  }

  getSelectedServices() {
    return this.userInfo.delivery_services.filter(function (service: any) {
      return service.selected === true;
    });
  }
}
