/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

/* Module */
import { CloverCallbackModule } from './clover-callback.module';

/* Containers */
import * as cloverCallbackContainers from './containers';

/* Guards */
import * as cloverCallbackGuards from './guards';

/* Routes */
export const ROUTES: Routes = [
    {
        path: '',
        canActivate: [],
        component: cloverCallbackContainers.CloverCallbackComponent
    },
];

@NgModule({
    imports: [CloverCallbackModule, RouterModule.forChild(ROUTES)],
    exports: [RouterModule],
})
export class CloverCallbackRoutingModule { }
