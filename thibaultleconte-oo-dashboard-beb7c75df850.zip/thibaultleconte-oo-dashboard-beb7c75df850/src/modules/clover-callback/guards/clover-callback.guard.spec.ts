import { TestBed } from '@angular/core/testing';

import { CloverCallbackGuard } from './clover-callback.guard';

describe('_Template Module Guards', () => {
    let cloverCallbackGuard: CloverCallbackGuard;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [],
            providers: [CloverCallbackGuard],
        });
        cloverCallbackGuard = TestBed.get(CloverCallbackGuard);
    });

    describe('canActivate', () => {
        it('should return an Observable<boolean>', () => {
            cloverCallbackGuard.canActivate().subscribe(response => {
                expect(response).toEqual(true);
            });
        });
    });

});
