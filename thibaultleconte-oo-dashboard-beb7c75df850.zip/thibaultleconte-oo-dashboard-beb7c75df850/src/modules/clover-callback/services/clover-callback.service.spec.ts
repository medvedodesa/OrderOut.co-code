import { TestBed } from '@angular/core/testing';

import { CloverCallbackService } from './clover-callback.service';

describe('CloverCallbackService', () => {
    let cloverCallbackService: CloverCallbackService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [CloverCallbackService],
        });
        cloverCallbackService = TestBed.get(CloverCallbackService);
    });

    describe('getCloverCallback$', () => {
        it('should return Observable<CloverCallback>', () => {
            cloverCallbackService.getCloverCallback$().subscribe(response => {
                expect(response).toEqual({});
            });
        });
    });
});
