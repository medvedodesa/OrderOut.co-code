import { Injectable } from "@angular/core";

import { ApiService } from "@common/services";
import { environment } from "environments/environment";

@Injectable()
export class CloverCallbackService {
  public pointOfSaleUrl = environment.backend_url + "pos";

  constructor(private api: ApiService) {}

  processCloverCallback(
    cloverMerchantId: string,
    cloverEmployeeId: string,
    cloverClientId: string,
    cloverCode: string
  ) {
    const url = `${this.pointOfSaleUrl}/clover/callback`;
    const params = {
      merchant_id: cloverMerchantId,
      employee_id: cloverEmployeeId,
      client_id: cloverClientId,
      code: cloverCode,
    };
    return this.api.post(url, params);
  }

  saveCloverLead(cloverLeadId: number, params: {}) {
    const url = `${this.pointOfSaleUrl}/clover/lead/${cloverLeadId}`;
    return this.api.post(url, params);
  }
}
