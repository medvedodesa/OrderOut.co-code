/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

/* Module */
import { OnboardingModule } from './onboarding.module';

/* Containers */
import * as onboardingContainers from './containers';

/* Guards */
import * as onboardingGuards from './guards';

/* Routes */
export const ROUTES: Routes = [
    {
        path: '',
        canActivate: [],
        component: onboardingContainers.OnboardingComponent,
    }
];

@NgModule({
    imports: [OnboardingModule, RouterModule.forChild(ROUTES)],
    exports: [RouterModule],
})
export class OnboardingRoutingModule {}
