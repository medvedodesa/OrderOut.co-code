import { Component, OnInit, OnDestroy } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { Subscription } from 'rxjs';

import { Account, Restaurant, DeliveryService, PointOfSale, Printer, const_ds } from "@common/models";

import { OnboardingService } from "../../services/onboarding.service";
import { UtilityService, SpinnerService } from "@common/services";
import { AppHelper } from '@common/helpers';

import { OnboardingAddDsDgComponent } from "../onboarding-add-ds-dg/onboarding-add-ds-dg.component";
import { OnboardingMenuListDgComponent } from "../onboarding-menu-list-dg/onboarding-menu-list-dg.component";
import { OnboardingSuccessDsDgComponent } from "../onboarding-success-ds-dg/onboarding-success-ds-dg.component";
import { OnboardingUbereatsStoresDgComponent } from "../onboarding-ubereats-stores-dg/onboarding-ubereats-stores-dg.component";

@Component({
  selector: "sbpro-onboarding",
  templateUrl: "./onboarding.component.html",
  styleUrls: ["onboarding.component.scss"],
})
export class OnboardingComponent implements OnInit, OnDestroy {
  public account: Account;
  public restaurant: Restaurant;
  public deliveryServices: DeliveryService[];
  public pointOfSale: PointOfSale;
  public printers: Printer[];
  public onboardDS;
  public dsList;
  public ubereatsStores = [];

  private restaurantId: number;
  public showConnectedDS: boolean = false;
  public showMissingItems: boolean = false;
  public supportUrl = "http://support.orderout.co/en/";
  public showSpinner: boolean = false;
  public modalOptions = {
    centered: true,
  };

  public subscriptions: Subscription = new Subscription();

  constructor(
    private route: ActivatedRoute,
    private spinnerService: SpinnerService,
    private onboardingService: OnboardingService,
    public utilityService: UtilityService,
    private modalService: NgbModal,
    private appHelper: AppHelper,
  ) { }

  ngOnInit() {
    this.restaurantId = this.route.snapshot.params["restaurantId"];
    this.showMissingItems =
      this.route.snapshot.queryParams.show_missing_items === "1";

    const currentRestaurant = this.appHelper.currentRestaurant;
    if (currentRestaurant && currentRestaurant.id) {
      this.subscriptions.add(this.appHelper.currentRestaurant$.subscribe(restaurant => {
        this.restaurantId = restaurant.id;
        this.getRestaurantStatus();
      }));
    } else {
      this.getRestaurantStatus();
    }

  }

  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }

  private getRestaurantStatus() {
    this.spinnerService.show();
    this.onboardingService.getRestaurantStatus(this.restaurantId).subscribe({
      next: (res) => {
        let restaurant_status = res.restaurant_status;
        this.account = restaurant_status.account;
        this.restaurant = restaurant_status.restaurant;
        this.pointOfSale = restaurant_status.pos_connected;
        this.deliveryServices = restaurant_status.ds_connected || [];
        this.printers = restaurant_status.printer_connected;
        this.filterAddDeliveryServices(res.global_settings.ds_available);
        this.getUberEatsStores(restaurant_status.ds_connected);
        this.setRestaurant();
      },
      complete: () => {
        this.spinnerService.hide();
      },
    });
  }

  setRestaurant() {
    const currentRestaurant = this.appHelper.currentRestaurant;
    currentRestaurant && currentRestaurant.id ? '' : this.appHelper.setRestaurant(this.restaurant);
  }

  filterAddDeliveryServices(availableDS) {
    this.onboardDS = availableDS;
    this.onboardDS.forEach((ds) => {
      ds.type = ds.name;
      ds.enable = const_ds[ds.name.toLowerCase()].enable;
    });
    if (this.deliveryServices && this.deliveryServices.length > 0) {
      this.onboardDS = availableDS.filter(function (this: any, obj) {
        return !this.has(obj.name) && obj.enable; // Filtered enable delivery services too
      }, new Set(this.deliveryServices.map((obj) => obj.type)));
      this.dsList = this.deliveryServices.concat(this.onboardDS);
    } else {
      this.dsList = availableDS.filter(function (obj) {
        return obj.enable; // Filtered enable delivery services too
      });
    }
  }

  openDSDialog(ds) {
    if (ds && ds.type && ds.type.toLowerCase() === "ubereats") {
      if (this.ubereatsStores && this.ubereatsStores.length === 0) {
        this.spinnerService.show();
        this.onboardingService
          .getUbereatsAuthUrl(this.restaurant.id)
          .subscribe({
            next: (res) => {
              this.spinnerService.hide();
              window.open(res.authorization_url, "_blank");
            },
            complete: () => {
              this.spinnerService.hide();
            },
          });
      } else {
        this.showUberEatsStoresDialog();
      }
    } else {
      const modalRef = this.modalService.open(
        OnboardingAddDsDgComponent,
        this.modalOptions
      );
      modalRef.componentInstance.ds = ds;
      modalRef.componentInstance.event.subscribe((delivery_service) => {
        this.spinnerService.show();
        this.onboardingService
          .updateRestaurantDS(this.restaurant.id, delivery_service)
          .subscribe({
            next: (res) => {
              this.spinnerService.hide();
              // Show success dialog if DS was connected successfully
              let isDSConnected = res.ds_connected.filter((connectedDs) => {
                return connectedDs.type === delivery_service.name;
              });
              if (isDSConnected && isDSConnected.length > 0) {
                const modalRef = this.modalService.open(
                  OnboardingSuccessDsDgComponent,
                  this.modalOptions
                );
                modalRef.componentInstance.ds = delivery_service;
              }

              this.deliveryServices = res.ds_connected;
              this.filterAddDeliveryServices(this.onboardDS);
            },
            complete: () => {
              this.spinnerService.hide();
            },
          });
      });
    }
  }

  toggleConnectedDS($event) {
    this.showConnectedDS = $event && $event.target && $event.target.checked;
    this.dsList = this.showConnectedDS === true ? this.deliveryServices : this.deliveryServices.concat(this.onboardDS);
  }

  getUnmappedList(ds) {
    let newOptions = Object.assign({}, {
      scrollable: true,
      size: 'lg'
    }, this.modalOptions);
    const modalRef = this.modalService.open(
      OnboardingMenuListDgComponent,
      newOptions
    );
    modalRef.componentInstance.ds = ds;
  }

  getUberEatsStores(connectedDS) {
    let isUberEatsConnected =
      (connectedDS &&
        connectedDS.filter((ds) => ds.type.toLowerCase() === "ubereats")) ||
      [];
    if (isUberEatsConnected && isUberEatsConnected.length === 0) {
      this.spinnerService.show();
      this.onboardingService.getUberEatsStores(this.restaurant.id).subscribe({
        next: (res) => {
          this.spinnerService.hide();
          this.ubereatsStores = res;
          if (res && res.length > 0) {
            this.showUberEatsStoresDialog();
          }
        },
        complete: () => {
          this.spinnerService.hide();
        },
      });
    } else {
      this.spinnerService.hide();
    }
  }

  showUberEatsStoresDialog() {
    let newOptions = Object.assign({}, {
      scrollable: true,
      windowClass: 'modal-us'
    }, this.modalOptions);
    const modalRef = this.modalService.open(
      OnboardingUbereatsStoresDgComponent,
      newOptions
    );
    modalRef.componentInstance.stores = this.ubereatsStores;
    modalRef.componentInstance.restaurant = this.restaurant;

    modalRef.result.then(
      result => {
        if (result && result === "reset") {
          this.ubereatsStores = []; // Reset stores
        }
      }, reason => {
      });

    modalRef.componentInstance.event.subscribe((store) => {
      this.spinnerService.show();
      this.onboardingService
        .connectUberEats(this.restaurant.id, store.store_id)
        .subscribe({
          next: (res) => {
            this.spinnerService.hide();
            const modalRef = this.modalService.open(
              OnboardingSuccessDsDgComponent,
              this.modalOptions
            );
            modalRef.componentInstance.ds = res;

            this.deliveryServices.push(res);
            this.filterAddDeliveryServices(this.onboardDS);
          },
          complete: () => {
            this.spinnerService.hide();
          },
        });
    });
  }

}
