import { ChangeDetectionStrategy, Component, OnInit } from "@angular/core";
import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";

@Component({
  selector: "sbpro-onboarding-success-ds-dg",
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: "./onboarding-success-ds-dg.component.html",
  styleUrls: ["onboarding-success-ds-dg.component.scss"],
})
export class OnboardingSuccessDsDgComponent implements OnInit {
  public ds;
  constructor(public modal: NgbActiveModal) {}
  ngOnInit() {}
}
