import { OnboardingComponent } from './onboarding/onboarding.component';
import { OnboardingAddDsDgComponent } from './onboarding-add-ds-dg/onboarding-add-ds-dg.component';
import { OnboardingSuccessDsDgComponent } from './onboarding-success-ds-dg/onboarding-success-ds-dg.component';
import { OnboardingUbereatsStoresDgComponent } from './onboarding-ubereats-stores-dg/onboarding-ubereats-stores-dg.component';
import { OnboardingMenuListDgComponent } from './onboarding-menu-list-dg/onboarding-menu-list-dg.component';

export const containers = [OnboardingComponent, OnboardingAddDsDgComponent, OnboardingSuccessDsDgComponent, OnboardingUbereatsStoresDgComponent, OnboardingMenuListDgComponent];

export * from './onboarding/onboarding.component';
export * from './onboarding-add-ds-dg/onboarding-add-ds-dg.component';
export * from './onboarding-success-ds-dg/onboarding-success-ds-dg.component';
export * from './onboarding-ubereats-stores-dg/onboarding-ubereats-stores-dg.component';
export * from './onboarding-menu-list-dg/onboarding-menu-list-dg.component';
