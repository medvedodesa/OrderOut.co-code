import { Component, OnInit, EventEmitter, ViewEncapsulation } from '@angular/core';
import { NgbActiveModal, NgbModal } from "@ng-bootstrap/ng-bootstrap";

import { Restaurant } from "@common/models/restaurant";
import { OnboardingService } from "../../services/onboarding.service";

@Component({
  selector: "sbpro-onboarding-ubereats-stores-dg",
  templateUrl: "./onboarding-ubereats-stores-dg.component.html",
  styleUrls: ["onboarding-ubereats-stores-dg.component.scss"],
  encapsulation: ViewEncapsulation.None
})
export class OnboardingUbereatsStoresDgComponent implements OnInit {
  public event: EventEmitter<any> = new EventEmitter();
  public restaurant: Restaurant;
  public stores;
  public showLoader: boolean = false;

  constructor(
    public modal: NgbActiveModal,
    public newModal: NgbModal,
    private onboardingService: OnboardingService
  ) { }

  ngOnInit() { }

  selectStore(store) {
    this.event.emit(store);
    this.modal.dismiss();
  }

  reset(content) {
    const modalRef = this.newModal.open(content, {
      centered: true
    });

    modalRef.result.then(
      result => {
        this.showLoader = true;
        this.onboardingService.delUberEatsStores(this.restaurant.id).subscribe({
          next: (res) => {
            this.showLoader = false;
            if (res && res.success === true) {
              this.modal.close("reset"); // Reset Stores
            }
          },
          complete: () => {
            this.showLoader = false;
          },
        });
      }, reason => {
      });
  }
}
