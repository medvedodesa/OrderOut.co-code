import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";
import { finalize } from 'rxjs/operators';
import { OnboardingService } from "../../services/onboarding.service";
import { OnboardingHelper } from "../../helpers/onboarding.helper";

@Component({
    selector: 'sbpro-onboarding-menu-list-dg',
    templateUrl: './onboarding-menu-list-dg.component.html',
    styleUrls: ['onboarding-menu-list-dg.component.scss']
})
export class OnboardingMenuListDgComponent implements OnInit {
    public unmapped_list;
    public showLoader: boolean = true;
    public ds;

    constructor(
        public onboardingService: OnboardingService,
        private onboardingHelper: OnboardingHelper,
        public modal: NgbActiveModal
    ) { }

    ngOnInit() {
        this.onboardingService.getUnmappedMenuList(this.ds.id)
            .pipe(
                finalize(() => {
                    this.showLoader = false;
                })
            )
            .subscribe(menuItems => {
                let itemsList = this.onboardingHelper.getNewMenuItems(menuItems, this.ds);
                this.unmapped_list = this.onboardingHelper.getUnMappedMenuList(itemsList);
                this.showLoader = false;
            });
    }
}
