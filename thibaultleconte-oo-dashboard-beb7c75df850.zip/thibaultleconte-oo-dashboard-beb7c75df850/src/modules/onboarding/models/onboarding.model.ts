import { Account } from "@common/models/account";
import { Restaurant } from "@common/models/restaurant";
import { DeliveryService, const_ds } from "@common/models/ds";
import { PointOfSale } from "@common/models/pos";
import { Printer } from "@common/models/printer";

export interface OnboardRestaurant {
    restaurant_status: RestaurantStatus;
    global_settings: GlobalSettings;
}

export interface RestaurantStatus {
    account: Account;
    restaurant: Restaurant;
    ds_connected: DeliveryService[];
    pos_connected: PointOfSale;
    printer_connected: Printer[];
}

export interface GlobalSettings {
    ds_available: ds[];
}

export interface ds {
    name: string;
    id: number;
}