import { OnboardingGuard } from './onboarding.guard';

export const guards = [OnboardingGuard];

export * from './onboarding.guard';
