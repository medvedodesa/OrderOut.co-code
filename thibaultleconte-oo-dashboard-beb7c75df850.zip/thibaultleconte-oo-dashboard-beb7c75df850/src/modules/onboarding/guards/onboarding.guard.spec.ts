import { TestBed } from '@angular/core/testing';

import { OnboardingGuard } from './onboarding.guard';

describe('_Template Module Guards', () => {
    let onboardingGuard: OnboardingGuard;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [],
            providers: [OnboardingGuard],
        });
        onboardingGuard = TestBed.get(OnboardingGuard);
    });

    describe('canActivate', () => {
        it('should return an Observable<boolean>', () => {
            onboardingGuard.canActivate().subscribe(response => {
                expect(response).toEqual(true);
            });
        });
    });

});
