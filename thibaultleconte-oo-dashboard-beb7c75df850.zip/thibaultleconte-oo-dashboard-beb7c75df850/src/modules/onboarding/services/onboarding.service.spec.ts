import { TestBed } from '@angular/core/testing';

import { OnboardingService } from './onboarding.service';

describe('OnboardingService', () => {
    let onboardingService: OnboardingService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [OnboardingService],
        });
        onboardingService = TestBed.get(OnboardingService);
    });

    describe('getOnboarding$', () => {
        it('should return Observable<Onboarding>', () => {
            onboardingService.getOnboarding$().subscribe(response => {
                expect(response).toEqual({});
            });
        });
    });
});
