import { OnboardingService } from './onboarding.service';

export const services = [OnboardingService];

export * from './onboarding.service';
