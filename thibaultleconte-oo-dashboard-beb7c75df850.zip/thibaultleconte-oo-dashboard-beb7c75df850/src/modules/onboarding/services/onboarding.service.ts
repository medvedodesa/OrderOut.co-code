import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';

import { OnboardRestaurant } from '../models/onboarding.model';
import { MenuItem } from '@common/models';
import { ApiService } from "@common/services/api.service";
import { environment } from "environments/environment";

const headerOptions = {
  headers: new HttpHeaders({
    'api-key': environment.DASHBOARD_ONBOARDING_API_KEY
  })
};

@Injectable()
export class OnboardingService {
    public onboardUrl = environment.backend_url + 'onboarding';
    public dsUrl = environment.backend_url + 'ds';
  
    constructor(private api: ApiService) { }
  
    getRestaurantStatus(restaurantId: number): Observable<OnboardRestaurant>  {
      const url = `${this.onboardUrl}/${restaurantId}`;
      return this.api.get(url, {}, headerOptions);
    }
  
    updateRestaurantDS(restaurantId: number, ds): Observable<any> {
      const url = `${this.onboardUrl}/${restaurantId}`;
      let payload = {
        "ds": [{
          "id": ds.id,
          "service_menu_url": ds.value
        }]
      };
      ds.username ? payload.ds[0]['service_username'] = ds.username : '';
      ds.password ? payload.ds[0]['service_password'] = ds.password : '';
      ds.pincode ? payload.ds[0]['service_pincode'] = ds.pincode : '';
      
      return this.api.put(url, payload, headerOptions);
    }
  
    getUnmappedMenuList(delivery_service_id: number): Observable<[MenuItem]>  {
      const url = `${this.dsUrl}/${delivery_service_id}/mapping/unmapped`;
      return this.api.get(url, {}, headerOptions);
    }
  
    getUbereatsAuthUrl(restaurantId: number) {
      const url = `${environment.backend_url}oauth/ubereats/${restaurantId}/authorization_url`;
      return this.api.get(url);
    }
  
    getUberEatsStores(restaurantId: number) {
      const url = `${environment.backend_url}restaurant/ubereats/${restaurantId}/store_data`;
      return this.api.get(url);
    }
  
    delUberEatsStores(restaurantId: number) {
      const url = `${environment.backend_url}restaurant/ubereats/${restaurantId}/store_data`;
      return this.api.delete(url);
    }
  
    connectUberEats(restaurantId: number, uberEatsStoreId: string) {
      const url = `${environment.backend_url}restaurant/${restaurantId}/ds/ubereats/connect`;
      const params = {
        "storeId": uberEatsStoreId
      };
      return this.api.post(url, params);
    }
}
