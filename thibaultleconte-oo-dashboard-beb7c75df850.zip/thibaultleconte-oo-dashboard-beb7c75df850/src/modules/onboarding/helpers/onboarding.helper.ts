import { Injectable } from '@angular/core';

import { Restaurant } from "@common/models/restaurant";
import { DeliveryService } from "@common/models/ds";
import { MenuItem } from "@common/models/menu";

@Injectable()
export class OnboardingHelper {
      /** 
   * Get new Menu items list with specific format to support CSV or dialog view on onboarding
  */
  getNewMenuItems(menuItems: MenuItem[], ds?: DeliveryService, account?: Account, restaurant?: Restaurant) {
    let newMenuItems: any = [];
    if (menuItems && menuItems.length > 0) {
      menuItems.forEach(menuItem => {
        let objMenuItem = {};
        objMenuItem['item_id'] = menuItem.id;
        account && account.name ? objMenuItem['account_name'] = account.name : '';
        restaurant && restaurant.name ? objMenuItem['restaurant_name'] = restaurant.name : '';
        ds && ds.type ? objMenuItem['delivery_service_type'] = ds.type : '';
        objMenuItem['item_name'] = menuItem.name;
        objMenuItem['mappedToMenuItem'] = menuItem.mappedToMenuItem;
        objMenuItem['modifier_name'] = '';
        objMenuItem['modifier_id'] = '';
        objMenuItem['mappedToMenuItemModifier'] = null;

        /* Modifier List */
        let modifier_list: any = [];
        if(menuItem.modifier_groups && menuItem.modifier_groups.length > 0) {
          menuItem.modifier_groups.forEach(modifier_group => {
            if(modifier_group.modifiers && modifier_group.modifiers.length > 0) {
              modifier_group.modifiers.forEach(modifier => {
                let clonedMenuItem = { ...objMenuItem };
                clonedMenuItem['modifier_name'] = modifier.name;
                clonedMenuItem['modifier_id'] = modifier.id;
                clonedMenuItem['mappedToMenuItemModifier'] = modifier.mappedToMenuItemModifier;
                modifier_list.push(clonedMenuItem)
              });
            }
          });
        }

        newMenuItems.push(objMenuItem);
        if(modifier_list.length > 0) {
          newMenuItems = newMenuItems.concat(modifier_list);
        }
      });
    }
    return newMenuItems;
  }

  getUnMappedMenuList(itemsList) {
    let unMappedMenuList = itemsList.filter(function(menuItem) {
      return menuItem.modifier_id ? menuItem.mappedToMenuItemModifier === null : menuItem.mappedToMenuItem === null;
    });
    return unMappedMenuList;
  }
}