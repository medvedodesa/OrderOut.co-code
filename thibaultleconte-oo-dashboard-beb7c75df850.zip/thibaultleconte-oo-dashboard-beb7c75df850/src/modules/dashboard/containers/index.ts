import { DashboardComponent } from './dashboard/dashboard.component';
import { DashboardOverviewComponent } from './dashboard-overview/dashboard-overview.component';

export const containers = [DashboardComponent, DashboardOverviewComponent];

export * from './dashboard/dashboard.component';
export * from './dashboard-overview/dashboard-overview.component';
