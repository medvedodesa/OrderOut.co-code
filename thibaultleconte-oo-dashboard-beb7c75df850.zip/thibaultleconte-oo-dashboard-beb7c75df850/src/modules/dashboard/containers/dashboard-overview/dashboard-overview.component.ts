import {
    ChangeDetectionStrategy,
    Component,
    OnInit,
    OnDestroy,
    AfterViewInit,
    ElementRef,
    ViewChild
} from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { BehaviorSubject, Subscription } from 'rxjs';

import { Restaurant } from '@common/models';
import { DashboardService } from '../../services';
import { SpinnerService, ChartsService, UtilityService, ExportFileService } from '@common/services';
import { AppHelper } from '@common/helpers';

@Component({
    selector: 'sbpro-dashboard-overview',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './dashboard-overview.component.html',
    styleUrls: ['dashboard-overview.component.scss'],
})
export class DashboardOverviewComponent implements OnInit, OnDestroy, AfterViewInit {
    public reportData: any;
    public isReportData: boolean = false;
    private stats: any;
    public stats$ = new BehaviorSubject<any>({});

    @ViewChild('orderPieChart') orderPieChart!: ElementRef<HTMLCanvasElement>;
    @ViewChild('orderLineBarChart') orderLineBarChart!: ElementRef<HTMLCanvasElement>;
    @ViewChild('orderLineChart') orderLineChart!: ElementRef<HTMLCanvasElement>;
    @ViewChild('orderBarChart') orderBarChart!: ElementRef<HTMLCanvasElement>;
    OrderPieChart: Chart;
    OrderLineBarChart: Chart;
    OrderLineChart: Chart;
    OrderBarChart: Chart;
    chartDefaultConfig: any;
    summaryConfig: any;

    public currentRestaurant: Restaurant;
    public dateRangeForm: FormGroup;

    public subscriptions: Subscription = new Subscription();

    constructor(
        private dnService: DashboardService,
        public appHelper: AppHelper,
        private spinnerService: SpinnerService,
        private chartsService: ChartsService,
        private utilityService: UtilityService,
        private efService: ExportFileService
    ) { }

    ngOnInit() {
        this.init();
        this.loadForm();
    }

    ngOnDestroy() {
        this.subscriptions.unsubscribe();
    }

    ngAfterViewInit() {
        this.dateRangeForm.controls.date.setValue('LAST_30_DAYS');
    }

    init() {
        this.chartDefaultConfig = {
            "UBEREATS": {
                backgroundColor: 'rgba(63, 192, 96, 1)', // Green #3FC060
                hoverBackgroundColor: 'rgba(63, 192, 96, 0.7)'
            },
            "POSTMATES": {
                backgroundColor: 'rgba(54, 69, 79, 1)', // Charcoal #36454F
                hoverBackgroundColor: 'rgba(54, 69, 79, 0.7)'
            },
            "GRUBHUB": {
                backgroundColor: 'rgba(246, 52, 64, 1)', // Red #F6343F
                hoverBackgroundColor: 'rgba(246, 52, 64, 0.7)'
            },
            "CHOWNOW": {
                backgroundColor: 'rgba(41, 96, 145, 1)', // Dark Blue #296091
                hoverBackgroundColor: 'rgba(41, 96, 145, 0.7)'
            },
            "WIX": {
                backgroundColor: 'rgba(250, 173, 77, 1)', // Light Orange #FAAD4D
                hoverBackgroundColor: 'rgba(250, 173, 77, 0.7)'
            },
            "DOORDASH": {
                backgroundColor: 'rgba(185, 221, 235, 1)', // Light Blue #B9DDEB
                hoverBackgroundColor: 'rgba(185, 221, 235, 0.7)'
            }
        }
        this.initSummaryConfig();
    }

    initSummaryConfig() {
        this.summaryConfig = {
            labels: [],
            orders: [],
            amounts: [],
            backgroundColor: [],
            hoverBackgroundColor: [],
            details: []
        };
    }

    initStats() {
        this.stats = {
            totalOrders: 0,
            totalRev: 0,
            revPerDay: 0,
            amtPerOrder: 0
        }
    }

    resetCharts() {
        if (this.OrderPieChart) {
            this.OrderPieChart.destroy();
        }
        if (this.OrderLineBarChart) {
            this.OrderLineBarChart.destroy();
        }
        if (this.OrderLineChart) {
            this.OrderLineChart.destroy();
        }
        if (this.OrderBarChart) {
            this.OrderBarChart.destroy();
        }
    }

    loadForm() {
        this.dateRangeForm = new FormGroup({
            date: new FormControl('')
        });
        this.onValueChanges();
    }

    onValueChanges() {
        let prevData = {
            date: ""
        };
        this.subscriptions.add(this.dateRangeForm.valueChanges
            .subscribe((form) => {
                if (JSON.stringify(form) != JSON.stringify(prevData)) {
                    prevData = form;
                    if (form && form.date && form.date.from_format && form.date.to_format) {
                        const obj = {
                            from_date: form.date.from_format,
                            to_date: form.date.to_format
                        }
                        this.getOrderTotal(obj);
                    }
                }
            }));
    }

    getOrderTotal(obj) {
        this.spinnerService.show();
        this.dnService.getOrderTotal(obj).subscribe((result) => {
            this.spinnerService.hide();
            this.showCurrentRestaurantData(result);
        });
    }

    showCurrentRestaurantData(result) {
        this.subscriptions.add(this.appHelper.currentRestaurant$.subscribe(restaurant => {
            if (restaurant && restaurant.id) {
                this.currentRestaurant = restaurant;
                this.summaryReport(result[restaurant.id]);
            }
        }));
    }

    summaryReport(result) {
        this.initSummaryConfig();
        this.initStats();
        this.resetCharts();

        // Stats, Orders summary and Pie Chart
        const summary = result && result.summary;
        if (summary && Object.keys(summary).length) {
            // CHOWNOW, UBEREATS, POSTMATES, GRUBHUB, DOORDASH, WIX
            // Sort Delivery service in DESC order by number of orders (total)
            let descSortedSummary = {};
            Object.keys(summary).sort((a, b) => {
                return summary[b].orders - summary[a].orders; // DESC order by orders (no of orders) field
            }).forEach(function (key) {
                descSortedSummary[key] = summary[key];
            });
            this.stats$.next(this.calcStats(descSortedSummary));
            this.drawPieChart(descSortedSummary);
        } else {
            this.stats$.next(this.stats); // Set initial stats if restaurant does not have any statistics
        }

        // Orders Report and LineBar Chart
        const report = result && result.report;
        if (report && report.length) {
            const sortedReport = report.sort((a, b) => {
                return (new Date(a.date) as any) - (new Date(b.date) as any); // ASC order by date field
            });

            this.reportData = {
                summary: result.summary,
                report: sortedReport
            };
            this.isReportData = true;
            this.drawLineBarChart(sortedReport);
        }
    }

    calcStats(orderReport) {
        if (orderReport && Object.keys(orderReport).length > 0) {
            for (const ds in orderReport) {
                this.stats.totalOrders += orderReport[ds].orders;
                this.stats.totalRev += orderReport[ds].amount;
            }
            this.stats.revPerDay = this.stats.totalRev / 30;
            this.stats.amtPerOrder = this.stats.totalRev / this.stats.totalOrders;
        }
        return this.stats;
    }

    drawPieChart(orderReport) {
        for (const ds in orderReport) {
            this.summaryConfig.labels.push(ds);
            this.summaryConfig.orders.push(orderReport[ds].orders);
            this.summaryConfig.amounts.push(Math.round(orderReport[ds].amount));
            this.summaryConfig.backgroundColor.push(this.chartDefaultConfig[ds].backgroundColor);
            this.summaryConfig.hoverBackgroundColor.push(this.chartDefaultConfig[ds].hoverBackgroundColor);
            this.summaryConfig.details.push({
                name: ds,
                order: orderReport[ds].orders,
                percent: ((orderReport[ds].orders * 100) / this.stats.totalOrders).toFixed(0)
            });
        }
        this.createPieChart(this.summaryConfig);
    }

    drawLineBarChart(orderReport) {
        if (orderReport && orderReport.length) {
            const reportConfig = {
                labels: [],
                orders: [],
                amounts: []
            } as any;
            orderReport.forEach(day => {
                reportConfig.labels.push(this.getFormatDateMd(day.date));
                reportConfig.orders.push(day.orders);
                reportConfig.amounts.push(day.amount && day.amount.toFixed(0));
            });

            this.createLineChart(reportConfig);
            this.createBarChart(reportConfig);
            // this.createLineBarChart(reportConfig);
        }
    }

    createPieChart(config) {
        this.OrderPieChart = new this.chartsService.Chart(this.orderPieChart.nativeElement, {
            type: 'pie',
            data: {
                labels: config.labels,
                datasets: [
                    {
                        data: config.orders,
                        backgroundColor: config.backgroundColor,
                        hoverBackgroundColor: config.hoverBackgroundColor,
                        hoverBorderColor: 'rgba(234, 236, 244, 1)',
                    },
                ],
            },
            options: {
                maintainAspectRatio: false,
            },
        });
    }

    createLineChart(config) {
        this.OrderLineChart = new this.chartsService.Chart(this.orderLineChart.nativeElement, {
            type: 'line',
            data: {
                labels: config.labels,
                datasets: [
                    {
                        label: 'Amount($)',
                        data: config.amounts,
                        backgroundColor: "rgba(255, 255, 255, 1)",
                        borderColor: "rgb(63, 81, 181, 1)", // #3f51b5
                    }
                ],
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
                legend: {
                    display: false
                },
                scales: {
                    xAxes: [{
                        // gridLines: {
                        //     drawOnChartArea: false, // Hide Grid lines
                        // },
                    }],
                    yAxes: [{
                        // gridLines: {
                        //     drawOnChartArea: false,
                        // },
                        ticks: {
                            callback: (label) => {
                                return "$" + label;
                            },
                            beginAtZero: true
                        }
                    }]
                }
            },
        });
    }

    createBarChart(config) {
        this.OrderBarChart = new this.chartsService.Chart(this.orderBarChart.nativeElement, {
            type: 'bar',
            data: {
                labels: config.labels,
                datasets: [
                    {
                        label: 'Orders',
                        data: config.orders,
                        backgroundColor: "rgb(63, 81, 181, 1)", // #3f51b5
                    },
                ],
            },
            options: {
                maintainAspectRatio: false,
                responsive: true,
                legend: {
                    display: false
                },
                scales: {
                    xAxes: [{
                        gridLines: {
                            drawOnChartArea: false, // Hide Grid lines
                        },
                    }],
                    yAxes: [{
                        // gridLines: {
                        //     drawOnChartArea: false,
                        // },
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            },
        });
    }

    createLineBarChart(config) {
        this.OrderLineBarChart = new this.chartsService.Chart(this.orderLineBarChart.nativeElement, {
            type: 'bar',
            data: {
                labels: config.labels,
                datasets: [
                    {
                        type: 'line',
                        //label: 'Dollor Amount of Orders',
                        label: 'Amount($)',
                        yAxisID: 'Amounts',
                        data: config.amounts,
                        backgroundColor: "rgba(255, 255, 255, 1)",
                        borderColor: "rgba(237, 76, 88, 1)"
                        // hoverBorderColor: 'rgba(234, 236, 244, 1)',
                    },
                    {
                        //label: 'Quantity of Orders',
                        label: 'Orders',
                        yAxisID: 'Orders',
                        data: config.orders,
                        backgroundColor: "rgba(0, 0, 0, 1)", // #ea8895
                        // hoverBorderColor: 'rgba(234, 236, 244, 1)',
                    },
                ],
            },
            options: {
                responsive: true,
                legend: {
                    position: 'bottom',
                },
                // elements: {
                //     point: {
                //         radius: 0  // Hide Dots on line chart
                //     }
                // },
                scales: {
                    xAxes: [{
                        gridLines: {
                            drawOnChartArea: false, // Hide Grid lines
                        },
                    }],
                    yAxes: [{
                        gridLines: {
                            drawOnChartArea: false,
                        },
                        id: 'Orders',
                        type: 'linear',
                        position: 'right',
                        scaleLabel: {
                            display: false,
                            labelString: 'Quantity of Orders'
                        },
                        ticks: {
                            beginAtZero: true
                        }
                    },
                    {
                        gridLines: {
                            drawOnChartArea: false,
                        },
                        id: 'Amounts',
                        type: 'linear',
                        position: 'left',
                        scaleLabel: {
                            display: false,
                            labelString: 'Dollor Amount of Orders'
                        },
                        ticks: {
                            callback: (label) => {
                                return "$" + label;
                            },
                            beginAtZero: true
                        }
                    }]
                }
            },
        });
    }

    exportCSV() {
        if (this.isReportData) {
            let titleList = ['Order Date', 'Delivery Service', 'Order Amount', 'Order Quantity'];
            let headList = ['date', 'type', 'amount', 'orders'];

            let newOrders = [] as any;
            this.reportData.report.map(report => {

                let objTotal: any = {};
                objTotal.date = this.utilityService.getFormatDate(new Date(report.date), 'shortDate', false);
                objTotal.type = "Total";
                objTotal.amount = this.utilityService.getFormatAmount(report.amount);
                objTotal.orders = report.orders;
                newOrders.push(objTotal);

                Object.keys(report.summary).forEach(key => {
                    let objType: any = {};
                    objType.date = '';
                    objType.type = key;
                    const amount = report.summary[key] && report.summary[key].amount ? this.utilityService.getFormatAmount(report.summary[key].amount) : 0;
                    objType.amount = amount;
                    objType.orders = (report.summary[key] && report.summary[key].orders) || 0;
                    newOrders.push(objType);
                });
                return report;
            });

            if (this.reportData && this.reportData.summary) {
                const summary = this.reportData.summary;
                newOrders.push({});
                newOrders.push({});

                let totalAmount = 0;
                let totalOrders = 0;
                let summaryOrders = [] as any;
                Object.keys(summary).forEach(key => {
                    let objType: any = {};
                    objType.date = '';
                    objType.type = key;

                    let amount: any = 0;
                    if (summary[key] && summary[key].amount) {
                        totalAmount += summary[key].amount;
                        amount = this.utilityService.getFormatAmount(summary[key].amount);
                    }
                    objType.amount = amount;

                    let orders = 0;
                    if (summary[key] && summary[key].orders) {
                        totalOrders += summary[key].orders;
                        orders = summary[key].orders;
                    }
                    objType.orders = orders;

                    summaryOrders.push(objType);
                });

                newOrders.push({
                    'date': 'Report Summary',
                    'type': 'Total',
                    'amount': this.utilityService.getFormatAmount(totalAmount),
                    'orders': totalOrders
                });
                newOrders = newOrders.concat(summaryOrders);
            }
            this.efService.downloadFile(newOrders, [titleList, headList], '-report');
        }
    }

    getFormatDateMd(date) {
        if (date) {
            let aDate = date.split('-');
            return aDate && aDate.length === 3 ? parseInt(aDate[1]) + '/' + parseInt(aDate[2]) : '';
        }
        return '';
    }
}

