import { Injectable } from '@angular/core';

import { ApiService } from "@common/services";
import { environment as env } from "environments/environment";

@Injectable()
export class DashboardService {
    public reportUrl = env.front_api_url + "report";

    constructor(private api: ApiService) { }

    getOrderTotal(obj) {
        let qParams;
        if (obj && obj.from_date && obj.to_date) {
            qParams = 'from_date=' + obj.from_date + '&to_date=' + obj.to_date;
        } else {
            qParams = 'count_days=30';
        }
        const url = `${this.reportUrl}/order/total?${qParams}`;
        return this.api.get(url);
    }

}
