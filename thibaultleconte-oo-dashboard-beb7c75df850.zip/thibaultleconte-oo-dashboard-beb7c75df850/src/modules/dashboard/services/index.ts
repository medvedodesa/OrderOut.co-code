import { DashboardService } from './dashboard.service';

export const services = [DashboardService];

export * from './dashboard.service';
