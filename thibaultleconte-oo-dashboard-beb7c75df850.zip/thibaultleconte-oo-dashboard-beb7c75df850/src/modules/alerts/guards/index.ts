import { AlertsGuard } from './alerts.guard';

export const guards = [AlertsGuard];

export * from './alerts.guard';
