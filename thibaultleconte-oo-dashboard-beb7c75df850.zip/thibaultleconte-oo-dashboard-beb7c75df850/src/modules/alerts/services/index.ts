import { AlertsService } from './alerts.service';

export const services = [AlertsService];

export * from './alerts.service';
