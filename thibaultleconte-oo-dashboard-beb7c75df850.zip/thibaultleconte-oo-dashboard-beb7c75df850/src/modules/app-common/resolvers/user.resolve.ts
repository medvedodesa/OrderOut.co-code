import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { EMPTY, Observable, of } from 'rxjs';
import { take, mergeMap, catchError } from 'rxjs/operators';
import { AuthService } from '@auth0/auth0-angular';
import { AppService } from '@common/services/app.service';
import { AppHelper } from '@common/helpers';

@Injectable()
export class UserResolve implements Resolve<Observable<any>> {

    constructor(
        private router: Router,
        private auth: AuthService,
        private appService: AppService,
        private appHelper: AppHelper,
    ) { }

    resolve(): Observable<any> {
        return this.auth.isAuthenticated$.pipe(
            take(1),
            mergeMap(isLoggedIn => {
                if (isLoggedIn) {
                    if (this.appHelper.user && this.appHelper.user.id) {
                        return this.appHelper.user$.pipe(take(1));
                    } else {
                        return this.appService.getUser().pipe(
                            take(1),
                            mergeMap(user => {
                                if (user && user.id) {
                                    this.appHelper.setUser(user);
                                    return of(user);
                                } else {
                                    return this.redirect();
                                }
                            }),
                            catchError(error => {
                                return this.redirect();
                            })
                        );
                    }
                } else {
                    return of(undefined);
                }
            })
        );
    }

    redirect() {
        this.router.navigate(["new"]);
        return EMPTY;
    }
}