import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { EMPTY, Observable, of } from 'rxjs';
import { take, mergeMap, catchError } from 'rxjs/operators';
import { AuthService } from '@auth0/auth0-angular';
import { AppService } from '@common/services/app.service';
import { AppHelper } from '@common/helpers';

@Injectable()
export class AccountResolve implements Resolve<Observable<any>> {

    constructor(
        private router: Router,
        private auth: AuthService,
        private appService: AppService,
        private appHelper: AppHelper,
    ) { }

    resolve(): Observable<any> {
        return this.auth.isAuthenticated$.pipe(
            take(1),
            mergeMap(isLoggedIn => {
                if (isLoggedIn) {
                    if (this.appHelper.account && this.appHelper.account.id) {
                        return this.appHelper.account$.pipe(take(1));
                    } else {
                        return this.appService.getAccount().pipe(
                            take(1),
                            mergeMap(account => {
                                if (account && account.id) {
                                    this.appHelper.setAccount(account);
                                    return of(account);
                                } else {
                                    return this.redirect();
                                }
                            }),
                            catchError(error => {
                                return this.redirect();
                            })
                        );
                    }
                } else {
                    return of(undefined);
                }
            })
        );
    }

    redirect() {
        this.router.navigate(["new"]);
        return EMPTY;
    }
}