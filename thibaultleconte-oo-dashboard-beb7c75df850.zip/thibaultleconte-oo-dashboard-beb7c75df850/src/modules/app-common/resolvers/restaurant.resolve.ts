import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { EMPTY, Observable, of } from 'rxjs';
import { take, mergeMap, catchError } from 'rxjs/operators';
import { AppService } from '@common/services/app.service';
import { AppHelper } from '@common/helpers';

@Injectable()
export class RestaurantResolve implements Resolve<Observable<any>> {

    constructor(
        private router: Router,
        private appService: AppService,
        private appHelper: AppHelper,
    ) { }

    resolve(): Observable<any> {
        if (this.appHelper.restaurants && this.appHelper.restaurants.length) {
            return this.appHelper.restaurants$.pipe(take(1));
        } else {
            return this.appService.getRestaurants().pipe(
                take(1),
                mergeMap(restaurants => {
                    if (restaurants && restaurants.length > 0) {
                        this.appHelper.setRestaurants(restaurants);
                        return of(restaurants);
                    } else {
                        return this.redirect();
                    }
                }),
                catchError(error => {
                    return this.redirect();
                })
            );
        }
    }

    redirect() {
        this.router.navigate(["new"]);
        return EMPTY;
    }
}