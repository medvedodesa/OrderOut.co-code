import { Injectable } from '@angular/core';
import { Resolve, Router, ActivatedRouteSnapshot } from '@angular/router';
import { EMPTY, Observable } from 'rxjs';
import { take, mergeMap, catchError, tap } from 'rxjs/operators';
import { AuthService } from '@auth0/auth0-angular';
import { AppService } from '@common/services/app.service';
import { AppHelper } from '@common/helpers';

@Injectable()
export class OnboardingResolve implements Resolve<Observable<any>> {

    constructor(
        private router: Router,
        private auth: AuthService,
        private appService: AppService,
        private appHelper: AppHelper,
    ) { }

    resolve(route: ActivatedRouteSnapshot): Observable<any> {
        return this.auth.isAuthenticated$.pipe(
            take(1),
            mergeMap(isLoggedIn => {
                if (isLoggedIn) {
                    if (this.appHelper.restaurants && this.appHelper.restaurants.length) {
                        return this.callback(route, this.appHelper.restaurants, false);
                    } else {
                        return this.appService.getRestaurants().pipe(
                            take(1),
                            mergeMap(restaurants => {
                                return this.callback(route, restaurants, true); // pass true to set restaurants inside the app helpers
                            }),
                            catchError(error => {
                                return this.redirect();
                            })
                        );
                    }
                } else {
                    return EMPTY;
                }
            })
        );
    }

    isRestaurantExist(restaurantId, restaurants) {
        return restaurants && restaurants.filter(restaurant => restaurant.id == restaurantId);
    }

    // setrestaurants callback param - Optional parameter (true/false) to set Restaurant/Restaurants. 
    // We set restaurants to helper if we get it from server.
    callback(route, restaurants, setrestaurants?) {
        const restaurant = this.isRestaurantExist(route.params.restaurantId, restaurants);
        if (restaurant && restaurant.length) {
            if (setrestaurants) {
                this.appHelper.setRestaurants(restaurants, true);
                this.appHelper.setRestaurant(restaurant[0]);
            }
            return restaurants;
        } else {
            return this.redirect();
        }
    }

    redirect() {
        this.router.navigate(["new"]);
        return EMPTY;
    }
}