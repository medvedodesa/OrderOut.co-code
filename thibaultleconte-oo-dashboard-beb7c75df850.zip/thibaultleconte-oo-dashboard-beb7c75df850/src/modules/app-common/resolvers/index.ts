import { AccountResolve } from './account.resolve';
import { RestaurantResolve } from './restaurant.resolve';
import { OnboardingResolve } from './onboarding.resolve';
import { UserResolve } from './user.resolve';

export const resolvers = [AccountResolve, RestaurantResolve, OnboardingResolve, UserResolve];

export * from './account.resolve';
export * from './restaurant.resolve';
export * from './onboarding.resolve';
export * from './user.resolve';