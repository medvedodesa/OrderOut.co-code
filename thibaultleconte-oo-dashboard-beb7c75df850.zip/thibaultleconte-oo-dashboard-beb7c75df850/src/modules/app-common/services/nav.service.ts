import { Injectable } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, NavigationError, NavigationCancel } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SpinnerService } from "@common/services/spinner.service";

@Injectable()
export class NavService {
    constructor(
        private router: Router,
        public modalService: NgbModal,
        private spinnerService: SpinnerService
    ) { }

    init() {
        this.router.events.subscribe(event => {
            if (event instanceof NavigationStart) {
                this.spinnerService.show();
            }
            if ((event instanceof NavigationEnd) || (event instanceof NavigationError) || (event instanceof NavigationCancel)) {
                this.scrollUp();
                this.spinnerService.hide();
                
                // close all open modals
                this.modalService.dismissAll();
            }
        })
    }

    scrollUp() {
        const element = document.querySelector('.main-wrapper');
        element && element.scrollIntoView({ behavior: 'smooth' });
    }
}

