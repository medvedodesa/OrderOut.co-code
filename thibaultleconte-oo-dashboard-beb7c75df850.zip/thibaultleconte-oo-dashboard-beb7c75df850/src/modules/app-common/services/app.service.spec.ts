import { TestBed } from '@angular/core/testing';

import { AppService } from './app.service';

describe('AppService', () => {
    let appService: AppService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [AppService],
        });
        appService = TestBed.get(AppService);
    });

    describe('getApp$', () => {
        it('should return Observable<{}}>', () => {
            appService.getApp$().subscribe(response => {
                expect(response).toEqual({});
            });
        });
    });
});
