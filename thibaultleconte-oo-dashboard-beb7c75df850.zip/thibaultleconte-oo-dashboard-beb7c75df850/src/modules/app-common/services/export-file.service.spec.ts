import { TestBed } from '@angular/core/testing';

import { ExportFileService } from './export-file.service';

describe('ExportFileService', () => {
    let exportFileService: ExportFileService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [ExportFileService],
        });
        exportFileService = TestBed.get(ExportFileService);
    });

    describe('getExportFile$', () => {
        it('should return Observable<{}}>', () => {
        });
    });
});
