import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DatePipe, DecimalPipe } from '@angular/common';
import { CopyToClipboard, CopyToClipboardOptions } from '@common/models';
import copyToClipboard from 'copy-to-clipboard';
import { Observable } from 'rxjs';
import { UTCFormatPipe } from '@common/pipes';

@Injectable()
export class UtilityService {
    _window: Window;
    parse: JSON['parse'];
    stringify: JSON['stringify'];
    localStorage: Storage;
    _copyToClipboard: CopyToClipboard;

    constructor(private http: HttpClient) {
        this._window = window;
        this.parse = JSON.parse;
        this.stringify = JSON.stringify;
        this.localStorage = localStorage;
        this._copyToClipboard = copyToClipboard;
    }

    get window(): Window {
        return this._window;
    }
    get version$(): Observable<string> {
        return this.http.get('/assets/version', { responseType: 'text' });
    }

    getStoredObject<T>(objectName: string): T | undefined {
        const objectString = this.localStorage.getItem(objectName);
        if (!objectString) {
            return undefined;
        }
        return this.parse(objectString) as T;
    }

    storeObject(objectName: string, objectToStore: {}): void {
        this.localStorage.setItem(objectName, this.stringify(objectToStore));
    }

    copyToClipboard(text: string, options?: CopyToClipboardOptions) {
        this._copyToClipboard(text, options);
    }

    pickBy(object) {
        const obj = {} as any;
        for (const key in object) {
            if (object[key]) {
                obj[key] = object[key];
            }
        }
        return obj;
    }

    openExternalURL(url: string) {
        let re = new RegExp("^(http|https)://", "i");
        if (!re.test(url)) {
            url = "http://" + url;
        }
        window.open(url, "_blank");
    }

    getFormatAmount(amount) {
        return new DecimalPipe('en-US').transform(amount, '1.2-2');
    }

    getFormatDate(date, dateFormat = 'short', convertUTC = true) {
        date = convertUTC ? new UTCFormatPipe().transform(date) : date;
        return new DatePipe('en-US').transform(date, dateFormat);
    }
}
