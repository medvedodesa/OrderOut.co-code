import { TestBed } from '@angular/core/testing';

import { ApiService } from './api.service';

describe('ApiService', () => {
    let apiService: ApiService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [ApiService],
        });
        apiService = TestBed.get(ApiService);
    });

    describe('getApi$', () => {
        it('should return Observable<{}}>', () => {
            apiService.getApi$().subscribe(response => {
                expect(response).toEqual({});
            });
        });
    });
});
