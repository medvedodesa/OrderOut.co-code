import { Injectable } from '@angular/core';
import { SelectedDateRange } from '@common/models';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap';
import {
    endOfDay,
    endOfMonth,
    endOfYear,
    startOfDay,
    startOfMonth,
    startOfYear,
    sub,
    format
} from 'date-fns';
import { BehaviorSubject, Subject } from 'rxjs';
import { distinctUntilChanged } from 'rxjs/operators';

@Injectable()
export class DateRangeService {
    _endDate$ = new Subject<Date | null>();
    _startDate$ = new Subject<Date | null>();
    _selectedDates$ = new Subject<any>();
    _selectedRange$ = new BehaviorSubject<SelectedDateRange>('CUSTOM');

    constructor() { }

    get endDate$() {
        return this._endDate$.pipe(distinctUntilChanged((a, b) => (a && a.getTime()) === (b && b.getTime())));
    }
    get startDate$() {
        return this._startDate$.pipe(distinctUntilChanged((a, b) => (a && a.getTime()) === (b && b.getTime())));
    }
    get selectedRange$() {
        return this._selectedRange$.pipe(distinctUntilChanged());
    }
    get selectedDates$() {
        return this._selectedDates$.pipe(distinctUntilChanged());
    }


    setCustom(fromDate: NgbDate, toDate: NgbDate) {
        const startDate = startOfDay(new Date(`${fromDate.month}/${fromDate.day}/${fromDate.year}`));
        const endDate = endOfDay(new Date(`${toDate.month}/${toDate.day}/${toDate.year}`));
        this._endDate$.next(endDate);
        this._startDate$.next(startDate);
        this.emitSelectedDates(startDate, endDate);
    }

    setRange(range: SelectedDateRange) {
        const today = new Date();
        let startDate;
        let endDate;
        switch (range) {
            case 'TODAY':
                startDate = startOfDay(today);
                endDate = endOfDay(today);
                break;
            case 'YESTERDAY':
                const subDay = this.subDay(1);
                startDate = startOfDay(subDay);
                endDate = endOfDay(subDay);
                break;
            case 'LAST_7_DAYS':
                startDate = startOfDay(this.subDay(6));
                endDate = endOfDay(today);
                break;
            case 'LAST_30_DAYS':
                startDate = startOfDay(this.subDay(29));
                endDate = endOfDay(today);
                break;
            case 'THIS_MONTH':
                startDate = startOfMonth(today);
                endDate = endOfMonth(today);
                break;
            case 'LAST_MONTH':
                const subMonth = this.subMonth(1);
                startDate = startOfMonth(subMonth);
                endDate = endOfMonth(subMonth);
                break;
            case 'THIS_YEAR':
                startDate = startOfYear(today);
                endDate = endOfYear(today);
                break;
            case 'LAST_YEAR':
                const subYear = this.subYear(1);
                startDate = startOfYear(subYear);
                endDate = endOfYear(subYear);
                break;
            case 'CUSTOM':
                break;
        }


        if (startDate) {
            this._startDate$.next(startDate);
        }
        if (endDate) {
            this._endDate$.next(endDate);
        }
        if (startDate && endDate) {
            this.emitSelectedDates(startDate, endDate);
        }
        this._selectedRange$.next(range);
    }

    reset() {
        const startDate = null;
        const endDate = null;
        this._startDate$.next(startDate);
        this._endDate$.next(endDate);
        this._selectedDates$.next({
            from: startDate,
            to: endDate,
        });
        this._selectedRange$.next('CUSTOM');
    }

    emitSelectedDates(startDate, endDate) {
        const formatStartDate = format(startDate, 'yyyy-MM-dd'); // YYYY-MM-DD Format
        const formatEndDate = format(endDate, 'yyyy-MM-dd'); // YYYY-MM-DD Format
        const fromUTCTime = this.getUTCTimeinSeconds(startDate);
        const toUTCTime = this.getUTCTimeinSeconds(endDate);
        this._selectedDates$.next({
            from: startDate,
            to: endDate,
            from_format: formatStartDate,
            to_format: formatEndDate,
            from_timestamp: fromUTCTime,
            to_timestamp: toUTCTime,
        });
    }

    subDay(day) {
        return sub(new Date(), {
            days: day,
        });
    }

    subMonth(month) {
        return sub(new Date(), {
            months: month,
        });
    }

    subYear(year) {
        return sub(new Date(), {
            years: year,
        });
    }

    getUTCTimeinSeconds(date) {
        const timeDiff = new Date().getTimezoneOffset() * 60;
        return Math.trunc(date.getTime() / 1000) - timeDiff;
    }
}
