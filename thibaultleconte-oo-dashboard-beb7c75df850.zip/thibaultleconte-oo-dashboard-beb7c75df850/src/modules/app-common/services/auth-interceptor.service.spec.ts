import { TestBed } from '@angular/core/testing';

import { AuthInterceptorService } from './auth-interceptor.service';

describe('AuthInterceptorService', () => {
    let authInterceptorService: AuthInterceptorService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [AuthInterceptorService],
        });
        authInterceptorService = TestBed.get(AuthInterceptorService);
    });

    describe('getAuthInterceptor$', () => {
        it('should return Observable<{}}>', () => {
            authInterceptorService.getAuthInterceptor$().subscribe(response => {
                expect(response).toEqual({});
            });
        });
    });
});
