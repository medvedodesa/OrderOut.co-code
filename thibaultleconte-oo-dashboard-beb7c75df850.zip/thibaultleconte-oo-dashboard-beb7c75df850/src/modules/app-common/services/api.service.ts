import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class ApiService {
    constructor(private http: HttpClient) { }

    /**
     * 
     * @param url request URL
     * @param options { params: params, headers: headers } - params and headers are optional fields.
     */
    get(url: string, params?: {}, headers?: {}): Observable<any> {
        const options = {
        params: params,
        headers: headers
        };
        return this.http.get<any>(url, options);
    }

    /**
     * 
     * @param url request URL
     * @param entity request parameters - optional field.
     * @param headerOptions request headers options - optional field.
     */
    put(url: string, entity?: {}, headerOptions?: {}): Observable<any> {
        return this.http.put<any>(url, entity, headerOptions);
    }

    /**
     * 
     * @param url request URL
     * @param entity request parameters
     * @param headerOptions request headers options - optional field.
     */
    post(url: string, entity: {}, headerOptions?: {}): Observable<any> {
        return this.http.post<any>(url, entity, headerOptions);
    }

    /**
     * 
     * @param url request URL
     */
    delete(url: string): Observable<any> {
        return this.http.delete<any>(url);
    }
}
