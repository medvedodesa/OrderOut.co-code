import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { ToastMessage, ToastMessageData, ToastMessageOptions } from '@common/models';
import { v4 as uuid } from 'uuid';

@Injectable()
export class ToastService {

    public toasts$ = new Subject<ToastMessage[]>();
    public defaultOptions = {
        autohide: true
    };

    constructor() { }

    toasts: ToastMessage[] = [];

    show(header: ToastMessageData, body: ToastMessageData, options: ToastMessageOptions) {
        options = { ...this.defaultOptions, ...options };
        this.toasts.push({ header, body, uuid: uuid(), options });
        this.toasts$.next(this.toasts);
    }

    remove(toastID: string) {
        this.toasts = this.toasts.filter(toast => toast.uuid !== toastID);
        this.toasts$.next(this.toasts);
    }

    showSuccess(params) {
        const header = params.header || 'Success!';
        const body = params.body;
        const successDefaultOptions = { headerClasses: 'bg-success text-white text-break', bodyClasses: 'text-success text-break', closeClasses: 'text-white' };
        this.show(header, body, { ...successDefaultOptions, ...params.options });
    }

    showError(params) {
        const header = params.header || 'Error!!!';
        const body = params.body;
        const errorDefaultOptions = { headerClasses: 'bg-danger text-white text-break', bodyClasses: 'text-danger text-break', closeClasses: 'text-white' };
        this.show(header, body, { ...errorDefaultOptions, ...params.options });
    }
}
