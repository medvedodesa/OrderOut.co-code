import { Injectable } from "@angular/core";
import { Observable } from 'rxjs';

import { ApiService } from "@common/services/api.service";
import { environment as env } from "environments/environment";
import { Account, Restaurant, User } from "@common/models";

@Injectable()
export class AppService {

  public accountUrl = env.front_api_url + "account";
  public restaurantUrl = env.front_api_url + "restaurant";
  public userUrl = env.front_api_url + "user";

  constructor(private api: ApiService) { }

  getAccount(): Observable<Account> {
    return this.api.get(this.accountUrl);
  }

  getRestaurants(): Observable<Restaurant[]> {
    return this.api.get(this.restaurantUrl);
  }

  getUser(): Observable<User> {
    return this.api.get(this.userUrl);
  }

}
