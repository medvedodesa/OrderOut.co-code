import { TestBed } from '@angular/core/testing';

import { SpinnerService } from './spinner.service';

describe('SpinnerService', () => {
    let spinnerService: SpinnerService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [SpinnerService],
        });
        spinnerService = TestBed.get(SpinnerService);
    });

    describe('getSpinner$', () => {
        it('should return Observable<{}}>', () => {
            spinnerService.getSpinner$().subscribe(response => {
                expect(response).toEqual({});
            });
        });
    });
});
