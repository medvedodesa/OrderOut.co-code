import { TestBed } from '@angular/core/testing';

import { DateRangeService } from './date-range.service';

describe('DateRangeService', () => {
    let dateRangeService: DateRangeService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [DateRangeService],
        });
        dateRangeService = TestBed.get(DateRangeService);
    });

    describe('getDateRange$', () => {
        it('should return Observable<{}}>', () => {
            dateRangeService.getDateRange$().subscribe(response => {
                expect(response).toEqual({});
            });
        });
    });
});
