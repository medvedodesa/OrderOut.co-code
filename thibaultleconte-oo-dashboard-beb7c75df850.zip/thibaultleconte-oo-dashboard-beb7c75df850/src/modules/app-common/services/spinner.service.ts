import { Injectable } from '@angular/core';

@Injectable()
export class SpinnerService {

    private body = document.querySelector('body')!;

    constructor() { }

    show() {
        this.body.classList.add('show-spinner');
    }

    hide() {
        this.body.classList.remove('show-spinner');
    }
}
