import { TestBed } from '@angular/core/testing';

import { NavService } from './nav.service';

describe('NavService', () => {
    let navService: NavService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [NavService],
        });
        navService = TestBed.get(NavService);
    });

    describe('getNav$', () => {
        it('should return Observable<{}}>', () => {
            navService.getNav$().subscribe(response => {
                expect(response).toEqual({});
            });
        });
    });
});
