import { MenuSync } from "./menuSync";

export interface PointOfSale {
  id: number;
  type: string;
  service_merchant_id: string;
  service_employee_id: string;
  menuSync: MenuSync;
  api_created_at: Date;
}
