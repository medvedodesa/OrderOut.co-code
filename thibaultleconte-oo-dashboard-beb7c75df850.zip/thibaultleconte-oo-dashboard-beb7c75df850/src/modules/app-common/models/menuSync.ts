export interface MenuSync {
  id: number;
  restaurant: number;
  service: number;
  fetch_menu_status: string;
  process_menu_status: string;
  map_total_menu_items: number;
  map_mapped_menu_items: number;
  map_unmapped_menu_items: number;
  map_total_menu_modifiers: number;
  map_mapped_menu_modifiers: number;
  map_unmapped_menu_modifiers: number;
}
