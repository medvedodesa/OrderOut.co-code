export class Account {
  api_created_at: string;
  id: number;
  name: string;
  ownerId: number;
}
