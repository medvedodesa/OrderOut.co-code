export interface Printer {
  id: number;
  jobStatusId: number;
  restaurant: number;
  status: number;
  mac: string;
  uuid: string;
  manufacturerName: string;
  manufacturerUUID: string;
  pairingSuccess: boolean;
  pairingSuccessCreatedAt: Date;
  api_created_at: Date;
}
