export interface CopyToClipboardOptions {
    debug?: boolean;
    message?: string;
    format?: string; // MIME type
}
export type CopyToClipboard = (text: string, options?: CopyToClipboardOptions) => boolean;

export type SelectedDateRange =
    | 'TODAY'
    | 'YESTERDAY'
    | 'LAST_7_DAYS'
    | 'LAST_30_DAYS'
    | 'THIS_MONTH'
    | 'LAST_MONTH'
    | 'THIS_YEAR'
    | 'LAST_YEAR'
    | 'CUSTOM';