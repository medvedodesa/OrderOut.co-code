export interface Restaurant {
  id: number;
  name: string;
  account?: Account;
  accountId?: number;
  account_name: string;
  pointOfSaleId: number | null;
  printDoubleOrder: boolean;
  pointOfSaleIntegrationEnabled?: boolean;
  preparation_time: number;
  api_created_at: string;
  selected?: boolean;
  // Billing Address
  street_address_1: string;
  street_address_2: string;
  street_address_3: string;
  address?: string;
  city: string;
  zipcode: string;
  state: string;
  country: string;
  phone_number: string;
}

export interface RestaurantsList {
  more: boolean;
  previousCursor: string;
  nextCursor: string;
  data: Restaurant[];
}

export interface User {
  id: number;
  firstname: string;
  lastname?: string;
  email: string;
  phone?: string;
  receives_notification: boolean;
  role: string;
  api_created_at: string;
  isOwner?: boolean;
}
