import { Injectable } from '@angular/core';
import {
  HttpEvent, HttpRequest, HttpHandler,
  HttpInterceptor, HttpErrorResponse
} from '@angular/common/http';
import { Observable, EMPTY } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

import { ErrorService, ToastService, SpinnerService } from '@common/services';

@Injectable()
export class ServerErrorInterceptor implements HttpInterceptor {

  constructor(
    private errorService: ErrorService,
    private toastService: ToastService,
    private spinnerService: SpinnerService
  ) {}

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    return next.handle(request).pipe(
      retry(1),
      catchError((error: HttpErrorResponse) => {
        let message = '';
        if (error.error instanceof ErrorEvent) {
          // client-side error
          message = `Error: ${error.error.message}`;
        } else {
          // server-side error
          message = this.errorService.getServerMessage(error);
        }
        this.openErrorDialog(error.status, message);
        return EMPTY;
      })
    );
  }

  openErrorDialog(status, message) {
    this.toastService.showError({
      header: status + ' Server Error!',
      body: message,
      options: {
          autohide: true
      }
    });
    this.spinnerService.hide(); // Hide the spinner
    console.error(message);
  }
}