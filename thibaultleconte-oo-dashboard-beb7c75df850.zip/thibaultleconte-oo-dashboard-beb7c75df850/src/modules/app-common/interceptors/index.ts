import { ServerErrorInterceptor } from './server-error.interceptor';

export const interceptors = [ServerErrorInterceptor];

export * from './server-error.interceptor';