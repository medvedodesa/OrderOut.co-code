/* tslint:disable: ordered-imports*/
import { NgModule, ModuleWithProviders, ErrorHandler } from '@angular/core';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

/* Modules */
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgSelectModule } from '@ng-select/ng-select';
import { IconsModule } from '@modules/icons/icons.module';

const modules = [IconsModule, NgbModule, NgSelectModule];

/* Containers */
import * as appCommonContainers from './containers';

/* Components */
import * as appCommonComponents from './components';

/* Directives */
import * as appCommonDirectives from './directives';

/* Guards */
import * as appCommonGuards from './guards';

/* Services */
import * as appCommonServices from './services';
import * as authServices from '@modules/auth/services';

/* Pipes */
import * as appCommonPipes from './pipes';

/* Interceptors */
import * as appCommonInterceptors from './interceptors';

/* Resolvers */
import * as appCommonResolvers from './resolvers';

/* Helpers */
import * as appHelpers from './helpers';

/* Global Error Handler */
import { GlobalErrorHandler } from './containers/error/global-error.handler';

@NgModule({
    imports: [CommonModule, RouterModule, FormsModule, ...modules],
    declarations: [
        ...appCommonContainers.containers,
        ...appCommonComponents.components,
        ...appCommonDirectives.directives,
        ...appCommonPipes.pipes,
    ],
    exports: [
        ...appCommonContainers.containers,
        ...appCommonComponents.components,
        ...appCommonDirectives.directives,
        ...appCommonPipes.pipes,
        ...modules,
    ],
})
export class AppCommonModule {
    static forRoot(): ModuleWithProviders<AppCommonModule> {
        return {
            ngModule: AppCommonModule,
            providers: [
                ...appCommonServices.services,
                ...authServices.services,
                ...appCommonGuards.guards,
                ...appCommonResolvers.resolvers,
                ...appHelpers.helpers,
                { provide: 'window', useValue: window },
                { provide: ErrorHandler, useClass: GlobalErrorHandler },
                { provide: HTTP_INTERCEPTORS, useClass: appCommonServices.AuthInterceptorService, multi: true },
                { provide: HTTP_INTERCEPTORS, useClass: appCommonInterceptors.ServerErrorInterceptor, multi: true },
            ],
        };
    }
}
