import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { distinctUntilChanged } from 'rxjs/operators';
import { Account, Restaurant, User } from '@common/models';

@Injectable()
export class AppHelper {
    private _account$ = new BehaviorSubject<Account>({} as any);
    private _restaurants$ = new BehaviorSubject<Restaurant[]>([] as any);
    private _currentRestaurant$ = new BehaviorSubject<Restaurant>({} as any);
    private _user$ = new BehaviorSubject<User>({} as any);

    public isMultiRestaurant: boolean;

    get account$(): Observable<Account> {
        return this._account$.pipe(distinctUntilChanged());
    }

    get account(): Account {
        return this._account$.value;
    }

    get restaurants$(): Observable<Restaurant[]> {
        return this._restaurants$.pipe(distinctUntilChanged());
    }

    get restaurants(): Restaurant[] {
        return this._restaurants$.value;
    }

    get currentRestaurant$() {
        return this._currentRestaurant$.pipe(distinctUntilChanged());
    }

    get currentRestaurant(): Restaurant {
        return this._currentRestaurant$.value;
    }

    get user$() {
        return this._user$.pipe(distinctUntilChanged());
    }

    get user(): User {
        return this._user$.value;
    }

    public setAccount(account: Account) {
        this._account$.next(account);
    }

    public setRestaurants(restaurants: Restaurant[], setManually?: boolean) {
        if (!setManually) {
            this._setRestaurant(restaurants);
        }
        this.isMultiRestaurant = restaurants && restaurants.length > 1 ? true : false;
        this._restaurants$.next(restaurants);
    }

    private _setRestaurant(restaurants: Restaurant[]) {
        let selectedRes = restaurants.filter(restaurant => {
            return restaurant.selected === true;
        });
        if (selectedRes && selectedRes.length > 0) {
            this.setRestaurant(selectedRes[0]);
        } else {
            this.setRestaurant(restaurants[0]);
        }
    }

    public setRestaurant(restaurant: Restaurant) {
        this._currentRestaurant$.next(restaurant);
    }

    public setUser(user: User) {
        this._user$.next(user);
    }

    public updateRestaurantInfo(restaurant: Restaurant) {
        let restaurants: any = this._restaurants$.value.map(obsRestaurant => {
            return obsRestaurant.id === restaurant.id ? restaurant : obsRestaurant;
        });
        this.setRestaurants(restaurants, true);
        this.setRestaurant(restaurant);
    }

}