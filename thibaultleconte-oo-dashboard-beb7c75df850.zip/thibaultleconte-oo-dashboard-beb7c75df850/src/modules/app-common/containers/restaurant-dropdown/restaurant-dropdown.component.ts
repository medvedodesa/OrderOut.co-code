import { Component, OnInit, OnDestroy, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { Restaurant } from '@common/models';
import { AppHelper } from '@common/helpers';

@Component({
    selector: 'sbpro-restaurant-dropdown',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './restaurant-dropdown.component.html',
    styleUrls: ['restaurant-dropdown.component.scss'],
})
export class RestaurantDropdownComponent implements OnInit, OnDestroy {

    public restaurant: Restaurant;
    public restaurants: Restaurant[];

    public subscriptions: Subscription = new Subscription();

    constructor(
        public route: Router,
        public activatedRoute: ActivatedRoute,
        private location: Location,
        public appHelper: AppHelper,
        private changeDetectorRef: ChangeDetectorRef
    ) { }

    ngOnInit() {
        this.subscriptions.add(this.appHelper.currentRestaurant$.subscribe(restaurant => {
            this.restaurant = restaurant;
            this.changeDetectorRef.markForCheck();
        }));

        this.subscriptions.add(this.appHelper.restaurants$.subscribe(restaurants => {
            this.restaurants = restaurants;
        }));
    }

    ngOnDestroy() {
        this.subscriptions.unsubscribe();
    }

    updateRestaurant(restaurant: Restaurant) {
        if (restaurant && restaurant.id) {
            this.appHelper.setRestaurant(restaurant);
            if (this.route.url.indexOf('onboarding') !== -1) {
                this.location.go(['restaurant', restaurant.id, 'onboarding'].join('/'));
                //this.route.navigate(['restaurant', restaurant.id, 'onboarding']);
            }
        }
    }
}
