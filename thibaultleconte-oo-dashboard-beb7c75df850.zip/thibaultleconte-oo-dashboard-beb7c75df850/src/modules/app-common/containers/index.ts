import { ToastViewComponent } from './toast-view/toast-view.component';
import { VersionComponent } from './version/version.component';
import { ErrorComponent } from './error/error.component';
import { RestaurantDropdownComponent } from './restaurant-dropdown/restaurant-dropdown.component';

export const containers = [VersionComponent, ToastViewComponent, ErrorComponent, RestaurantDropdownComponent];

export * from './version/version.component';
export * from './toast-view/toast-view.component';
export * from './error/error.component';
export * from './restaurant-dropdown/restaurant-dropdown.component';
