import { ErrorHandler, Injectable, Injector } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';

import { ErrorService } from '../../services/error.service';
import { ToastService, SpinnerService } from '@common/services';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {

    // Error handling is important and needs to be loaded first.
    // Because of this we should manually inject the services with Injector.
    constructor(private injector: Injector) { }

    handleError(error: Error | HttpErrorResponse) {

        const errorService = this.injector.get(ErrorService);
        const notifier = this.injector.get(ToastService);
        const spinner = this.injector.get(SpinnerService);

        let message;
        let stackTrace;

        if (error instanceof HttpErrorResponse) {
            // Server Error
            const status = error.status || 'Unknown'
            message = errorService.getServerMessage(error);
            stackTrace = errorService.getServerStack(error);
            notifier.showError({
                header: status + ' Server Error!',
                body: message,
                options: {
                    autohide: true
                }
            });
        } else {
            // Client Error
            message = errorService.getClientMessage(error);
            stackTrace = errorService.getClientStack(error);
            notifier.showError({
                header: 'Client Error!',
                body: message
            });
        }

        // Always log errors - we may use third party services like Sentry, Rollbar
        // logger.logError(message, stackTrace);

        spinner.hide(); // Hide the spinner
        console.error(error);
    }
}