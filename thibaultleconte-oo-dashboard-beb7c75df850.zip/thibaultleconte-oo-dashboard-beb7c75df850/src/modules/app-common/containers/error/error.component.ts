import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

@Component({
    selector: 'sbpro-error',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './error.component.html',
    styleUrls: ['error.component.scss'],
})
export class ErrorComponent implements OnInit {
    constructor() {}
    ngOnInit() {}
}
