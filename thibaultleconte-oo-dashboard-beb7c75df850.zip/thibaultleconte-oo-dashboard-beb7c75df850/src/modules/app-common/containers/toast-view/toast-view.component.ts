import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { ToastMessage } from '@common/models';
import { ToastService } from '@common/services/toast.service';

@Component({
    selector: 'sbpro-toast-view',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './toast-view.component.html',
    styleUrls: ['toast-view.component.scss'],
})
export class ToastViewComponent implements OnInit {

    public toasts: ToastMessage[] = [];

    constructor(
        public toastService: ToastService,
        private changeDetectorRef: ChangeDetectorRef
    ) { }

    ngOnInit() {
        this.toastService.toasts$.subscribe(toasts => {
            this.toasts = toasts;
            this.changeDetectorRef.detectChanges();
        });
    }
}
