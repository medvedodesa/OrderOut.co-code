import { UTCFormatPipe } from './utcformat.pipe';
import { MapPipe } from './map.pipe';

export const pipes = [UTCFormatPipe, MapPipe];

export * from './utcformat.pipe';
export * from './map.pipe';