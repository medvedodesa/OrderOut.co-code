import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'UTCFormat'
})
export class UTCFormatPipe implements PipeTransform {

  transform(value: unknown, ...args: unknown[]): unknown {
    if (!value) { return }
    return value + 'Z';
  }

}
