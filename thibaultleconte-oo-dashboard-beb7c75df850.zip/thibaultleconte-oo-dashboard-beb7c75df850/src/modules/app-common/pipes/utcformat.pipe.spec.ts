import { UTCFormatPipe } from './utcformat.pipe';

describe('UTCFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new UTCFormatPipe();
    expect(pipe).toBeTruthy();
  });
});
