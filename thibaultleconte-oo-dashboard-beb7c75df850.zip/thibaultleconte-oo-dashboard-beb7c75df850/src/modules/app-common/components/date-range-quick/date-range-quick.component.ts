import {
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    Component,
    Input,
    OnDestroy,
    OnInit,
    ViewChild,
    forwardRef,
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { SelectedDateRange } from '@common/models';
import { DateRangeService } from '@common/services';
import {
    NgbDate,
    NgbDateParserFormatter,
    Placement,
} from '@ng-bootstrap/ng-bootstrap';
import { combineLatest, Subscription } from 'rxjs';

import { DropdownComponent } from '../dropdown/dropdown.component';

@Component({
    selector: 'sbpro-date-range-quick',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './date-range-quick.component.html',
    styleUrls: ['date-range-quick.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => DateRangeQuickComponent),
            multi: true
        }
    ]
})
export class DateRangeQuickComponent implements OnInit, OnDestroy, ControlValueAccessor {
    @ViewChild('calendarDropdown') calendarDropdown!: DropdownComponent;
    @Input() placement: Placement = 'bottom-right';
    @Input() maxDate: Date = new Date();
    @Input() resetBtn: boolean = true;

    value;
    onChange: any = () => { }
    onTouch: any = () => { }

    today: Date = new Date();
    endDate!: Date | null;
    startDate!: Date | null;
    selectedRange!: SelectedDateRange;

    hoveredDate: NgbDate | null = null;
    fromDate!: NgbDate | null;
    toDate!: NgbDate | null;
    maximumDate: NgbDate;
    subscription: Subscription = new Subscription();

    showLabel: boolean = false;

    constructor(
        public dateRangeService: DateRangeService,
        private changeDetectorRef: ChangeDetectorRef,
        public formatter: NgbDateParserFormatter,
    ) {
        this.maximumDate = new NgbDate(
            this.maxDate.getFullYear(),
            this.maxDate.getMonth() + 1,
            this.maxDate.getDate()
        );
        this.fromDate = new NgbDate(
            this.today.getFullYear(),
            this.today.getMonth(),
            this.today.getDate()
        );
    }

    writeValue(value: SelectedDateRange) {
        if (value) {
            this.value = value;
            if (value !== 'CUSTOM') {
                this.setRange(value);
            }
        }
    }

    registerOnChange(fn: any) {
        this.onChange = fn
    }

    registerOnTouched(fn: any) {
        this.onTouch = fn
    }

    ngOnInit() {
        this.subscription.add(
            combineLatest([
                this.dateRangeService.endDate$,
                this.dateRangeService.startDate$,
                this.dateRangeService.selectedRange$,
            ]).subscribe(([endDate, startDate, selectedRange]) => {
                this.endDate = endDate;
                this.startDate = startDate;
                this.selectedRange = selectedRange;
                this.fromDate = startDate ? new NgbDate(
                    startDate.getFullYear(),
                    startDate.getMonth() + 1,
                    startDate.getDate()
                ) : null;
                this.toDate = endDate ? new NgbDate(
                    endDate.getFullYear(),
                    endDate.getMonth() + 1,
                    endDate.getDate()
                ) : null;
                this.changeDetectorRef.detectChanges();
            })
        );
        this.dateRangeService.selectedDates$.subscribe(selectedDate => {
            this.onValueChanges(selectedDate);
        });
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    setRange(range: SelectedDateRange) {
        this.value = range;
        this.dateRangeService.setRange(range);
    }
    onDateSelection(date: NgbDate) {
        if (!this.fromDate && !this.toDate) {
            this.fromDate = date;
        } else if (this.fromDate && !this.toDate && date && (date.equals(this.fromDate) || date.after(this.fromDate))) {
            this.toDate = date;
            this.dateRangeService.setCustom(this.fromDate, this.toDate);

            // Set value and range to CUSTOM
            this.value = this.selectedRange = 'CUSTOM';
            this.changeDetectorRef.detectChanges();

            this.calendarDropdown.close();
        } else {
            this.toDate = null;
            this.fromDate = date;
        }
    }
    reset() {
        this.dateRangeService.reset();
        this.calendarDropdown.close();
    }
    cancel() {
        this.calendarDropdown.close();
    }
    isHovered(date: NgbDate) {
        return (
            this.fromDate &&
            !this.toDate &&
            this.hoveredDate &&
            date.after(this.fromDate) &&
            date.before(this.hoveredDate)
        );
    }
    isInside(date: NgbDate) {
        return this.toDate && date.after(this.fromDate as any) && date.before(this.toDate);
    }
    isRange(date: NgbDate) {
        return (
            date.equals(this.fromDate as any) ||
            (this.toDate && date.equals(this.toDate)) ||
            this.isInside(date) ||
            this.isHovered(date)
        );
    }
    onValueChanges(selectedDate) {
        selectedDate = selectedDate.from && selectedDate.to ? selectedDate : '';
        this.onChange(selectedDate);
    }
    getDisplayValue(value: SelectedDateRange) {
        return value.replace(/_/g, " ");
    }
}
