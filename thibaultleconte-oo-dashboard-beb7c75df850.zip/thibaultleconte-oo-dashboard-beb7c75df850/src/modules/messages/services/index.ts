import { MessagesService } from './messages.service';

export const services = [MessagesService];

export * from './messages.service';
