import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';
import { UserService } from '@modules/auth/services';
import { AppHelper } from '@common/helpers';

@Component({
    selector: 'sbpro-top-nav-user',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './top-nav-user.component.html',
    styleUrls: ['top-nav-user.component.scss'],
})
export class TopNavUserComponent implements OnInit {

    @Input() placement = 'bottom-right';
    dropdownClasses: string[] = [];

    constructor(
        public userService: UserService,
        public appHelper: AppHelper
    ) { }

    ngOnInit() { }
}
