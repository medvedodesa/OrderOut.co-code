import {
    ChangeDetectionStrategy,
    ChangeDetectorRef,
    Component,
    HostBinding,
    Input,
    OnDestroy,
    OnInit,
} from '@angular/core';
import { Intercom } from "ng-intercom";
import { Subscription } from 'rxjs';
import { take } from 'rxjs/operators';

import { environment as env } from "environments/environment";
import { NavigationService } from '@modules/navigation/services';
import { UserService } from '@modules/auth/services';
import { UtilityService } from '@common/services';
import { AppHelper } from '@common/helpers';
import { sideNavItems, sideNavSections } from '@modules/navigation/data/side-nav-dashboard.data';
import { sideNavItemsOld, sideNavSectionsOld } from '@modules/navigation/data/side-nav-dashboard-old.data';
import { Restaurant } from '@common/models';


@Component({
    selector: 'sbpro-layout-dashboard',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './layout-dashboard.component.html',
    styleUrls: ['layout-dashboard.component.scss'],
})
export class LayoutDashboardComponent implements OnInit, OnDestroy {
    @Input() static = false;
    @Input() light = false;
    @Input() rtl = false;
    @Input() oldSideNav = false;
    @Input() hideNavbar = true;
    @HostBinding('class.sidenav-toggled') sideNavHidden = false;
    subscription: Subscription = new Subscription();
    sideNavItems = sideNavItems;
    sideNavSections = sideNavSections;
    sidenavStyle = 'sidenav-dark';
    currentRestaurant: Restaurant;

    constructor(
        public intercom: Intercom,
        public utilityService: UtilityService,
        public navigationService: NavigationService,
        private changeDetectorRef: ChangeDetectorRef,
        public userService: UserService,
        private appHelper: AppHelper,
    ) { }
    ngOnInit() {
        if (this.light) {
            this.sidenavStyle = 'sidenav-light';
        }
        if (this.oldSideNav) {
            this.sideNavItems = sideNavItemsOld;
            this.sideNavSections = sideNavSectionsOld;
        } else {
            this.sidenavStyle = this.sidenavStyle + ' new-sidenav';
        }
        this.subscription.add(
            this.navigationService.sideNavVisible$().subscribe(isVisible => {
                this.sideNavHidden = !isVisible;
                this.changeDetectorRef.markForCheck();
            })
        );
        this.updateSlideNavLink(this.sideNavItems);
        this.launchIntercom();
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

    closeSideNavIfOpen() {
        const BOOTSTRAP_LG_WIDTH = 992;
        if (this.utilityService.window.innerWidth >= 992) {
            return;
        }
        // After the lg breakpoint, hidden is actually visible.
        // So the toggleSideNav below only will fire if the screen is < 992px
        // and the sideNav is open.
        if (this.sideNavHidden) {
            this.navigationService.toggleSideNav(true);
        }
    }

    updateSlideNavLink(sideNavItems) {
        this.appHelper.currentRestaurant$.subscribe(currentRestaurant => {
            if (currentRestaurant && currentRestaurant.id) {
                this.currentRestaurant = currentRestaurant;

                // Updating onboarding link
                if (sideNavItems && sideNavItems.onboarding && sideNavItems.onboarding.linkq) {
                    sideNavItems.onboarding.link = sideNavItems.onboarding.linkq.replace(':restaurantId', currentRestaurant.id);
                }

                // Updating intercom information
                const userdata = this.getIntercomUserData(currentRestaurant);
                this.intercom.update(userdata);
            }
        });
    }

    launchIntercom() {
        this.userService.user$.subscribe(user => {
            if (user && user.email) {
                this.appHelper.currentRestaurant$.pipe(take(2)).subscribe(currentRestaurant => {
                    if (currentRestaurant && currentRestaurant.id) {
                        setTimeout(() => {
                            const userdata = this.getIntercomUserData(currentRestaurant);
                            const bootInput = Object.assign({}, {
                                app_id: env.INTERCOM_APP_ID,
                                email: user.email,
                            }, userdata);
                            this.intercom.boot(bootInput);
                        }, 1000);
                    }
                });
            }
        });
    }

    getIntercomUserData(currentRestaurant: Restaurant) {
        return {
            "account_id": currentRestaurant.accountId,
            "restaurant_id": currentRestaurant.id,
            "restaurant_name": currentRestaurant.name
        }
    }
}
