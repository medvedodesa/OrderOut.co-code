import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';
import { NavigationService } from '@modules/navigation/services';
import { Observable } from 'rxjs';
import { AppHelper } from '@common/helpers';

@Component({
    selector: 'sb-top-nav',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './top-nav.component.html',
    styleUrls: ['top-nav.component.scss'],
})
export class TopNavComponent implements OnInit {
    @Input() rtl = false;
    @Input() user$: Observable<any>;
    @Input() islink = true;
    @Input() ismenu = true;
    constructor(private navigationService: NavigationService, public appHelper: AppHelper) { }
    ngOnInit() { }
    toggleSideNav() {
        this.navigationService.toggleSideNav();
    }
}
