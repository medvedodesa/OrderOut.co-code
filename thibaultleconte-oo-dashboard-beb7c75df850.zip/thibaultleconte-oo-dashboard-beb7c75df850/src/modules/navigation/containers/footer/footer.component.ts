import { ChangeDetectionStrategy, Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { UtilityService } from "@common/services";

@Component({
    selector: 'sb-footer',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './footer.component.html',
    styleUrls: ['footer.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class FooterComponent implements OnInit {
    public ppUrl = "https://www.orderout.co/privacy-policy";
    public tcUrl = "https://www.orderout.co/terms-and-conditions";

    @Input() dark = false;

    constructor(public utilityService: UtilityService,) { }

    ngOnInit() { }
}
