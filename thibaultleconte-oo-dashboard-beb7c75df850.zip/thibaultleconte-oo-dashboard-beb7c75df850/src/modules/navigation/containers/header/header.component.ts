import { ChangeDetectionStrategy, Component, OnInit, Input, ContentChild, TemplateRef } from '@angular/core';
import { AppHelper } from '@common/helpers';

@Component({
    selector: 'sbpro-header',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './header.component.html',
    styleUrls: ['header.component.scss'],
})
export class HeaderComponent implements OnInit {
    @Input() title: string = "Dashboard";
    @ContentChild('rightColumn') rightColumnRef: TemplateRef<any>;
    constructor(public appHelper: AppHelper) { }
    ngOnInit() { }
}
