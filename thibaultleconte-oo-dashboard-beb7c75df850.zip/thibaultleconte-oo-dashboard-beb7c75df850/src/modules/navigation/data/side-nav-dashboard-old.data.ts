import { SideNavItems, SideNavSection } from '@modules/navigation/models';

export const sideNavSectionsOld: SideNavSection[] = [
    {
        text: 'CORE',
        items: ['dashboards'],
    },
    {
        text: 'INTERFACE',
        items: ['layout', 'components', 'utilities', 'pages', 'flows'],
    },
    {
        text: 'ADDONS',
        items: ['charts', 'tables'],
    },
];

export const sideNavItemsOld: SideNavItems = {
    charts: {
        icon: 'bar-chart',
        link: '/charts',
        text: 'Charts',
    },
    components: {
        icon: 'package',
        submenu: [
            {
                link: '/dashboard-old/components/alerts',
                text: 'Alerts',
            },
            {
                link: '/dashboard-old/components/avatars',
                text: 'Avatars',
                new: true,
            },
            {
                link: '/dashboard-old/components/badges',
                text: 'Badges',
            },
            {
                link: '/dashboard-old/components/buttons',
                text: 'Buttons',
            },
            {
                link: '/dashboard-old/components/cards',
                text: 'Cards',
            },
            {
                link: '/dashboard-old/components/dropdowns',
                text: 'Dropdowns',
            },
            {
                link: '/dashboard-old/components/forms',
                text: 'Forms',
            },
            {
                link: '/dashboard-old/components/modal',
                text: 'Modal',
            },
            {
                link: '/dashboard-old/components/navigation',
                text: 'Navigation',
            },
            {
                link: '/dashboard-old/components/progress',
                text: 'Progress',
            },
            {
                link: '/dashboard-old/components/toasts',
                text: 'Toasts',
            },
            {
                link: '/dashboard-old/components/tooltips',
                text: 'Tooltips',
            },
        ],
        text: 'Components',
    },
    dashboards: {
        icon: 'activity',
        submenu: [
            {
                link: '/dashboard-old',
                text: 'Default',
            },
            {
                link: '/dashboard-old/multipurpose',
                text: 'Multipurpose',
                new: true,
            },
            {
                link: '/dashboard-old/affiliate',
                text: 'Affiliate',
                new: true,
            },
        ],
        text: 'Dashboards',
    },
    flows: {
        icon: 'repeat',
        submenu: [
            {
                link: '/auth/multi-tenant-select',
                text: 'Multi-Tenant Registration',
            },
        ],
        text: 'Flows',
    },
    layout: {
        icon: 'layout',
        submenu: [
            {
                link: '/dashboard-old/static',
                text: 'Static Navigation',
            },
            {
                link: '/dashboard-old/dark',
                text: 'Dark Sidenav',
            },
            {
                link: '/dashboard-old/rtl',
                text: 'RTL Layout',
            },
            {
                text: 'Page Headers',
                submenu: [
                    {
                        link: '/dashboard-old/page-headers/simplified',
                        text: 'Simplified',
                    },
                    {
                        link: '/dashboard-old/page-headers/content-overlap',
                        text: 'Content Overlap',
                    },
                    {
                        link: '/dashboard-old/page-headers/breadcrumbs',
                        text: 'Breadcrumbs',
                    },
                    {
                        link: '/dashboard-old/page-headers/light',
                        text: 'Light',
                    },
                ],
            },
        ],
        text: 'Layout',
    },
    pages: {
        icon: 'book-open',
        submenu: [
            {
                submenu: [
                    {
                        submenu: [
                            {
                                link: '/auth/login',
                                text: 'Login',
                            },
                            {
                                link: '/auth/register',
                                text: 'Register',
                            },
                            {
                                link: '/auth/forgot-password',
                                text: 'Forgot Password',
                            },
                        ],
                        text: 'Basic',
                    },
                    {
                        submenu: [
                            {
                                link: '/auth/login-social',
                                text: 'Login',
                            },
                            {
                                link: '/auth/register-social',
                                text: 'Register',
                            },
                            {
                                link: '/auth/forgot-password-social',
                                text: 'Forgot Password',
                            },
                        ],
                        text: 'Social',
                    },
                ],
                text: 'Authentication',
            },
            {
                link: '/dashboard-old/pages/blank',
                text: 'Blank',
            },
            {
                submenu: [
                    {
                        link: '/error/401',
                        text: '401 Page',
                    },
                    {
                        link: '/error/404',
                        text: '404 Page',
                    },
                    {
                        link: '/error/404-glitch',
                        text: '404 Page (Glitch Effect)',
                    },
                    {
                        link: '/error/500',
                        text: '500 Page',
                    },
                ],
                text: 'Error',
            },
        ],
        text: 'Pages',
    },
    tables: {
        icon: 'filter',
        link: '/tables',
        text: 'Tables',
    },
    utilities: {
        icon: 'tool',
        submenu: [
            {
                link: '/dashboard-old/utilities/animations',
                text: 'Animations',
            },
            {
                link: '/dashboard-old/utilities/background',
                text: 'Background',
                new: true,
            },
            {
                link: '/dashboard-old/utilities/borders',
                text: 'Borders',
            },
            {
                link: '/dashboard-old/utilities/lift',
                text: 'Lift',
                new: true,
            },
            {
                link: '/dashboard-old/utilities/shadows',
                text: 'Shadows',
            },
            {
                link: '/dashboard-old/utilities/typography',
                text: 'Typography',
            },
        ],
        text: 'Utilities',
    },
};
