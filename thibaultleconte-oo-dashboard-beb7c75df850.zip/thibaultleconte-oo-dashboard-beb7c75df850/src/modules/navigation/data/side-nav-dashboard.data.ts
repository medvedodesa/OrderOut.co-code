import { SideNavItems, SideNavSection } from '@modules/navigation/models';

export const sideNavSections: SideNavSection[] = [
    {
        text: 'CORE',
        items: ['dashboard'],
    },
    {
        text: 'ORDERS',
        items: ['orders'],
    },
    {
        text: 'ONBOARDING',
        items: ['onboarding'],
    },
    {
        text: 'SETTINGS',
        items: ['settings'],
    },
    {
        text: 'LOGOUT',
        items: ['logout'],
    },
];

export const sideNavItems: SideNavItems = {
    dashboard: {
        icon: 'activity',
        link: '/dashboard',
        text: 'Reporting',
    },
    orders: {
        icon: 'file-text',
        link: '/orders',
        text: 'Orders',
    },
    onboarding: {
        icon: 'link-2',
        linkq: '/restaurant/:restaurantId/onboarding',
        text: 'Integrations',
    },
    settings: {
        icon: 'settings',
        link: '/settings',
        text: 'Settings',
    },
    logout: {
        icon: 'log-out',
        link: 'logout',
        text: 'Logout',
    },
};
