/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SBRouteData } from '@modules/navigation/models';

/* Module */
import { SettingsModule } from './settings.module';

/* Containers */
import * as settingsContainers from './containers';

/* Guards */
import * as settingsGuards from './guards';

/* Routes */
export const ROUTES: Routes = [
    {
        path: '',
        canActivate: [],
        component: settingsContainers.SettingsComponent,
        children: [
            {
                path: '',
                data: {
                    title: 'Dashboard - Account Admin',
                    breadcrumbs: [
                        {
                            text: 'Account Admin',
                            active: true,
                        },
                    ],
                } as SBRouteData,
                component: settingsContainers.SettingsViewComponent,
            }
        ],
    },
];

@NgModule({
    imports: [SettingsModule, RouterModule.forChild(ROUTES)],
    exports: [RouterModule],
})
export class SettingsRoutingModule {}
