/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgBootstrapFormValidationModule } from 'ng-bootstrap-form-validation';

/* Modules */
import { AppCommonModule } from '@common/app-common.module';
import { NavigationModule } from '@modules/navigation/navigation.module';

/* Components */
import * as settingsComponents from './components';

/* Containers */
import * as settingsContainers from './containers';

/* Guards */
import * as settingsGuards from './guards';

/* Services */
import * as settingsServices from './services';

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        ReactiveFormsModule,
        FormsModule,
        HttpClientModule,
        AppCommonModule,
        NavigationModule,
        NgBootstrapFormValidationModule,
    ],
    providers: [...settingsServices.services, ...settingsGuards.guards],
    declarations: [...settingsContainers.containers, ...settingsComponents.components],
    exports: [...settingsContainers.containers, ...settingsComponents.components],
})
export class SettingsModule {}
