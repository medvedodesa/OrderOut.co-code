import { SettingsGuard } from './settings.guard';

export const guards = [SettingsGuard];

export * from './settings.guard';
