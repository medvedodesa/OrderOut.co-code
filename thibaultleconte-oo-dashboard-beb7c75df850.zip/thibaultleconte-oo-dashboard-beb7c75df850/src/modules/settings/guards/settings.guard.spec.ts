import { TestBed } from '@angular/core/testing';

import { SettingsGuard } from './settings.guard';

describe('_Template Module Guards', () => {
    let settingsGuard: SettingsGuard;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [],
            providers: [SettingsGuard],
        });
        settingsGuard = TestBed.get(SettingsGuard);
    });

    describe('canActivate', () => {
        it('should return an Observable<boolean>', () => {
            settingsGuard.canActivate().subscribe(response => {
                expect(response).toEqual(true);
            });
        });
    });

});
