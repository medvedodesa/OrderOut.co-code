import { TestBed } from '@angular/core/testing';

import { SettingsService } from './settings.service';

describe('SettingsService', () => {
    let settingsService: SettingsService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [SettingsService],
        });
        settingsService = TestBed.get(SettingsService);
    });

    describe('getSettings$', () => {
        it('should return Observable<Settings>', () => {
            settingsService.getSettings$().subscribe(response => {
                expect(response).toEqual({});
            });
        });
    });
});
