import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

import { ApiService } from "@common/services/api.service";
import { environment as env } from "environments/environment";
import { Restaurant, User } from '@common/models';

@Injectable()
export class SettingsService {
    public restaurantUrl = env.front_api_url + "restaurant";

    constructor(private api: ApiService) { }

    updateUser(restaurantId: number, user: User): Observable<User> {
        const url = `${this.restaurantUrl}/${restaurantId}/user/${user.id}`;
        const payload = {
            "firstname": user.firstname,
            "lastname": user.lastname,
            "email": user.email,
            "phone": user.phone,
        }
        return this.api.put(url, payload);
    }

    updateBillingAddress(restaurant: Restaurant): Observable<Restaurant> {
        const url = `${this.restaurantUrl}/${restaurant.id}`;
        const payload = {
            "street_address_1": restaurant.street_address_1,
            "street_address_2": restaurant.street_address_2,
            "street_address_3": restaurant.street_address_3,
            "city": restaurant.city,
            "state": restaurant.state,
            "country": restaurant.country,
            "zipcode": restaurant.zipcode,
        }
        return this.api.put(url, payload);
        return of({} as any);
    }
}
