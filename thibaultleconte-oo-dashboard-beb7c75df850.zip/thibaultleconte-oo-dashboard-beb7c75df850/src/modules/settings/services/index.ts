import { SettingsService } from './settings.service';

export const services = [SettingsService];

export * from './settings.service';
