import { ChangeDetectionStrategy, Component, OnInit, EventEmitter } from '@angular/core';
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";
import { CreditCardValidators } from 'angular-cc-library';

@Component({
    selector: 'sbpro-settings-credit-card',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './settings-credit-card.component.html',
    styleUrls: ['settings-credit-card.component.scss'],
})
export class SettingsCreditCardComponent implements OnInit {

    public ccFormGroup: FormGroup;
    public event: EventEmitter<any> = new EventEmitter();
    public ccDetails;

    constructor(
        public modal: NgbActiveModal
    ) { }

    ngOnInit() {
        this.buildForm();
    }

    buildForm() {
        const nonWhitespaceRegExp: RegExp = new RegExp("\\S");

        this.ccFormGroup = new FormGroup({
            creditCard: new FormControl(this.ccDetails.ccnumber, [CreditCardValidators.validateCCNumber]),
            expirationDate: new FormControl(this.ccDetails.expirationDate, [CreditCardValidators.validateExpDate]),
            cvv: new FormControl(this.ccDetails.cvv, [Validators.minLength(3), Validators.maxLength(4)]),
        });
    }

    onSubmit() {
        console.log(this.ccFormGroup);
    }
}
