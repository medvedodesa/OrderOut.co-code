import { Component, OnInit, OnDestroy } from '@angular/core';

import { Account, Restaurant, DeliveryService, PointOfSale, Printer } from '@common/models';

import { OnboardingService } from '@modules/onboarding/services';
import { SpinnerService } from "@common/services";
import { AppHelper } from '@common/helpers';
import { Subscription } from 'rxjs';

@Component({
    selector: 'sbpro-settings-restaurant',
    templateUrl: './settings-restaurant.component.html',
    styleUrls: ['settings-restaurant.component.scss'],
    providers: [OnboardingService]
})
export class SettingsRestaurantComponent implements OnInit, OnDestroy {

    public restaurants: Restaurant[];
    public account: Account;
    public restaurant: Restaurant;
    public deliveryServices: DeliveryService[];
    public pointOfSale: PointOfSale;
    public printers: Printer[];

    public subscriptions: Subscription = new Subscription();

    constructor(
        private spinnerService: SpinnerService,
        public onboardingService: OnboardingService,
        public appHelper: AppHelper
    ) { }

    ngOnInit() {
        this.subscriptions.add(this.appHelper.currentRestaurant$.subscribe(restaurant => {
            this.restaurant = restaurant;
            this.getRestaurantStatus(restaurant);
        }));
    }

    ngOnDestroy() {
        this.subscriptions.unsubscribe();
    }

    private getRestaurantStatus(restaurant: Restaurant) {
        this.spinnerService.show();
        this.subscriptions.add(this.onboardingService.getRestaurantStatus(restaurant.id).subscribe({
            next: (res) => {
                this.spinnerService.hide();
                let restaurant_status = res.restaurant_status;
                this.account = restaurant_status.account;
                this.pointOfSale = restaurant_status.pos_connected;
                this.deliveryServices = restaurant_status.ds_connected || [];
                this.printers = restaurant_status.printer_connected;
            },
            complete: () => {
                this.spinnerService.hide();
            },
        }));
    }

}
