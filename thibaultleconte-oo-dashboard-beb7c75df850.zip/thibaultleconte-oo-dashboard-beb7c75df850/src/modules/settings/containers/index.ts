import { SettingsComponent } from './settings/settings.component';
import { SettingsViewComponent } from './settings-view/settings-view.component';
import { SettingsAccountComponent } from './settings-account/settings-account.component';
import { SettingsBillingComponent } from './settings-billing/settings-billing.component';
import { SettingsCreditCardComponent } from './settings-credit-card/settings-credit-card.component';
import { SettingsRestaurantComponent } from './settings-restaurant/settings-restaurant.component';

export const containers = [SettingsComponent, SettingsViewComponent, SettingsAccountComponent, SettingsBillingComponent, SettingsCreditCardComponent, SettingsRestaurantComponent];

export * from './settings/settings.component';
export * from './settings-view/settings-view.component';
export * from './settings-account/settings-account.component';
export * from './settings-billing/settings-billing.component';
export * from './settings-credit-card/settings-credit-card.component';
export * from './settings-restaurant/settings-restaurant.component';
