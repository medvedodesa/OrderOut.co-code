import { ChangeDetectionStrategy, Component, OnInit, EventEmitter } from '@angular/core';
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";

import { Restaurant } from '@common/models';
import { AppHelper } from "@common/helpers";
import { SettingsService } from '../../services/settings.service';
import { SpinnerService, ToastService } from "@common/services";

@Component({
    selector: 'sbpro-settings-billing',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './settings-billing.component.html',
    styleUrls: ['settings-billing.component.scss'],
})
export class SettingsBillingComponent implements OnInit {

    public billingFormGroup: FormGroup;
    public event: EventEmitter<any> = new EventEmitter();
    public billingAddress: Restaurant;

    constructor(
        public modal: NgbActiveModal,
        public appHelper: AppHelper,
        private settingsService: SettingsService,
        private spinnerService: SpinnerService,
        private toastService: ToastService,
    ) { }

    ngOnInit() {
        this.buildForm();
    }

    buildForm() {
        const nonWhitespaceRegExp: RegExp = new RegExp("\\S");
        const cscRegExp: RegExp = new RegExp(/^[A-Za-z]+$/im);
        const aValidators = [Validators.pattern(cscRegExp), Validators.minLength(2), Validators.maxLength(15)];
        const zipRegExp: RegExp = new RegExp(/^\d{5}(?:[-\s]\d{4})?|[A-Z]\d[A-Z]\d[A-Z]\d$/im);

        this.billingFormGroup = new FormGroup({
            street_address_1: new FormControl(this.billingAddress.street_address_1, [Validators.pattern(nonWhitespaceRegExp)]),
            street_address_2: new FormControl(this.billingAddress.street_address_2, [Validators.pattern(nonWhitespaceRegExp)]),
            street_address_3: new FormControl(this.billingAddress.street_address_3, [Validators.pattern(nonWhitespaceRegExp)]),
            city: new FormControl(this.billingAddress.city, aValidators),
            state: new FormControl(this.billingAddress.state, aValidators),
            country: new FormControl(this.billingAddress.country, aValidators),
            zipcode: new FormControl(this.billingAddress.zipcode, [Validators.pattern(zipRegExp)]),
        });
    }

    onSubmit() {
        if (this.billingFormGroup && this.billingFormGroup.value && this.billingFormGroup.dirty) {
            this.modal.close();
            this.spinnerService.show();
            const params = Object.assign({}, this.appHelper.currentRestaurant, this.billingFormGroup.value);
            this.settingsService.updateBillingAddress(params)
                .subscribe((restaurant) => {
                    this.spinnerService.hide();
                    if (restaurant && restaurant.id) {
                        this.appHelper.updateRestaurantInfo(restaurant);
                        this.toastService.showSuccess({
                            header: 'Billing Information',
                            body: 'Your Billing information updated successfully.'
                        });
                    } else {
                        this.toastService.showError({
                            body: 'Something went wrong!',
                        });
                    }
                });
        }
    }
}
