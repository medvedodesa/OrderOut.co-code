import { Component, OnInit } from '@angular/core';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";

import { AppHelper } from '@common/helpers';
import { Restaurant, User } from '@common/models';

import { SettingsAccountComponent } from '../settings-account/settings-account.component';
import { SettingsBillingComponent } from '../settings-billing/settings-billing.component';
// import { SettingsCreditCardComponent } from '../settings-credit-card/settings-credit-card.component';

@Component({
    selector: 'sbpro-settings-view',
    templateUrl: './settings-view.component.html',
    styleUrls: ['settings-view.component.scss'],
})
export class SettingsViewComponent implements OnInit {

    public user: User;
    public restaurant: Restaurant;
    public modalOptions = {
        centered: true,
        scrollable: true
    };
    public isBillingUpdatable: boolean;

    constructor(
        private modalService: NgbModal,
        public appHelper: AppHelper
    ) { }

    ngOnInit() {
        this.appHelper.user$.subscribe(user => {
            if (user && user.id) {
                this.user = user;
                if (user && user.role) {
                    const roles = ['owner', 'manager', 'admin'];
                    this.isBillingUpdatable = roles.some(role => role === user.role.toLowerCase()) ? true : false;
                }
            }
        });
        this.appHelper.currentRestaurant$.subscribe(restaurant => {
            if (restaurant && restaurant.id) {
                this.restaurant = restaurant;

                this.restaurant.address = this.getAddress(restaurant);
            }
        });
    }

    updateAccountDetails() {
        const modalRef = this.modalService.open(
            SettingsAccountComponent,
            this.modalOptions
        );
        modalRef.componentInstance.user = this.user;
    }

    updateBillingAddress() {
        const billingModalOptions = Object.assign({}, this.modalOptions, {
            size: 'lg'
        })
        const modalRef = this.modalService.open(
            SettingsBillingComponent,
            billingModalOptions
        );
        modalRef.componentInstance.billingAddress = this.restaurant;
    }

    getAddress(restaurant) {
        let address = '';
        if (restaurant.street_address_1) {
            address += restaurant.street_address_1 + ' ';
        }
        if (restaurant.street_address_1) {
            address += restaurant.street_address_2 + ' ';
        }
        address += restaurant.street_address_3;
        return address;
    }

    // updateCCDetails() {
    //     const modalRef = this.modalService.open(
    //         SettingsCreditCardComponent,
    //         this.modalOptions
    //     );
    //     modalRef.componentInstance.ccDetails = cc_details;
    // }
}
