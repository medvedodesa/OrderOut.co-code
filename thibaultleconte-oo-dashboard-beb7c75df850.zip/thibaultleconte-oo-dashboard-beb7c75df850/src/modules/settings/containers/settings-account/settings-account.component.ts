import { ChangeDetectionStrategy, Component, OnInit, EventEmitter } from '@angular/core';
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { NgbActiveModal } from "@ng-bootstrap/ng-bootstrap";

import { User } from '@common/models';
import { AppHelper } from "@common/helpers";
import { SettingsService } from '../../services/settings.service';
import { SpinnerService, ToastService } from "@common/services";

@Component({
    selector: 'sbpro-settings-account',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './settings-account.component.html',
    styleUrls: ['settings-account.component.scss'],
})
export class SettingsAccountComponent implements OnInit {

    public accountFormGroup: FormGroup;
    public event: EventEmitter<any> = new EventEmitter();
    public user: User;

    constructor(
        public modal: NgbActiveModal,
        public appHelper: AppHelper,
        private settingsService: SettingsService,
        private spinnerService: SpinnerService,
        private toastService: ToastService,
    ) { }

    ngOnInit() {
        this.buildForm();
    }

    buildForm() {
        const nameRegExp: RegExp = new RegExp(/^(?!\s)([a-z ,.'-]+)$/im);
        const aValidators = [Validators.pattern(nameRegExp), Validators.minLength(2), Validators.maxLength(20)];
        const phoneNumberRegExp: RegExp = new RegExp(/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im);

        this.accountFormGroup = new FormGroup({
            firstname: new FormControl(this.user.firstname, aValidators),
            lastname: new FormControl(this.user.lastname, aValidators),
            phone: new FormControl(this.user.phone, [Validators.pattern(phoneNumberRegExp)]),
        });
    }

    onSubmit() {
        if (this.accountFormGroup && this.accountFormGroup.value && this.accountFormGroup.dirty) {
            const params = Object.assign({}, this.appHelper.user, this.accountFormGroup.value);
            this.modal.close();
            this.spinnerService.show();
            this.settingsService.updateUser(this.appHelper.currentRestaurant.id, params)
                .subscribe((user) => {
                    this.spinnerService.hide();
                    if (user && user.id) {
                        this.appHelper.setUser(user);
                        this.toastService.showSuccess({
                            header: 'User Information',
                            body: 'Your Account information updated successfully.'
                        });
                    } else {
                        this.toastService.showError({
                            body: 'Something went wrong!',
                        });
                    }
                });
        }
    }

}
