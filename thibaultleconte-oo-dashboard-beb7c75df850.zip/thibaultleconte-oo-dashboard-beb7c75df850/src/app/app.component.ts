import { Component } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ChildActivationEnd, Router } from '@angular/router';
import { filter } from 'rxjs/operators';
import { NavService } from "@common/services/nav.service";

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
})
export class AppComponent {
    public hideNavbar: boolean = true;
    public classes: string;
    constructor(public router: Router, private titleService: Title, private navService: NavService) {
        this.router.events
            .pipe(filter(event => event instanceof ChildActivationEnd))
            .subscribe(event => {
                let snapshot = (event as ChildActivationEnd).snapshot;
                while (snapshot.firstChild !== null) {
                    snapshot = snapshot.firstChild;
                }
                this.hideNavbar = snapshot.data && snapshot.data.hideNavbar;
                this.classes = snapshot.data && snapshot.data.classes;
                this.titleService.setTitle(snapshot.data.title || 'OrderOut Dashboard');
            });

        this.navService.init();
    }
}
