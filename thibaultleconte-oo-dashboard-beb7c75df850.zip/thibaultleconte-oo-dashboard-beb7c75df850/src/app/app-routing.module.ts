import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '@auth0/auth0-angular';

import { SBRouteData } from '@modules/navigation/models';
import { AccountResolve, RestaurantResolve, OnboardingResolve, UserResolve } from '@common/resolvers';

const routes: Routes = [
    {
        path: '',
        pathMatch: 'full',
        redirectTo: 'dashboard',
    },

    {
        path: 'dashboard',
        canActivate: [AuthGuard],
        resolve: {
            user: UserResolve,
            account: AccountResolve,
            restaurants: RestaurantResolve
        },
        data: {
            classes: 'dashboard-page'
        } as SBRouteData,
        loadChildren: () =>
            import('modules/dashboard/dashboard-routing.module').then(
                m => m.DashboardRoutingModule
            ),
    },
    {
        path: 'orders',
        canActivate: [AuthGuard],
        resolve: {
            user: UserResolve,
            account: AccountResolve,
            restaurants: RestaurantResolve
        },
        data: {
            classes: 'orders-page'
        } as SBRouteData,
        loadChildren: () =>
            import('modules/order/order-routing.module').then(
                m => m.OrderRoutingModule
            ),
    },
    {
        path: 'settings',
        canActivate: [AuthGuard],
        resolve: {
            user: UserResolve,
            account: AccountResolve,
            restaurants: RestaurantResolve
        },
        data: {
            classes: 'settings-page'
        } as SBRouteData,
        loadChildren: () =>
            import('modules/settings/settings-routing.module').then(
                m => m.SettingsRoutingModule
            ),
    },
    {
        path: 'new',
        canActivate: [AuthGuard],
        resolve: {
            user: UserResolve
        },
        data: {
            hideNavbar: true,
            classes: 'new-page'
        } as SBRouteData,
        loadChildren: () =>
            import('modules/setup/setup-routing.module').then(
                m => m.SetupRoutingModule
            ),
    },
    {
        path: 'restaurant/:restaurantId/onboarding',
        resolve: {
            user: UserResolve,
            account: AccountResolve,
            restaurants: OnboardingResolve
        },
        data: {
            classes: 'onboarding-page'
        } as SBRouteData,
        loadChildren: () =>
            import('modules/onboarding/onboarding-routing.module').then(
                m => m.OnboardingRoutingModule
            ),
    },
    {
        path: 'callback/clover',
        data: {
            hideNavbar: true,
            classes: 'clover-callback-page'
        } as SBRouteData,
        loadChildren: () =>
            import('modules/clover-callback/clover-callback-routing.module').then(
                m => m.CloverCallbackRoutingModule
            ),
    },
    {
        path: 'tables',
        loadChildren: () =>
            import('modules/tables/tables-routing.module').then(m => m.TablesRoutingModule),
    },
    {
        path: 'version',
        loadChildren: () =>
            import('modules/app-common/app-common-routing.module').then(
                m => m.AppCommonRoutingModule
            ),
    },
    {
        path: 'error',
        loadChildren: () =>
            import('modules/error/error-routing.module').then(m => m.ErrorRoutingModule),
    },
    {
        path: '**',
        pathMatch: 'full',
        resolve: {
            user: UserResolve
        },
        data: {
            hideNavbar: true,
            classes: 'error-page'
        } as SBRouteData,
        loadChildren: () =>
            import('modules/error/error-routing.module').then(m => m.ErrorRoutingModule),
    },
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { scrollPositionRestoration: 'enabled' })],
    exports: [RouterModule],
})
export class AppRoutingModule { }
