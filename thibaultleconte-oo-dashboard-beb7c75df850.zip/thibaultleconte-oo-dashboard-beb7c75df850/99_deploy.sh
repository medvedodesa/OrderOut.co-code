#!/bin/sh
#
# thibault@orderout.co
#
# 02/26/2021
#

ng build --prod

gcloud config configurations activate orderout-dashboard

# Automatic - No confirmation
gcloud app deploy --quiet
